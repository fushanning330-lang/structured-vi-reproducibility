PLOS ONE Supporting Information - S2 File (V8.9.1)

Purpose
-------
This archive contains publication-facing derived numerical data, author-generated analysis/simulation source code, a standalone publication-output reproduction route, and the recovered frozen V3 G1 project source used for the fitting workflow. Raw FDA AEMS/FAERS extracts are not redistributed.

Frozen V3 G1 source release
---------------------------
G1_FROZEN_PROJECT_SOURCE contains the recovered frozen source tree needed to inspect the V3 G1 fitting workflow and its dependencies. The exact executed canary and remaining-matrix runners, V3 structured guide, probabilistic target, parameter-persistence module, reference-data loader, deterministic upstream generator, seed configuration, package source, frozen requirements, and related scripts/configuration are included. SOURCE_IDENTITY_MANIFEST.csv records SHA256 and size for every released source file, and verify_g1_source_hashes.py checks the eight key G1 source identities without running inference. Historical one-shot execution guards are preserved and should not be interpreted as an instruction to rerun consumed identities.

Standalone publication-output reproduction
-----------------------------------------
From the extracted S2 directory, run:

    python reproduce_plos_outputs.py --data-dir . --output-dir reproduced_outputs

Minimal dependencies for this publication-output route are listed in requirements.txt. It reads only the supplied derived CSVs and does not require raw regulatory extracts or historical fitted NPZ artifacts.

Output mapping
--------------
Table 1 -> V3_RUN_MATRIX.csv
Table 2 -> G2_* CSVs
Table 3 -> G3_* pairwise/block CSVs
Table 4 -> G3_COMPONENT_DECOMPOSITION_EXTENDED.csv
Table 5 -> V8_P4_VS_P1_DESCRIPTIVE_COMPARISON.csv
Fig 1 -> conceptual schematic; not numerically regenerated
Fig 2 -> conceptual schematic; not numerically regenerated
Fig 3 -> G2_FACTOR_PRINCIPAL_ANGLES.csv, G2_PROJECTION_DISTANCE.csv, G2_PROCRUSTES_COMPARISON.csv, G2_LOCATION_PAIRWISE.csv
Fig 4 -> G3_SIGMA_PAIRWISE.csv, G3_CORRELATION_CONSEQUENCE.csv, G3_SPECTRUM_CONSEQUENCE.csv
Fig 5 -> G3_COMPONENT_PAIRWISE.csv, G3_BLOCK_COVARIANCE_CONSEQUENCE.csv, G3_COMPONENT_DECOMPOSITION_EXTENDED.csv
S1 Fig -> V8_P4_VS_P1_DESCRIPTIVE_COMPARISON.csv
S2 Fig -> V8_CELL_SUMMARY_FLAT.csv
S3 Fig -> V8_P4_VS_P1_DESCRIPTIVE_COMPARISON.csv
S4 Fig -> G2_BLOCK_COVARIANCE_ALLOCATION.csv, G2_BLOCK_DELTA_ALLOCATION.csv, G2_DELTA_RHO_PAIRWISE.csv, G2_MARGINAL_SCALE_CV.csv
S5 Fig -> V8_CELL_SUMMARY_FLAT.csv
S6 Fig -> V8_CELL_SUMMARY_FLAT.csv


V8.9.1 matched-four sensitivity, code license, and content verification
-----------------------------------------------
POSTHOC_MATCHED_FOUR_SENSITIVITY_V8_9_1.csv reports a read-only, post hoc descriptive sensitivity that restricts P4 to the four optimizer seeds common to P1 (1001, 2002, 3003, 5005). It is derived only from the frozen G2/G3 pairwise CSVs and does not refit any application model or rerun simulation fits. Recompute it with:

    python reproduce_matched_four_sensitivity.py

LICENSE_CODE_MIT.txt applies the MIT License to author-generated code in this S2 archive. It does not alter terms applicable to third-party materials or raw FDA AEMS/FAERS source data, which are not redistributed.

Scientific scope
----------------
This source-recovery and packaging update does not alter the scientific model, variational architecture, run identities, simulation fits, tables, figures, or any frozen fitted value. V8.9.1 carries forward the read-only descriptive sensitivity computed from existing frozen pairwise CSVs and adds no new fit or simulation result. Pairwise observations reuse fitted runs and remain descriptive; no p-values or significance tests are generated. The synthetic benchmark remains a well-specified known-target calibration, not a model-misspecification test.

V8.9.1 public-repository scope
-------------------------------
At submission, the public GitHub repository contains the baseline reproduction archive. The V8.9.1 submission-specific matched-four files, MIT code license, and content-hash manifest are supplied in this S2 File; they are not represented as a separate public GitHub release.
