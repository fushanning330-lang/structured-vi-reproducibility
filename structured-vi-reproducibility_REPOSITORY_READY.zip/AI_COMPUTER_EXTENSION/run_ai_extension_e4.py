from pathlib import Path
import numpy as np, pandas as pd, math
from scipy.linalg import solve_triangular, eigvalsh
ROOT=Path('/mnt/data/PLOS_AI_EXTENSION'); OUT=ROOT/'results'; LOG2PI=math.log(2*math.pi)

def R(rho,m=11):
    i=np.arange(m); return rho**np.abs(i[:,None]-i[None,:])
def dense_cov(s,U,rho,n_non=158,m=11):
    d=len(s); npairs=(d-n_non)//m; B=np.zeros((d,d)); B[np.arange(n_non),np.arange(n_non)]=s[:n_non]**2; rr=R(rho,m)
    for p in range(npairs):
        a=n_non+p*m; b=a+m; sp=s[a:b]; B[a:b,a:b]=(sp[:,None]*rr)*sp[None,:]
    return B+U@U.T
def apply_r_inv(w,rho):
    out=np.empty_like(w); den=1-rho*rho
    out[...,0]=w[...,0]-rho*w[...,1]
    out[...,1:-1]=(1+rho*rho)*w[...,1:-1]-rho*(w[...,:-2]+w[...,2:])
    out[...,-1]=-rho*w[...,-2]+w[...,-1]
    return out/den
def binv(X,s,rho,n_non=158,m=11):
    vec=X.ndim==1; X=X[:,None] if vec else X; d,k=X.shape; npairs=(d-n_non)//m; out=np.empty_like(X)
    out[:n_non]=X[:n_non]/(s[:n_non,None]**2)
    t=X[n_non:].reshape(npairs,m,k); st=s[n_non:].reshape(npairs,m); w=t/st[:,:,None]; w=np.transpose(w,(0,2,1)); w=apply_r_inv(w,rho); w=np.transpose(w,(0,2,1))/st[:,:,None]; out[n_non:]=w.reshape(npairs*m,k)
    return out[:,0] if vec else out
def slogq(z,loc,s,U,rho):
    d=len(s); npairs=(d-158)//11; BIU=binv(U,s,rho); K=np.eye(U.shape[1])+U.T@BIU; Lk=np.linalg.cholesky(K); delta=z-loc; b=binv(delta,s,rho); v=U.T@b; y=solve_triangular(Lk,v,lower=True,check_finite=False); quad=delta@b-y@y; ldb=2*np.log(s).sum()+npairs*10*math.log(1-rho*rho); ldk=2*np.log(np.diag(Lk)).sum(); return -0.5*(d*LOG2PI+ldb+ldk+quad)
rows=[]
for sd in [0.0,0.5]:
  for rho in [0.0,0.3,0.6,0.9,0.97,0.99]:
    rng=np.random.default_rng(927451+int(sd*1000)+int(rho*10000)); d=708; s=np.exp(rng.normal(0,sd,size=d)); U=np.zeros((d,12)); groups=np.array_split(np.arange(158),3)
    for g,idx in enumerate(groups): U[np.ix_(idx,np.arange(g*4,(g+1)*4))]=rng.normal(0,0.035,size=(len(idx),4))
    loc=rng.normal(0,0.15,size=d); S=dense_cov(s,U,rho); L=np.linalg.cholesky(S); ev=eigvalsh(S,check_finite=False); cond=float(ev[-1]/ev[0]); errs=[]; nonfinite=0
    for j in range(10):
      z=rng.normal(size=d); a=slogq(z,loc,s,U,rho); delta=z-loc; y=solve_triangular(L,delta,lower=True,check_finite=False); b=-0.5*(d*LOG2PI+2*np.log(np.diag(L)).sum()+y@y)
      if not (np.isfinite(a) and np.isfinite(b)): nonfinite+=1
      else: errs.append(abs(a-b))
    rows.append({'rho':rho,'log_scale_sd':sd,'condition_number':cond,'n_draws':10,'nonfinite_count':nonfinite,'max_abs_logq_error':max(errs) if errs else np.nan,'mean_abs_logq_error':float(np.mean(errs)) if errs else np.nan})
df=pd.DataFrame(rows); df.to_csv(OUT/'E4_NUMERICAL_CONDITIONING_STRESS.csv',index=False); print(df.to_string(index=False))
