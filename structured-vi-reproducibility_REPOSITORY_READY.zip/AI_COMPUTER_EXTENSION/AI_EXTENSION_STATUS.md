# PLOS ONE AI/Computer Extension — Experimental Status

Parent manuscript: V8.7.8 FINAL AUDITED SUBMISSION (immutable parent)

New experiments completed without rerunning application G1 or the original 239 simulation fits:
- E1: scalability / sample+logq kernel benchmark
- E2: covariance-structure representational ablation
- E3: rank-capacity ablation
- E4: numerical-conditioning stress benchmark at d=708

Interpretation boundaries:
- E1 is a computational kernel benchmark, not end-to-end pharmacovigilance runtime.
- E2/E3 are controlled known-target representational ablations; the matched family/rank is in-family by construction.
- E4 is numerical-kernel stress testing, not model-misspecification or pharmacovigilance accuracy testing.
- No p-values or inferential confidence intervals were added.
