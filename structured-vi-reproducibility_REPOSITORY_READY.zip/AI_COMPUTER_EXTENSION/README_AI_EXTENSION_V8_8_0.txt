AI/COMPUTER EXTENSION FOR V8.8.0

This directory is additive to the immutable V8.7.8 S2 release. No parent application G1 fit or original 239 Module B fit was rerun.

E1: structured-vs-dense sample+logq kernel scaling benchmark.
E2: deterministic covariance-structure ablation on six known targets.
E3: deterministic rank-capacity truncation ablation.
E4: d=708 numerical-conditioning stress benchmark.

Publication mapping:
- Fig 6 panels A-B: results/E1_SCALABILITY_BENCHMARK.csv
- Fig 6 panel C: results/E2_STRUCTURAL_ABLATION_SUMMARY.csv
- Fig 6 panel D: results/E3_RANK_CAPACITY_SUMMARY.csv
- Table 6: results/E4_NUMERICAL_CONDITIONING_STRESS.csv and TABLE6_SOURCE_DATA.csv

Interpretation guards are recorded in AI_COMPUTER_EXTENSION_PROTOCOL_FREEZE_V3.json and AI_EXTENSION_STATUS.md.
