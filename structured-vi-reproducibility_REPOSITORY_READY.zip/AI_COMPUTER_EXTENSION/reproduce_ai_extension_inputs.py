from pathlib import Path
import pandas as pd
# This script intentionally consumes frozen derived CSVs only; it does not refit the application or original simulations.
ROOT=Path(__file__).resolve().parent
E1=pd.read_csv(ROOT/"results/E1_SCALABILITY_BENCHMARK.csv")
E2=pd.read_csv(ROOT/"results/E2_STRUCTURAL_ABLATION_SUMMARY.csv")
E3=pd.read_csv(ROOT/"results/E3_RANK_CAPACITY_SUMMARY.csv")
E4=pd.read_csv(ROOT/"results/E4_NUMERICAL_CONDITIONING_STRESS.csv")
print("Frozen extension inputs loaded:", len(E1), len(E2), len(E3), len(E4))
print("Fig 6 source: E1/E2/E3; Table 6 source: E4")
