from pathlib import Path
import importlib.util, numpy as np, pandas as pd
from scipy.linalg import solve_triangular
ROOT=Path('/mnt/data/PLOS_AI_EXTENSION'); OUT=ROOT/'results'
p=ROOT/'S2'/'Q2_simulation_target_generator_V4.py'
spec=importlib.util.spec_from_file_location('tg',p); tg=importlib.util.module_from_spec(spec); spec.loader.exec_module(tg)

def corr_from_cov(S):
    sd=np.sqrt(np.diag(S)); return S/(sd[:,None]*sd[None,:])
def reverse_kl(q,p):
    d=p.shape[0]
    Lp=np.linalg.cholesky(p); Lq=np.linalg.cholesky(q)
    X=solve_triangular(Lp,q,lower=True,check_finite=False)
    PinvQ=solve_triangular(Lp.T,X,lower=False,check_finite=False)
    tr=float(np.trace(PinvQ))
    ldp=2*np.log(np.diag(Lp)).sum(); ldq=2*np.log(np.diag(Lq)).sum()
    return 0.5*(tr-d+ldp-ldq)
def metrics(q,p):
    kl=reverse_kl(q,p)
    rel=float(np.linalg.norm(q-p,'fro')/np.linalg.norm(p,'fro'))
    cq=corr_from_cov(q); cp=corr_from_cov(p); iu=np.triu_indices_from(cp,k=1)
    crmse=float(np.sqrt(np.mean((cq[iu]-cp[iu])**2)))
    return kl,rel,crmse
rows=[]
for tid,(cond,share) in tg.TARGET_MAP.items():
    t=tg.make_target(cond,share,tg.TARGET_SEEDS[tid]); B=t['B_star']; U=t['U_star']; P=t['Sigma_star']
    # singular values are equal in construction but SVD gives a deterministic orthogonal ordering
    uu,ss,vh=np.linalg.svd(U,full_matrices=False)
    for r in [0,1,2,3,4]:
        Ur=(uu[:,:r]*ss[:r])@vh[:r,:] if r>0 else np.zeros_like(U)
        Q=B+Ur@Ur.T
        kl,rel,crmse=metrics(Q,P)
        rows.append({'target_id':tid,'conditioning':cond,'trace_share_target':share,'retained_rank':r,
                     'reverse_KL_q_to_p':kl,'covariance_relative_frobenius':rel,'correlation_RMSE':crmse,
                     'target_condition_number':t['cond_number']})
df=pd.DataFrame(rows)
df.to_csv(OUT/'E3_RANK_CAPACITY_TARGETWISE.csv',index=False)
s=(df.groupby('retained_rank').agg(n_targets=('target_id','count'),mean_reverse_KL=('reverse_KL_q_to_p','mean'),median_reverse_KL=('reverse_KL_q_to_p','median'),max_reverse_KL=('reverse_KL_q_to_p','max'),mean_cov_relF=('covariance_relative_frobenius','mean'),mean_corr_RMSE=('correlation_RMSE','mean')).reset_index())
s.to_csv(OUT/'E3_RANK_CAPACITY_SUMMARY.csv',index=False)
print(s.to_string(index=False))
