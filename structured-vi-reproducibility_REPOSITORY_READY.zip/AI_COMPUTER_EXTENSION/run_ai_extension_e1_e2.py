from __future__ import annotations
import json, math, os, platform, time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.linalg import solve_triangular

ROOT = Path('/mnt/data/PLOS_AI_EXTENSION')
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
SEED = 918273
RNG = np.random.default_rng(SEED)
LOG2PI = math.log(2*math.pi)

# ----------------------- structured covariance helpers -----------------------
def make_v3_like_params(n_pairs: int, block_len: int=11, rank_total: int=12, rho: float=0.6, seed: int=0):
    rng = np.random.default_rng(seed)
    n_non = int(round(3.16*n_pairs))
    d = n_non + n_pairs*block_len
    # positive scales around 1, moderate heterogeneity
    log_s = rng.normal(0.0, 0.18, size=d)
    s = np.exp(log_s)
    # V3-like local factor support: only non-temporal coordinates; total rank 12.
    U = np.zeros((d, rank_total), dtype=np.float64)
    # split non-temporal coordinates into 3 semantic groups, each rank 4
    groups = np.array_split(np.arange(n_non), 3)
    for g, idx in enumerate(groups):
        cols = slice(g*4, (g+1)*4)
        U[np.ix_(idx, np.arange(g*4, (g+1)*4))] = rng.normal(0, 0.035, size=(len(idx),4))
    loc = rng.normal(0, 0.15, size=d)
    return d, n_non, s, U, loc

def temporal_R(rho: float, m: int=11):
    idx=np.arange(m)
    return rho ** np.abs(idx[:,None]-idx[None,:])

def dense_cov(s, U, rho, n_non, block_len=11):
    d=len(s); n_pairs=(d-n_non)//block_len
    B=np.zeros((d,d),dtype=np.float64)
    B[np.arange(n_non),np.arange(n_non)] = s[:n_non]**2
    R=temporal_R(rho,block_len)
    for p in range(n_pairs):
        a=n_non+p*block_len; b=a+block_len
        sp=s[a:b]
        B[a:b,a:b]=(sp[:,None]*R)*sp[None,:]
    return B + U@U.T

def apply_r_inv(w, rho):
    # w (..., block_len)
    out=np.empty_like(w)
    denom=1-rho*rho
    out[...,0]=w[...,0]-rho*w[...,1]
    out[...,1:-1]=(1+rho*rho)*w[...,1:-1]-rho*(w[...,:-2]+w[...,2:])
    out[...,-1]=-rho*w[...,-2]+w[...,-1]
    return out/denom

def b_inv_apply(X, s, rho, n_non, block_len=11):
    # X shape (d,) or (d,k)
    X=np.asarray(X)
    vec = X.ndim==1
    if vec: X2=X[:,None]
    else: X2=X
    d,k=X2.shape; n_pairs=(d-n_non)//block_len
    out=np.empty_like(X2)
    out[:n_non,:]=X2[:n_non,:]/(s[:n_non,None]**2)
    temp=X2[n_non:,:].reshape(n_pairs,block_len,k)
    st=s[n_non:].reshape(n_pairs,block_len)
    w=temp/st[:,:,None]
    # transpose to (..., block_len) for helper
    w2=np.transpose(w,(0,2,1))
    w2=apply_r_inv(w2,rho)
    w=np.transpose(w2,(0,2,1))/st[:,:,None]
    out[n_non:,:]=w.reshape(n_pairs*block_len,k)
    return out[:,0] if vec else out

def structured_logpdf(z,loc,s,U,rho,n_non,block_len=11):
    d=len(s); n_pairs=(d-n_non)//block_len
    BinvU=b_inv_apply(U,s,rho,n_non,block_len)
    K=np.eye(U.shape[1])+U.T@BinvU
    Lk=np.linalg.cholesky(K)
    delta=z-loc
    b=b_inv_apply(delta,s,rho,n_non,block_len)
    v=U.T@b
    y=solve_triangular(Lk,v,lower=True,check_finite=False)
    quad=float(delta@b-y@y)
    logdetB=2*np.log(s).sum()+n_pairs*(block_len-1)*math.log(1-rho*rho)
    logdetK=2*np.log(np.diag(Lk)).sum()
    return -0.5*(d*LOG2PI+logdetB+logdetK+quad)

def structured_sample_and_logq(eps_non, eta, eps_u, loc,s,U,rho,n_non,block_len=11):
    d=len(s); n_pairs=(d-n_non)//block_len
    sqrt1=math.sqrt(1-rho*rho)
    y=np.empty_like(eta)
    y[:,0]=eta[:,0]
    for t in range(1,block_len):
        y[:,t]=rho*y[:,t-1]+sqrt1*eta[:,t]
    r_non=s[:n_non]*eps_non
    r_temp=(s[n_non:].reshape(n_pairs,block_len)*y).reshape(-1)
    z=loc+np.concatenate([r_non,r_temp])+U@eps_u
    return structured_logpdf(z,loc,s,U,rho,n_non,block_len)

def dense_sample_and_logq(eps, loc, L):
    z=loc+L@eps
    delta=z-loc
    y=solve_triangular(L,delta,lower=True,check_finite=False)
    d=len(loc)
    return -0.5*(d*LOG2PI+2*np.log(np.diag(L)).sum()+float(y@y))

# ---------------------------- E1 scaling benchmark --------------------------
rows=[]; eq_rows=[]
for n_pairs in [5,10,25,50,75,100]:
    d,n_non,s,U,loc=make_v3_like_params(n_pairs,seed=SEED+n_pairs)
    rho=0.6; block_len=11
    S=dense_cov(s,U,rho,n_non,block_len)
    L=np.linalg.cholesky(S)
    rng=np.random.default_rng(SEED+1000+n_pairs)
    # equivalence on 5 direct samples
    abs_err=[]
    for _ in range(5):
        z=rng.normal(size=d)
        a=structured_logpdf(z,loc,s,U,rho,n_non,block_len)
        delta=z-loc
        y=solve_triangular(L,delta,lower=True,check_finite=False)
        b=-0.5*(d*LOG2PI+2*np.log(np.diag(L)).sum()+float(y@y))
        abs_err.append(abs(a-b))
    eq_rows.append({'n_pairs':n_pairs,'d':d,'max_abs_logq_error':max(abs_err),'mean_abs_logq_error':float(np.mean(abs_err))})

    # deterministic random variates reused each repetition type
    eps_non=rng.normal(size=n_non)
    eta=rng.normal(size=(n_pairs,block_len))
    eps_u=rng.normal(size=U.shape[1])
    eps_dense=rng.normal(size=d)

    # warmup
    for _ in range(5):
        structured_sample_and_logq(eps_non,eta,eps_u,loc,s,U,rho,n_non,block_len)
        dense_sample_and_logq(eps_dense,loc,L)

    ts=[]; td=[]
    for _ in range(30):
        t0=time.perf_counter_ns(); structured_sample_and_logq(eps_non,eta,eps_u,loc,s,U,rho,n_non,block_len); t1=time.perf_counter_ns(); ts.append((t1-t0)/1e6)
        t0=time.perf_counter_ns(); dense_sample_and_logq(eps_dense,loc,L); t1=time.perf_counter_ns(); td.append((t1-t0)/1e6)

    # guide parameter counts: loc + diag log scale + three rank-4 local factors + rho
    local_factor_params=n_non*4
    structured_total=2*d+local_factor_params+1
    fullrank_total=d + d*(d+1)//2
    meanfield_total=2*d
    # parameter bytes float64
    rows.append({
        'n_pairs':n_pairs,'latent_dim':d,'non_temporal_dim':n_non,
        'structured_rank_total':12,
        'structured_total_parameters':structured_total,
        'fullrank_total_parameters':fullrank_total,
        'meanfield_total_parameters':meanfield_total,
        'fullrank_to_structured_parameter_ratio':fullrank_total/structured_total,
        'structured_parameter_MB':structured_total*8/1024**2,
        'fullrank_parameter_MB':fullrank_total*8/1024**2,
        'structured_sample_logq_median_ms':float(np.median(ts)),
        'structured_sample_logq_min_ms':float(np.min(ts)),
        'structured_sample_logq_max_ms':float(np.max(ts)),
        'fullrank_sample_logq_median_ms':float(np.median(td)),
        'fullrank_sample_logq_min_ms':float(np.min(td)),
        'fullrank_sample_logq_max_ms':float(np.max(td)),
        'fullrank_to_structured_runtime_ratio':float(np.median(td)/np.median(ts)),
    })

pd.DataFrame(rows).to_csv(OUT/'E1_SCALABILITY_BENCHMARK.csv',index=False)
pd.DataFrame(eq_rows).to_csv(OUT/'E1_NUMERICAL_EQUIVALENCE.csv',index=False)

# --------------------------- E2 structural ablation --------------------------
import importlib.util
p=ROOT/'S2'/'Q2_simulation_target_generator_V4.py'
spec=importlib.util.spec_from_file_location('tg',p); tg=importlib.util.module_from_spec(spec); spec.loader.exec_module(tg)

def corr_from_cov(S):
    sd=np.sqrt(np.diag(S)); return S/(sd[:,None]*sd[None,:])

def reverse_kl(q,p):
    d=p.shape[0]
    Lp=np.linalg.cholesky(p); Lq=np.linalg.cholesky(q)
    # tr(P^-1 Q)
    X=solve_triangular(Lp,q,lower=True,check_finite=False)
    PinvQ=solve_triangular(Lp.T,X,lower=False,check_finite=False)
    tr=float(np.trace(PinvQ))
    ldp=2*np.log(np.diag(Lp)).sum(); ldq=2*np.log(np.diag(Lq)).sum()
    return 0.5*(tr-d+ldp-ldq)

def mf_reverse_opt(p):
    # q diagonal optimum for KL(q||p): q_ii = 1/(P^-1)_ii
    Prec=np.linalg.inv(p)
    v=1/np.diag(Prec)
    return np.diag(v)

def metrics(q,p):
    kl=reverse_kl(q,p)
    rel=float(np.linalg.norm(q-p,'fro')/np.linalg.norm(p,'fro'))
    cq=corr_from_cov(q); cp=corr_from_cov(p)
    iu=np.triu_indices_from(cp,k=1)
    crmse=float(np.sqrt(np.mean((cq[iu]-cp[iu])**2)))
    return kl,rel,crmse

ab=[]
for tid,(cond,share) in tg.TARGET_MAP.items():
    target=tg.make_target(cond,share,tg.TARGET_SEEDS[tid])
    B=target['B_star']; U=target['U_star']; P=target['Sigma_star']
    families={
        'FULL_STRUCTURED_MATCHED':P.copy(),
        'NO_LOW_RANK':B.copy(),
        'NO_AR1':np.diag(np.diag(B))+U@U.T,
        'MEAN_FIELD_REVERSE_KL_OPT':mf_reverse_opt(P),
    }
    for fam,Q in families.items():
        kl,rel,crmse=metrics(Q,P)
        ab.append({'target_id':tid,'conditioning':cond,'trace_share_target':share,'family':fam,
                   'reverse_KL_q_to_p':kl,'covariance_relative_frobenius':rel,'correlation_RMSE':crmse,
                   'target_condition_number':target['cond_number']})

dfab=pd.DataFrame(ab)
dfab.to_csv(OUT/'E2_STRUCTURAL_ABLATION_TARGETWISE.csv',index=False)
summary=(dfab.groupby('family').agg(
    n_targets=('target_id','count'),
    mean_reverse_KL=('reverse_KL_q_to_p','mean'),
    median_reverse_KL=('reverse_KL_q_to_p','median'),
    max_reverse_KL=('reverse_KL_q_to_p','max'),
    mean_cov_relF=('covariance_relative_frobenius','mean'),
    mean_corr_RMSE=('correlation_RMSE','mean')
).reset_index())
summary.to_csv(OUT/'E2_STRUCTURAL_ABLATION_SUMMARY.csv',index=False)

# environment + run manifest
manifest={
 'protocol_sha256':'4ea7f0dd319033b885098945a2dc4b30202a207cb35786b49dfaf169f45d1b9e',
 'executed_at_utc':pd.Timestamp.utcnow().isoformat(),
 'python':platform.python_version(), 'platform':platform.platform(),
 'numpy':np.__version__, 'pandas':pd.__version__,
 'thread_env':{k:os.environ.get(k) for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']},
 'outputs':['E1_SCALABILITY_BENCHMARK.csv','E1_NUMERICAL_EQUIVALENCE.csv','E2_STRUCTURAL_ABLATION_TARGETWISE.csv','E2_STRUCTURAL_ABLATION_SUMMARY.csv']
}
(OUT/'AI_EXTENSION_E1_E2_RUN_MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('E1')
print(pd.DataFrame(rows).to_string(index=False))
print('\nEQUIV')
print(pd.DataFrame(eq_rows).to_string(index=False))
print('\nE2 summary')
print(summary.to_string(index=False))
