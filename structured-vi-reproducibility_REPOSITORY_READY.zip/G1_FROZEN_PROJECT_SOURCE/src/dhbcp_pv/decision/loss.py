from __future__ import annotations
import numpy as np

def expected_loss_priority(
    p_dangerous: np.ndarray,
    p_serious: np.ndarray,
    fn_cost: float = 5.0,
    fp_cost: float = 1.0,
    lambda_severity: float = 1.0,
) -> np.ndarray:
    p_dangerous = np.asarray(p_dangerous, dtype=float)
    p_serious = np.asarray(p_serious, dtype=float)
    miss_cost = fn_cost * (1.0 + lambda_severity * p_serious)
    loss_defer = p_dangerous * miss_cost
    loss_investigate = (1.0 - p_dangerous) * fp_cost
    return loss_defer - loss_investigate
