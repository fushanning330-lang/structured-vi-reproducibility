"""Operational state, temporal, discrimination and ranking metrics."""

from __future__ import annotations

import numpy as np
from sklearn.metrics import average_precision_score, f1_score, roc_auc_score


STATE_TO_ID = {"Background": 0, "Emerging": 1, "Persistent": 2, "Waning": 3}


def discrimination_metrics(truth: np.ndarray, score: np.ndarray) -> dict[str, float]:
    truth = np.asarray(truth, dtype=bool)
    score = np.asarray(score, dtype=float)
    if truth.all() or (~truth).all():
        return {"auprc": float(truth.mean()), "auroc": 0.5}
    return {
        "auprc": float(average_precision_score(truth, score)),
        "auroc": float(roc_auc_score(truth, score)),
    }


def state_metrics(
    true_state: np.ndarray,
    true_x: np.ndarray,
    state_probability: np.ndarray,
    x_mean: np.ndarray,
    x_sd: np.ndarray,
    p_persist: np.ndarray,
    p_change: np.ndarray,
    pair_index: np.ndarray,
    true_change_quarter: np.ndarray,
) -> dict[str, float]:
    true_id = np.array([STATE_TO_ID[str(value)] for value in true_state])
    predicted = np.argmax(state_probability, axis=1)
    persistent_truth = true_id == 2
    change_errors: list[float] = []
    for pair in np.unique(pair_index):
        mask = pair_index == pair
        change = int(true_change_quarter[mask][0])
        if change > 0:
            predicted_change = int(np.arange(1, mask.sum() + 1)[np.argmax(p_change[mask])])
            change_errors.append(abs(predicted_change - change))
    coverage = np.mean((true_x >= x_mean - 1.96 * x_sd) & (true_x <= x_mean + 1.96 * x_sd))
    return {
        "macro_f1": float(f1_score(true_id, predicted, labels=[0, 1, 2, 3], average="macro", zero_division=0)),
        "change_mae": float(np.mean(change_errors)) if change_errors else 0.0,
        "persistence_brier": float(np.mean((p_persist - persistent_truth) ** 2)),
        "x_rmse": float(np.sqrt(np.mean((x_mean - true_x) ** 2))),
        "x_interval_coverage": float(coverage),
    }


def temporal_metrics(
    alert: np.ndarray,
    pair_index: np.ndarray,
    quarter: np.ndarray,
    true_change_quarter: np.ndarray,
) -> dict[str, float]:
    delays: list[float] = []
    within = {1: [], 2: [], 4: []}
    prechange: list[float] = []
    for pair in np.unique(pair_index):
        mask = pair_index == pair
        pair_alert = alert[mask]
        pair_quarter = quarter[mask]
        change = int(true_change_quarter[mask][0])
        if change > 0:
            post = pair_quarter[pair_alert & (pair_quarter >= change)]
            if len(post):
                delay = int(post[0] - change)
                delays.append(float(delay))
            else:
                delay = 10_000
            for horizon in within:
                within[horizon].append(float(delay <= horizon))
            prechange.append(float(np.any(pair_alert & (pair_quarter < change))))
        else:
            prechange.append(float(np.any(pair_alert)))
    return {
        "median_detection_delay": float(np.median(delays)) if delays else 40.0,
        "detected_within_1q": float(np.mean(within[1])) if within[1] else 0.0,
        "detected_within_2q": float(np.mean(within[2])) if within[2] else 0.0,
        "detected_within_4q": float(np.mean(within[4])) if within[4] else 0.0,
        "prechange_false_alert": float(np.mean(prechange)) if prechange else 0.0,
    }


def ranking_metrics(
    truth: np.ndarray,
    score: np.ndarray,
    alert: np.ndarray,
    pair_index: np.ndarray,
    quarter: np.ndarray,
    *,
    k: int = 2,
) -> dict[str, float]:
    precisions: list[float] = []
    recalls: list[float] = []
    ndcgs: list[float] = []
    top_sets: list[set[int]] = []
    for time in np.unique(quarter):
        mask = quarter == time
        order = np.argsort(-score[mask], kind="stable")[:k]
        local_truth = truth[mask]
        hits = local_truth[order].astype(float)
        precisions.append(float(hits.mean()))
        recalls.append(float(hits.sum() / max(local_truth.sum(), 1)))
        discounts = 1.0 / np.log2(np.arange(2, len(hits) + 2))
        dcg = float(np.sum(hits * discounts))
        ideal_hits = np.sort(local_truth.astype(float))[::-1][:k]
        idcg = float(np.sum(ideal_hits * discounts))
        ndcgs.append(dcg / idcg if idcg > 0 else 0.0)
        top_sets.append(set(pair_index[mask][order].tolist()))
    jaccard = []
    for previous, current in zip(top_sets[:-1], top_sets[1:]):
        jaccard.append(len(previous & current) / max(len(previous | current), 1))
    return {
        "precision_at_k": float(np.mean(precisions)),
        "recall_at_k": float(np.mean(recalls)),
        "ndcg_at_k": float(np.mean(ndcgs)),
        "alerts_per_10000": float(np.mean(alert) * 10_000.0),
        "topk_jaccard": float(np.mean(jaccard)) if jaccard else 1.0,
    }

