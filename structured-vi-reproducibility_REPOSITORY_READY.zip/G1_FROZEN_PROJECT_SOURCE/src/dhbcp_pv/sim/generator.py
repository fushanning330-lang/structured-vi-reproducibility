from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd

STATE_NAMES = np.array(["Background", "Emerging", "Persistent", "Waning"], dtype=object)
PHASE2_SCENARIOS = (
    "null_no_signal",
    "abrupt_emergence",
    "gradual_emergence",
    "transient_spike",
    "persistent_signal",
    "waning_signal",
    "sparse_low_count",
    "overdispersed_counts",
    "low_frequency_high_seriousness",
)

@dataclass(frozen=True)
class SimConfig:
    n_pairs: int = 64
    n_quarters: int = 40
    seed: int = 104729
    h_max: int = 12
    phi: float = 10.0
    base_serious_prob: float = 0.08


@dataclass(frozen=True)
class ScenarioConfig:
    scenario: str
    n_pairs: int = 20
    n_quarters: int = 40
    replicates: int = 3
    seeds: tuple[int, ...] = (104729, 130363, 155921, 196613)

def _sample_duration(rng: np.random.Generator, state: int, h_max: int) -> int:
    # Engineering generator only: explicit-duration state process.
    # Durations approximate a truncated negative-binomial family.
    means = [6.0, 2.0, 5.0, 3.0]
    mean = means[state]
    p = 2.0 / (2.0 + mean)
    d = 1 + rng.negative_binomial(2, p)
    return int(np.clip(d, 1, h_max))

def _next_state(rng: np.random.Generator, state: int) -> int:
    probs = {
        0: np.array([0.75, 0.25, 0.00, 0.00]),
        1: np.array([0.05, 0.10, 0.70, 0.15]),
        2: np.array([0.05, 0.00, 0.80, 0.15]),
        3: np.array([0.70, 0.05, 0.05, 0.20]),
    }[state]
    return int(rng.choice(4, p=probs))

def _state_sequence(rng: np.random.Generator, T: int, h_max: int, force_signal: bool) -> np.ndarray:
    z = np.zeros(T, dtype=int)
    t = 0
    state = 0
    forced_at = int(rng.integers(max(4, T//5), max(5, 3*T//5))) if force_signal else T + 1
    while t < T:
        if force_signal and state == 0 and t >= forced_at:
            state = 1
        d = min(_sample_duration(rng, state, h_max), T - t)
        z[t:t+d] = state
        t += d
        if t < T:
            state = _next_state(rng, state)
    return z

def simulate_panel(cfg: SimConfig = SimConfig()) -> pd.DataFrame:
    rng = np.random.default_rng(cfg.seed)
    rows = []
    drift = np.array([0.0, 0.22, 0.02, -0.18])
    state_serious = np.array([0.0, 0.10, 0.35, 0.15])

    drug_eff = rng.normal(0, 0.18, cfg.n_pairs)
    event_eff = rng.normal(0, 0.18, cfg.n_pairs)
    pair_eff = rng.normal(0, 0.28, cfg.n_pairs)

    for i in range(cfg.n_pairs):
        force_signal = i >= cfg.n_pairs // 2
        z = _state_sequence(rng, cfg.n_quarters, cfg.h_max, force_signal)
        x = np.zeros(cfg.n_quarters)
        for t in range(1, cfg.n_quarters):
            x[t] = x[t-1] + drift[z[t]] + rng.normal(0, 0.08)

        expected = np.exp(rng.normal(np.log(2.0), 0.9, cfg.n_quarters))
        eta = drug_eff[i] + event_eff[i] + pair_eff[i] + x
        mean = expected * np.exp(eta)

        # NumPy NB parameterization: mean = n*(1-p)/p; n=phi.
        p_nb = cfg.phi / (cfg.phi + mean)
        y = rng.negative_binomial(cfg.phi, p_nb)

        logit_base = np.log(cfg.base_serious_prob / (1 - cfg.base_serious_prob))
        logits = logit_base + state_serious[z] + 0.55 * np.maximum(x, 0)
        pi = 1 / (1 + np.exp(-logits))
        s = rng.binomial(y, pi)

        for t in range(cfg.n_quarters):
            rows.append({
                "pair_id": f"P{i:04d}",
                "quarter_index": t,
                "state_id": int(z[t]),
                "state": str(STATE_NAMES[z[t]]),
                "latent_x": float(x[t]),
                "m_expected": float(expected[t]),
                "mean_reports": float(mean[t]),
                "y_reports": int(y[t]),
                "s_serious": int(s[t]),
                "serious_prob": float(pi[t]),
                "forced_signal_pair": bool(force_signal),
            })
    return pd.DataFrame(rows)


def _scenario_truth(scenario: str, n_quarters: int, pair_index: int) -> dict[str, np.ndarray | int | bool]:
    if scenario not in PHASE2_SCENARIOS:
        raise ValueError(f"Unknown Phase 2 scenario: {scenario}")
    change = 10 + pair_index % 7
    log_rr = np.zeros(n_quarters, dtype=float)
    state = np.full(n_quarters, "Background", dtype=object)
    serious = np.full(n_quarters, 0.08, dtype=float)
    persistence = 0
    is_signal = scenario != "null_no_signal"

    if scenario == "abrupt_emergence":
        log_rr[change:] = 0.9
        state[change] = "Emerging"
        state[change + 1 :] = "Persistent"
        persistence = n_quarters - change
    elif scenario == "gradual_emergence":
        duration = min(8, n_quarters - change)
        log_rr[change : change + duration] = np.linspace(0.12, 0.9, duration)
        log_rr[change + duration :] = 0.9
        state[change : change + duration] = "Emerging"
        state[change + duration :] = "Persistent"
        persistence = n_quarters - change
    elif scenario == "transient_spike":
        duration = min(3, n_quarters - change)
        log_rr[change : change + duration] = 1.25
        state[change] = "Emerging"
        state[change + 1 : change + duration] = "Persistent"
        state[change + duration : min(change + duration + 2, n_quarters)] = "Waning"
        persistence = duration
    elif scenario in {"persistent_signal", "sparse_low_count", "overdispersed_counts", "low_frequency_high_seriousness"}:
        effect = 0.75 if scenario == "persistent_signal" else 1.0
        log_rr[change:] = effect
        state[change] = "Emerging"
        state[change + 1 :] = "Persistent"
        persistence = n_quarters - change
    elif scenario == "waning_signal":
        duration = min(8, n_quarters - change)
        log_rr[change : change + duration] = 1.0
        tail = n_quarters - change - duration
        if tail > 0:
            log_rr[change + duration :] = np.linspace(0.9, 0.0, tail)
        state[change] = "Emerging"
        state[change + 1 : change + duration] = "Persistent"
        state[change + duration :] = "Waning"
        persistence = duration
    if scenario == "low_frequency_high_seriousness":
        serious[change:] = 0.50
    else:
        serious += 0.08 * (log_rr > 0)
    return {
        "true_log_rr": log_rr,
        "true_state": state,
        "true_serious_probability": serious,
        "true_change_quarter": change if is_signal else -1,
        "true_persistence_duration": persistence,
        "is_true_signal": is_signal,
    }


def simulate_scenario(config: ScenarioConfig) -> pd.DataFrame:
    """Generate a deterministic Phase 2 pilot scenario with explicit truth metadata."""
    rows: list[dict[str, object]] = []
    scenario_index = PHASE2_SCENARIOS.index(config.scenario)
    for replicate in range(config.replicates):
        seed = config.seeds[replicate % len(config.seeds)] + scenario_index * 1009
        rng = np.random.default_rng(seed)
        for pair_index in range(config.n_pairs):
            truth = _scenario_truth(config.scenario, config.n_quarters, pair_index)
            if config.scenario in {"sparse_low_count", "low_frequency_high_seriousness"}:
                expected = rng.lognormal(np.log(0.18), 0.35, config.n_quarters)
            else:
                expected = rng.lognormal(np.log(2.0), 0.55, config.n_quarters)
            phi = 1.5 if config.scenario == "overdispersed_counts" else 10.0
            pair_effect = rng.normal(0.0, 0.18)
            mean = expected * np.exp(pair_effect + truth["true_log_rr"])
            probability = phi / (phi + mean)
            y = rng.negative_binomial(phi, probability)
            s = rng.binomial(y, truth["true_serious_probability"])
            for quarter_index in range(config.n_quarters):
                rows.append(
                    {
                        "scenario": config.scenario,
                        "replicate": replicate,
                        "seed": seed,
                        "pair_id": f"{config.scenario}::P{pair_index:03d}",
                        "quarter_index": quarter_index,
                        "m_expected": float(expected[quarter_index]),
                        "mean_reports": float(mean[quarter_index]),
                        "dispersion_phi": phi,
                        "y_reports": int(y[quarter_index]),
                        "s_serious": int(s[quarter_index]),
                        "true_state": str(truth["true_state"][quarter_index]),
                        "true_change_quarter": int(truth["true_change_quarter"]),
                        "true_persistence_duration": int(truth["true_persistence_duration"]),
                        "true_log_rr": float(truth["true_log_rr"][quarter_index]),
                        "true_serious_probability": float(truth["true_serious_probability"][quarter_index]),
                        "is_true_signal": bool(truth["is_true_signal"]),
                        "result_scope": "ENGINEERING_PILOT_NOT_FORMAL",
                    }
                )
    return pd.DataFrame(rows)


def run_phase2_pilot_suite() -> pd.DataFrame:
    return pd.concat(
        [simulate_scenario(ScenarioConfig(scenario=scenario)) for scenario in PHASE2_SCENARIOS],
        ignore_index=True,
    )
