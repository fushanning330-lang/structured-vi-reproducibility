"""Cross-classified 18-drug x 9-event Phase 3B simulation generator."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from dhbcp_pv.sim.formal_phase3 import SCENARIOS, STATE_NAMES, _truth_path


@dataclass(frozen=True)
class HierarchicalReplicate:
    tier: str
    y: np.ndarray
    serious: np.ndarray
    expected: np.ndarray
    drug_index: np.ndarray
    event_index: np.ndarray
    pair_id: np.ndarray
    scenario: np.ndarray
    oa_row: np.ndarray
    true_state_id: np.ndarray
    true_state: np.ndarray
    true_x: np.ndarray
    true_serious_probability: np.ndarray
    true_change_quarter: np.ndarray
    true_persistence_duration: np.ndarray
    is_true_signal: np.ndarray
    truth: dict[str, np.ndarray | float]


def cross_classified_design() -> dict[str, np.ndarray]:
    drug_index = np.repeat(np.arange(18), 9)
    event_index = np.tile(np.arange(9), 18)
    scenario_index = (drug_index + event_index) % 9
    oa_row = ((drug_index + 2 * event_index) % 18) + 1
    return {
        "drug_index": drug_index,
        "event_index": event_index,
        "scenario_index": scenario_index,
        "scenario": np.asarray(SCENARIOS, dtype=object)[scenario_index],
        "oa_row": oa_row,
        "pair_id": np.asarray(
            [f"D{drug + 1:02d}::E{event + 1:02d}" for drug, event in zip(drug_index, event_index)],
            dtype=object,
        ),
    }


def validate_cross_classification() -> dict[str, bool | int]:
    design = cross_classified_design()
    drug = design["drug_index"]
    event = design["event_index"]
    scenario = design["scenario_index"]
    oa = design["oa_row"]
    return {
        "pairs": len(drug),
        "unique_pairs": len(set(zip(drug.tolist(), event.tolist()))),
        "each_drug_all_nine_scenarios_once": all(
            sorted(scenario[drug == index].tolist()) == list(range(9)) for index in range(18)
        ),
        "each_event_each_scenario_twice": all(
            all(int(np.sum((event == e) & (scenario == s))) == 2 for s in range(9))
            for e in range(9)
        ),
        "each_scenario_all_18_oa_rows_once": all(
            sorted(oa[scenario == s].tolist()) == list(range(1, 19)) for s in range(9)
        ),
    }


def _centered_effects(
    rng: np.random.Generator, size: int, sigma: float
) -> np.ndarray:
    values = rng.normal(0.0, sigma, size)
    return values - values.mean()


def _sample_duration(
    rng: np.random.Generator, mean_duration: float, shape: float
) -> int:
    mean_nb = max(mean_duration - 1.0, 1e-6)
    probability = shape / (shape + mean_nb)
    return 1 + int(rng.negative_binomial(shape, probability))


def _sample_hsmm_state_path(
    rng: np.random.Generator,
    n_quarters: int,
    duration_means: np.ndarray,
    duration_shapes: np.ndarray,
    emerging_to_persistent: float,
) -> np.ndarray:
    state = np.zeros(n_quarters, dtype=int)
    current = 0
    time = 0
    while time < n_quarters:
        duration = _sample_duration(
            rng, float(duration_means[current]), float(duration_shapes[current])
        )
        stop = min(time + duration, n_quarters)
        state[time:stop] = current
        time = stop
        if time >= n_quarters:
            break
        if current == 0:
            current = 1
        elif current == 1:
            current = 2 if rng.random() < emerging_to_persistent else 3
        elif current == 2:
            current = 3
        else:
            current = 0
    return state


def _shared_truth(rng: np.random.Generator) -> dict[str, np.ndarray | float]:
    alpha = _centered_effects(rng, 18, 0.25)
    beta = _centered_effects(rng, 9, 0.20)
    pair = rng.normal(0.0, 0.30, 162)
    serious_drug = _centered_effects(rng, 18, 0.30)
    serious_event = _centered_effects(rng, 9, 0.25)
    return {
        "mu": 0.0,
        "sigma_drug": 0.25,
        "sigma_event": 0.20,
        "sigma_pair": 0.30,
        "alpha_drug": alpha,
        "beta_event": beta,
        "b_pair": pair,
        "sigma_serious_drug": 0.30,
        "sigma_serious_event": 0.25,
        "serious_drug": serious_drug,
        "serious_event": serious_event,
        "gamma0": -1.5,
        "gamma_state": np.array([0.0, 0.25, 0.35, 0.10]),
        "gamma_x": 0.50,
        "phi": 10.0,
        "drift": np.array([0.0, 0.25, 0.0, -0.25]),
        "dynamic_sd": np.array([0.20, 0.20, 0.12, 0.20]),
        "duration_means": np.array([6.0, 2.0, 5.0, 3.0]),
        "duration_shapes": np.full(4, 2.0),
        "emerging_to_persistent_probability": 2.0 / 3.0,
    }


def _known_offsets(
    rng: np.random.Generator,
    baseline: np.ndarray,
    drug_index: np.ndarray,
    event_index: np.ndarray,
    n_quarters: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    drug_exposure = _centered_effects(rng, 18, 0.30)
    event_prevalence = _centered_effects(rng, 9, 0.25)
    season = 0.12 * np.sin(2.0 * np.pi * np.arange(n_quarters) / 4.0)
    log_expected = (
        np.log(baseline)[:, None]
        + drug_exposure[drug_index, None]
        + event_prevalence[event_index, None]
        + season[None, :]
        + rng.normal(0.0, 0.08, (len(baseline), n_quarters))
    )
    return np.exp(log_expected), drug_exposure, event_prevalence


def generate_tier_a_replicate(
    seed: int,
    *,
    n_quarters: int = 40,
) -> HierarchicalReplicate:
    """Generate one model-conformant recovery replicate from the exact hierarchy."""
    rng = np.random.default_rng(seed)
    design = cross_classified_design()
    drug = design["drug_index"]
    event = design["event_index"]
    truth = _shared_truth(rng)
    expected, exposure, prevalence = _known_offsets(
        rng, np.full(162, 2.0), drug, event, n_quarters
    )
    truth["drug_exposure"] = exposure
    truth["event_prevalence"] = prevalence
    state_id = np.zeros((162, n_quarters), dtype=int)
    x = np.zeros((162, n_quarters), dtype=float)
    for pair in range(162):
        state_id[pair] = _sample_hsmm_state_path(
            rng,
            n_quarters,
            np.asarray(truth["duration_means"]),
            np.asarray(truth["duration_shapes"]),
            float(truth["emerging_to_persistent_probability"]),
        )
        x[pair, 0] = rng.normal(0.0, 0.35)
        for quarter in range(1, n_quarters):
            state = state_id[pair, quarter]
            x[pair, quarter] = (
                x[pair, quarter - 1]
                + np.asarray(truth["drift"])[state]
                + rng.normal(0.0, np.asarray(truth["dynamic_sd"])[state])
            )
    count_baseline = (
        float(truth["mu"])
        + np.asarray(truth["alpha_drug"])[drug]
        + np.asarray(truth["beta_event"])[event]
        + np.asarray(truth["b_pair"])
    )
    mean = expected * np.exp(count_baseline[:, None] + x)
    phi = float(truth["phi"])
    y = rng.negative_binomial(phi, phi / (phi + mean))
    serious_logit = (
        float(truth["gamma0"])
        + np.asarray(truth["gamma_state"])[state_id]
        + float(truth["gamma_x"]) * np.maximum(x, 0.0)
        + np.asarray(truth["serious_drug"])[drug, None]
        + np.asarray(truth["serious_event"])[event, None]
    )
    serious_probability = 1.0 / (1.0 + np.exp(-serious_logit))
    serious = rng.binomial(y, serious_probability)
    change = np.zeros(162, dtype=int)
    duration = np.zeros(162, dtype=int)
    for pair in range(162):
        transitions = np.flatnonzero(state_id[pair, 1:] != state_id[pair, :-1]) + 2
        change[pair] = int(transitions[0]) if len(transitions) else 0
        duration[pair] = int(np.sum(state_id[pair] == 2))
    signal = np.isin(state_id, [1, 2]) & (x > 0)
    return HierarchicalReplicate(
        tier="A_MODEL_CONFORMANT_RECOVERY",
        y=y,
        serious=serious,
        expected=expected,
        drug_index=drug,
        event_index=event,
        pair_id=design["pair_id"],
        scenario=np.full(162, "MODEL_CONFORMANT_HSMM", dtype=object),
        oa_row=design["oa_row"],
        true_state_id=state_id,
        true_state=STATE_NAMES[state_id],
        true_x=x,
        true_serious_probability=serious_probability,
        true_change_quarter=change,
        true_persistence_duration=duration,
        is_true_signal=signal,
        truth=truth,
    )


def generate_tier_b_replicate(
    seed: int,
    phase3_config: dict[str, object],
    *,
    n_quarters: int = 40,
) -> HierarchicalReplicate:
    """Generate the corrected operational stress tier on a shared hierarchy."""
    rng = np.random.default_rng(seed)
    design = cross_classified_design()
    drug = design["drug_index"]
    event = design["event_index"]
    scenario = design["scenario"]
    oa_row = design["oa_row"]
    truth = _shared_truth(rng)
    levels = phase3_config["orthogonal_design"]["level_values"]
    rows = phase3_config["orthogonal_design"]["rows_1_based_levels"]
    baseline = np.zeros(162)
    target = np.zeros(162)
    phi = np.zeros(162)
    base_serious = np.zeros(162)
    change = np.zeros(162, dtype=int)
    requested_duration = np.zeros(162, dtype=int)
    for pair, row_id in enumerate(oa_row):
        row = rows[row_id - 1]
        base_serious[pair] = levels["seriousness_base_prob_2lvl"][row[0] - 1]
        baseline[pair] = levels["baseline_expected_count_3lvl"][row[1] - 1]
        target[pair] = levels["signal_log_rr_3lvl"][row[2] - 1]
        phi[pair] = levels["overdispersion_phi_3lvl"][row[3] - 1]
        change[pair] = levels["change_quarter_3lvl"][row[4] - 1]
        requested_duration[pair] = levels["persistence_duration_3lvl"][row[5] - 1]
        if scenario[pair] in {"sparse_low_count", "low_frequency_high_seriousness"}:
            baseline[pair] *= 0.25
    expected, exposure, prevalence = _known_offsets(
        rng, baseline, drug, event, n_quarters
    )
    truth["drug_exposure"] = exposure
    truth["event_prevalence"] = prevalence
    state_id = np.zeros((162, n_quarters), dtype=int)
    x = np.zeros((162, n_quarters), dtype=float)
    persistence = np.zeros(162, dtype=int)
    for pair in range(162):
        x[pair], state_id[pair], persistence[pair] = _truth_path(
            str(scenario[pair]),
            float(target[pair]),
            int(change[pair]),
            int(requested_duration[pair]),
            n_quarters,
        )
    count_baseline = (
        float(truth["mu"])
        + np.asarray(truth["alpha_drug"])[drug]
        + np.asarray(truth["beta_event"])[event]
        + np.asarray(truth["b_pair"])
    )
    mean = expected * np.exp(count_baseline[:, None] + x)
    y = np.zeros((162, n_quarters), dtype=int)
    for pair in range(162):
        y[pair] = rng.negative_binomial(phi[pair], phi[pair] / (phi[pair] + mean[pair]))
    state_adjustment = np.array([0.0, 0.25, 0.35, 0.10])
    base_logit = np.log(base_serious / (1.0 - base_serious))
    serious_logit = (
        base_logit[:, None]
        + state_adjustment[state_id]
        + 0.5 * np.maximum(x, 0.0)
        + np.asarray(truth["serious_drug"])[drug, None]
        + np.asarray(truth["serious_event"])[event, None]
    )
    serious_probability = 1.0 / (1.0 + np.exp(-serious_logit))
    high = scenario == "low_frequency_high_seriousness"
    for pair in np.flatnonzero(high):
        serious_probability[pair, change[pair] - 1 :] = np.maximum(
            serious_probability[pair, change[pair] - 1 :], 0.50
        )
    serious = rng.binomial(y, serious_probability)
    true_change = np.where(scenario == "null_no_signal", 0, change)
    signal = np.isin(state_id, [1, 2]) & (x > 0)
    truth["phi_pair"] = phi
    truth["oa_base_serious_probability"] = base_serious
    return HierarchicalReplicate(
        tier="B_OPERATIONAL_STRESS",
        y=y,
        serious=serious,
        expected=expected,
        drug_index=drug,
        event_index=event,
        pair_id=design["pair_id"],
        scenario=scenario,
        oa_row=oa_row,
        true_state_id=state_id,
        true_state=STATE_NAMES[state_id],
        true_x=x,
        true_serious_probability=serious_probability,
        true_change_quarter=true_change,
        true_persistence_duration=persistence,
        is_true_signal=signal,
        truth=truth,
    )

