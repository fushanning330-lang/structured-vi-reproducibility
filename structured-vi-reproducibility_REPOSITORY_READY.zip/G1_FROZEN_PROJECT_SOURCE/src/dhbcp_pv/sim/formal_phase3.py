"""Pre-frozen nine-scenario, 18-row OA Phase 3 simulation generator."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


SCENARIOS = (
    "null_no_signal",
    "abrupt_emergence",
    "gradual_emergence",
    "transient_spike",
    "persistent_signal",
    "waning_signal",
    "sparse_low_count",
    "overdispersed_counts",
    "low_frequency_high_seriousness",
)
STATE_NAMES = np.array(["Background", "Emerging", "Persistent", "Waning"], dtype=object)


@dataclass(frozen=True)
class FormalReplicate:
    y: np.ndarray
    serious: np.ndarray
    expected: np.ndarray
    true_state: np.ndarray
    true_log_rr: np.ndarray
    true_serious_probability: np.ndarray
    true_change_quarter: np.ndarray
    true_persistence_duration: np.ndarray
    is_true_signal: np.ndarray
    scenario: np.ndarray
    oa_row: np.ndarray
    pair_id: np.ndarray
    phi: np.ndarray


def _truth_path(
    scenario: str,
    target: float,
    change_quarter: int,
    duration: int,
    n_quarters: int,
) -> tuple[np.ndarray, np.ndarray, int]:
    x = np.zeros(n_quarters, dtype=float)
    state = np.zeros(n_quarters, dtype=int)
    start = change_quarter - 1
    persistence = 0
    if scenario == "null_no_signal":
        return x, state, persistence
    if scenario == "gradual_emergence":
        stop = min(start + 4, n_quarters)
        x[start:stop] = np.linspace(target / 4.0, target, stop - start)
        state[start:stop] = 1
        x[stop:] = target
        state[stop:] = 2
        persistence = n_quarters - start
    elif scenario == "transient_spike":
        stop = min(start + duration, n_quarters)
        x[start:stop] = target
        state[start] = 1
        state[start + 1 : stop] = 2
        tail_stop = min(stop + 2, n_quarters)
        if tail_stop > stop:
            x[stop:tail_stop] = np.linspace(target * 2.0 / 3.0, target / 3.0, tail_stop - stop)
            state[stop:tail_stop] = 3
        persistence = stop - start
    elif scenario == "waning_signal":
        stop = min(start + duration, n_quarters)
        x[start:stop] = target
        state[start] = 1
        state[start + 1 : stop] = 2
        tail_stop = min(stop + 4, n_quarters)
        if tail_stop > stop:
            x[stop:tail_stop] = np.linspace(target * 0.8, 0.0, tail_stop - stop)
            state[stop:tail_stop] = 3
        persistence = stop - start
    else:
        x[start:] = target
        state[start] = 1
        state[start + 1 :] = 2
        persistence = n_quarters - start
    return x, state, persistence


def generate_formal_replicate(seed: int, config: dict[str, object]) -> FormalReplicate:
    rng = np.random.default_rng(seed)
    n_quarters = int(config["quarters"])
    design = config["orthogonal_design"]
    levels = design["level_values"]
    rows = design["rows_1_based_levels"]
    n_pairs = len(SCENARIOS) * len(rows)
    y = np.zeros((n_pairs, n_quarters), dtype=int)
    serious = np.zeros_like(y)
    expected = np.zeros((n_pairs, n_quarters), dtype=float)
    true_state = np.empty((n_pairs, n_quarters), dtype=object)
    true_x = np.zeros((n_pairs, n_quarters), dtype=float)
    true_serious = np.zeros((n_pairs, n_quarters), dtype=float)
    true_change = np.zeros(n_pairs, dtype=int)
    true_duration = np.zeros(n_pairs, dtype=int)
    scenario_values = np.empty(n_pairs, dtype=object)
    oa_values = np.zeros(n_pairs, dtype=int)
    pair_ids = np.empty(n_pairs, dtype=object)
    phi_values = np.zeros(n_pairs, dtype=float)
    pair = 0
    for scenario in SCENARIOS:
        for oa_row, row in enumerate(rows, start=1):
            serious_base = float(levels["seriousness_base_prob_2lvl"][row[0] - 1])
            baseline = float(levels["baseline_expected_count_3lvl"][row[1] - 1])
            target = float(levels["signal_log_rr_3lvl"][row[2] - 1])
            phi = float(levels["overdispersion_phi_3lvl"][row[3] - 1])
            change = int(levels["change_quarter_3lvl"][row[4] - 1])
            duration = int(levels["persistence_duration_3lvl"][row[5] - 1])
            if scenario in {"sparse_low_count", "low_frequency_high_seriousness"}:
                baseline *= 0.25
            x, state_id, persistence = _truth_path(scenario, target, change, duration, n_quarters)
            seasonal = np.exp(0.12 * np.sin(2.0 * np.pi * np.arange(n_quarters) / 4.0))
            expected_path = baseline * seasonal * np.exp(rng.normal(0.0, 0.08, n_quarters))
            mean = expected_path * np.exp(x)
            probability = phi / (phi + mean)
            count = rng.negative_binomial(phi, probability)
            serious_probability = np.full(n_quarters, serious_base)
            serious_probability += 0.04 * (state_id == 1) + 0.08 * (state_id == 2) + 0.03 * (state_id == 3)
            if scenario == "low_frequency_high_seriousness":
                serious_probability[change - 1 :] = np.maximum(serious_probability[change - 1 :], 0.50)
            serious_probability = np.clip(serious_probability, 1e-5, 1.0 - 1e-5)
            serious_count = rng.binomial(count, serious_probability)
            y[pair] = count
            serious[pair] = serious_count
            expected[pair] = expected_path
            true_state[pair] = STATE_NAMES[state_id]
            true_x[pair] = x
            true_serious[pair] = serious_probability
            true_change[pair] = 0 if scenario == "null_no_signal" else change
            true_duration[pair] = persistence
            scenario_values[pair] = scenario
            oa_values[pair] = oa_row
            pair_ids[pair] = f"{scenario}::OA{oa_row:02d}"
            phi_values[pair] = phi
            pair += 1
    signal_status = np.isin(true_state, ["Emerging", "Persistent"]) & (true_x > 0)
    return FormalReplicate(
        y=y,
        serious=serious,
        expected=expected,
        true_state=true_state,
        true_log_rr=true_x,
        true_serious_probability=true_serious,
        true_change_quarter=true_change,
        true_persistence_duration=true_duration,
        is_true_signal=signal_status,
        scenario=scenario_values,
        oa_row=oa_values,
        pair_id=pair_ids,
        phi=phi_values,
    )

