from __future__ import annotations
import math

def ror(a: float, b: float, c: float, d: float, continuity: float = 0.5) -> float:
    a, b, c, d = [x + continuity for x in (a, b, c, d)]
    return (a * d) / (b * c)

def prr(a: float, b: float, c: float, d: float, continuity: float = 0.5) -> float:
    a, b, c, d = [x + continuity for x in (a, b, c, d)]
    return (a / (a + b)) / (c / (c + d))

def log_ror_se(a: float, b: float, c: float, d: float, continuity: float = 0.5) -> float:
    a, b, c, d = [x + continuity for x in (a, b, c, d)]
    return math.sqrt(1/a + 1/b + 1/c + 1/d)
