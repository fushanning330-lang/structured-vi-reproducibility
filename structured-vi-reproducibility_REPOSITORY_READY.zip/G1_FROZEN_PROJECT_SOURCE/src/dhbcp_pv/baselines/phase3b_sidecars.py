"""Subprocess adapters for frozen, isolated Phase 3B baseline environments."""

from __future__ import annotations

import csv
import json
import os
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class SidecarResult:
    score: np.ndarray
    alert: np.ndarray
    failures: list[dict[str, object]]
    metadata: dict[str, object]


def run_mddc_sidecar(
    y: np.ndarray,
    drug_index: np.ndarray,
    event_index: np.ndarray,
    *,
    seed: int,
    python_executable: Path,
    runner: Path,
    scratch_root: Path,
    timeout_seconds: int = 180,
) -> SidecarResult:
    scratch_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=scratch_root, prefix="mddc_") as temp:
        temp_path = Path(temp)
        input_path = temp_path / "input.npz"
        output_path = temp_path / "output.npz"
        np.savez_compressed(
            input_path,
            y=np.asarray(y),
            drug_index=np.asarray(drug_index),
            event_index=np.asarray(event_index),
        )
        completed = subprocess.run(
            [
                str(python_executable),
                str(runner),
                "--input",
                str(input_path),
                "--output",
                str(output_path),
                "--seed",
                str(seed),
            ],
            check=True,
            timeout=timeout_seconds,
            capture_output=True,
            text=True,
        )
        del completed
        result = np.load(output_path)
        metadata = json.loads(str(result["metadata"]))
        return SidecarResult(
            score=np.asarray(result["score"]),
            alert=np.asarray(result["alert"], dtype=bool),
            failures=list(metadata.pop("failures")),
            metadata=metadata,
        )


def run_pvebayes_sidecar(
    y: np.ndarray,
    *,
    seed: int,
    r_executable: Path,
    runner: Path,
    r_library: Path,
    scratch_root: Path,
    timeout_seconds: int = 180,
) -> SidecarResult:
    scratch_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=scratch_root, prefix="pvebayes_") as temp:
        temp_path = Path(temp)
        input_path = temp_path / "input.csv"
        output_path = temp_path / "output.csv"
        failure_path = temp_path / "failures.csv"
        np.savetxt(
            input_path,
            np.asarray(y, dtype=int),
            delimiter=",",
            fmt="%d",
            header=",".join(f"q{quarter + 1}" for quarter in range(np.asarray(y).shape[1])),
            comments="",
        )
        subprocess.run(
            [
                str(r_executable),
                "--vanilla",
                "-s",
                "-f",
                str(runner),
                "--args",
                str(input_path),
                str(output_path),
                str(failure_path),
                str(seed),
            ],
            check=True,
            timeout=timeout_seconds,
            capture_output=True,
            text=True,
            env={**os.environ, "R_LIBS_USER": str(r_library)},
        )
        output = np.genfromtxt(output_path, delimiter=",", names=True, dtype=None, encoding="utf-8")
        score = np.full(np.asarray(y).shape, np.nan)
        alert = np.zeros(np.asarray(y).shape, dtype=bool)
        for row in np.atleast_1d(output):
            pair = int(row["pair_index"])
            quarter = int(row["quarter"]) - 1
            score_value = str(row["score"])
            score[pair, quarter] = np.nan if score_value == "NA" else float(score_value)
            alert[pair, quarter] = str(row["alert"]).upper() == "TRUE"
        with failure_path.open(newline="", encoding="utf-8") as handle:
            failures = list(csv.DictReader(handle))
        return SidecarResult(
            score=score,
            alert=alert,
            failures=failures,
            metadata={
                "package": "pvEBayes",
                "version": "0.3.0",
                "model": "GPS",
                "posterior_draws": 64,
                "cutoff_signal": 1.001,
                "alert_probability": 0.95,
                "prefix_accumulation": True,
            },
        )
