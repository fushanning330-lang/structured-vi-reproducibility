"""Frozen comparator implementations."""

