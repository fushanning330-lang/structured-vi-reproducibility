"""Frozen, operational comparator registry used by the Phase 3 simulation."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.special import ndtr
from scipy.stats import norm


PRIMARY_METHODS = (
    "ROR",
    "PRR",
    "BCPNN_IC",
    "EBGM_MGPS_EQUIVALENT",
    "STATIC_HIERARCHICAL_NB",
    "PELT",
    "CUSUM",
    "BOCPD",
    "TEMPORAL_ENSEMBLE",
)


@dataclass(frozen=True)
class BaselineOutput:
    score: np.ndarray
    alert: np.ndarray


def _pseudo_contingency(y: float, expected: float) -> tuple[float, float, float, float]:
    population = 100_000.0
    drug_total = max(100.0, y + 20.0, expected * 20.0)
    non_drug_event = max(expected * population / drug_total, 0.5)
    a = y
    b = max(drug_total - a, 0.5)
    c = non_drug_event
    d = max(population - a - b - c, 0.5)
    return a, b, c, d


def _static_methods(y: np.ndarray, expected: np.ndarray) -> dict[str, BaselineOutput]:
    n = len(y)
    scores = {name: np.zeros(n) for name in PRIMARY_METHODS[:5]}
    alerts = {name: np.zeros(n, dtype=bool) for name in PRIMARY_METHODS[:5]}
    cumulative_y = 0.0
    cumulative_expected = 0.0
    for t in range(n):
        cumulative_y += float(y[t])
        cumulative_expected += float(expected[t])
        a, b, c, d = _pseudo_contingency(cumulative_y, cumulative_expected)
        aa, bb, cc, dd = a + 0.5, b + 0.5, c + 0.5, d + 0.5
        log_ror = np.log((aa * dd) / (bb * cc))
        log_ror_se = np.sqrt(1.0 / aa + 1.0 / bb + 1.0 / cc + 1.0 / dd)
        ror_lower = log_ror - 1.96 * log_ror_se
        scores["ROR"][t] = ror_lower
        alerts["ROR"][t] = ror_lower > 0 and cumulative_y >= 3

        prr = (aa / (aa + bb)) / (cc / (cc + dd))
        chi_square = (cumulative_y - cumulative_expected) ** 2 / max(cumulative_expected, 1e-8)
        scores["PRR"][t] = min(prr / 2.0, chi_square / 4.0) - 1.0
        alerts["PRR"][t] = prr >= 2.0 and chi_square >= 4.0 and cumulative_y >= 3

        information_component = np.log2((cumulative_y + 0.5) / (cumulative_expected + 0.5))
        ic_sd = np.sqrt(1.0 / (cumulative_y + 0.5) + 1.0 / (cumulative_expected + 0.5)) / np.log(2.0)
        ic025 = information_component - 1.96 * ic_sd
        scores["BCPNN_IC"][t] = ic025
        alerts["BCPNN_IC"][t] = ic025 > 0.0

        ebgm = (cumulative_y + 1.0) / (cumulative_expected + 1.0)
        scores["EBGM_MGPS_EQUIVALENT"][t] = np.log(ebgm)
        alerts["EBGM_MGPS_EQUIVALENT"][t] = ebgm > 1.0

        observed_log_rr = np.log((cumulative_y + 0.5) / (cumulative_expected + 0.5))
        observation_variance = 1.0 / (cumulative_y + 0.5) + 1.0 / (cumulative_expected + 0.5)
        prior_variance = 0.5**2
        posterior_variance = 1.0 / (1.0 / prior_variance + 1.0 / observation_variance)
        posterior_mean = posterior_variance * observed_log_rr / observation_variance
        p_positive = ndtr(posterior_mean / np.sqrt(posterior_variance))
        scores["STATIC_HIERARCHICAL_NB"][t] = p_positive - 1.0 / 6.0
        alerts["STATIC_HIERARCHICAL_NB"][t] = p_positive > 1.0 / 6.0
    return {name: BaselineOutput(scores[name], alerts[name]) for name in scores}


def _pelt_prefix(residual: np.ndarray, penalty: float = 3.0) -> BaselineOutput:
    n = len(residual)
    score = np.zeros(n)
    alert = np.zeros(n, dtype=bool)
    for endpoint in range(2, n + 1):
        values = residual[:endpoint]
        prefix = np.concatenate([[0.0], np.cumsum(values)])
        prefix_sq = np.concatenate([[0.0], np.cumsum(values * values)])
        cost = np.full(endpoint + 1, np.inf)
        previous = np.full(endpoint + 1, -1, dtype=int)
        cost[0] = -penalty
        for stop in range(1, endpoint + 1):
            candidates = np.arange(stop)
            count = stop - candidates
            total = prefix[stop] - prefix[candidates]
            total_sq = prefix_sq[stop] - prefix_sq[candidates]
            segment_cost = total_sq - total * total / count
            objective = cost[candidates] + segment_cost + penalty
            best = int(np.argmin(objective))
            cost[stop] = objective[best]
            previous[stop] = best
        last_start = previous[endpoint]
        if last_start > 0:
            last_mean = float(values[last_start:].mean())
            earlier_mean = float(values[:last_start].mean())
            score[endpoint - 1] = last_mean - earlier_mean
            alert[endpoint - 1] = score[endpoint - 1] > 0.25
    return BaselineOutput(score, alert)


def _cusum(residual: np.ndarray, reference: float = 0.15, threshold: float = 3.0) -> BaselineOutput:
    standardized = residual / 0.75
    statistic = np.zeros(len(residual))
    for t, value in enumerate(standardized):
        statistic[t] = max(0.0, (statistic[t - 1] if t else 0.0) + value - reference)
    return BaselineOutput(statistic - threshold, statistic >= threshold)


def _bocpd(
    residual: np.ndarray,
    hazard: float = 0.05,
    prior_sd: float = 1.0,
    observation_sd: float = 0.75,
    alert_probability: float = 0.20,
) -> BaselineOutput:
    n = len(residual)
    run_probability = np.zeros(n + 1)
    run_probability[0] = 1.0
    means = np.zeros(n + 1)
    precisions = np.full(n + 1, 1.0 / prior_sd**2)
    cp_probability = np.zeros(n)
    for t, value in enumerate(residual):
        active = t + 1
        predictive_sd = np.sqrt(observation_sd**2 + 1.0 / precisions[:active])
        predictive = norm.pdf(value, loc=means[:active], scale=predictive_sd)
        new_probability = np.zeros_like(run_probability)
        new_probability[1 : active + 1] = run_probability[:active] * (1.0 - hazard) * predictive
        prior_predictive = norm.pdf(value, loc=0.0, scale=np.sqrt(observation_sd**2 + prior_sd**2))
        new_probability[0] = run_probability[:active].sum() * hazard * prior_predictive
        normalizer = max(new_probability[: active + 1].sum(), 1e-300)
        new_probability /= normalizer
        cp_probability[t] = new_probability[0]
        old_means = means.copy()
        old_precisions = precisions.copy()
        means[0] = 0.0
        precisions[0] = 1.0 / prior_sd**2
        updated_precision = old_precisions[:active] + 1.0 / observation_sd**2
        means[1 : active + 1] = (
            old_precisions[:active] * old_means[:active] + value / observation_sd**2
        ) / updated_precision
        precisions[1 : active + 1] = updated_precision
        run_probability = new_probability
    return BaselineOutput(cp_probability - alert_probability, cp_probability >= alert_probability)


def run_all_baselines(y: np.ndarray, expected: np.ndarray) -> dict[str, BaselineOutput]:
    """Run every hard-required comparator using rolling prefixes only."""
    y = np.asarray(y, dtype=float)
    expected = np.asarray(expected, dtype=float)
    if y.ndim != 1 or y.shape != expected.shape:
        raise ValueError("y and expected must be equal-length one-dimensional arrays")
    output = _static_methods(y, expected)
    residual = np.log((y + 0.5) / (expected + 0.5))
    output["PELT"] = _pelt_prefix(residual)
    output["CUSUM"] = _cusum(residual)
    output["BOCPD"] = _bocpd(residual)
    votes = np.stack([output[name].alert for name in ("PELT", "CUSUM", "BOCPD")]).sum(axis=0)
    output["TEMPORAL_ENSEMBLE"] = BaselineOutput(votes / 3.0 - 0.5, votes >= 2)
    return output


def baseline_registry_rows() -> list[dict[str, object]]:
    common = {"operational_filtering": True, "frozen_before_formal_run": True}
    rows = [
        {"method": "ROR", "version": "Wald-95-v1", "source": "standard 2x2 reporting odds ratio", "rule": "lower_95_ci_gt_1_and_y_ge_3", "status": "COMPLETE"},
        {"method": "PRR", "version": "MHRA-rule-v1", "source": "standard proportional reporting ratio", "rule": "PRR>=2, chi-square>=4, y>=3", "status": "COMPLETE"},
        {"method": "BCPNN_IC", "version": "IC-normal-v1", "source": "BCPNN information-component equivalent", "rule": "IC025>0", "status": "COMPLETE"},
        {"method": "EBGM_MGPS_EQUIVALENT", "version": "gamma-poisson-v1", "source": "single-gamma Poisson empirical Bayes equivalent", "rule": "posterior RR>1", "status": "COMPLETE"},
        {"method": "STATIC_HIERARCHICAL_NB", "version": "normal-shrinkage-v1", "source": "Phase 2 static hierarchical NB operational approximation", "rule": "P(logRR>0)>1/6", "status": "COMPLETE"},
        {"method": "PELT", "version": "exact-L2-v1", "source": "optimal partitioning with PELT objective", "rule": "penalty=3; latest mean increase>0.25", "status": "COMPLETE"},
        {"method": "CUSUM", "version": "one-sided-v1", "source": "one-sided standardized CUSUM", "rule": "k=0.15; h=3", "status": "COMPLETE"},
        {"method": "BOCPD", "version": "Gaussian-conjugate-v1", "source": "Bayesian online change-point detection", "rule": "hazard=.05; cp probability>=.20", "status": "COMPLETE"},
        {"method": "TEMPORAL_ENSEMBLE", "version": "vote-v1", "source": "frozen PELT+CUSUM+BOCPD ensemble", "rule": "at least 2 of 3", "status": "COMPLETE"},
    ]
    for row in rows:
        row.update(common)
    for method in ("MDDC", "FLEXIBLE_EMPIRICAL_BAYES", "BAYESIAN_EARLY_DETECTION_COMPETITOR"):
        rows.append({"method": method, "version": "unavailable", "source": "no faithfully verified implementation in frozen environment", "rule": "not executed", "status": "BLOCKED_EXTERNAL_IMPLEMENTATION", **common})
    return rows


def phase3b_baseline_registry_rows() -> list[dict[str, object]]:
    """Corrected registry after official-package remediation."""
    rows = baseline_registry_rows()[:-3]
    common = {"operational_filtering": True, "frozen_before_formal_run": True}
    rows.extend(
        [
            {
                "method": "MDDC",
                "version": "PyPI MDDC 1.1.0",
                "source": "https://pypi.org/project/MDDC/",
                "rule": "official mddc; boxplot; coefficient=1.5; accumulated 9x18 prefix table",
                "status": "COMPLETE_VERIFIED_PACKAGE",
                **common,
            },
            {
                "method": "PVEBAYES_GPS",
                "version": "CRAN pvEBayes 0.3.0",
                "source": "https://cran.r-project.org/package=pvEBayes",
                "rule": "official pvEBayes GPS; 64 posterior draws; P(RR>1.001)>=0.95",
                "status": "COMPLETE_WITH_LOGGED_SPARSE_PREFIX_FAILURES",
                **common,
            },
            {
                "method": "DRUG_SIMILARITY_BAYESIAN",
                "version": "authors repository frozen commit",
                "source": "https://github.com/PengyueLab/Drug_Sim_ADE_Mining",
                "rule": "requires faithful co-medication-derived similar-drug inputs",
                "status": "DEFER_TO_PHASE4_EXTERNAL_COVARIATE_DEPENDENCY",
                **common,
            },
        ]
    )
    return rows
