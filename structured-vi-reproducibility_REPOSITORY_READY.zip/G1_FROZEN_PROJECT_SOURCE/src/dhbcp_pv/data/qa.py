"""Phase 2 count invariants, causal eligibility and selected-pair densification."""

from __future__ import annotations

from collections.abc import Iterable

import numpy as np
import pandas as pd


QUARTERS = tuple(f"{year}Q{quarter}" for year in range(2015, 2026) for quarter in range(1, 5))
QUARTER_INDEX = {quarter: index for index, quarter in enumerate(QUARTERS)}


def add_causal_eligibility(
    frame: pd.DataFrame,
    *,
    min_reports: int = 3,
    min_quarters: int = 2,
) -> pd.DataFrame:
    required = {"drug_entity", "event_pt", "quarter", "y"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Missing eligibility columns: {sorted(missing)}")
    out = frame.copy()
    out["quarter_index"] = out["quarter"].map(QUARTER_INDEX)
    if out["quarter_index"].isna().any():
        raise ValueError("Quarter outside frozen 2015Q1-2025Q4 range")
    out = out.sort_values(["drug_entity", "event_pt", "quarter_index"], kind="mergesort")
    grouped = out.groupby(["drug_entity", "event_pt"], sort=False)
    out["cum_pair_reports_t"] = grouped["y"].cumsum()
    out["quarters_with_reports_t"] = grouped["y"].transform(lambda x: x.gt(0).cumsum())
    out["eligible_t"] = (
        out["cum_pair_reports_t"].ge(min_reports)
        & out["quarters_with_reports_t"].ge(min_quarters)
    )
    return out


def densify_selected_pairs(
    sparse: pd.DataFrame,
    pairs: pd.DataFrame | Iterable[tuple[str, str]],
    quarters: Iterable[str],
) -> pd.DataFrame:
    """Densify only an explicit pair universe; a full Cartesian universe is never inferred."""
    if isinstance(pairs, pd.DataFrame):
        pair_frame = pairs[["drug_entity", "event_pt"]].drop_duplicates().copy()
    else:
        pair_frame = pd.DataFrame(pairs, columns=["drug_entity", "event_pt"]).drop_duplicates()
    quarter_values = list(quarters)
    if not quarter_values or any(quarter not in QUARTER_INDEX for quarter in quarter_values):
        raise ValueError("Densification quarters must be a non-empty subset of the frozen range")
    pair_frame["_key"] = 1
    quarter_frame = pd.DataFrame({"quarter": quarter_values, "_key": 1})
    grid = pair_frame.merge(quarter_frame, on="_key").drop(columns="_key")
    value_columns = [column for column in sparse.columns if column not in {"drug_entity", "event_pt", "quarter"}]
    out = grid.merge(sparse, how="left", on=["drug_entity", "event_pt", "quarter"], validate="one_to_one")
    for column in ("y", "s"):
        if column in out:
            out[column] = out[column].fillna(0).astype("int64")
    out = add_causal_eligibility(out)
    return out.sort_values(["drug_entity", "event_pt", "quarter_index"], kind="mergesort").reset_index(drop=True)


def count_invariants(frame: pd.DataFrame) -> dict[str, object]:
    checks = {
        "nonnegative_y": bool((frame["y"] >= 0).all()),
        "nonnegative_s": bool((frame["s"] >= 0).all()),
        "s_le_y": bool((frame["s"] <= frame["y"]).all()),
        "y_le_n_d": bool((frame["y"] <= frame["n_d"]).all()),
        "y_le_n_e": bool((frame["y"] <= frame["n_e"]).all()),
        "n_d_le_n_total": bool((frame["n_d"] <= frame["n_total"]).all()),
        "n_e_le_n_total": bool((frame["n_e"] <= frame["n_total"]).all()),
        "positive_n_total": bool((frame["n_total"] > 0).all()),
        "nonnegative_m_expected": bool(np.isfinite(frame["m_expected"]).all() and (frame["m_expected"] >= 0).all()),
        "frozen_quarter_range": bool(frame["quarter"].isin(QUARTERS).all()),
        "unique_pair_quarter": not bool(frame.duplicated(["drug_entity", "event_pt", "quarter"]).any()),
    }
    return {"checks": checks, "passed": all(checks.values()), "rows": int(len(frame))}

