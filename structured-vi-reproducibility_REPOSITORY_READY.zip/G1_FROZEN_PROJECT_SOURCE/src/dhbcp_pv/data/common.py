from __future__ import annotations
from pathlib import Path
import hashlib
import re
import pandas as pd

_SPACE = re.compile(r"\s+")

def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()

def normalize_text(value: object) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    s = str(value).strip().upper()
    return _SPACE.sub(" ", s)

def quarter_from_date(series: pd.Series) -> pd.Series:
    dt = pd.to_datetime(series, errors="coerce")
    return dt.dt.to_period("Q").astype("string")

def read_dollar_ascii(path: str | Path, **kwargs) -> pd.DataFrame:
    return pd.read_csv(
        path,
        sep="$",
        quotechar='"',
        dtype="string",
        encoding=kwargs.pop("encoding", "latin-1"),
        low_memory=False,
        on_bad_lines="warn",
        **kwargs,
    )
