from __future__ import annotations
from pathlib import Path
import re
import pandas as pd
from .common import read_dollar_ascii, normalize_text
from .drug_mapper import canonical_ingredient_set

FILE_PATTERNS = {
    "demo": re.compile(r"^DEMO.*\.txt$", re.I),
    "drug": re.compile(r"^DRUG.*\.txt$", re.I),
    "reac": re.compile(r"^REAC.*\.txt$", re.I),
    "outc": re.compile(r"^OUTC.*\.txt$", re.I),
}

def discover_tables(extracted_dir: str | Path) -> dict[str, Path]:
    root = Path(extracted_dir)
    found: dict[str, Path] = {}
    for p in root.rglob("*.txt"):
        for key, rx in FILE_PATTERNS.items():
            if rx.match(p.name):
                found[key] = p
    return found

def audit_headers(extracted_dir: str | Path) -> dict:
    tables = discover_tables(extracted_dir)
    out = {"tables": {}, "missing_tables": []}
    for required in FILE_PATTERNS:
        if required not in tables:
            out["missing_tables"].append(required)
            continue
        df = read_dollar_ascii(tables[required], nrows=5)
        out["tables"][required] = {
            "path": str(tables[required]),
            "columns": [str(c).upper() for c in df.columns],
        }
    return out

def canonical_ingredient(value: object) -> str:
    # Backward-compatible helper. Phase 2 learns the active separator set from development only.
    return canonical_ingredient_set(value, (";", "|", " + ", " / "))
