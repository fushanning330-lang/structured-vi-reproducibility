from __future__ import annotations
from pathlib import Path
from .common import read_dollar_ascii

REQUIRED_FILES = [
    "Reports.txt",
    "Drug_Product.txt",
    "Drug_Product_Ingredients.txt",
    "Reactions.txt",
    "Seriousness_LX.txt",
    "Report_Drug.txt",
]

def audit_headers(extracted_dir: str | Path) -> dict:
    root = Path(extracted_dir)
    index = {p.name.lower(): p for p in root.rglob("*.txt")}
    out = {"tables": {}, "missing_tables": []}
    for name in REQUIRED_FILES:
        p = index.get(name.lower())
        if p is None:
            out["missing_tables"].append(name)
            continue
        df = read_dollar_ascii(p, nrows=5)
        out["tables"][name] = {
            "path": str(p),
            "columns": [str(c).upper() for c in df.columns],
        }
    return out
