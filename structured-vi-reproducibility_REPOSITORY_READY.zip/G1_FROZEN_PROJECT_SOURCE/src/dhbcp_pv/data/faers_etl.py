"""Leakage-safe, streaming Phase 2 FAERS ETL built on DuckDB."""

from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import duckdb
import pandas as pd
import yaml

from .common import sha256_file
from .drug_mapper import (
    UNRESOLVED_PREFIX,
    active_delimiters,
    canonical_ingredient_set,
    normalize_value,
    profile_delimiters,
)
from .faers import discover_tables


REQUIRED_SCHEMAS = {
    "demo": [
        "PRIMARYID", "CASEID", "CASEVERSION", "I_F_CODE", "EVENT_DT", "MFR_DT",
        "INIT_FDA_DT", "FDA_DT", "REPT_COD", "AUTH_NUM", "MFR_NUM", "MFR_SNDR",
        "LIT_REF", "AGE", "AGE_COD", "AGE_GRP", "SEX", "E_SUB", "WT", "WT_COD",
        "REPT_DT", "TO_MFR", "OCCP_COD", "REPORTER_COUNTRY", "OCCR_COUNTRY",
    ],
    "drug": [
        "PRIMARYID", "CASEID", "DRUG_SEQ", "ROLE_COD", "DRUGNAME", "PROD_AI",
        "VAL_VBM", "ROUTE", "DOSE_VBM", "CUM_DOSE_CHR", "CUM_DOSE_UNIT", "DECHAL",
        "RECHAL", "LOT_NUM", "EXP_DT", "NDA_NUM", "DOSE_AMT", "DOSE_UNIT",
        "DOSE_FORM", "DOSE_FREQ",
    ],
    "reac": ["PRIMARYID", "CASEID", "PT", "DRUG_REC_ACT"],
    "outc": ["PRIMARYID", "CASEID", "OUTC_COD"],
}
SERIOUS_CODES = {
    "DE": "Death",
    "LT": "Life-Threatening",
    "HO": "Hospitalization - Initial or Prolonged",
    "DS": "Disability",
    "CA": "Congenital Anomaly",
    "RI": "Required Intervention to Prevent Permanent Impairment/Damage",
    "OT": "Other Serious (Important Medical Event)",
}
QUARTERS = tuple(f"{year}Q{quarter}" for year in range(2015, 2026) for quarter in range(1, 5))
SPLIT_SQL = """
CASE
  WHEN quarter_index <= 31 THEN 'development'
  WHEN quarter_index <= 35 THEN 'internal_validation'
  WHEN quarter_index <= 39 THEN 'temporal_test_1'
  ELSE 'temporal_test_2'
END
"""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sql_path(path: Path) -> str:
    return str(path).replace("'", "''")


class Phase2ETL:
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.raw = self.root / "data/raw/faers"
        self.interim = self.root / "data/interim"
        self.processed = self.root / "data/processed"
        self.manifests = self.root / "data/manifests"
        self.results = self.root / "results/phase2"
        self.provenance = self.root / "provenance/phase2"
        for directory in (self.interim, self.processed, self.manifests, self.results, self.provenance):
            directory.mkdir(parents=True, exist_ok=True)
        self.config_path = self.root / "config/phase2_etl_v1.yaml"
        self.config = yaml.safe_load(self.config_path.read_text(encoding="utf-8"))
        self.config_sha256 = sha256_file(self.config_path)
        self.db_path = self.interim / "phase2_etl.duckdb"
        temp_dir = self.interim / "duckdb_temp"
        temp_dir.mkdir(exist_ok=True)
        self.con = duckdb.connect(str(self.db_path))
        self.con.execute("SET threads=4")
        self.con.execute("SET memory_limit='12GB'")
        self.con.execute(f"SET temp_directory='{_sql_path(temp_dir)}'")
        self.con.execute("SET preserve_insertion_order=false")
        self.files = self._discover_files()
        self.input_verification: dict[str, object] = {}
        self.active_ingredient_delimiters: tuple[str, ...] = ()
        self.delimiter_profile: list[dict[str, object]] = []
        self.mapping_sha256 = ""

    def close(self) -> None:
        self.con.close()

    def _discover_files(self) -> dict[str, list[Path]]:
        files: dict[str, list[Path]] = {key: [] for key in REQUIRED_SCHEMAS}
        quarters_seen: list[str] = []
        for quarter in QUARTERS:
            qdir = self.raw / f"faers_ascii_{quarter.lower()}"
            tables = discover_tables(qdir)
            missing = sorted(set(REQUIRED_SCHEMAS) - set(tables))
            if missing:
                raise RuntimeError(f"{quarter}: missing required extracted tables {missing}")
            quarters_seen.append(quarter)
            for key in files:
                files[key].append(tables[key].resolve())
        if quarters_seen != list(QUARTERS):
            raise RuntimeError("Frozen quarter discovery mismatch")
        return files

    def verify_inputs(self) -> dict[str, object]:
        cached_path = self.results / "phase2_input_verification.json"
        if cached_path.exists():
            cached = json.loads(cached_path.read_text(encoding="utf-8"))
            if cached.get("status") == "PASS" and cached.get("archives") == 44 and cached.get("redownloaded") == 0:
                self.input_verification = cached
                print("[phase2] reusing same-run 44/44 frozen archive verification", flush=True)
                return cached
        print("[phase2] verifying 44 existing FDA archives; no download branch is called", flush=True)
        manifest_path = self.manifests / "fda_download_manifest.csv"
        with manifest_path.open(newline="", encoding="utf-8-sig") as handle:
            rows = list(csv.DictReader(handle))
        if len(rows) != 44:
            raise RuntimeError(f"Expected 44 FDA manifest rows, found {len(rows)}")
        periods = {(row["year"], row["quarter"]) for row in rows}
        expected = {(str(year), str(quarter)) for year in range(2015, 2026) for quarter in range(1, 5)}
        if periods != expected:
            raise RuntimeError("FDA manifest period set is not exactly 2015Q1-2025Q4")

        verified = []
        for index, row in enumerate(sorted(rows, key=lambda r: (int(r["year"]), int(r["quarter"]))), 1):
            archive_id = f"faers_ascii_{row['year']}q{row['quarter']}"
            path = self.raw / f"{archive_id}.zip"
            if not path.exists():
                raise RuntimeError(f"Missing frozen archive {path}")
            size_ok = path.stat().st_size == int(row["bytes"])
            digest = sha256_file(path)
            hash_ok = digest == row["sha256"]
            with zipfile.ZipFile(path) as zf:
                zip_ok = zf.testzip() is None
            if not (size_ok and hash_ok and zip_ok):
                raise RuntimeError(f"Frozen FDA archive verification failed: {archive_id}")
            verified.append({"archive_id": archive_id, "bytes": path.stat().st_size, "sha256": digest})
            if index % 8 == 0 or index == 44:
                print(f"[phase2] archive verification {index}/44", flush=True)

        schema_audit = json.loads((self.manifests / "schema_audit.json").read_text(encoding="utf-8"))
        if len(schema_audit.get("faers", {})) != 44:
            raise RuntimeError("Phase 0/1 schema audit does not contain 44 quarters")
        for archive_id, audit in schema_audit["faers"].items():
            if audit.get("missing_tables"):
                raise RuntimeError(f"{archive_id}: missing tables in frozen audit")
            for table, expected_columns in REQUIRED_SCHEMAS.items():
                actual = audit["tables"][table]["columns"]
                if actual != expected_columns:
                    raise RuntimeError(f"{archive_id}/{table}: audited schema differs from Phase 2 freeze")
        self.input_verification = {
            "status": "PASS",
            "archives": 44,
            "bytes": sum(item["bytes"] for item in verified),
            "sha256_matches": 44,
            "zip_integrity_passed": 44,
            "schema_quarters_passed": 44,
            "redownloaded": 0,
        }
        cached_path.write_text(json.dumps(self.input_verification, indent=2) + "\n", encoding="utf-8")
        return self.input_verification

    def _csv_function(self, table: str) -> tuple[str, list[str]]:
        sql = """read_csv(?, delim='$', header=true, all_varchar=true, union_by_name=true,
                 filename=true, encoding='utf-8', strict_mode=false, null_padding=true,
                 quote='"', escape='"', max_line_size=10485760)"""
        return sql, [str(path) for path in self.files[table]]

    def _table_exists(self, name: str) -> bool:
        return bool(self.con.execute(
            "SELECT count(*) FROM information_schema.tables WHERE table_name=?", [name]
        ).fetchone()[0])

    def _copy(self, query: str, target: Path) -> None:
        temp = target.with_suffix(target.suffix + ".tmp")
        if temp.exists():
            temp.unlink()
        # DuckDB parallel Parquet writers can assign sorted rows to row groups nondeterministically.
        # Freeze final artifact serialization to one thread; upstream relational work remains parallel.
        self.con.execute("SET threads=1")
        try:
            self.con.execute(
                f"COPY ({query}) TO '{_sql_path(temp)}' "
                "(FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 100000)"
            )
        finally:
            self.con.execute("SET threads=4")
        os.replace(temp, target)

    def build_incident_cases(self) -> None:
        if self._table_exists("incident_selected") and self._table_exists("incident_exceptions"):
            selected = self.con.execute("SELECT count(*) FROM incident_selected").fetchone()[0]
            if selected > 0:
                print(f"[phase2] reusing persisted causal incident cohort ({selected} rows)", flush=True)
                return
        print("[phase2] scanning DEMO and constructing causal incident cohort", flush=True)
        csv_fn, paths = self._csv_function("demo")
        self.con.execute("DROP TABLE IF EXISTS demo_stage")
        self.con.execute(
            f"""
            CREATE TABLE demo_stage AS
            WITH raw AS (
              SELECT
                upper(regexp_extract(filename, 'faers_ascii_([0-9]{{4}}q[1-4])', 1)) AS source_quarter,
                trim(primaryid) AS primaryid,
                try_cast(trim(primaryid) AS BIGINT) AS primaryid_num,
                trim(caseid) AS caseid,
                trim(caseversion) AS caseversion,
                try_cast(trim(caseversion) AS BIGINT) AS caseversion_num,
                trim(init_fda_dt) AS init_fda_dt,
                CASE WHEN regexp_full_match(trim(init_fda_dt), '[0-9]{{8}}')
                     THEN try_strptime(trim(init_fda_dt), '%Y%m%d') END AS init_date,
                i_f_code, event_dt, fda_dt, rept_cod, age, age_cod, age_grp, sex,
                wt, wt_cod, reporter_country, occr_country
              FROM {csv_fn}
            ), dated AS (
              SELECT *,
                CASE WHEN init_date IS NOT NULL
                     THEN cast(year(init_date) AS VARCHAR) || 'Q' || cast(quarter(init_date) AS VARCHAR)
                END AS initial_quarter,
                (cast(substr(source_quarter, 1, 4) AS INTEGER) - 2015) * 4
                  + cast(substr(source_quarter, 6, 1) AS INTEGER) - 1 AS source_quarter_index,
                CASE WHEN init_date IS NOT NULL
                     THEN (year(init_date) - 2015) * 4 + quarter(init_date) - 1 END AS initial_quarter_index
              FROM raw
            )
            SELECT * FROM dated
            """,
            [paths],
        )
        self.con.execute("DROP TABLE IF EXISTS demo_case_status")
        self.con.execute(
            """
            CREATE TABLE demo_case_status AS
            SELECT
              caseid,
              count(*) AS raw_version_rows,
              sum(CASE WHEN caseid IS NULL OR caseid='' THEN 1 ELSE 0 END) AS invalid_caseid_rows,
              sum(CASE WHEN primaryid_num IS NULL THEN 1 ELSE 0 END) AS invalid_primaryid_rows,
              sum(CASE WHEN caseversion_num IS NULL THEN 1 ELSE 0 END) AS nonnumeric_caseversion_rows,
              sum(CASE WHEN init_date IS NULL THEN 1 ELSE 0 END) AS invalid_init_date_rows,
              count(DISTINCT initial_quarter) FILTER (WHERE initial_quarter IS NOT NULL) AS distinct_initial_quarters,
              min(initial_quarter) AS initial_quarter,
              min(initial_quarter_index) AS initial_quarter_index,
              sum(CASE WHEN initial_quarter_index > source_quarter_index THEN 1 ELSE 0 END) AS impossible_order_rows,
              max(CASE WHEN source_quarter=initial_quarter THEN 1 ELSE 0 END) AS has_initial_quarter_version
            FROM demo_stage
            GROUP BY caseid
            """
        )
        self.con.execute("DROP TABLE IF EXISTS incident_exceptions")
        self.con.execute(
            """
            CREATE TABLE incident_exceptions AS
            SELECT *,
              CASE
                WHEN caseid IS NULL OR caseid='' OR invalid_caseid_rows>0 THEN 'MISSING_CASEID'
                WHEN invalid_primaryid_rows>0 THEN 'MISSING_OR_NONNUMERIC_PRIMARYID'
                WHEN nonnumeric_caseversion_rows>0 THEN 'NONNUMERIC_CASEVERSION'
                WHEN invalid_init_date_rows>0 THEN 'MISSING_OR_INVALID_INIT_FDA_DT'
                WHEN distinct_initial_quarters<>1 THEN 'INCONSISTENT_INIT_FDA_DT'
                WHEN impossible_order_rows>0 THEN 'IMPOSSIBLE_TEMPORAL_ORDERING'
                WHEN initial_quarter_index<0 THEN 'PRE_2015_INITIAL'
                WHEN initial_quarter_index>43 THEN 'POST_2025_INITIAL'
                WHEN has_initial_quarter_version=0 THEN 'NO_INITIAL_QUARTER_VERSION'
              END AS exclusion_reason
            FROM demo_case_status
            WHERE
              caseid IS NULL OR caseid='' OR invalid_caseid_rows>0 OR invalid_primaryid_rows>0
              OR nonnumeric_caseversion_rows>0 OR invalid_init_date_rows>0
              OR distinct_initial_quarters<>1 OR impossible_order_rows>0
              OR initial_quarter_index<0 OR initial_quarter_index>43 OR has_initial_quarter_version=0
            """
        )
        self.con.execute("DROP TABLE IF EXISTS incident_selected")
        self.con.execute(
            f"""
            CREATE TABLE incident_selected AS
            WITH eligible_cases AS (
              SELECT * FROM demo_case_status
              WHERE caseid IS NOT NULL AND caseid<>'' AND invalid_caseid_rows=0
                AND invalid_primaryid_rows=0 AND nonnumeric_caseversion_rows=0
                AND invalid_init_date_rows=0 AND distinct_initial_quarters=1
                AND impossible_order_rows=0 AND initial_quarter_index BETWEEN 0 AND 43
                AND has_initial_quarter_version=1
            ), ranked AS (
              SELECT d.*,
                row_number() OVER (
                  PARTITION BY d.caseid
                  ORDER BY d.caseversion_num DESC, d.primaryid_num DESC
                ) AS selected_rank,
                count(*) OVER (PARTITION BY d.caseid, d.caseversion_num) AS rows_at_selected_version
              FROM demo_stage d
              JOIN eligible_cases c USING (caseid)
              WHERE d.source_quarter=c.initial_quarter
            )
            SELECT
              source_quarter AS quarter,
              source_quarter_index AS quarter_index,
              {SPLIT_SQL.replace('quarter_index', 'source_quarter_index')} AS split,
              primaryid, caseid, caseversion, caseversion_num, init_fda_dt,
              initial_quarter, i_f_code, event_dt, fda_dt, rept_cod, age, age_cod,
              age_grp, sex, wt, wt_cod, reporter_country, occr_country,
              rows_at_selected_version
            FROM ranked
            WHERE selected_rank=1
            """
        )
        self._copy(
            "SELECT * FROM incident_exceptions ORDER BY coalesce(initial_quarter_index, -999), caseid",
            self.interim / "faers_incident_case_exceptions.parquet",
        )
        print(
            "[phase2] incident cohort rows",
            self.con.execute("SELECT count(*) FROM incident_selected").fetchone()[0],
            "exceptions",
            self.con.execute("SELECT count(*) FROM incident_exceptions").fetchone()[0],
            flush=True,
        )

    def build_drugs(self) -> None:
        mapping_path = self.processed / "drug_mapping_dev_v1.parquet"
        case_drugs_path = self.interim / "faers_case_drugs.parquet"
        if self._table_exists("case_drugs") and self._table_exists("drug_mapping_dev") and mapping_path.exists() and case_drugs_path.exists():
            dev_prod_values = self.con.execute(
                "SELECT DISTINCT prod_ai FROM drug_selected_raw WHERE quarter_index<=31 AND trim(prod_ai)<>''"
            ).fetch_df()["prod_ai"].tolist()
            self.delimiter_profile = profile_delimiters(dev_prod_values)
            self.active_ingredient_delimiters = active_delimiters(self.delimiter_profile)
            self.mapping_sha256 = sha256_file(mapping_path)
            print(f"[phase2] reusing frozen drug products ({self.mapping_sha256})", flush=True)
            return
        print("[phase2] joining same-quarter selected versions to DRUG", flush=True)
        csv_fn, paths = self._csv_function("drug")
        self.con.execute("DROP TABLE IF EXISTS drug_selected_raw")
        self.con.execute(
            f"""
            CREATE TABLE drug_selected_raw AS
            WITH raw AS (
              SELECT
                upper(regexp_extract(filename, 'faers_ascii_([0-9]{{4}}q[1-4])', 1)) AS source_quarter,
                trim(primaryid) AS primaryid,
                trim(caseid) AS caseid,
                trim(drug_seq) AS drug_seq,
                upper(trim(role_cod)) AS role_cod,
                coalesce(drugname, '') AS drugname,
                coalesce(prod_ai, '') AS prod_ai
              FROM {csv_fn}
            )
            SELECT i.quarter, i.quarter_index, i.split, i.primaryid, i.caseid,
                   r.drug_seq, r.role_cod, r.drugname, r.prod_ai
            FROM raw r
            JOIN incident_selected i
              ON r.source_quarter=i.quarter AND r.primaryid=i.primaryid AND r.caseid=i.caseid
            WHERE r.role_cod IN ('PS','SS')
            """,
            [paths],
        )

        dev_prod_values = self.con.execute(
            "SELECT DISTINCT prod_ai FROM drug_selected_raw WHERE quarter_index<=31 AND trim(prod_ai)<>''"
        ).fetch_df()["prod_ai"].tolist()
        self.delimiter_profile = profile_delimiters(dev_prod_values)
        self.active_ingredient_delimiters = active_delimiters(self.delimiter_profile)
        print(
            "[phase2] development-only active PROD_AI delimiters",
            repr(self.active_ingredient_delimiters),
            flush=True,
        )

        prod_values = self.con.execute(
            "SELECT DISTINCT coalesce(prod_ai,'') AS raw_prod_ai FROM drug_selected_raw"
        ).fetch_df()
        prod_values["prod_ai_norm"] = prod_values["raw_prod_ai"].map(normalize_value)
        prod_values["canonical_ingredient_set"] = prod_values["raw_prod_ai"].map(
            lambda value: canonical_ingredient_set(value, self.active_ingredient_delimiters)
        )
        name_values = self.con.execute(
            "SELECT DISTINCT coalesce(drugname,'') AS raw_drugname FROM drug_selected_raw"
        ).fetch_df()
        name_values["drugname_norm"] = name_values["raw_drugname"].map(normalize_value)
        self.con.register("prod_value_lookup_df", prod_values)
        self.con.register("name_value_lookup_df", name_values)
        self.con.execute("CREATE OR REPLACE TABLE prod_value_lookup AS SELECT * FROM prod_value_lookup_df")
        self.con.execute("CREATE OR REPLACE TABLE name_value_lookup AS SELECT * FROM name_value_lookup_df")
        self.con.unregister("prod_value_lookup_df")
        self.con.unregister("name_value_lookup_df")

        self.con.execute("DROP TABLE IF EXISTS drug_normalized")
        self.con.execute(
            """
            CREATE TABLE drug_normalized AS
            SELECT d.*, p.prod_ai_norm, p.canonical_ingredient_set, n.drugname_norm
            FROM drug_selected_raw d
            JOIN prod_value_lookup p ON coalesce(d.prod_ai,'')=p.raw_prod_ai
            JOIN name_value_lookup n ON coalesce(d.drugname,'')=n.raw_drugname
            """
        )
        self.con.execute("DROP TABLE IF EXISTS drug_mapping_dev")
        self.con.execute(
            """
            CREATE TABLE drug_mapping_dev AS
            SELECT
              drugname_norm,
              min(canonical_ingredient_set) AS canonical_ingredient_set,
              count(*) AS development_evidence_rows,
              count(DISTINCT canonical_ingredient_set) AS distinct_ingredient_sets,
              min(quarter) AS first_development_quarter,
              max(quarter) AS last_development_quarter,
              '2015Q1-2022Q4' AS evidence_period
            FROM drug_normalized
            WHERE quarter_index<=31 AND drugname_norm<>'' AND canonical_ingredient_set<>''
            GROUP BY drugname_norm
            HAVING count(DISTINCT canonical_ingredient_set)=1
            """
        )
        self._copy("SELECT * FROM drug_mapping_dev ORDER BY drugname_norm", mapping_path)
        self.mapping_sha256 = sha256_file(mapping_path)
        print(
            "[phase2] development mapping frozen before validation application",
            self.con.execute("SELECT count(*) FROM drug_mapping_dev").fetchone()[0],
            self.mapping_sha256,
            flush=True,
        )

        self.con.execute("DROP TABLE IF EXISTS case_drugs")
        self.con.execute(
            f"""
            CREATE TABLE case_drugs AS
            WITH mapped AS (
              SELECT d.*,
                CASE
                  WHEN d.canonical_ingredient_set<>'' THEN d.canonical_ingredient_set
                  WHEN m.canonical_ingredient_set IS NOT NULL THEN m.canonical_ingredient_set
                  ELSE '{UNRESOLVED_PREFIX}' || CASE WHEN d.drugname_norm='' THEN '<BLANK>' ELSE d.drugname_norm END
                END AS drug_entity,
                CASE
                  WHEN d.canonical_ingredient_set<>'' THEN 'PROD_AI'
                  WHEN m.canonical_ingredient_set IS NOT NULL THEN 'DEV_DRUGNAME_MAP'
                  ELSE 'UNRESOLVED'
                END AS mapping_source,
                CASE
                  WHEN d.canonical_ingredient_set<>'' THEN 1
                  WHEN m.canonical_ingredient_set IS NOT NULL THEN 2
                  ELSE 3
                END AS mapping_rank
              FROM drug_normalized d
              LEFT JOIN drug_mapping_dev m USING (drugname_norm)
            )
            SELECT quarter, quarter_index, split, primaryid, caseid, drug_entity,
                   bool_or(role_cod='PS') AS has_ps,
                   bool_or(role_cod='SS') AS has_ss,
                   arg_min(mapping_source, mapping_rank) AS mapping_source
            FROM mapped
            GROUP BY quarter, quarter_index, split, primaryid, caseid, drug_entity
            """
        )
        self._copy(
            "SELECT * FROM case_drugs ORDER BY quarter_index, caseid, drug_entity",
            self.interim / "faers_case_drugs.parquet",
        )

    def build_events_and_outcomes(self) -> None:
        required_tables = ("case_events", "case_outcomes", "case_serious")
        required_paths = (
            self.interim / "faers_case_events.parquet",
            self.interim / "faers_case_outcomes.parquet",
            self.interim / "faers_incident_cases.parquet",
        )
        if all(self._table_exists(table) for table in required_tables) and all(path.exists() for path in required_paths):
            print("[phase2] reusing persisted REAC/OUTC products", flush=True)
            return
        print("[phase2] joining selected versions to REAC and OUTC", flush=True)
        csv_fn, paths = self._csv_function("reac")
        self.con.execute("DROP TABLE IF EXISTS reaction_selected_raw")
        self.con.execute(
            f"""
            CREATE TABLE reaction_selected_raw AS
            WITH raw AS (
              SELECT upper(regexp_extract(filename, 'faers_ascii_([0-9]{{4}}q[1-4])', 1)) AS source_quarter,
                     trim(primaryid) AS primaryid, trim(caseid) AS caseid, coalesce(pt,'') AS pt
              FROM {csv_fn}
            )
            SELECT i.quarter, i.quarter_index, i.split, i.primaryid, i.caseid, r.pt
            FROM raw r JOIN incident_selected i
              ON r.source_quarter=i.quarter AND r.primaryid=i.primaryid AND r.caseid=i.caseid
            """,
            [paths],
        )
        pt_values = self.con.execute("SELECT DISTINCT pt AS raw_pt FROM reaction_selected_raw").fetch_df()
        pt_values["event_pt"] = pt_values["raw_pt"].map(normalize_value)
        self.con.register("pt_value_lookup_df", pt_values)
        self.con.execute("CREATE OR REPLACE TABLE pt_value_lookup AS SELECT * FROM pt_value_lookup_df")
        self.con.unregister("pt_value_lookup_df")
        self.con.execute("DROP TABLE IF EXISTS case_events")
        self.con.execute(
            """
            CREATE TABLE case_events AS
            SELECT DISTINCT r.quarter, r.quarter_index, r.split, r.primaryid, r.caseid, p.event_pt
            FROM reaction_selected_raw r JOIN pt_value_lookup p ON r.pt=p.raw_pt
            WHERE p.event_pt<>''
            """
        )
        self._copy(
            "SELECT * FROM case_events ORDER BY quarter_index, caseid, event_pt",
            self.interim / "faers_case_events.parquet",
        )

        csv_fn, paths = self._csv_function("outc")
        self.con.execute("DROP TABLE IF EXISTS case_outcomes")
        self.con.execute(
            f"""
            CREATE TABLE case_outcomes AS
            WITH raw AS (
              SELECT upper(regexp_extract(filename, 'faers_ascii_([0-9]{{4}}q[1-4])', 1)) AS source_quarter,
                     trim(primaryid) AS primaryid, trim(caseid) AS caseid,
                     upper(trim(outc_cod)) AS outc_cod
              FROM {csv_fn}
            )
            SELECT DISTINCT i.quarter, i.quarter_index, i.split, i.primaryid, i.caseid,
                   r.outc_cod,
                   r.outc_cod IN ('DE','LT','HO','DS','CA','RI','OT') AS documented_serious
            FROM raw r JOIN incident_selected i
              ON r.source_quarter=i.quarter AND r.primaryid=i.primaryid AND r.caseid=i.caseid
            WHERE r.outc_cod IS NOT NULL AND r.outc_cod<>''
            """,
            [paths],
        )
        self.con.execute("DROP TABLE IF EXISTS case_serious")
        self.con.execute(
            """
            CREATE TABLE case_serious AS
            SELECT i.quarter, i.quarter_index, i.split, i.primaryid, i.caseid,
                   coalesce(max(cast(o.documented_serious AS INTEGER)),0)::INTEGER AS serious,
                   count(o.outc_cod) AS distinct_outcome_codes
            FROM incident_selected i
            LEFT JOIN case_outcomes o USING (quarter, quarter_index, split, primaryid, caseid)
            GROUP BY i.quarter, i.quarter_index, i.split, i.primaryid, i.caseid
            """
        )
        self._copy(
            "SELECT * FROM case_outcomes ORDER BY quarter_index, caseid, outc_cod",
            self.interim / "faers_case_outcomes.parquet",
        )
        self._copy(
            """SELECT i.*, s.serious, s.distinct_outcome_codes
               FROM incident_selected i JOIN case_serious s
               USING (quarter, quarter_index, split, primaryid, caseid)
               ORDER BY quarter_index, caseid""",
            self.interim / "faers_incident_cases.parquet",
        )

    def _build_scope(self, scope: str, drug_filter: str, output_name: str) -> None:
        suffix = scope.lower()
        self.con.execute(f"DROP TABLE IF EXISTS scope_drugs_{suffix}")
        self.con.execute(f"CREATE TABLE scope_drugs_{suffix} AS SELECT * FROM case_drugs WHERE {drug_filter}")
        self.con.execute(f"DROP TABLE IF EXISTS case_population_{suffix}")
        self.con.execute(
            f"""
            CREATE TABLE case_population_{suffix} AS
            SELECT DISTINCT d.quarter, d.quarter_index, d.split, d.primaryid, d.caseid, s.serious
            FROM scope_drugs_{suffix} d
            JOIN case_events e USING (quarter, quarter_index, split, primaryid, caseid)
            JOIN case_serious s USING (quarter, quarter_index, split, primaryid, caseid)
            """
        )
        self.con.execute(f"DROP TABLE IF EXISTS n_total_{suffix}")
        self.con.execute(
            f"""CREATE TABLE n_total_{suffix} AS
                 SELECT quarter, quarter_index, split, count(*)::BIGINT AS n_total
                 FROM case_population_{suffix} GROUP BY quarter, quarter_index, split"""
        )
        self.con.execute(f"DROP TABLE IF EXISTS n_drug_{suffix}")
        self.con.execute(
            f"""CREATE TABLE n_drug_{suffix} AS
                 SELECT d.quarter, d.quarter_index, d.split, d.drug_entity, count(*)::BIGINT AS n_d
                 FROM scope_drugs_{suffix} d JOIN case_population_{suffix} p
                 USING (quarter, quarter_index, split, primaryid, caseid)
                 GROUP BY d.quarter, d.quarter_index, d.split, d.drug_entity"""
        )
        self.con.execute(f"DROP TABLE IF EXISTS n_event_{suffix}")
        self.con.execute(
            f"""CREATE TABLE n_event_{suffix} AS
                 SELECT e.quarter, e.quarter_index, e.split, e.event_pt, count(*)::BIGINT AS n_e
                 FROM case_events e JOIN case_population_{suffix} p
                 USING (quarter, quarter_index, split, primaryid, caseid)
                 GROUP BY e.quarter, e.quarter_index, e.split, e.event_pt"""
        )
        self.con.execute(f"DROP TABLE IF EXISTS pair_base_{suffix}")
        self.con.execute(
            f"""
            CREATE TABLE pair_base_{suffix} AS
            SELECT d.quarter, d.quarter_index, d.split, d.drug_entity, e.event_pt,
                   count(*)::BIGINT AS y, sum(p.serious)::BIGINT AS s
            FROM scope_drugs_{suffix} d
            JOIN case_events e USING (quarter, quarter_index, split, primaryid, caseid)
            JOIN case_population_{suffix} p USING (quarter, quarter_index, split, primaryid, caseid)
            GROUP BY d.quarter, d.quarter_index, d.split, d.drug_entity, e.event_pt
            """
        )
        self.con.execute(f"DROP TABLE IF EXISTS pair_panel_{suffix}")
        self.con.execute(
            f"""
            CREATE TABLE pair_panel_{suffix} AS
            WITH joined AS (
              SELECT p.*, d.n_d, e.n_e, n.n_total,
                     cast(d.n_d AS DOUBLE)*cast(e.n_e AS DOUBLE)/cast(n.n_total AS DOUBLE) AS m_expected
              FROM pair_base_{suffix} p
              JOIN n_drug_{suffix} d USING (quarter, quarter_index, split, drug_entity)
              JOIN n_event_{suffix} e USING (quarter, quarter_index, split, event_pt)
              JOIN n_total_{suffix} n USING (quarter, quarter_index, split)
            ), cumulative AS (
              SELECT *,
                sum(y) OVER (PARTITION BY drug_entity,event_pt ORDER BY quarter_index ROWS UNBOUNDED PRECEDING)
                  AS cum_pair_reports_t,
                sum(CASE WHEN y>0 THEN 1 ELSE 0 END) OVER
                  (PARTITION BY drug_entity,event_pt ORDER BY quarter_index ROWS UNBOUNDED PRECEDING)
                  AS quarters_with_reports_t
              FROM joined
            )
            SELECT *,
              cum_pair_reports_t>=3 AND quarters_with_reports_t>=2 AS eligible_t,
              '{scope}' AS role_scope
            FROM cumulative
            """
        )
        self._copy(
            f"SELECT * FROM pair_panel_{suffix} ORDER BY drug_entity, event_pt, quarter_index",
            self.processed / output_name,
        )

    def build_counts(self) -> None:
        required_tables = ("pair_panel_ps_ss", "pair_panel_ps_only", "quarter_marginals")
        required_paths = (
            self.processed / "faers_pair_quarter_sparse.parquet",
            self.processed / "faers_pair_quarter_ps_only_sparse.parquet",
            self.processed / "faers_quarter_marginals.parquet",
        )
        if all(self._table_exists(table) for table in required_tables) and all(path.exists() for path in required_paths):
            print("[phase2] reusing persisted marginals and sparse panels", flush=True)
            return
        print("[phase2] building unique CASEID marginals and sparse pair-quarter panels", flush=True)
        self._build_scope("PS_SS", "has_ps OR has_ss", "faers_pair_quarter_sparse.parquet")
        print("[phase2] PS+SS sparse panel complete", flush=True)
        self._build_scope("PS_ONLY", "has_ps", "faers_pair_quarter_ps_only_sparse.parquet")
        print("[phase2] PS-only sparse panel complete", flush=True)
        self.con.execute("DROP TABLE IF EXISTS quarter_marginals")
        parts = []
        for scope in ("PS_SS", "PS_ONLY"):
            suffix = scope.lower()
            parts.extend(
                [
                    f"SELECT '{scope}' role_scope, quarter, quarter_index, split, 'N_TOTAL' margin_type, '' entity, n_total n_cases FROM n_total_{suffix}",
                    f"SELECT '{scope}' role_scope, quarter, quarter_index, split, 'N_DRUG' margin_type, drug_entity entity, n_d n_cases FROM n_drug_{suffix}",
                    f"SELECT '{scope}' role_scope, quarter, quarter_index, split, 'N_EVENT' margin_type, event_pt entity, n_e n_cases FROM n_event_{suffix}",
                ]
            )
        self.con.execute("CREATE TABLE quarter_marginals AS " + " UNION ALL ".join(parts))
        self._copy(
            "SELECT * FROM quarter_marginals ORDER BY role_scope, quarter_index, margin_type, entity",
            self.processed / "faers_quarter_marginals.parquet",
        )

    def _artifact_manifest(self) -> list[dict[str, object]]:
        paths = [
            self.interim / "faers_incident_cases.parquet",
            self.interim / "faers_incident_case_exceptions.parquet",
            self.interim / "faers_case_drugs.parquet",
            self.interim / "faers_case_events.parquet",
            self.interim / "faers_case_outcomes.parquet",
            self.processed / "drug_mapping_dev_v1.parquet",
            self.processed / "faers_quarter_marginals.parquet",
            self.processed / "faers_pair_quarter_sparse.parquet",
            self.processed / "faers_pair_quarter_ps_only_sparse.parquet",
        ]
        rows = []
        for path in paths:
            row_count = self.con.execute("SELECT count(*) FROM read_parquet(?)", [str(path)]).fetchone()[0]
            rows.append(
                {
                    "artifact": path.name,
                    "path": str(path),
                    "rows": int(row_count),
                    "bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "phase2_config_sha256": self.config_sha256,
                    "environment_sha256": "4a8d2985b1b3696b1de40911609de94fa9e2f88998f6e2bdb708e978cef23b6e",
                }
            )
        manifest_path = self.manifests / "phase2_processed_artifacts.csv"
        with manifest_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        shutil.copy2(manifest_path, self.results / "35_PHASE2_PROCESSED_ARTIFACT_MANIFEST.csv")
        return rows

    def build_reports(self) -> dict[str, object]:
        print("[phase2] generating QA, no-leakage and artifact manifests", flush=True)
        by_quarter = self.con.execute(
            """
            SELECT i.quarter, count(*) incident_cases,
                   coalesce(p1.n_total,0) ps_ss_case_population,
                   coalesce(p2.n_total,0) ps_only_case_population
            FROM incident_selected i
            LEFT JOIN n_total_ps_ss p1 USING (quarter,quarter_index,split)
            LEFT JOIN n_total_ps_only p2 USING (quarter,quarter_index,split)
            GROUP BY i.quarter,p1.n_total,p2.n_total ORDER BY i.quarter
            """
        ).fetch_df().to_dict("records")
        exclusions = self.con.execute(
            "SELECT exclusion_reason, count(*) count FROM incident_exceptions GROUP BY exclusion_reason ORDER BY exclusion_reason"
        ).fetch_df().to_dict("records")
        mapping_qa = self.con.execute(
            """
            SELECT split, mapping_source, count(*) case_drug_rows,
                   count(DISTINCT drug_entity) distinct_drug_entities
            FROM case_drugs GROUP BY split,mapping_source ORDER BY split,mapping_source
            """
        ).fetch_df()
        mapping_qa.to_csv(self.results / "36_PHASE2_DRUG_MAPPING_QA.csv", index=False)
        outcome_coverage = self.con.execute(
            """
            SELECT coalesce(outc_cod,'NO_OUTCOME_ROW') outcome_code, count(*) row_count
            FROM (
              SELECT outc_cod FROM case_outcomes
              UNION ALL
              SELECT NULL FROM case_serious WHERE distinct_outcome_codes=0
            ) GROUP BY outcome_code ORDER BY outcome_code
            """
        ).fetch_df().to_dict("records")
        pt_drift = self.con.execute(
            """
            WITH first_seen AS (
              SELECT event_pt,min(cast(substr(quarter,1,4) AS INTEGER)) first_year FROM case_events GROUP BY event_pt
            )
            SELECT cast(substr(e.quarter,1,4) AS INTEGER) calendar_year,
                   count(*) case_event_rows, count(DISTINCT e.event_pt) unique_pts,
                   count(DISTINCT CASE WHEN f.first_year=cast(substr(e.quarter,1,4) AS INTEGER) THEN e.event_pt END) first_seen_pts
            FROM case_events e JOIN first_seen f USING(event_pt)
            GROUP BY calendar_year ORDER BY calendar_year
            """
        ).fetch_df().to_dict("records")
        panel_checks = {}
        for scope in ("ps_ss", "ps_only"):
            row = self.con.execute(
                f"""
                SELECT count(*) row_count,
                  sum(CASE WHEN s>y THEN 1 ELSE 0 END) s_gt_y,
                  sum(CASE WHEN y>n_d OR y>n_e THEN 1 ELSE 0 END) y_gt_margin,
                  sum(CASE WHEN n_d>n_total OR n_e>n_total THEN 1 ELSE 0 END) margin_gt_total,
                  sum(CASE WHEN n_total<=0 OR m_expected<0 OR NOT isfinite(m_expected) THEN 1 ELSE 0 END) invalid_expected,
                  count(*)-count(DISTINCT (drug_entity,event_pt,quarter)) duplicate_pair_quarters,
                  sum(CASE WHEN eligible_t<>(cum_pair_reports_t>=3 AND quarters_with_reports_t>=2) THEN 1 ELSE 0 END) eligibility_mismatch
                FROM pair_panel_{scope}
                """
            ).fetchone()
            panel_checks[scope.upper()] = dict(zip(
                ["rows", "s_gt_y", "y_gt_margin", "margin_gt_total", "invalid_expected", "duplicate_pair_quarters", "eligibility_mismatch"],
                map(int, row),
            ))

        qa = {
            "generated_utc": _utc_now(),
            "status": "PASS",
            "scope": "ENGINEERING_PHASE2_NOT_FORMAL",
            "input_verification": self.input_verification,
            "source_encoding": {
                "audit": "176/176 required DEMO/DRUG/REAC/OUTC TXT files identified as US-ASCII",
                "reader": "UTF-8 (ASCII-compatible)",
                "documented_adaptation": "DuckDB rejected a latin-1 label for 2018Q4 DRUG despite the file being US-ASCII; no bytes or semantics were changed.",
            },
            "incident_cases": {
                "selected": int(self.con.execute("SELECT count(*) FROM incident_selected").fetchone()[0]),
                "exceptions": int(self.con.execute("SELECT count(*) FROM incident_exceptions").fetchone()[0]),
                "exclusions_by_reason": exclusions,
                "year_quarter_counts": by_quarter,
            },
            "drug_mapping": {
                "training_period": "2015Q1-2022Q4 only",
                "mapping_rows": int(self.con.execute("SELECT count(*) FROM drug_mapping_dev").fetchone()[0]),
                "mapping_sha256": self.mapping_sha256,
                "active_delimiters": list(self.active_ingredient_delimiters),
                "development_delimiter_profile": self.delimiter_profile,
                "coverage": mapping_qa.to_dict("records"),
            },
            "event_pt_profile_by_year": pt_drift,
            "seriousness": {
                "documented_codes": SERIOUS_CODES,
                "outcome_coverage": outcome_coverage,
                "unknown_outcome_codes": self.con.execute(
                    "SELECT count(*) FROM case_outcomes WHERE NOT documented_serious"
                ).fetchone()[0],
            },
            "panels": panel_checks,
        }
        if any(
            values[key] != 0
            for values in panel_checks.values()
            for key in ("s_gt_y", "y_gt_margin", "margin_gt_total", "invalid_expected", "duplicate_pair_quarters", "eligibility_mismatch")
        ):
            qa["status"] = "FAIL"
        (self.results / "33_PHASE2_ETL_QA.json").write_text(
            json.dumps(qa, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )

        no_leakage_checks = {
            "selected_version_is_physically_in_initial_quarter": self.con.execute(
                "SELECT count(*)=0 FROM incident_selected WHERE quarter<>initial_quarter"
            ).fetchone()[0],
            "exactly_one_selected_row_per_caseid": self.con.execute(
                "SELECT count(*)=count(DISTINCT caseid) FROM incident_selected"
            ).fetchone()[0],
            "no_later_followup_replacement": self.con.execute(
                "SELECT count(*)=0 FROM incident_selected WHERE quarter_index<>(cast(substr(initial_quarter,1,4) AS INTEGER)-2015)*4+cast(substr(initial_quarter,6,1) AS INTEGER)-1"
            ).fetchone()[0],
            "drug_mapping_evidence_development_only": self.con.execute(
                "SELECT count(*)=0 FROM drug_mapping_dev WHERE last_development_quarter>'2022Q4' OR evidence_period<>'2015Q1-2022Q4'"
            ).fetchone()[0],
            "no_duplicate_case_drug_entity": self.con.execute(
                "SELECT count(*)=count(DISTINCT (quarter,caseid,drug_entity)) FROM case_drugs"
            ).fetchone()[0],
            "no_duplicate_case_event": self.con.execute(
                "SELECT count(*)=count(DISTINCT (quarter,caseid,event_pt)) FROM case_events"
            ).fetchone()[0],
            "ps_ss_pair_count_invariants": qa["panels"]["PS_SS"]["s_gt_y"] == 0
                and qa["panels"]["PS_SS"]["duplicate_pair_quarters"] == 0,
            "ps_only_pair_count_invariants": qa["panels"]["PS_ONLY"]["s_gt_y"] == 0
                and qa["panels"]["PS_ONLY"]["duplicate_pair_quarters"] == 0,
            "causal_eligibility_exact": qa["panels"]["PS_SS"]["eligibility_mismatch"] == 0
                and qa["panels"]["PS_ONLY"]["eligibility_mismatch"] == 0,
            "no_2026_primary_rows": self.con.execute(
                "SELECT count(*)=0 FROM incident_selected WHERE quarter>'2025Q4'"
            ).fetchone()[0],
        }
        no_leakage = {
            "generated_utc": _utc_now(),
            "checks": {key: bool(value) for key, value in no_leakage_checks.items()},
            "passed": all(bool(value) for value in no_leakage_checks.values()),
            "mapping_sha256": self.mapping_sha256,
            "formal_results_produced": False,
        }
        (self.results / "34_PHASE2_NO_LEAKAGE_TESTS.json").write_text(
            json.dumps(no_leakage, indent=2) + "\n", encoding="utf-8"
        )
        artifacts = self._artifact_manifest()
        self._write_outcome_codebook()
        return {"qa": qa, "no_leakage": no_leakage, "artifacts": artifacts}

    def _write_outcome_codebook(self) -> None:
        source = self.raw / "faers_ascii_2025q4/ASCII/ASC_NTS.pdf"
        source_sha = sha256_file(source)
        rows = [
            {
                "outc_cod": code,
                "meaning_text": meaning,
                "serious": 1,
                "source_document": str(source),
                "source_document_sha256": source_sha,
                "source_pdf_page": 9,
                "evidence": "ASC_NTS outcome-file table; all listed values are serious patient outcomes",
            }
            for code, meaning in SERIOUS_CODES.items()
        ]
        path = self.results / "37_PHASE2_OUTCOME_CODEBOOK.csv"
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        shutil.copy2(source, self.provenance / "FAERS_ASC_NTS_2025Q4.pdf")

    def run(self) -> dict[str, object]:
        try:
            self.verify_inputs()
            self.build_incident_cases()
            self.build_drugs()
            self.build_events_and_outcomes()
            self.build_counts()
            return self.build_reports()
        finally:
            self.close()


def run_phase2_etl(root: str | Path) -> dict[str, object]:
    return Phase2ETL(root).run()
