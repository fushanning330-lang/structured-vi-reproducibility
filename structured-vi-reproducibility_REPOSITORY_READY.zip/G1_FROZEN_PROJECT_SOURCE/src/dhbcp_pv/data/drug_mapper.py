"""Deterministic, development-frozen FAERS drug normalization utilities."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable

import pandas as pd


SPACE = re.compile(r"\s+")
DELIMITER_CANDIDATES = (";", "|", " + ", " / ")
UNRESOLVED_PREFIX = "UNRESOLVED_NAME::"


def normalize_value(value: object) -> str:
    """NFKC-normalize, trim, uppercase and collapse Unicode whitespace."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    normalized = unicodedata.normalize("NFKC", str(value))
    return SPACE.sub(" ", normalized.strip().upper())


def profile_delimiters(values: Iterable[object]) -> list[dict[str, object]]:
    """Profile conservative candidate separators without using validation data."""
    normalized = [normalize_value(value) for value in values]
    rows: list[dict[str, object]] = []
    for delimiter in DELIMITER_CANDIDATES:
        matches = [value for value in normalized if delimiter in value]
        rows.append(
            {
                "delimiter": delimiter,
                "unique_values_with_delimiter": len(set(matches)),
                "observed": bool(matches),
                "examples": sorted(set(matches))[:10],
            }
        )
    return rows


def active_delimiters(profile: Iterable[dict[str, object]]) -> tuple[str, ...]:
    """Freeze only separators actually observed in development PROD_AI values."""
    observed = {str(row["delimiter"]) for row in profile if bool(row["observed"])}
    return tuple(delimiter for delimiter in DELIMITER_CANDIDATES if delimiter in observed)


def canonical_ingredient_set(value: object, delimiters: Iterable[str]) -> str:
    """Return a sorted unique ingredient set using a previously frozen separator list."""
    normalized = normalize_value(value)
    if not normalized:
        return ""
    delimiters = tuple(delimiters)
    if not delimiters:
        return normalized
    pattern = "(?:" + "|".join(re.escape(delimiter) for delimiter in delimiters) + ")"
    parts = sorted({part.strip(" ,") for part in re.split(pattern, normalized) if part.strip(" ,")})
    return " + ".join(parts)


def unresolved_entity(normalized_drugname: str) -> str:
    return f"{UNRESOLVED_PREFIX}{normalized_drugname or '<BLANK>'}"

