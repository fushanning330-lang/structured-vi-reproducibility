"""
V3_LOCAL_BLOCK_AR1_NO_SHARED — structured variational guide (42ZO frozen).

Frozen design (artifact 42ZO_V3_LOCAL_BLOCK_AR1_MATHEMATICAL_SPECIFICATION_FREEZE,
classification V3_LOCAL_BLOCK_AR1_MATHEMATICAL_SPECIFICATION_FROZEN; architecture
decision 42ZN POST-G2 adaptive, SHARED_FACTOR_DOMINATED localization):

    posterior over the 708-dim UNCONSTRAINED latent z:
        Sigma_V3 = B_AR1 + U_local @ U_local.T
        B_AR1 = blockdiag(diag(s[0:158]**2), B_1, ..., B_50)   # structured AR(1) residual
        B_p = S_p @ R_11(rho) @ S_p                            # per temporal pair
        R_11(rho)[i,j] = rho ** abs(i-j)                       # 11x11 AR(1) correlation
        rho = RHO_MAX * tanh(v3_raw_temporal_rho),  RHO_MAX = 0.99
        U_local = embedded [F_count_plus_initial | F_dynamic_scale | F_seriousness]
                  (708, 12); temporal_path has NO learned low-rank factor
        s = exp(effective_log_scale)
        effective_log_scale = clip(v3_diag_log_scale, -300.0, 300.0)

Canonical fitted parameters (exactly SIX; total = 2049):
    v3_loc                  (708,)
    v3_diag_log_scale       (708,)
    v3_F_count_plus_initial (120,4)
    v3_F_dynamic_scale      (16,4)
    v3_F_seriousness        (22,4)
    v3_raw_temporal_rho     scalar

NO shared global factor (v2_F_shared removed COMPLETELY and NOT replaced).
NO learned generic cross-semantic-block covariance factor.

Exact log q (Woodbury rank 12):
    A = B^-1 U_local (708x12);  K = I_12 + U_local^T A (12x12);
    delta = z - loc;  b = B^-1 delta;  v = U_local^T b;
    logdetSigma = logdetB + logdetK;
    quadratic = delta^T b - v^T K^-1 v;
    logq = -0.5 * (708*log(2pi) + logdetSigma + quadratic).
Cholesky / triangular solves ONLY; NO explicit inverse of 708x708 matrices.

Sampling representation:
    z = loc + L_B eps_B + U_local eps_U ; eps_B ~ N(0,I_708), eps_U ~ N(0,I_12);
    temporal B recurrence exactly the V2 implementation; no new stochastic
    structure.

Initialization / RNG (frozen 42ZO):
    master_key = PRNGKey(seed); prototype_key, factor_init_key, svi_init_key,
    svi_runtime_key = random.split(master_key, 4).
    factor_keys = random.split(factor_init_key, 5);  key0 = shared_reserved_unused;
    key1 = count_plus_initial; key2 = dynamic_scale; key3 = seriousness;
    key4 = temporal_reserved_unused.  Local-factor initialization uses the SAME
    deterministic factor subkeys as V2 for the same seed.
    loc: init_to_median(num_samples=5); diag scale 0.1 (log(0.1));
    local factor 0.01*Normal; raw rho 0.

Implementation rules: constraints.real_matrix for matrix factors; float64;
effective clipped log scale; AD-safe B^-1 (multiply by exp(-eff) rather than
divide); Cholesky solves, never explicit K inverse. NO SVI / NO optimization /
NO posterior inference in this file.
"""

from typing import Dict

import jax
import jax.numpy as jnp
import numpyro
from numpyro import distributions as dist
from numpyro.distributions import constraints
from numpyro.infer.autoguide import AutoContinuous

# ---------------------------------------------------------------------------
# Frozen constants (42ZO / inherited V2 42E-42F / 42H B2).
# ---------------------------------------------------------------------------
_LATENT_DIM = 708
_RHO_MAX = 0.99  # fixed numerical constant, NOT fitted
LOG_SCALE_ABS_MAX = 300.0  # implementation safety envelope (NOT a scientific bound)
_RANK_BLOCK = 4            # each local block factor has rank 4
_N_LOCAL_FACTOR_COLS = 12  # 3 blocks x 4
_T_NON_TEMPORAL = 158
_N_PAIRS = 50
_T_LEN = 11
_DIAG_SCALE_INIT = 0.1
# Frozen semantic block segments (artifact 18 / 20; identical to V2 guide).
_BLOCK_SEGMENTS: Dict[str, list] = {
    "count_plus_initial": [(0, 70), (108, 158)],   # 120
    "dynamic_scale":       [(70, 86)],             # 16
    "seriousness":         [(86, 108)],            # 22
    "temporal_path":       [(158, 708)],           # 550
}
_BLOCK_ORDER = ["count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]
_NON_PATH_BLOCKS = ["count_plus_initial", "dynamic_scale", "seriousness"]
# Frozen factor-init subkey order (artifact 25B / 42E §12 / 42ZO): split(factor_init_key, 5)
# -> [shared_reserved_unused, count_plus_initial, dynamic_scale, seriousness,
#     temporal_reserved_unused].  key1/key2/key3 are the SAME subkeys as V2.
_FACTOR_SUBKEY_ORDER = ["shared", "count_plus_initial", "dynamic_scale", "seriousness", "temporal_reserved"]
_TWO_PI_LOG = jnp.log(2.0 * jnp.pi)


def _block_index_arrays(dim: int) -> Dict[str, jnp.ndarray]:
    out = {}
    for name, segs in _BLOCK_SEGMENTS.items():
        out[name] = jnp.concatenate([jnp.arange(a, b) for a, b in segs])
    return out


def _effective_log_scale(diag_log_scale):
    """42H B2 / 42ZO: implementation safety envelope clip."""
    return jnp.clip(diag_log_scale, -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX)


# ---------------------------------------------------------------------------
# AR(1) building blocks (42E §5 / 42F §5-6; identical to V2 guide).
# ---------------------------------------------------------------------------
def _rho_from_raw(raw_rho):
    """rho = RHO_MAX * tanh(raw). Image (-0.99, 0.99)."""
    return _RHO_MAX * jnp.tanh(raw_rho)


def _r11(rho):
    """R_11(rho)[i,j] = rho ** abs(i-j), shape (11,11)."""
    i = jnp.arange(_T_LEN)
    j = jnp.arange(_T_LEN)
    return rho ** jnp.abs(i[:, None] - j[None, :])


def _tridiag_t(rho):
    """T matrix (42F §6): diag [1, 1+rho^2, ..., 1+rho^2, 1]; off-diag -rho."""
    d = jnp.ones(_T_LEN)
    d = d.at[1:-1].set(1.0 + rho ** 2)
    o = jnp.full(_T_LEN - 1, -rho)
    return jnp.diag(d) + jnp.diag(o, 1) + jnp.diag(o, -1)


def _apply_r_inv(w, rho):
    """R_11^{-1} @ w blockwise: R_11^{-1} = T / (1-rho**2)."""
    denom = 1.0 - rho ** 2
    out = jnp.zeros_like(w)
    out = out.at[..., 0].set(w[..., 0] - rho * w[..., 1])
    inner = (1.0 + rho ** 2) * w[..., 1:-1] - rho * (w[..., :-2] + w[..., 2:])
    out = out.at[..., 1:-1].set(inner)
    out = out.at[..., -1].set(-rho * w[..., -2] + w[..., -1])
    return out / denom


# ---------------------------------------------------------------------------
# Custom posterior distribution (708-dim; Sigma_V3 = B_AR1 + U_local U_local^T).
# ---------------------------------------------------------------------------
class V3LocalBlockAR1Distribution(dist.Distribution):
    """Structured V3 posterior (42ZO): Sigma = B_AR1 + U_local U_local.T.

    U_local is 708x12 (three local block factors, rank 4 each); K is 12x12;
    Woodbury via Cholesky triangular solves; AD-safe B^-1 via exp(-eff)
    multiplications; effective clipped log scale everywhere.
    """

    arg_constraints = {
        "loc": constraints.real_vector,
        "diag_log_scale": constraints.real_vector,
        "U": constraints.real_matrix,  # (708, 12) matrix-valued real constraint
        "raw_temporal_rho": constraints.real,
    }
    support = constraints.real_vector

    def __init__(self, loc, diag_log_scale, U, raw_temporal_rho, *, validate_args=None):
        self.loc = loc
        self.diag_log_scale = diag_log_scale
        self.U = U
        self.raw_temporal_rho = raw_temporal_rho
        event_shape = jnp.shape(loc)[-1:]
        batch_shape = jnp.broadcast_shapes(
            jnp.shape(loc)[:-1], jnp.shape(diag_log_scale)[:-1], jnp.shape(U)[:-2]
        )
        super().__init__(batch_shape=batch_shape, event_shape=event_shape, validate_args=validate_args)

    @property
    def has_rsample(self):
        return True

    @property
    def mean(self):
        return self.loc

    def _rho(self):
        return _rho_from_raw(self.raw_temporal_rho)

    def _effective_log_scale(self):
        return _effective_log_scale(self.diag_log_scale)

    def _s(self):
        return jnp.exp(self._effective_log_scale())

    # ---------------- reparameterized sampling (42ZO / V2 42E §8, 42F §7) -----
    def sample(self, key, sample_shape=()):
        s = self._s()
        rho = self._rho()
        key_non, key_eta, key_u = jax.random.split(key, 3)
        eps_non = jax.random.normal(key_non, sample_shape + (_T_NON_TEMPORAL,))
        eta = jax.random.normal(key_eta, sample_shape + (_N_PAIRS, _T_LEN))
        sqrt_1mr2 = jnp.sqrt(jnp.maximum(1.0 - rho ** 2, 0.0))
        y = eta[..., 0]
        ys = [y]
        for t in range(1, _T_LEN):
            y = rho * y + sqrt_1mr2 * eta[..., t]
            ys.append(y)
        y = jnp.stack(ys, axis=-1)  # (..., 50, 11)
        s_temp = jnp.reshape(s[158:708], (_N_PAIRS, _T_LEN))
        r_temp = s_temp * y
        r_temp_flat = jnp.reshape(r_temp, r_temp.shape[:-2] + (550,))
        r_non = s[0:158] * eps_non
        structured = jnp.concatenate([r_non, r_temp_flat], axis=-1)
        # low-rank local component U_local @ eps_U (rank 12)
        eps_u = jax.random.normal(key_u, sample_shape + (self.U.shape[-1],))
        z = self.loc + structured + jnp.einsum("...ij,...j->...i", self.U, eps_u)
        return z

    # ---------------- exact log_prob (Woodbury rank 12; 42ZO) ----------------
    def _b_inv_apply(self, X):
        """Blockwise B^{-1} @ X (identical structure to V2; AD-safe)."""
        inv_s = jnp.exp(-self._effective_log_scale())  # 1/s, AD-safe multiply
        rho = self._rho()
        transposed = False
        if X.ndim == 2 and X.shape[0] == 708:
            X = X.T
            transposed = True
        inv_s2_non = inv_s[0:158] ** 2
        X_non = X[..., 0:158] * inv_s2_non
        X_temp = X[..., 158:708]
        inv_s_temp = jnp.reshape(inv_s[158:708], (_N_PAIRS, _T_LEN))
        if X_temp.ndim == 1:
            w = jnp.reshape(X_temp, (_N_PAIRS, _T_LEN))
            w = w * inv_s_temp
            w = _apply_r_inv(w, rho)
            w = w * inv_s_temp
            out_temp = jnp.reshape(w, (550,))
        elif X_temp.ndim == 2:
            k = X_temp.shape[0]
            w = jnp.reshape(X_temp, (k, _N_PAIRS, _T_LEN))
            w = w * inv_s_temp[None, ...]
            w = _apply_r_inv(w, rho)
            w = w * inv_s_temp[None, ...]
            out_temp = jnp.reshape(w, (k, 550))
        else:
            lead = X_temp.shape[:-1]
            w = jnp.reshape(X_temp, lead + (_N_PAIRS, _T_LEN))
            w = w * inv_s_temp
            w = _apply_r_inv(w, rho)
            w = w * inv_s_temp
            out_temp = jnp.reshape(w, lead + (550,))
        out = jnp.concatenate([X_non, out_temp], axis=-1)
        if transposed:
            out = out.T
        return out

    @staticmethod
    def _woodbury_solve(Lk, v):
        """Solve K x = v with K = Lk Lk.T via Cholesky triangular solves only."""
        n = Lk.shape[-1]
        Lk_b = jnp.broadcast_to(Lk, v.shape[:-1] + (n, n))
        vb = v[..., None]
        w = jax.lax.linalg.triangular_solve(Lk_b, vb, left_side=True, lower=True)[..., 0]
        x = jax.lax.linalg.triangular_solve(
            Lk_b, w[..., None], left_side=True, lower=True, transpose_a=True
        )[..., 0]
        return x

    def log_prob(self, value):
        rho = self._rho()
        dls_eff = self._effective_log_scale()
        delta = value - self.loc  # (..., 708)
        # logdet(B) = 2*sum(effective_log_scale) + 50*10*log1p(-rho^2)
        logdet_b = 2.0 * jnp.sum(dls_eff, axis=-1) + (
            _N_PAIRS * (_T_LEN - 1) * jnp.log1p(-rho ** 2)
        )
        binv_delta = self._b_inv_apply(delta)
        binv_u = self._b_inv_apply(self.U)  # (708,12) -> (708,12)
        # K = I_12 + U_local^T @ B^{-1} U_local
        k_mat = jnp.eye(self.U.shape[-1]) + self.U.T @ binv_u
        Lk = jnp.linalg.cholesky(k_mat)  # 12x12
        logdet_k = 2.0 * jnp.sum(jnp.log(jnp.diag(Lk)))
        v = jnp.einsum("ij,...i->...j", self.U, binv_delta)
        x = self._woodbury_solve(Lk, v)
        quad = jnp.sum(delta * binv_delta, axis=-1) - jnp.sum(v * x, axis=-1)
        logdet_sigma = logdet_b + logdet_k
        return -0.5 * (self.event_shape[0] * _TWO_PI_LOG + logdet_sigma + quad)


# ---------------------------------------------------------------------------
# V3 guide (AutoContinuous subclass; only the posterior distribution changes).
# ---------------------------------------------------------------------------
class V3LocalBlockAR1AutoGuide(AutoContinuous):
    """V3_LOCAL_BLOCK_AR1_NO_SHARED guide (42ZO frozen).

    No shared factor parameter. U_local is 708x12. Exactly six canonical
    params (2049 elements). Local-factor init uses the SAME deterministic
    factor subkeys as V2 (split(factor_init_key, 5) -> keys 1/2/3).
    """

    def __init__(self, model, *, prefix="v3", init_loc_fn=numpyro.infer.init_to_median,
                 factor_init_key=None, **kwargs):
        super().__init__(model, prefix=prefix, init_loc_fn=init_loc_fn, **kwargs)
        self.factor_init_key = factor_init_key
        self._block_segments = _BLOCK_SEGMENTS
        self._block_order = _BLOCK_ORDER
        self._non_path_blocks = _NON_PATH_BLOCKS

    # ---- helper: build U_local (708,12) from the three local block factors ----
    @staticmethod
    def _build_u_local(F_count, F_dynamic, F_serious):
        # Embed per frozen semantic segments into a (708,12) matrix.
        U = jnp.zeros((_LATENT_DIM, _N_LOCAL_FACTOR_COLS), dtype=F_count.dtype)
        idx = _block_index_arrays(_LATENT_DIM)
        U = U.at[idx["count_plus_initial"], 0:4].set(F_count)
        U = U.at[idx["dynamic_scale"], 4:8].set(F_dynamic)
        U = U.at[idx["seriousness"], 8:12].set(F_serious)
        return U

    # ---- the ONLY replaced piece: the unconstrained 708-dim posterior dist ----
    def _get_posterior(self):
        prefix = self.prefix
        loc = numpyro.param("{}_loc".format(prefix), self._init_latent)
        diag_log_scale = numpyro.param(
            "{}_diag_log_scale".format(prefix),
            jnp.full(self.latent_dim, jnp.log(_DIAG_SCALE_INIT)),
        )
        # --- factor init (frozen RNG schedule; same 5-way split as V2) ---
        if self.factor_init_key is not None:
            fsub = jax.random.split(self.factor_init_key, 5)
            # key0 = shared_reserved_unused; key1..3 = local blocks; key4 unused.
            subkey_for = {name: fsub[i] for i, name in enumerate(_FACTOR_SUBKEY_ORDER)}
        else:
            subkey_for = None

        def make_factor_init(subkey, shape):
            return lambda _rng: 0.01 * jax.random.normal(subkey, shape)

        def make_factor_init_rng(shape):
            return lambda rng_key: 0.01 * jax.random.normal(rng_key, shape)

        # three NON-path block factors (NO shared factor; NO temporal factor)
        Fb = {}
        for name in self._non_path_blocks:
            segs = self._block_segments[name]
            dim_b = sum(b - a for a, b in segs)
            if self.factor_init_key is not None:
                init = make_factor_init(subkey_for[name], (dim_b, _RANK_BLOCK))
            else:
                init = make_factor_init_rng((dim_b, _RANK_BLOCK))
            Fb[name] = numpyro.param("{}_F_{}".format(prefix, name), init)
        U = self._build_u_local(Fb["count_plus_initial"], Fb["dynamic_scale"], Fb["seriousness"])
        # temporal rho: raw init 0.0 => rho 0.0; no RNG
        raw_rho = numpyro.param("{}_raw_temporal_rho".format(prefix), jnp.array(0.0))
        return V3LocalBlockAR1Distribution(loc, diag_log_scale, U, raw_rho)
