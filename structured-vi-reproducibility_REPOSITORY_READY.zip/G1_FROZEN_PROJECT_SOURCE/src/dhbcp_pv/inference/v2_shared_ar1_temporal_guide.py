"""
V2_SHARED_PLUS_TEMPORAL_STRUCTURED — SHARED_AR1_CORRELATION_TEMPORAL_RESIDUAL
variational guide (PROTOTYPE, deterministic implementation preflight only).

Frozen design (artifacts 42E + 42F):
    posterior over the 708-dim UNCONSTRAINED latent z:
        Sigma_V2 = B + U @ U.T
        B = blockdiag(diag(s[0:158]**2), B_1, ..., B_50)   # structured AR(1) residual
        B_p = S_p @ R_11(rho) @ S_p                        # per temporal pair
        R_11(rho)[i,j] = rho ** abs(i-j)                   # 11x11 AR(1) correlation
        rho = RHO_MAX * tanh(v2_raw_temporal_rho),  RHO_MAX = 0.99
        U = [F_shared | emb(F_count) | emb(F_dynamic) | emb(F_seriousness)]  # (708, 28)
        s = exp(v2_diag_log_scale)

Canonical fitted parameters (exactly 7; total = 13377):
    v2_loc                  (708,)
    v2_diag_log_scale       (708,)
    v2_F_shared             (708,16)
    v2_F_count_plus_initial (120,4)
    v2_F_dynamic_scale      (16,4)
    v2_F_seriousness        (22,4)
    v2_raw_temporal_rho     scalar
    NO v2_F_temporal_path.

This guide INHERITS NumPyro 0.21.0 ``AutoContinuous`` and reuses its:
  * _setup_prototype      (model inspection + latent ravel)
  * packing / unpacking   (UnpackTransform / _unpack_latent)
  * per-site support transform (biject_to(site['fn'].support))
  * Jacobian handling     (log_density = -log_abs_det_jacobian(unconstrained_value, value))
Only the unconstrained 708-dim base posterior DISTRIBUTION is replaced.

Production log_prob uses blockwise B^{-1} + analytic AR(1) logdet + Woodbury
low-rank correction (K = I_28 + U.T B^{-1} U). NO dense 708x708 inverse in
production. Dense 708 MultivariateNormal may be used ONLY as an independent
G0 oracle. NO SVI / NO optimization / NO posterior inference in this file.
"""
from typing import Dict

import jax
import jax.numpy as jnp
import numpyro
from numpyro import distributions as dist
from numpyro.distributions import constraints
from numpyro.infer.autoguide import AutoContinuous

# ---------------------------------------------------------------------------
# Frozen constants (artifacts 42E / 42F).
# ---------------------------------------------------------------------------
_LATENT_DIM = 708
_RHO_MAX = 0.99  # 42F: RHO_MAX = 0.99 (fixed numerical constant, NOT fitted)
_RANK_SHARED = 16
_RANK_BLOCK = 4
_T_NON_TEMPORAL = 158          # packed 0:158 are non-temporal coordinates
_N_PAIRS = 50
_T_LEN = 11                    # temporal block length (base_increment native [50,11])
_DIAG_SCALE_INIT = 0.1
# Frozen semantic block masks (artifact 18 packed map / artifact 20 budget).
_BLOCK_SEGMENTS: Dict[str, list] = {
    "count_plus_initial": [(0, 70), (108, 158)],   # 120
    "dynamic_scale":       [(70, 86)],             # 16
    "seriousness":         [(86, 108)],            # 22
    "temporal_path":       [(158, 708)],           # 550
}
_BLOCK_ORDER = ["count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]
# Frozen factor-init subkey order (artifact 25B / 42E §12): split(factor_init_key, 5)
# -> [shared, count_plus_initial, dynamic_scale, seriousness, temporal_reserved].
_FACTOR_SUBKEY_ORDER = ["shared", "count_plus_initial", "dynamic_scale", "seriousness", "temporal_reserved"]
_NON_PATH_BLOCKS = ["count_plus_initial", "dynamic_scale", "seriousness"]
_TWO_PI_LOG = jnp.log(2.0 * jnp.pi)


def _block_index_arrays(dim: int) -> Dict[str, jnp.ndarray]:
    out = {}
    for name, segs in _BLOCK_SEGMENTS.items():
        out[name] = jnp.concatenate([jnp.arange(a, b) for a, b in segs])
    return out


# ---------------------------------------------------------------------------
# AR(1) building blocks (42E §5 / 42F §5-6).
# ---------------------------------------------------------------------------
def _rho_from_raw(raw_rho):
    """Safe transform: rho = RHO_MAX * tanh(raw). Image (-0.99, 0.99)."""
    return _RHO_MAX * jnp.tanh(raw_rho)


def _r11(rho):
    """R_11(rho)[i,j] = rho ** abs(i-j), shape (11,11)."""
    i = jnp.arange(_T_LEN)
    j = jnp.arange(_T_LEN)
    return rho ** jnp.abs(i[:, None] - j[None, :])


def _tridiag_t(rho):
    """T matrix (42F §6): diag [1, 1+rho^2, ..., 1+rho^2, 1]; off-diag -rho."""
    d = jnp.ones(_T_LEN)
    d = d.at[1:-1].set(1.0 + rho ** 2)
    o = jnp.full(_T_LEN - 1, -rho)
    return jnp.diag(d) + jnp.diag(o, 1) + jnp.diag(o, -1)


def _apply_r_inv(w, rho):
    """R_11^{-1} @ w blockwise: w shape (..., 11) -> same shape.
    R_11^{-1} = T / (1-rho**2); T tridiagonal as in 42F §6."""
    denom = 1.0 - rho ** 2
    out = jnp.zeros_like(w)
    out = out.at[..., 0].set(w[..., 0] - rho * w[..., 1])
    inner = (1.0 + rho ** 2) * w[..., 1:-1] - rho * (w[..., :-2] + w[..., 2:])
    out = out.at[..., 1:-1].set(inner)
    out = out.at[..., -1].set(-rho * w[..., -2] + w[..., -1])
    return out / denom


# ---------------------------------------------------------------------------
# Custom posterior distribution (708-dim, reparameterized, exact log_prob).
# ---------------------------------------------------------------------------
class V2AR1TemporalDistribution(dist.Distribution):
    """Structured V2 posterior: Sigma = B + U U.T (42E §7, §8, §9; 42F)."""

    arg_constraints = {
        "loc": constraints.real_vector,
        "diag_log_scale": constraints.real_vector,
        "U": constraints.real_vector,
        "raw_temporal_rho": constraints.real,
    }
    support = constraints.real_vector

    def __init__(self, loc, diag_log_scale, U, raw_temporal_rho, *, validate_args=None):
        self.loc = loc
        self.diag_log_scale = diag_log_scale
        self.U = U
        self.raw_temporal_rho = raw_temporal_rho
        event_shape = jnp.shape(loc)[-1:]
        batch_shape = jnp.broadcast_shapes(
            jnp.shape(loc)[:-1], jnp.shape(diag_log_scale)[:-1], jnp.shape(U)[:-2]
        )
        super().__init__(batch_shape=batch_shape, event_shape=event_shape, validate_args=validate_args)

    @property
    def has_rsample(self):
        return True

    @property
    def mean(self):
        return self.loc

    def _rho(self):
        return _rho_from_raw(self.raw_temporal_rho)

    def _s(self):
        return jnp.exp(self.diag_log_scale)

    # ---------------- reparameterized sampling (42E §8 / 42F §7) ----------------
    def sample(self, key, sample_shape=()):
        s = self._s()
        rho = self._rho()
        key_non, key_eta, key_u = jax.random.split(key, 3)
        # eps_non ~ N(0, I_158)
        eps_non = jax.random.normal(key_non, sample_shape + (_T_NON_TEMPORAL,))
        # eta ~ N(0, I_[50,11])
        eta = jax.random.normal(key_eta, sample_shape + (_N_PAIRS, _T_LEN))
        # AR(1) recurrence per pair (42F §7): y_0 = eta_0;
        #   y_t = rho * y_{t-1} + sqrt(1-rho**2) * eta_t  for t=1..10
        sqrt_1mr2 = jnp.sqrt(jnp.maximum(1.0 - rho ** 2, 0.0))
        y = eta[..., 0]
        ys = [y]
        for t in range(1, _T_LEN):
            y = rho * y + sqrt_1mr2 * eta[..., t]
            ys.append(y)
        y = jnp.stack(ys, axis=-1)  # (..., 50, 11)
        # temporal residual: reshape s[158:708] -> [50,11], elementwise multiply
        s_temp = jnp.reshape(s[158:708], (_N_PAIRS, _T_LEN))
        r_temp = s_temp * y
        # flatten pair-major/time-minor (packed 158 + pair*11 + time)
        r_temp_flat = jnp.reshape(r_temp, r_temp.shape[:-2] + (550,))
        r_non = s[0:158] * eps_non
        structured = jnp.concatenate([r_non, r_temp_flat], axis=-1)
        # low-rank component U @ eps_U
        eps_u = jax.random.normal(key_u, sample_shape + (self.U.shape[-1],))
        z = self.loc + structured + jnp.einsum("...ij,...j->...i", self.U, eps_u)
        return z

    # ---------------- exact log_prob (42E §9 / 42F §5-6, §13) ----------------
    def _b_inv_apply(self, X):
        """Blockwise B^{-1} @ X.

        X may be:
          * vector delta: shape (..., 708)      (coordinate axis last)
          * low-rank factor U: shape (708, 28)  (coordinate axis first)
        Non-temporal rows are divided by s^2; each temporal block applies the
        analytic AR(1) precision (42F §6):  R_11^{-1} = T / (1 - rho**2).
        """
        s = self._s()
        rho = self._rho()
        transposed = False
        if X.ndim == 2 and X.shape[0] == 708:
            X = X.T  # (28, 708): coords last, batch/column axis first
            transposed = True
        # --- non-temporal: divide by s^2 (broadcast over trailing coord axis) ---
        s_non2 = s[0:158] ** 2
        X_non = X[..., 0:158] / s_non2
        # --- temporal: apply blockwise AR(1) precision ---
        X_temp = X[..., 158:708]
        s_temp = jnp.reshape(s[158:708], (_N_PAIRS, _T_LEN))
        if X_temp.ndim == 1:
            # vector (550,)
            w = jnp.reshape(X_temp, (_N_PAIRS, _T_LEN))
            w = w / s_temp
            w = _apply_r_inv(w, rho)
            w = w / s_temp
            out_temp = jnp.reshape(w, (550,))
        elif X_temp.ndim == 2:
            # (k, 550): k batch/column rows, time within each
            k = X_temp.shape[0]
            w = jnp.reshape(X_temp, (k, _N_PAIRS, _T_LEN))
            w = w / s_temp[None, ...]
            w = _apply_r_inv(w, rho)  # time axis last
            w = w / s_temp[None, ...]
            out_temp = jnp.reshape(w, (k, 550))
        else:
            # batched vector (..., 550)
            lead = X_temp.shape[:-1]
            w = jnp.reshape(X_temp, lead + (_N_PAIRS, _T_LEN))
            w = w / s_temp
            w = _apply_r_inv(w, rho)
            w = w / s_temp
            out_temp = jnp.reshape(w, lead + (550,))
        out = jnp.concatenate([X_non, out_temp], axis=-1)
        if transposed:
            out = out.T  # back to (708, 28)
        return out

    def log_prob(self, value):
        rho = self._rho()
        delta = value - self.loc  # (..., 708)
        # logdet(B) = 2*sum(log s) + 50*10*log1p(-rho^2)   (42E §12)
        logdet_b = 2.0 * jnp.sum(self.diag_log_scale, axis=-1) + (
            _N_PAIRS * (_T_LEN - 1) * jnp.log1p(-rho ** 2)
        )
        # B^{-1} delta
        binv_delta = self._b_inv_apply(delta)
        # B^{-1} U  (U: (708,28))
        binv_u = self._b_inv_apply(self.U)
        # K = I_28 + U.T @ B^{-1} U
        k_mat = jnp.eye(self.U.shape[-1]) + self.U.T @ binv_u
        # Cholesky of K (28x28)
        k_chol = jnp.linalg.cholesky(k_mat)
        logdet_k = 2.0 * jnp.sum(jnp.log(jnp.diag(k_chol)))
        # v = U.T @ B^{-1} delta  (broadcast over leading batch dims)
        v = jnp.einsum("ij,...i->...j", self.U, binv_delta)
        # solve K x = v (batch-compatible): K^{-1} (28x28) applied via einsum
        k_inv = jnp.linalg.inv(k_mat)
        x = jnp.einsum("ij,...j->...i", k_inv, v)
        quad = jnp.sum(delta * binv_delta, axis=-1) - jnp.sum(v * x, axis=-1)
        logdet_sigma = logdet_b + logdet_k
        return -0.5 * (self.event_shape[0] * _TWO_PI_LOG + logdet_sigma + quad)


# ---------------------------------------------------------------------------
# V2 guide (AutoContinuous subclass; only the posterior distribution changes).
# ---------------------------------------------------------------------------
class V2SharedAR1TemporalAutoGuide(AutoContinuous):
    """V2_SHARED_PLUS_TEMPORAL_STRUCTURED guide with shared AR(1) temporal
    residual (artifacts 42E + 42F)."""

    def __init__(self, model, *, prefix="v2", init_loc_fn=numpyro.infer.init_to_median,
                 factor_init_key=None, **kwargs):
        super().__init__(model, prefix=prefix, init_loc_fn=init_loc_fn, **kwargs)
        self.factor_init_key = factor_init_key
        self._block_segments = _BLOCK_SEGMENTS
        self._block_order = _BLOCK_ORDER
        self._non_path_blocks = _NON_PATH_BLOCKS

    # ---- helper: build U (708,28) from the four generic factor params ----
    @staticmethod
    def _build_u(F_shared, F_count, F_dynamic, F_serious):
        dim = F_shared.shape[0]
        U = jnp.zeros((dim, 28), dtype=F_shared.dtype)
        U = U.at[:, :16].set(F_shared)
        idx = _block_index_arrays(dim)
        U = U.at[idx["count_plus_initial"], 16:20].set(F_count)
        U = U.at[idx["dynamic_scale"], 20:24].set(F_dynamic)
        U = U.at[idx["seriousness"], 24:28].set(F_serious)
        return U

    # ---- the ONLY replaced piece: the unconstrained 708-dim posterior dist ----
    def _get_posterior(self):
        prefix = self.prefix
        loc = numpyro.param("{}_loc".format(prefix), self._init_latent)
        # Frozen init (42E §11): diag scale 0.1 => diag_log_scale = log(0.1)
        diag_log_scale = numpyro.param(
            "{}_diag_log_scale".format(prefix),
            jnp.full(self.latent_dim, jnp.log(_DIAG_SCALE_INIT)),
        )
        # --- factor init (frozen RNG schedule, 42E §12) ---
        if self.factor_init_key is not None:
            # split(factor_init_key, 5) -> [shared, count_plus_initial, dynamic_scale,
            #                              seriousness, temporal_reserved]
            fsub = jax.random.split(self.factor_init_key, 5)
            subkey_for = {name: fsub[i] for i, name in enumerate(_FACTOR_SUBKEY_ORDER)}
        else:
            subkey_for = None

        def make_factor_init(subkey, shape):
            return lambda _rng: 0.01 * jax.random.normal(subkey, shape)

        def make_factor_init_rng(shape):
            return lambda rng_key: 0.01 * jax.random.normal(rng_key, shape)

        if self.factor_init_key is not None:
            F_shared = numpyro.param(
                "{}_F_shared".format(prefix),
                make_factor_init(subkey_for["shared"], (self.latent_dim, _RANK_SHARED)),
            )
        else:
            F_shared = numpyro.param(
                "{}_F_shared".format(prefix),
                make_factor_init_rng((self.latent_dim, _RANK_SHARED)),
            )
        # three NON-path block factors (NO temporal block factor, 42E §3)
        Fb = {}
        for name in self._non_path_blocks:
            segs = self._block_segments[name]
            dim_b = sum(b - a for a, b in segs)
            if self.factor_init_key is not None:
                init = make_factor_init(subkey_for[name], (dim_b, _RANK_BLOCK))
            else:
                init = make_factor_init_rng((dim_b, _RANK_BLOCK))
            Fb[name] = numpyro.param("{}_F_{}".format(prefix, name), init)
        U = self._build_u(F_shared, Fb["count_plus_initial"], Fb["dynamic_scale"], Fb["seriousness"])
        # temporal rho (42E §5 / 42F §2): raw init 0.0 => rho 0.0; no RNG
        raw_rho = numpyro.param("{}_raw_temporal_rho".format(prefix), jnp.array(0.0))
        return V2AR1TemporalDistribution(loc, diag_log_scale, U, raw_rho)
