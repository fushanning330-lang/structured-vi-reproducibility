"""Genuine NumPyro SVI with a temporally structured Gaussian path guide."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from time import perf_counter
from typing import Any, Callable

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
import numpyro.distributions as dist
from jax import random
from numpyro import handlers
from numpyro.distributions import constraints
from numpyro.infer import Predictive, SVI, Trace_ELBO
from numpyro.infer.autoguide import AutoNormal, init_to_median
from numpyro.optim import ClippedAdam

from dhbcp_pv.models.full_joint_model import full_joint_model


PATH_SITES = ("x_initial", "base_increment")


@dataclass(frozen=True)
class SVIConfig:
    learning_rate: float = 0.015
    max_steps: int = 80
    minimum_steps: int = 30
    early_stop_patience: int = 15
    relative_tolerance: float = 1e-4
    gradient_clip_norm: float = 10.0
    num_elbo_particles: int = 1


@dataclass(frozen=True)
class StructuredSVIResult:
    params: dict[str, jnp.ndarray]
    loss_trace: np.ndarray
    initial_loss: float
    terminal_loss: float
    steps: int
    convergence_code: str
    wall_clock_seconds: float
    finite: bool
    nonfinite_gradient_or_loss_steps: int
    model_sites: tuple[str, ...]
    guide_sites: tuple[str, ...]
    site_coverage_passed: bool
    guide_family: str = "global_AutoNormal_plus_pairwise_bidiagonal_increment_MVN"
    objective: str = "numpyro.infer.Trace_ELBO"


@dataclass(frozen=True)
class RollingSVIConfig:
    max_quarters: int = 40
    initial_steps: int = 40
    updates_per_quarter: int = 4
    learning_rate: float = 0.015
    gradient_clip_norm: float = 10.0
    num_elbo_particles: int = 1
    early_stop_patience: int | None = None
    relative_tolerance: float = 1e-4
    minimum_steps_per_update: int = 1


class StructuredTimeGuide:
    """Composite guide: AutoNormal globals plus bidiagonal increment MVNs."""

    def __init__(self, model: Callable[..., Any]) -> None:
        global_model = handlers.block(model, hide=list(PATH_SITES))
        self.global_guide = AutoNormal(
            global_model,
            prefix="global",
            init_loc_fn=init_to_median(num_samples=5),
        )

    def __call__(
        self,
        y: jnp.ndarray,
        serious: jnp.ndarray,
        expected: jnp.ndarray,
        drug_index: jnp.ndarray,
        event_index: jnp.ndarray,
        n_drugs: int,
        n_events: int,
        *,
        hmax: int = 12,
        ablation: str = "FULL",
        available_through: int | None = None,
    ) -> dict[str, jnp.ndarray]:
        values = self.global_guide(
            y,
            serious,
            expected,
            drug_index,
            event_index,
            n_drugs,
            n_events,
            hmax=hmax,
            ablation=ablation,
            available_through=available_through,
        )
        n_pairs, n_quarters = y.shape
        initial_loc = numpyro.param("structured_x_initial_loc", jnp.zeros(n_pairs))
        initial_scale = numpyro.param(
            "structured_x_initial_scale",
            jnp.full(n_pairs, 0.25),
            constraint=constraints.positive,
        )
        x_initial = numpyro.sample(
            "x_initial", dist.Normal(initial_loc, initial_scale).to_event(1)
        )
        values["x_initial"] = x_initial
        if n_quarters > 1:
            length = n_quarters - 1
            increment_loc = numpyro.param(
                "structured_increment_loc", jnp.zeros((n_pairs, length))
            )
            diagonal = numpyro.param(
                "structured_increment_diagonal",
                jnp.full((n_pairs, length), 0.18),
                constraint=constraints.positive,
            )
            if length > 1:
                subdiagonal = numpyro.param(
                    "structured_increment_subdiagonal",
                    jnp.full((n_pairs, length - 1), 0.025),
                )
                lower = jax.vmap(jnp.diag)(diagonal) + jax.vmap(
                    lambda value: jnp.diag(value, k=-1)
                )(subdiagonal)
            else:
                lower = jax.vmap(jnp.diag)(diagonal)
            base_increment = numpyro.sample(
                "base_increment",
                dist.MultivariateNormal(increment_loc, scale_tril=lower).to_event(1),
            )
            values["base_increment"] = base_increment
        return values


def build_structured_guide(
    model: Callable[..., Any] = full_joint_model,
) -> StructuredTimeGuide:
    return StructuredTimeGuide(model)


@lru_cache(maxsize=160)
def _cached_primary_components(
    n_pairs: int,
    n_quarters: int,
    n_drugs: int,
    n_events: int,
    hmax: int,
    ablation: str,
    config: SVIConfig,
) -> tuple[StructuredTimeGuide, SVI]:
    """Reuse guide prototypes and compiled updates for identical formal shapes."""
    del n_pairs, n_quarters, n_drugs, n_events, hmax, ablation
    guide = build_structured_guide(full_joint_model)
    optimizer = ClippedAdam(
        step_size=config.learning_rate,
        clip_norm=config.gradient_clip_norm,
    )
    svi = SVI(
        full_joint_model,
        guide,
        optimizer,
        Trace_ELBO(num_particles=config.num_elbo_particles),
    )
    return guide, svi


@lru_cache(maxsize=160)
def _cached_stable_full_run(
    n_pairs: int,
    n_quarters: int,
    n_drugs: int,
    n_events: int,
    hmax: int,
    ablation: str,
    available_through: int | None,
    config: SVIConfig,
):
    """Compile one exact bounded/early-stopped SVI scan per formal shape.

    The model data are dynamic arguments, so all replicates with the same
    shape reuse the same executable.  Once the frozen early-stop rule fires,
    remaining scan slots are strict no-ops and do not advance the optimizer.
    """
    guide, svi = _cached_primary_components(
        n_pairs,
        n_quarters,
        n_drugs,
        n_events,
        hmax,
        ablation,
        config,
    )

    def run(
        state,
        y,
        serious,
        expected,
        drug_index,
        event_index,
    ):
        initial = (
            state,
            jnp.asarray(jnp.inf),
            jnp.asarray(0, dtype=jnp.int32),
            jnp.asarray(True),
            jnp.asarray(0, dtype=jnp.int32),
            jnp.asarray(0, dtype=jnp.int32),
            jnp.asarray(jnp.nan),
        )

        def body(carry, _):
            def active_branch(current):
                current_state, best, stale, _, steps, nonfinite, _ = current
                new_state, loss = svi.stable_update(
                    current_state,
                    y,
                    serious,
                    expected,
                    drug_index,
                    event_index,
                    n_drugs,
                    n_events,
                    hmax=hmax,
                    ablation=ablation,
                    available_through=available_through,
                )
                finite = jnp.isfinite(loss)
                relative = jnp.where(
                    jnp.isfinite(best),
                    (best - loss) / jnp.maximum(jnp.abs(best), 1.0),
                    jnp.inf,
                )
                new_best = jnp.minimum(best, loss)
                eligible = steps + 1 >= config.minimum_steps
                new_stale = jnp.where(
                    eligible,
                    jnp.where(relative > config.relative_tolerance, 0, stale + 1),
                    stale,
                )
                stopped = eligible & (new_stale >= config.early_stop_patience)
                new_carry = (
                    new_state,
                    new_best,
                    new_stale,
                    finite & ~stopped,
                    steps + 1,
                    nonfinite + (~finite).astype(jnp.int32),
                    loss,
                )
                return new_carry, (loss, jnp.asarray(True))

            def inactive_branch(current):
                return current, (current[-1], jnp.asarray(False))

            return jax.lax.cond(carry[3], active_branch, inactive_branch, carry)

        final, outputs = jax.lax.scan(body, initial, None, length=config.max_steps)
        return final, outputs

    return guide, svi, jax.jit(run)


def _sample_site_names(trace: dict[str, dict[str, Any]]) -> tuple[str, ...]:
    return tuple(
        sorted(
            name
            for name, site in trace.items()
            if site["type"] == "sample" and not site.get("is_observed", False)
        )
    )


def latent_site_coverage(
    model: Callable[..., Any],
    guide: Callable[..., Any],
    rng_key: jax.Array,
    *args: Any,
    **kwargs: Any,
) -> tuple[tuple[str, ...], tuple[str, ...], bool]:
    model_trace = handlers.trace(handlers.seed(model, rng_key)).get_trace(*args, **kwargs)
    guide_trace = handlers.trace(handlers.seed(guide, random.fold_in(rng_key, 1))).get_trace(
        *args, **kwargs
    )
    model_sites = _sample_site_names(model_trace)
    guide_sites = _sample_site_names(guide_trace)
    return model_sites, guide_sites, set(model_sites) == set(guide_sites)


def run_structured_svi(
    rng_key: jax.Array,
    y: jnp.ndarray,
    serious: jnp.ndarray,
    expected: jnp.ndarray,
    drug_index: jnp.ndarray,
    event_index: jnp.ndarray,
    n_drugs: int,
    n_events: int,
    *,
    hmax: int = 12,
    ablation: str = "FULL",
    available_through: int | None = None,
    config: SVIConfig = SVIConfig(),
    model: Callable[..., Any] = full_joint_model,
) -> StructuredSVIResult:
    """Optimize an actual Trace_ELBO and return learned variational parameters."""
    if model is full_joint_model:
        guide, svi, stable_full_run = _cached_stable_full_run(
            int(y.shape[0]),
            int(y.shape[1]),
            n_drugs,
            n_events,
            hmax,
            ablation,
            available_through,
            config,
        )
    else:
        guide = build_structured_guide(model)
        optimizer = ClippedAdam(
            step_size=config.learning_rate,
            clip_norm=config.gradient_clip_norm,
        )
        svi = SVI(
            model,
            guide,
            optimizer,
            Trace_ELBO(num_particles=config.num_elbo_particles),
        )
        stable_full_run = None
    args = (
        jnp.asarray(y),
        jnp.asarray(serious),
        jnp.asarray(expected),
        jnp.asarray(drug_index),
        jnp.asarray(event_index),
        n_drugs,
        n_events,
    )
    kwargs = {
        "hmax": hmax,
        "ablation": ablation,
        "available_through": available_through,
    }
    started = perf_counter()
    state = svi.init(rng_key, *args, **kwargs)
    if stable_full_run is not None:
        final, outputs = stable_full_run(state, *args[:5])
        state = final[0]
        steps = int(final[4])
        nonfinite_gradient_or_loss_steps = int(final[5])
        losses = np.asarray(outputs[0])[:steps]
    else:
        loss_values: list[float] = []
        best = np.inf
        stale = 0
        nonfinite_gradient_or_loss_steps = 0
        for step in range(config.max_steps):
            state, loss = svi.stable_update(state, *args, **kwargs)
            value = float(loss)
            loss_values.append(value)
            if not np.isfinite(value):
                nonfinite_gradient_or_loss_steps += 1
                break
            relative = (
                (best - value) / max(abs(best), 1.0) if np.isfinite(best) else np.inf
            )
            if value < best:
                best = value
            if step + 1 >= config.minimum_steps:
                if relative > config.relative_tolerance:
                    stale = 0
                else:
                    stale += 1
                if stale >= config.early_stop_patience:
                    break
        losses = np.asarray(loss_values)
        steps = len(losses)
    if nonfinite_gradient_or_loss_steps:
        convergence_code = "NONFINITE_LOSS_OR_GRADIENT"
    elif steps < config.max_steps:
        convergence_code = "EARLY_STOP_RELATIVE_LOSS"
    else:
        convergence_code = "MAX_STEPS"
    params = svi.get_params(state)
    jax.block_until_ready(jax.tree.leaves(params)[0])
    finite_params = all(bool(jnp.isfinite(value).all()) for value in jax.tree.leaves(params))
    model_sites, guide_sites, coverage = latent_site_coverage(
        model, guide, random.fold_in(rng_key, 2), *args, **kwargs
    )
    finite = bool(len(losses) and np.isfinite(losses).all() and finite_params and coverage)
    return StructuredSVIResult(
        params=params,
        loss_trace=losses,
        initial_loss=float(losses[0]),
        terminal_loss=float(losses[-1]),
        steps=steps,
        convergence_code=convergence_code,
        wall_clock_seconds=perf_counter() - started,
        finite=finite,
        nonfinite_gradient_or_loss_steps=nonfinite_gradient_or_loss_steps,
        model_sites=model_sites,
        guide_sites=guide_sites,
        site_coverage_passed=coverage,
    )


def sample_structured_posterior(
    rng_key: jax.Array,
    params: dict[str, jnp.ndarray],
    y: jnp.ndarray,
    serious: jnp.ndarray,
    expected: jnp.ndarray,
    drug_index: jnp.ndarray,
    event_index: jnp.ndarray,
    n_drugs: int,
    n_events: int,
    *,
    num_samples: int = 64,
    hmax: int = 12,
    ablation: str = "FULL",
    available_through: int | None = None,
    model: Callable[..., Any] = full_joint_model,
) -> dict[str, jnp.ndarray]:
    """Draw continuous posterior samples from the learned composite guide."""
    guide = build_structured_guide(model)
    predictive = Predictive(guide, params=params, num_samples=num_samples)
    return predictive(
        rng_key,
        jnp.asarray(y),
        jnp.asarray(serious),
        jnp.asarray(expected),
        jnp.asarray(drug_index),
        jnp.asarray(event_index),
        n_drugs,
        n_events,
        hmax=hmax,
        ablation=ablation,
        available_through=available_through,
    )


def structured_covariance_diagnostics(
    params: dict[str, jnp.ndarray],
) -> dict[str, float | bool]:
    diagonal = np.asarray(params["structured_increment_diagonal"])
    subdiagonal = np.asarray(params.get("structured_increment_subdiagonal", np.zeros((1, 0))))
    positive = bool((diagonal > 0).all())
    nonzero_offdiagonal = bool(subdiagonal.size and np.any(np.abs(subdiagonal) > 1e-8))
    minimum_eigenvalue = np.inf
    for pair in range(min(len(diagonal), 20)):
        lower = np.diag(diagonal[pair])
        if subdiagonal.shape[-1]:
            lower += np.diag(subdiagonal[pair], k=-1)
        covariance = lower @ lower.T
        minimum_eigenvalue = min(minimum_eigenvalue, float(np.linalg.eigvalsh(covariance).min()))
    return {
        "diagonal_positive": positive,
        "nonzero_permitted_offdiagonal": nonzero_offdiagonal,
        "minimum_covariance_eigenvalue": float(minimum_eigenvalue),
        "positive_definite": bool(minimum_eigenvalue > 0),
    }


class RollingPrefixSVI:
    """Stateful prefix-only optimizer with fixed internal prior padding.

    The public update method accepts exactly quarters 1..t.  Prior-only latent
    padding keeps parameter shapes fixed for warm starts; no future observation
    array can enter the API.
    """

    def __init__(
        self,
        rng_key: jax.Array,
        n_pairs: int,
        drug_index: jnp.ndarray,
        event_index: jnp.ndarray,
        n_drugs: int,
        n_events: int,
        *,
        hmax: int = 12,
        ablation: str = "FULL",
        config: RollingSVIConfig = RollingSVIConfig(),
    ) -> None:
        self.rng_key = rng_key
        self.n_pairs = n_pairs
        self.drug_index = jnp.asarray(drug_index)
        self.event_index = jnp.asarray(event_index)
        self.n_drugs = n_drugs
        self.n_events = n_events
        self.hmax = hmax
        self.ablation = ablation
        self.config = config
        svi_config = SVIConfig(
            learning_rate=config.learning_rate,
            max_steps=max(config.initial_steps, config.updates_per_quarter),
            minimum_steps=1,
            early_stop_patience=10_000,
            gradient_clip_norm=config.gradient_clip_norm,
            num_elbo_particles=config.num_elbo_particles,
        )
        self.guide, self.svi = _cached_primary_components(
            n_pairs,
            config.max_quarters,
            n_drugs,
            n_events,
            hmax,
            ablation,
            svi_config,
        )
        self.state = None
        self.available_through = 0
        self.loss_by_prefix: list[list[float]] = []
        self.total_optimization_seconds = 0.0

    def _pad(
        self,
        y_prefix: np.ndarray,
        serious_prefix: np.ndarray,
        expected_prefix: np.ndarray,
    ) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
        y_prefix = np.asarray(y_prefix)
        serious_prefix = np.asarray(serious_prefix)
        expected_prefix = np.asarray(expected_prefix)
        if y_prefix.ndim != 2 or y_prefix.shape[0] != self.n_pairs:
            raise ValueError("prefix arrays must have shape [configured pairs, available quarters]")
        if serious_prefix.shape != y_prefix.shape or expected_prefix.shape != y_prefix.shape:
            raise ValueError("all prefix arrays must share shape")
        if y_prefix.shape[1] > self.config.max_quarters:
            raise ValueError("future arrays exceed the frozen maximum quarter count")
        if np.any(serious_prefix < 0) or np.any(serious_prefix > y_prefix):
            raise ValueError("serious counts must satisfy 0 <= serious <= y")
        if np.any(expected_prefix <= 0):
            raise ValueError("expected count offsets must be positive")
        remaining = self.config.max_quarters - y_prefix.shape[1]
        y = np.pad(y_prefix, ((0, 0), (0, remaining)), constant_values=0)
        serious = np.pad(serious_prefix, ((0, 0), (0, remaining)), constant_values=0)
        expected = np.pad(expected_prefix, ((0, 0), (0, remaining)), constant_values=1.0)
        return jnp.asarray(y), jnp.asarray(serious), jnp.asarray(expected)

    def update_prefix(
        self,
        y_prefix: np.ndarray,
        serious_prefix: np.ndarray,
        expected_prefix: np.ndarray,
    ) -> list[float]:
        available = int(np.asarray(y_prefix).shape[1])
        if available != self.available_through + 1:
            raise ValueError(
                "rolling prefix must advance exactly one quarter and cannot import future data"
            )
        y, serious, expected = self._pad(y_prefix, serious_prefix, expected_prefix)
        args = (
            y,
            serious,
            expected,
            self.drug_index,
            self.event_index,
            self.n_drugs,
            self.n_events,
        )
        kwargs = {
            "hmax": self.hmax,
            "ablation": self.ablation,
            "available_through": available,
        }
        self.rng_key, init_key = random.split(self.rng_key)
        if self.state is None:
            self.state = self.svi.init(init_key, *args, **kwargs)
            steps = self.config.initial_steps
        else:
            steps = self.config.updates_per_quarter
        started = perf_counter()
        losses = []
        best = np.inf
        stale = 0
        for step in range(steps):
            self.state, loss = self.svi.stable_update(self.state, *args, **kwargs)
            value = float(loss)
            if not np.isfinite(value):
                raise FloatingPointError(
                    f"non-finite SVI loss or gradient at prefix {available}"
                )
            losses.append(value)
            relative = (
                (best - value) / max(abs(best), 1.0) if np.isfinite(best) else np.inf
            )
            if value < best:
                best = value
            patience = self.config.early_stop_patience
            if patience is not None and step + 1 >= self.config.minimum_steps_per_update:
                if relative > self.config.relative_tolerance:
                    stale = 0
                else:
                    stale += 1
                if stale >= patience:
                    break
        self.total_optimization_seconds += perf_counter() - started
        self.available_through = available
        self.loss_by_prefix.append(losses)
        return losses

    @property
    def params(self) -> dict[str, jnp.ndarray]:
        if self.state is None:
            raise RuntimeError("no prefix has been optimized")
        return self.svi.get_params(self.state)

    def posterior_samples(
        self,
        y_prefix: np.ndarray,
        serious_prefix: np.ndarray,
        expected_prefix: np.ndarray,
        *,
        num_samples: int = 64,
    ) -> dict[str, jnp.ndarray]:
        available = int(np.asarray(y_prefix).shape[1])
        if available != self.available_through:
            raise ValueError("posterior sampling is allowed only for the optimized current prefix")
        y, serious, expected = self._pad(y_prefix, serious_prefix, expected_prefix)
        self.rng_key, sample_key = random.split(self.rng_key)
        predictive = Predictive(self.guide, params=self.params, num_samples=num_samples)
        samples = predictive(
            sample_key,
            y,
            serious,
            expected,
            self.drug_index,
            self.event_index,
            self.n_drugs,
            self.n_events,
            hmax=self.hmax,
            ablation=self.ablation,
            available_through=available,
        )
        # Return only latent path dimensions that existed through t.  The
        # internal prior padding is not an observed/future operational output.
        samples["base_increment"] = samples["base_increment"][..., : max(available - 1, 0)]
        return samples

    def checkpoint_metadata(self) -> dict[str, object]:
        return {
            "available_through": self.available_through,
            "prefixes_complete": len(self.loss_by_prefix),
            "last_loss": self.loss_by_prefix[-1][-1] if self.loss_by_prefix else None,
            "loss_trace_by_prefix": self.loss_by_prefix,
            "convergence_code": "FROZEN_STEP_SCHEDULE_COMPLETE",
            "optimizer_state_present": self.state is not None,
            "rng_state": np.asarray(random.key_data(self.rng_key)).tolist(),
            "optimization_seconds": self.total_optimization_seconds,
        }
