"""Phase 3C.2 target-preserving temporal level/contrast coordinates."""

from __future__ import annotations

import jax.numpy as jnp
import numpyro
import numpyro.distributions as dist
from numpyro import handlers

from dhbcp_pv.models.full_joint_model import full_joint_model

LEVEL_PROPOSAL_SD = 1.0
CONTRAST_PROPOSAL_SD = 1.0


def helmert_level_contrast_basis(n_quarters: int, dtype=jnp.float64):
    """Return u and Q where [u,Q] is an orthogonal Helmert matrix.

    u = 1/sqrt(T) and columns of Q are orthonormal zero-sum contrasts.
    """
    if n_quarters < 1:
        raise ValueError("n_quarters must be >= 1")
    t = int(n_quarters)
    u = jnp.ones((t,), dtype=dtype) / jnp.sqrt(jnp.asarray(t, dtype=dtype))
    if t == 1:
        return u, jnp.zeros((1, 0), dtype=dtype)

    cols = []
    for j in range(t - 1):
        denom = jnp.sqrt(jnp.asarray((j + 1) * (j + 2), dtype=dtype))
        col = jnp.zeros((t,), dtype=dtype)
        col = col.at[: j + 1].set(1.0 / denom)
        col = col.at[j + 1].set(-(j + 1) / denom)
        cols.append(col)
    q = jnp.stack(cols, axis=1)
    return u, q


def level_contrast_to_path(level_coord, contrast_coord):
    level_coord = jnp.asarray(level_coord)
    contrast_coord = jnp.asarray(contrast_coord)
    t = int(contrast_coord.shape[-1]) + 1
    u, q = helmert_level_contrast_basis(t, dtype=level_coord.dtype)
    return level_coord[..., None] * u + jnp.matmul(contrast_coord, q.T)


def path_to_level_contrast(x_path):
    x_path = jnp.asarray(x_path)
    t = int(x_path.shape[-1])
    u, q = helmert_level_contrast_basis(t, dtype=x_path.dtype)
    level = jnp.sum(x_path * u, axis=-1)
    if t == 1:
        contrast = jnp.zeros(x_path.shape[:-1] + (0,), dtype=x_path.dtype)
    else:
        contrast = jnp.matmul(x_path, q)
    return level, contrast


def path_to_original_coordinates(x_path):
    x_path = jnp.asarray(x_path)
    x_initial = x_path[..., 0]
    if x_path.shape[-1] == 1:
        increment = jnp.zeros(x_path.shape[:-1] + (0,), dtype=x_path.dtype)
    else:
        increment = x_path[..., 1:] - x_path[..., :-1]
    return x_initial, increment


def original_coordinates_to_level_contrast(x_initial, base_increment):
    x_initial = jnp.asarray(x_initial)
    base_increment = jnp.asarray(base_increment)
    if base_increment.shape[-1] == 0:
        x_path = x_initial[..., None]
    else:
        x_path = jnp.concatenate(
            [
                x_initial[..., None],
                x_initial[..., None] + jnp.cumsum(base_increment, axis=-1),
            ],
            axis=-1,
        )
    level, contrast = path_to_level_contrast(x_path)
    return level, contrast, x_path


def level_contrast_reference_model(
    y,
    serious,
    expected,
    drug_index,
    event_index,
    n_drugs: int,
    n_events: int,
    *,
    hmax: int = 12,
    ablation: str = "FULL",
    available_through: int | None = None,
):
    """Target-preserving wrapper around the unchanged full_joint_model."""
    if available_through is not None:
        raise ValueError(
            "Phase3C.2 reference wrapper requires a physically truncated prefix; "
            "available_through must be None."
        )

    y = jnp.asarray(y)
    n_pairs, n_quarters = y.shape

    level_proposal = dist.Normal(0.0, LEVEL_PROPOSAL_SD)
    contrast_proposal = dist.Normal(0.0, CONTRAST_PROPOSAL_SD)

    path_level_coord = numpyro.sample(
        "path_level_coord",
        level_proposal.expand([n_pairs]).to_event(1),
    )
    if n_quarters > 1:
        path_contrast_coord = numpyro.sample(
            "path_contrast_coord",
            contrast_proposal.expand([n_pairs, n_quarters - 1]).to_event(2),
        )
    else:
        path_contrast_coord = jnp.zeros((n_pairs, 0), dtype=y.dtype)

    x_path = level_contrast_to_path(path_level_coord, path_contrast_coord)
    x_initial, base_increment = path_to_original_coordinates(x_path)

    conditioned = handlers.condition(
        full_joint_model,
        data={"x_initial": x_initial, "base_increment": base_increment},
    )
    conditioned(
        y,
        serious,
        expected,
        drug_index,
        event_index,
        n_drugs,
        n_events,
        hmax=hmax,
        ablation=ablation,
        available_through=None,
    )

    proposal_log_density = jnp.sum(level_proposal.log_prob(path_level_coord))
    if n_quarters > 1:
        proposal_log_density = proposal_log_density + jnp.sum(
            contrast_proposal.log_prob(path_contrast_coord)
        )
    numpyro.factor(
        "level_contrast_auxiliary_proposal_correction",
        -proposal_log_density,
    )

    numpyro.deterministic("phase3c2_x_path", x_path)
