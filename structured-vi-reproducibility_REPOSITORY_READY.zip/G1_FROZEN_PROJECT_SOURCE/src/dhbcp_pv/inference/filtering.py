"""Operational rolling-prefix filtering; smoothing is deliberately excluded."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import jax
import jax.numpy as jnp
import numpy as np
from scipy.special import ndtr

from dhbcp_pv.decision.loss import expected_loss_priority
from dhbcp_pv.inference.structured_vi import StructuredVIResult, fit_structured_vi
from dhbcp_pv.models.hsmm import forward_filter, substantive_transition_matrix
from dhbcp_pv.models.joint_model import (
    DEFAULT_DURATION_MEANS,
    DEFAULT_DURATION_SHAPES,
    joint_emission_log_likelihood,
    seriousness_probability,
)
from dhbcp_pv.models.smoothing import HSMMSmoothingResult, forward_backward_smoother


@dataclass(frozen=True)
class OperationalFilterResult:
    x_mean: np.ndarray
    x_sd: np.ndarray
    state_probability: np.ndarray
    p_change: np.ndarray
    p_persist_h2: np.ndarray
    p_serious: np.ndarray
    delta_expected_loss: np.ndarray
    score: np.ndarray
    alert: np.ndarray
    elbo_trace: np.ndarray
    prefix_log_marginal: np.ndarray
    operational_filtering: bool
    guide: StructuredVIResult


@dataclass(frozen=True)
class BatchOperationalFilterResult:
    x_mean: np.ndarray
    x_sd: np.ndarray
    state_probability: np.ndarray
    p_change: np.ndarray
    p_persist_h2: np.ndarray
    p_serious: np.ndarray
    delta_expected_loss: np.ndarray
    score: np.ndarray
    alert: np.ndarray
    operational_filtering: bool = True


@lru_cache(maxsize=3)
def _compiled_batch_hsmm(hmax: int):
    def one(emission: jnp.ndarray):
        result = forward_filter(
            emission,
            DEFAULT_DURATION_MEANS,
            DEFAULT_DURATION_SHAPES,
            substantive_transition_matrix(),
            hmax=hmax,
            persistence_horizon=2,
        )
        return (
            result.filtered_state_probability,
            result.substantive_change_probability,
            result.persistence_probability_h2,
        )

    return jax.jit(jax.vmap(one))


def _batch_gaussian_guide(y: np.ndarray, expected: np.ndarray, phi: float) -> tuple[np.ndarray, np.ndarray]:
    n_pairs, n_quarters = y.shape
    x_mean = np.zeros((n_pairs, n_quarters), dtype=float)
    x_variance = np.zeros((n_pairs, n_quarters), dtype=float)
    previous_mean = np.zeros(n_pairs)
    previous_variance = np.full(n_pairs, 0.35**2)
    for quarter in range(n_quarters):
        prior_mean = np.zeros(n_pairs) if quarter == 0 else previous_mean
        prior_variance = np.full(n_pairs, 0.35**2) if quarter == 0 else previous_variance + 0.20**2
        observation = np.log((y[:, quarter] + 0.5) / (expected[:, quarter] + 0.5))
        observation_variance = 1.0 / (y[:, quarter] + 0.5) + 1.0 / phi
        gain = prior_variance / (prior_variance + observation_variance)
        previous_mean = prior_mean + gain * (observation - prior_mean)
        previous_variance = np.maximum((1.0 - gain) * prior_variance, 1e-10)
        x_mean[:, quarter] = previous_mean
        x_variance[:, quarter] = previous_variance
    return x_mean, np.sqrt(x_variance)


def batch_operational_filter(
    y: np.ndarray,
    serious: np.ndarray,
    expected: np.ndarray,
    *,
    hmax: int = 12,
    phi: float = 10.0,
    fn_cost: float = 5.0,
    fp_cost: float = 1.0,
    lambda_severity: float = 1.0,
) -> BatchOperationalFilterResult:
    """Vectorized formal-simulation path with the same prefix-only guide and exact HSMM."""
    y = np.asarray(y, dtype=float)
    serious = np.asarray(serious, dtype=float)
    expected = np.asarray(expected, dtype=float)
    if y.ndim != 2 or y.shape != serious.shape or y.shape != expected.shape:
        raise ValueError("batch arrays must share shape [pairs, quarters]")
    if np.any(serious < 0) or np.any(serious > y) or np.any(expected <= 0):
        raise ValueError("invalid batch counts")
    x_mean, x_sd = _batch_gaussian_guide(y, expected, phi)
    emission = jax.vmap(joint_emission_log_likelihood)(
        jnp.asarray(x_mean), jnp.asarray(y), jnp.asarray(serious)
    )
    state_probability, p_change, p_persist = _compiled_batch_hsmm(hmax)(emission)
    state_probability = np.asarray(state_probability)
    p_change = np.asarray(p_change)
    p_persist = np.asarray(p_persist)
    state_seriousness = np.asarray(jax.vmap(seriousness_probability)(jnp.asarray(x_mean)))
    p_serious = np.sum(state_probability * state_seriousness, axis=2)
    p_x_positive = ndtr(x_mean / np.maximum(x_sd, 1e-10))
    p_dangerous = (state_probability[:, :, 1] + state_probability[:, :, 2]) * p_x_positive
    delta = expected_loss_priority(
        p_dangerous,
        p_serious,
        fn_cost=fn_cost,
        fp_cost=fp_cost,
        lambda_severity=lambda_severity,
    )
    if not all(
        np.isfinite(array).all()
        for array in (x_mean, x_sd, state_probability, p_change, p_persist, p_serious, delta)
    ):
        raise FloatingPointError("non-finite batch posterior")
    if not np.allclose(state_probability.sum(axis=2), 1.0, atol=2e-6):
        raise FloatingPointError("batch state probabilities are not normalized")
    return BatchOperationalFilterResult(
        x_mean=x_mean,
        x_sd=x_sd,
        state_probability=state_probability,
        p_change=p_change,
        p_persist_h2=p_persist,
        p_serious=p_serious,
        delta_expected_loss=np.asarray(delta),
        score=np.asarray(delta),
        alert=np.asarray(delta) > 0.0,
    )


def operational_filter(
    y: np.ndarray,
    serious: np.ndarray,
    expected: np.ndarray,
    *,
    hmax: int = 12,
    phi: float = 10.0,
    fn_cost: float = 5.0,
    fp_cost: float = 1.0,
    lambda_severity: float = 1.0,
    operational: bool = True,
    full_sequence_smoothing: bool = False,
) -> OperationalFilterResult:
    """Run the production guide followed by exact discrete HSMM filtering."""
    if not operational or full_sequence_smoothing:
        raise ValueError("operational output requires rolling-prefix filtering; smoothing is diagnostic only")
    y = np.asarray(y, dtype=float)
    serious = np.asarray(serious, dtype=float)
    expected = np.asarray(expected, dtype=float)
    if y.shape != serious.shape or y.shape != expected.shape:
        raise ValueError("y, serious and expected must have identical shapes")
    if np.any(serious > y) or np.any(serious < 0):
        raise ValueError("serious report count must satisfy 0 <= serious <= y")
    guide = fit_structured_vi(y, expected, phi=phi)
    emission = joint_emission_log_likelihood(
        jnp.asarray(guide.x_mean), jnp.asarray(y), jnp.asarray(serious)
    )
    hsmm = forward_filter(
        emission,
        DEFAULT_DURATION_MEANS,
        DEFAULT_DURATION_SHAPES,
        substantive_transition_matrix(),
        hmax=hmax,
        persistence_horizon=2,
    )
    state_probability = np.asarray(hsmm.filtered_state_probability)
    state_seriousness = np.asarray(seriousness_probability(jnp.asarray(guide.x_mean)))
    p_serious = np.sum(state_probability * state_seriousness, axis=1)
    # The frozen decision rule requires both an E/P state and x>0.  The
    # structured Gaussian guide supplies the latter probability.
    p_x_positive = ndtr(guide.x_mean / np.maximum(guide.x_sd, 1e-10))
    p_dangerous = (state_probability[:, 1] + state_probability[:, 2]) * p_x_positive
    delta = expected_loss_priority(
        p_dangerous,
        p_serious,
        fn_cost=fn_cost,
        fp_cost=fp_cost,
        lambda_severity=lambda_severity,
    )
    prefix_log_marginal = np.asarray(hsmm.prefix_log_marginal)
    elbo_trace = guide.surrogate_elbo_trace + prefix_log_marginal
    arrays = (
        guide.x_mean,
        guide.x_sd,
        state_probability,
        hsmm.substantive_change_probability,
        hsmm.persistence_probability_h2,
        p_serious,
        delta,
        elbo_trace,
    )
    if not all(np.isfinite(np.asarray(array)).all() for array in arrays):
        raise FloatingPointError("non-finite operational posterior output")
    if not np.allclose(state_probability.sum(axis=1), 1.0, atol=2e-6):
        raise FloatingPointError("filtered state probabilities are not normalized")
    return OperationalFilterResult(
        x_mean=guide.x_mean,
        x_sd=guide.x_sd,
        state_probability=state_probability,
        p_change=np.asarray(hsmm.substantive_change_probability),
        p_persist_h2=np.asarray(hsmm.persistence_probability_h2),
        p_serious=p_serious,
        delta_expected_loss=np.asarray(delta),
        score=np.asarray(delta),
        alert=np.asarray(delta) > 0.0,
        elbo_trace=elbo_trace,
        prefix_log_marginal=prefix_log_marginal,
        operational_filtering=True,
        guide=guide,
    )


def fit_or_update_filtering_prefix(
    y_prefix: np.ndarray,
    serious_prefix: np.ndarray,
    expected_prefix: np.ndarray,
    *,
    available_through: int,
    **kwargs: object,
) -> OperationalFilterResult:
    """Guarded operational API that cannot accept hidden future-quarter arrays."""
    if len(y_prefix) != available_through:
        raise ValueError("operational prefix length must equal available_through; future arrays rejected")
    return operational_filter(y_prefix, serious_prefix, expected_prefix, **kwargs)


def fit_smoothing_full_sequence(
    y: np.ndarray,
    serious: np.ndarray,
    expected: np.ndarray,
    hmax: int = 12,
    phi: float = 10.0,
) -> HSMMSmoothingResult:
    """True diagnostic forward-backward smoother, excluded from formal metrics."""
    guide = fit_structured_vi(y, expected, phi=phi)
    emission = joint_emission_log_likelihood(
        jnp.asarray(guide.x_mean), jnp.asarray(y), jnp.asarray(serious)
    )
    return forward_backward_smoother(
        emission,
        DEFAULT_DURATION_MEANS,
        DEFAULT_DURATION_SHAPES,
        substantive_transition_matrix(),
        hmax=hmax,
    )
