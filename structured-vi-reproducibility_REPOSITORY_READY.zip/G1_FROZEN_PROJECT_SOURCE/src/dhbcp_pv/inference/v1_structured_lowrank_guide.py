"""
V1_SHARED_PLUS_BLOCK_LOW_RANK — structured low-rank variational guide (PROTOTYPE).

Frozen design (artifacts 22 / 23 / 23A):
    posterior over the 708-dim UNCONSTRAINED latent z:
        z ~ LowRankMultivariateNormal(loc, cov_factor=F_total, cov_diag=scale_diag**2)
        covariance:  Sigma = cov_diag + F_total @ F_total.T
        where  cov_diag = scale_diag**2 ;  scale_diag = exp(diag_log_scale)
        F_total = [F_shared | M_count@F_count | M_dynamic@F_dynamic
                            | M_serious@F_serious | M_path@F_path]      # (708, 32)

This guide INHERITS NumPyro 0.21.0 ``AutoContinuous`` and reuses its:
  * ``_setup_prototype``      (model inspection + latent ravel)
  * packing / unpacking       (``UnpackTransform`` / ``self._unpack_latent``)
  * per-site support transform (``biject_to(site['fn'].support)``)
  * Jacobian handling         (``log_density = -log_abs_det_jacobian(unconstrained_value, value)``)

Only the unconstrained 708-dim base posterior DISTRIBUTION is replaced.
We do NOT hand-roll 24 Delta-site transforms/Jacobians.

Per artifact 23A:
  * support transform is FORWARD:  ``value = transform(unconstrained_value)``  (NOT ``.inv``)
  * diagonal residual:  ``scale_diag = exp(diag_log_scale)`` ;  ``D = diag(scale_diag**2)``

NO SVI / NO optimization / NO NeuTra / NO MCMC / NO posterior sampling here.
This file is a prototype for offline deterministic design review only.
"""

from typing import Dict

import jax
import jax.numpy as jnp
import numpyro
from numpyro import distributions as dist
from numpyro.infer.autoguide import AutoContinuous

# ---------------------------------------------------------------------------
# Frozen semantic block masks.
# Source: the frozen packed-latent map (artifact 18) and the frozen
#         variance-budget review (artifact 20). These are the SCIENTIFIC-MODEL
#         semantic blocks. They are NOT derived from any principal-component
#         analysis of the failed inference chain. Do not replace with
#         data-driven masks.
# ---------------------------------------------------------------------------
_BLOCK_SEGMENTS: Dict[str, list] = {
    "count_plus_initial": [(0, 70), (108, 158)],   # 120  (mu..raw_pair, x_initial)
    "dynamic_scale":       [(70, 86)],             # 16   (delta_*..emerging_to_persistent_prob)
    "seriousness":         [(86, 108)],            # 22   (gamma*..raw_serious_event)
    "temporal_path":       [(158, 708)],           # 550  (base_increment)
}
_RANK_SHARED = 16
_RANK_BLOCK = 4
_BLOCK_ORDER = ["count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]
# Frozen factor-init subkey order (artifact 25B / FINAL SOURCE CONFORMANCE FIX):
#   random.split(factor_init_key, 5) -> [shared, count_plus_initial, dynamic_scale,
#                                        seriousness, temporal_path]
_FACTOR_SUBKEY_ORDER = ["shared", "count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]
# Frozen initial diagonal scale (artifact 25): diag_scale_init = 0.1.
_DIAG_SCALE_INIT = 0.1


def _block_index_arrays(dim: int) -> Dict[str, jnp.ndarray]:
    out = {}
    for name, segs in _BLOCK_SEGMENTS.items():
        out[name] = jnp.concatenate([jnp.arange(a, b) for a, b in segs])
    return out


class StructuredLowRankAutoGuide(AutoContinuous):
    """AutoContinuous subclass whose unconstrained posterior is a single
    structured low-rank MultivariateNormal (V1_SHARED_PLUS_BLOCK_LOW_RANK)."""

    def __init__(self, model, *, rank_shared=_RANK_SHARED, rank_block=_RANK_BLOCK,
                 prefix="auto", init_loc_fn=numpyro.infer.init_to_median,
                 factor_init_key=None, **kwargs):
        super().__init__(model, prefix=prefix, init_loc_fn=init_loc_fn, **kwargs)
        self.rank_shared = rank_shared
        self.rank_block = rank_block
        self._block_segments = _BLOCK_SEGMENTS
        self._block_order = _BLOCK_ORDER
        # Frozen RNG schedule (artifact 25B): when provided, all 5 low-rank factors
        # are initialized deterministically from factor_init_key (NOT from the
        # prototype seed handler). When None, factors init from the prototype
        # handler rng_key (used by offline dry preflight shape checks).
        self.factor_init_key = factor_init_key

    # ---- helper: embed block factors into the full 708-dim space -> F_total ----
    def _build_f_total(self, F_shared, Fb):
        dim = F_shared.shape[0]
        n_cols = self.rank_shared + self.rank_block * len(self._block_order)
        F_total = jnp.zeros((dim, n_cols), dtype=F_shared.dtype)
        F_total = F_total.at[:, :self.rank_shared].set(F_shared)
        col = self.rank_shared
        block_idx = _block_index_arrays(dim)
        for name in self._block_order:
            idx = block_idx[name]
            F_total = F_total.at[idx, col:col + self.rank_block].set(Fb[name])
            col += self.rank_block
        return F_total

    # ---- helper: covariance from diag_log_scale + F_total (per artifact 23A) ----
    @staticmethod
    def _build_covariance(diag_log_scale, F_total):
        # D = diag(scale_diag**2);  scale_diag = exp(diag_log_scale)
        scale_diag = jnp.exp(diag_log_scale)
        D = jnp.diag(scale_diag ** 2)
        Sigma = D + F_total @ F_total.T
        return Sigma

    # ---- helper: reconstruct F_total (708,32) from a param dict (diagnostics) ----
    def build_f_total_from_params(self, params: Dict[str, jnp.ndarray]) -> jnp.ndarray:
        prefix = self.prefix
        F_shared = params["{}_F_shared".format(prefix)]
        dim = F_shared.shape[0]
        n_cols = self.rank_shared + self.rank_block * len(self._block_order)
        F_total = jnp.zeros((dim, n_cols), dtype=F_shared.dtype)
        F_total = F_total.at[:, :self.rank_shared].set(F_shared)
        col = self.rank_shared
        block_idx = _block_index_arrays(dim)
        for name in self._block_order:
            idx = block_idx[name]
            F_total = F_total.at[idx, col:col + self.rank_block].set(
                params["{}_F_{}".format(prefix, name)]
            )
            col += self.rank_block
        return F_total

    # ---- the ONLY replaced piece: the unconstrained 708-dim posterior dist ----
    def _get_posterior(self):
        loc = numpyro.param("{}_loc".format(self.prefix), self._init_latent)
        # explicit, unambiguous name (artifact 23A): NOT the ambiguous `log_diag`.
        # Frozen init (artifact 25): diag_scale_init = 0.1  =>  diag_log_scale = log(0.1).
        diag_log_scale = numpyro.param(
            "{}_diag_log_scale".format(self.prefix),
            jnp.full(self.latent_dim, jnp.log(_DIAG_SCALE_INIT)),
        )
        # --- factor init (frozen RNG schedule, artifact 25B) ---
        if self.factor_init_key is not None:
            # factor_subkeys = random.split(factor_init_key, 5) in FIXED order:
            #   [0] shared  [1] count_plus_initial  [2] dynamic_scale
            #   [3] seriousness  [4] temporal_path
            fsub = jax.random.split(self.factor_init_key, 5)
            subkey_for = {name: fsub[i] for i, name in enumerate(_FACTOR_SUBKEY_ORDER)}

            def make_factor_init(subkey, shape):
                # Deterministic from the frozen subkey; prototype handler rng ignored.
                return lambda _rng: 0.01 * jax.random.normal(subkey, shape)
        else:
            subkey_for = None

            def make_factor_init(_ignored, shape):
                # Used only by offline dry preflight shape checks (prototype handler rng).
                return lambda rng_key: 0.01 * jax.random.normal(rng_key, shape)

        # shared cross-block low-rank factor (708, rank_shared)
        if self.factor_init_key is not None:
            sk_shared = subkey_for["shared"]
            fshared_init = lambda _r, _k=sk_shared: 0.01 * jax.random.normal(
                _k, (self.latent_dim, self.rank_shared)
            )
        else:
            fshared_init = make_factor_init(None, (self.latent_dim, self.rank_shared))
        F_shared = numpyro.param("{}_F_shared".format(self.prefix), fshared_init)
        # four semantic block-specific low-rank factors (native block dims, rank_block)
        Fb = {}
        for name in self._block_order:
            segs = self._block_segments[name]
            dim_b = sum(b - a for a, b in segs)
            if self.factor_init_key is not None:
                sk = subkey_for[name]
                init = lambda _r, _k=sk, _d=dim_b: 0.01 * jax.random.normal(_k, (_d, self.rank_block))
            else:
                init = lambda _r, _d=dim_b: 0.01 * jax.random.normal(_r, (_d, self.rank_block))
            Fb[name] = numpyro.param("{}_F_{}".format(self.prefix, name), init)
        F_total = self._build_f_total(F_shared, Fb)
        # Native low-rank covariance form (artifacts 23A / 24A):
        #   Sigma = cov_diag + cov_factor @ cov_factor.T
        #   cov_factor = F_total (708, 32) ; cov_diag = scale_diag**2 ; scale_diag = exp(diag_log_scale)
        # Numerically identical to the dense MultivariateNormal(covariance_matrix=Sigma)
        # used in artifact 24, but avoids materializing the full 708x708 matrix at train time.
        scale_diag = jnp.exp(diag_log_scale)
        cov_diag = scale_diag ** 2
        return dist.LowRankMultivariateNormal(loc=loc, cov_factor=F_total, cov_diag=cov_diag)
