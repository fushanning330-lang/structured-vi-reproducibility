"""Phase 3C.1 target-preserving direct-path reference coordinates.

This module deliberately wraps the unchanged Phase3B/3C full_joint_model.
It does not duplicate the scientific model.
"""

from __future__ import annotations

import jax.numpy as jnp
import numpyro
import numpyro.distributions as dist
from numpyro import handlers

from dhbcp_pv.models.full_joint_model import full_joint_model


AUX_PATH_PROPOSAL_SD = 0.50


def direct_path_to_original_coordinates(
    x_path_coord: jnp.ndarray,
) -> tuple[jnp.ndarray, jnp.ndarray]:
    """Map direct path levels to the original (x_initial, base_increment).

    This is an exact linear bijection with determinant +1.
    """
    x_path_coord = jnp.asarray(x_path_coord)
    x_initial = x_path_coord[..., 0]
    if x_path_coord.shape[-1] <= 1:
        base_increment = jnp.zeros(
            x_path_coord.shape[:-1] + (0,), dtype=x_path_coord.dtype
        )
    else:
        base_increment = x_path_coord[..., 1:] - x_path_coord[..., :-1]
    return x_initial, base_increment


def original_coordinates_to_direct_path(
    x_initial: jnp.ndarray,
    base_increment: jnp.ndarray,
) -> jnp.ndarray:
    """Inverse mapping from original path coordinates to direct levels."""
    x_initial = jnp.asarray(x_initial)
    base_increment = jnp.asarray(base_increment)
    if base_increment.shape[-1] == 0:
        return x_initial[..., None]
    return jnp.concatenate(
        [
            x_initial[..., None],
            x_initial[..., None] + jnp.cumsum(base_increment, axis=-1),
        ],
        axis=-1,
    )


def direct_path_reference_model(
    y: jnp.ndarray,
    serious: jnp.ndarray,
    expected: jnp.ndarray,
    drug_index: jnp.ndarray,
    event_index: jnp.ndarray,
    n_drugs: int,
    n_events: int,
    *,
    hmax: int = 12,
    ablation: str = "FULL",
    available_through: int | None = None,
) -> None:
    """Reference-only target-preserving coordinate wrapper.

    `available_through` is intentionally unsupported here because Phase3C.1
    uses already-truncated t=12/t=24/t=40 reference datasets.  This prevents
    a direct-path coordinate spanning unseen future quarters.
    """
    if available_through is not None:
        raise ValueError(
            "Phase3C.1 direct-path reference wrapper requires a physically "
            "truncated prefix dataset; available_through must be None."
        )

    y = jnp.asarray(y)
    n_pairs, n_quarters = y.shape

    proposal = dist.Normal(0.0, AUX_PATH_PROPOSAL_SD)
    x_path_coord = numpyro.sample(
        "x_path_coord",
        proposal.expand([n_pairs, n_quarters]).to_event(2),
    )

    x_initial, base_increment = direct_path_to_original_coordinates(x_path_coord)

    # Condition the unchanged scientific model on the original path coordinates.
    conditioned = handlers.condition(
        full_joint_model,
        data={
            "x_initial": x_initial,
            "base_increment": base_increment,
        },
    )
    conditioned(
        y,
        serious,
        expected,
        drug_index,
        event_index,
        n_drugs,
        n_events,
        hmax=hmax,
        ablation=ablation,
        available_through=None,
    )

    # Remove the computational proposal density. Since the coordinate mapping
    # has |det J|=1, no additional Jacobian term is required.
    numpyro.factor(
        "direct_path_auxiliary_proposal_correction",
        -jnp.sum(proposal.log_prob(x_path_coord)),
    )
