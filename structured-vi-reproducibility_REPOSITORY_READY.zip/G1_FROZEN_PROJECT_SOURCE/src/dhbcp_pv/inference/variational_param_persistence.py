"""Parameter persistence for Phase3C.4V (PARAMETER-PERSISTENT VARIATIONAL VALIDATION).

Purpose
-------
Persist the FULL ``svi.get_params(final_state)`` mapping of every completed
Phase3C.4V validation run so that the fitted variational guide distribution can
be recovered LATER without re-optimization (G2 location/scale/subspace stability,
G3 posterior draws / importance diagnostics).

Design rules (frozen by 36_PHASE3C4V_PARAMETER_PERSISTENT_VALIDATION_PROTOCOL):
  * Format: NPZ (arrays) + JSON manifest (per-parameter name/shape/dtype/
    number_of_elements/SHA256 + file-level SHA256s). Pickle is NEVER the
    canonical format.
  * Atomic write: write "<path>.tmp" first, then ``os.replace`` only after the
    payload is fully written.
  * Round-trip must be EXACT: same keys, same shapes, same dtypes,
    max_abs_diff == 0. Any dtype conversion / bit-level change is a FAILURE.
  * ``load_params`` returns ``dict[str, np.ndarray]`` (numpy-array compatible;
    jax arrays are trivially produced via ``jnp.asarray``).
  * ``recover_fitted_guide`` only restores/validates the parameter dictionary
    against the guide parameter schema. It NEVER samples, never runs inference.

This module imports ONLY stdlib + numpy (no numpyro / jax / inference).
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Dict, Optional

import numpy as np

__all__ = [
    "save_params",
    "load_params",
    "validate_params_roundtrip",
    "params_manifest",
    "params_sha256",
    "recover_fitted_guide",
    "atomic_write_bytes",
    "atomic_write_json",
    "PARAM_PERSISTENCE_SCHEMA_VERSION",
]

PARAM_PERSISTENCE_SCHEMA_VERSION = "1.0"


# --------------------------------------------------------------------------- #
# atomic I/O                                                                   #
# --------------------------------------------------------------------------- #
def atomic_write_bytes(path: Path, data: bytes) -> None:
    """Write bytes atomically: tmp file -> os.replace."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "wb") as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def atomic_write_json(path: Path, obj) -> None:
    """Write a JSON-serializable object atomically (UTF-8, indent=2)."""
    data = json.dumps(obj, indent=2, ensure_ascii=False).encode("utf-8")
    atomic_write_bytes(path, data)


# --------------------------------------------------------------------------- #
# helpers                                                                      #
# --------------------------------------------------------------------------- #
def _as_host_array(v):
    """Convert a jax array / numpy scalar / list into a host numpy ndarray.

    Works generically via ``np.asarray`` (jax arrays implement __array__).
    Scalars become 0-d arrays so dtype is preserved through NPZ storage.
    """
    arr = np.asarray(v)
    if arr.dtype == object:
        raise ValueError("object-dtype parameters are not supported by the NPZ persistence format")
    return np.ascontiguousarray(arr)


def _array_sha256(arr: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(arr).tobytes()).hexdigest()


# --------------------------------------------------------------------------- #
# manifest                                                                     #
# --------------------------------------------------------------------------- #
def params_manifest(params: Dict[str, np.ndarray]) -> dict:
    """Per-parameter manifest: name / shape / dtype / number_of_elements / SHA256."""
    entries = {}
    for name in sorted(params.keys()):
        arr = _as_host_array(params[name])
        entries[name] = {
            "name": name,
            "shape": list(arr.shape),
            "dtype": str(arr.dtype),
            "number_of_elements": int(arr.size),
            "sha256": _array_sha256(arr),
        }
    return {
        "schema_version": PARAM_PERSISTENCE_SCHEMA_VERSION,
        "n_parameters": len(entries),
        "parameters": entries,
    }


def params_sha256(params: Dict[str, np.ndarray]) -> str:
    """Stable content hash of the parameter mapping (independent of file names)."""
    man = params_manifest(params)
    lines = []
    for name in sorted(man["parameters"].keys()):
        e = man["parameters"][name]
        lines.append(f"{name}|{e['shape']}|{e['dtype']}|{e['sha256']}")
    return hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------- #
# save / load                                                                  #
# --------------------------------------------------------------------------- #
def save_params(params: Dict[str, np.ndarray],
                npz_path,
                manifest_path: Optional[Path] = None) -> dict:
    """Save the full parameter mapping as NPZ (+ JSON manifest), atomically.

    Returns the manifest dict (which includes the NPZ file SHA256 and the
    manifest file SHA256 after writing).
    """
    npz_path = Path(npz_path)
    arrays = {name: _as_host_array(v) for name, v in params.items()}
    # atomic NPZ write. NOTE: np.savez appends ".npz" when the target does NOT
    # end with ".npz", so the temp name must itself end in ".npz".
    tmp_npz = npz_path.with_name(npz_path.stem + ".tmp.npz")
    np.savez(tmp_npz, **arrays)
    os.replace(tmp_npz, npz_path)

    man = params_manifest(params)
    man["npz_file"] = npz_path.name
    man["npz_sha256"] = hashlib.sha256(npz_path.read_bytes()).hexdigest()

    if manifest_path is not None:
        manifest_path = Path(manifest_path)
        atomic_write_json(manifest_path, man)
        man["manifest_file"] = manifest_path.name
        man["manifest_sha256"] = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    return man


def load_params(npz_path) -> Dict[str, np.ndarray]:
    """Load an NPZ parameter file into ``dict[str, np.ndarray]`` (dtypes preserved)."""
    npz_path = Path(npz_path)
    with np.load(npz_path, allow_pickle=False) as z:
        return {name: z[name] for name in z.files}


# --------------------------------------------------------------------------- #
# round-trip validation                                                        #
# --------------------------------------------------------------------------- #
def validate_params_roundtrip(params: Dict[str, np.ndarray],
                              npz_path,
                              manifest_path: Optional[Path] = None) -> dict:
    """Save -> reload -> compare. Exactness required.

    Checks:
      * save succeeds (atomic)
      * reload succeeds
      * same keys / shapes / dtypes
      * per-parameter max_abs_diff == 0
      * per-parameter data SHA256 matches manifest
      * manifest file (if given) matches and its SHA256 is recorded
    """
    checks = {}
    try:
        man = save_params(params, npz_path, manifest_path)
        loaded = load_params(npz_path)

        checks["reload_succeeded"] = True
        checks["keys_match"] = set(loaded.keys()) == set(params.keys())
        checks["shapes_match"] = all(
            loaded[k].shape == np.asarray(params[k]).shape for k in params
        )
        checks["dtypes_match"] = all(
            str(loaded[k].dtype) == str(np.asarray(params[k]).dtype) for k in params
        )
        max_diffs = {}
        for k in params:
            a = np.asarray(params[k])
            b = loaded[k]
            max_diffs[k] = float(np.max(np.abs(a - b))) if a.size else 0.0
        checks["max_abs_diff"] = max_diffs
        checks["max_abs_diff_all_zero"] = all(v == 0.0 for v in max_diffs.values())
        checks["data_hashes_match"] = all(
            _array_sha256(loaded[k]) == man["parameters"][k]["sha256"] for k in params
        )
        checks["params_sha256_stable"] = (
            params_sha256(params) == params_sha256(loaded)
        )
        checks["npz_sha256_recorded"] = (
            hashlib.sha256(npz_path.read_bytes()).hexdigest() == man["npz_sha256"]
        )
        if manifest_path is not None:
            m2 = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
            checks["manifest_reloads"] = True
            checks["manifest_matches"] = (
                m2.get("n_parameters") == man.get("n_parameters")
                and all(
                    m2["parameters"][k]["sha256"] == man["parameters"][k]["sha256"]
                    for k in params
                )
            )
            checks["manifest_sha256_recorded"] = (
                hashlib.sha256(Path(manifest_path).read_bytes()).hexdigest()
                == man["manifest_sha256"]
            )
        else:
            checks["manifest_reloads"] = None
            checks["manifest_matches"] = None
            checks["manifest_sha256_recorded"] = None
        checks["PASS"] = bool(
            checks["reload_succeeded"]
            and checks["keys_match"]
            and checks["shapes_match"]
            and checks["dtypes_match"]
            and checks["max_abs_diff_all_zero"]
            and checks["data_hashes_match"]
            and checks["params_sha256_stable"]
            and checks["npz_sha256_recorded"]
            and (checks["manifest_reloads"] is not False)
            and (checks["manifest_matches"] is not False)
            and (checks["manifest_sha256_recorded"] is not False)
        )
    except Exception as exc:  # noqa: BLE001
        checks["error"] = repr(exc)
        checks["PASS"] = False
    return checks


# --------------------------------------------------------------------------- #
# fitted-guide recovery (schema validation ONLY - never samples)               #
# --------------------------------------------------------------------------- #
def recover_fitted_guide(params: Dict[str, np.ndarray],
                         required_schema: Dict[str, tuple]) -> dict:
    """Validate that a persisted parameter mapping can rebuild the guide.

    ``required_schema`` maps parameter name -> expected shape tuple.
    This function NEVER samples, NEVER runs the model/guide, NEVER performs
    inference. It only checks key presence, shapes, dtypes and finiteness.

    Returns:
        {recoverable: bool, keys_found: [...], missing: [...],
         shape_mismatch: [...], all_finite: bool, schema_compatible: bool}
    """
    keys_found = []
    missing = []
    shape_mismatch = []
    all_finite = True
    for name, shape in required_schema.items():
        if name not in params:
            missing.append(name)
            continue
        keys_found.append(name)
        arr = np.asarray(params[name])
        if tuple(arr.shape) != tuple(shape):
            shape_mismatch.append({"name": name, "expected": list(shape), "actual": list(arr.shape)})
        if np.issubdtype(arr.dtype, np.floating) or np.issubdtype(arr.dtype, np.integer):
            if not bool(np.all(np.isfinite(arr))):
                all_finite = False
    recoverable = bool(not missing and not shape_mismatch and all_finite)
    return {
        "recoverable": recoverable,
        "keys_found": keys_found,
        "missing": missing,
        "shape_mismatch": shape_mismatch,
        "all_finite": all_finite,
        "schema_compatible": recoverable,
    }
