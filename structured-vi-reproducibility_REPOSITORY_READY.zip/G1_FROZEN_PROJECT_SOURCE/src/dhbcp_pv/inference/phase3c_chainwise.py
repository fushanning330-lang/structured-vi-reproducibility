"""Interruption-safe, target-preserving helpers for Phase3C NUTS chains."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

import jax
import numpy as np
from jax import random


CHAIN_IDS = (0, 1, 2, 3)


def original_nuts_rng_keys(reference_seed: int, cutoff: int) -> jax.Array:
    """Reconstruct the exact four keys used by the original parallel runner."""
    return random.split(random.PRNGKey(reference_seed + 6000 + cutoff), 4)


def select_stacked_chain(tree: Any, chain_id: int) -> Any:
    """Select one of four original chain states without redrawing anything."""
    if chain_id not in CHAIN_IDS:
        raise ValueError("chain_id must be one of 0, 1, 2, 3")

    def select(value: Any) -> Any:
        array = np.asarray(value)
        if array.ndim == 0 or array.shape[0] != 4:
            raise ValueError("every stacked initial-state leaf must have leading dimension 4")
        return value[chain_id]

    return jax.tree.map(select, tree)


def fingerprint_array(value: Any) -> str:
    array = np.ascontiguousarray(np.asarray(value))
    digest = hashlib.sha256()
    digest.update(str(array.dtype).encode())
    digest.update(json.dumps(array.shape).encode())
    digest.update(array.tobytes(order="C"))
    return digest.hexdigest()


def fingerprint_tree(tree: Any) -> str:
    """Stable fingerprint for a pytree's structure, dtype, shape, and bytes."""
    leaves, structure = jax.tree.flatten(tree)
    digest = hashlib.sha256()
    digest.update(str(structure).encode())
    for leaf in leaves:
        digest.update(fingerprint_array(leaf).encode())
    return digest.hexdigest()


def chain_paths(directory: Path, rung: str, cutoff: int, chain_id: int) -> tuple[Path, Path]:
    stem = f"{rung}_t{cutoff:02d}_chain{chain_id}"
    return directory / f"{stem}.npz", directory / f"{stem}.json"


def valid_chain_checkpoint(
    artifact_path: Path,
    metadata_path: Path,
    *,
    rung: str,
    cutoff: int,
    chain_id: int,
) -> tuple[bool, str]:
    """Accept only a complete metadata+artifact pair with a matching SHA-256."""
    if not artifact_path.exists() and not metadata_path.exists():
        return False, "MISSING"
    if not artifact_path.is_file() or not metadata_path.is_file():
        return False, "PARTIAL_PAIR"
    try:
        metadata = json.loads(metadata_path.read_text())
    except (OSError, json.JSONDecodeError):
        return False, "INVALID_METADATA"
    if metadata.get("status") != "COMPLETE":
        return False, f"STATUS_{metadata.get('status', 'MISSING')}"
    if (
        metadata.get("rung") != rung
        or int(metadata.get("cutoff", -1)) != cutoff
        or int(metadata.get("chain_id", -1)) != chain_id
    ):
        return False, "IDENTITY_MISMATCH"
    artifact = metadata.get("chain_artifact", {})
    if artifact_path.stat().st_size != artifact.get("bytes"):
        return False, "SIZE_MISMATCH"
    digest = hashlib.sha256()
    with artifact_path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest() != artifact.get("sha256"):
        return False, "SHA256_MISMATCH"
    return True, "VALID"


def combine_chain_arrays(components: list[Mapping[str, np.ndarray]]) -> dict[str, np.ndarray]:
    """Combine four one-chain artifacts in their original chain order."""
    if len(components) != 4:
        raise ValueError("exactly four chain components are required")
    names = set(components[0])
    if any(set(component) != names for component in components[1:]):
        raise ValueError("chain components have different array names")
    combined: dict[str, np.ndarray] = {}
    for name in sorted(names):
        values = [np.asarray(component[name]) for component in components]
        if any(value.ndim == 0 or value.shape[0] != 1 for value in values):
            raise ValueError(f"component {name} does not contain exactly one leading chain")
        trailing = values[0].shape[1:]
        if any(value.shape[1:] != trailing for value in values[1:]):
            raise ValueError(f"component {name} shapes do not match")
        combined[name] = np.concatenate(values, axis=0)
    return combined
