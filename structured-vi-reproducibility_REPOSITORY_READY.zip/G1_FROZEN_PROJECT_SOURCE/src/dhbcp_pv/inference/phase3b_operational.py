"""Checkpointed rolling-prefix Phase 3B operational inference."""

from __future__ import annotations

import gzip
import os
import pickle
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter

import jax
import numpy as np
from jax import random

from dhbcp_pv.inference.posterior_integration import integrate_posterior_outputs
from dhbcp_pv.inference.structured_svi import (
    RollingPrefixSVI,
    RollingSVIConfig,
)


@dataclass(frozen=True)
class OperationalPanelResult:
    x_mean: np.ndarray
    x_sd: np.ndarray
    x_q025: np.ndarray
    x_q975: np.ndarray
    state_probability: np.ndarray
    p_change: np.ndarray
    p_persist_h2: np.ndarray
    p_serious: np.ndarray
    p_dangerous: np.ndarray
    p_dangerous_serious: np.ndarray
    delta_expected_loss: np.ndarray
    delta_mcse: np.ndarray
    score: np.ndarray
    alert: np.ndarray
    loss_by_prefix: list[list[float]]
    optimization_seconds: float
    posterior_integration_seconds: float
    total_seconds: float
    resumed_from_prefix: int
    posterior_samples: int
    operational_filtering: bool = True


def _atomic_pickle(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with gzip.open(temporary, "wb", compresslevel=3) as handle:
        pickle.dump(payload, handle, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(temporary, path)


def _load_checkpoint(path: Path) -> dict[str, object]:
    with gzip.open(path, "rb") as handle:
        return pickle.load(handle)


def _empty_arrays(n_pairs: int, n_quarters: int) -> dict[str, np.ndarray]:
    return {
        "x_mean": np.full((n_pairs, n_quarters), np.nan),
        "x_sd": np.full((n_pairs, n_quarters), np.nan),
        "x_q025": np.full((n_pairs, n_quarters), np.nan),
        "x_q975": np.full((n_pairs, n_quarters), np.nan),
        "state_probability": np.full((n_pairs, n_quarters, 4), np.nan),
        "p_change": np.full((n_pairs, n_quarters), np.nan),
        "p_persist_h2": np.full((n_pairs, n_quarters), np.nan),
        "p_serious": np.full((n_pairs, n_quarters), np.nan),
        "p_dangerous": np.full((n_pairs, n_quarters), np.nan),
        "p_dangerous_serious": np.full((n_pairs, n_quarters), np.nan),
        "delta_expected_loss": np.full((n_pairs, n_quarters), np.nan),
        "delta_mcse": np.full((n_pairs, n_quarters), np.nan),
        "score": np.full((n_pairs, n_quarters), np.nan),
        "alert": np.zeros((n_pairs, n_quarters), dtype=bool),
    }


def run_checkpointed_rolling_model(
    y: np.ndarray,
    serious: np.ndarray,
    expected: np.ndarray,
    drug_index: np.ndarray,
    event_index: np.ndarray,
    *,
    seed: int,
    ablation: str,
    checkpoint_path: Path,
    config_hash: str,
    source_hash: str,
    hmax: int = 12,
    initial_steps: int = 1,
    updates_per_quarter: int = 1,
    learning_rate: float = 0.015,
    posterior_samples: int = 64,
    fn_cost: float = 5.0,
    fp_cost: float = 1.0,
    lambda_severity: float = 1.0,
) -> OperationalPanelResult:
    """Fit every prefix in order and atomically save recovery state after each."""
    started = perf_counter()
    y = np.asarray(y)
    serious = np.asarray(serious)
    expected = np.asarray(expected)
    n_pairs, n_quarters = y.shape
    rolling = RollingPrefixSVI(
        random.PRNGKey(seed),
        n_pairs,
        drug_index,
        event_index,
        int(np.max(drug_index)) + 1,
        int(np.max(event_index)) + 1,
        hmax=hmax,
        ablation=ablation,
        config=RollingSVIConfig(
            max_quarters=n_quarters,
            initial_steps=initial_steps,
            updates_per_quarter=updates_per_quarter,
            learning_rate=learning_rate,
        ),
    )
    arrays = _empty_arrays(n_pairs, n_quarters)
    integration_seconds = 0.0
    resumed = 0
    if checkpoint_path.exists():
        saved = _load_checkpoint(checkpoint_path)
        if saved["config_hash"] != config_hash or saved["source_hash"] != source_hash:
            raise RuntimeError("rolling checkpoint hash differs from frozen source/config")
        if saved["ablation"] != ablation or int(saved["seed"]) != seed:
            raise RuntimeError("rolling checkpoint identity mismatch")
        rolling.state = jax.tree.map(jax.device_put, saved["state"])
        rolling.rng_key = jax.device_put(saved["rng_key"])
        rolling.available_through = int(saved["available_through"])
        rolling.loss_by_prefix = saved["loss_by_prefix"]
        rolling.total_optimization_seconds = float(saved["optimization_seconds"])
        arrays = saved["arrays"]
        integration_seconds = float(saved["posterior_integration_seconds"])
        resumed = rolling.available_through
    for quarter in range(rolling.available_through + 1, n_quarters + 1):
        rolling.update_prefix(y[:, :quarter], serious[:, :quarter], expected[:, :quarter])
        integration_started = perf_counter()
        samples = rolling.posterior_samples(
            y[:, :quarter],
            serious[:, :quarter],
            expected[:, :quarter],
            num_samples=posterior_samples,
        )
        integrated = integrate_posterior_outputs(
            samples,
            y[:, :quarter],
            serious[:, :quarter],
            drug_index,
            event_index,
            int(np.max(drug_index)) + 1,
            int(np.max(event_index)) + 1,
            hmax=hmax,
            fn_cost=fn_cost,
            fp_cost=fp_cost,
            lambda_severity=lambda_severity,
            ablation=ablation,
        )
        integration_seconds += perf_counter() - integration_started
        index = quarter - 1
        for name in (
            "x_mean",
            "x_sd",
            "x_q025",
            "x_q975",
            "p_change",
            "p_persist_h2",
            "p_serious",
            "p_dangerous",
            "p_dangerous_serious",
            "delta_expected_loss",
            "delta_mcse",
            "score",
            "alert",
        ):
            arrays[name][:, index] = np.asarray(getattr(integrated, name))[:, -1]
        arrays["state_probability"][:, index, :] = integrated.state_probability[:, -1, :]
        _atomic_pickle(
            checkpoint_path,
            {
                "version": "phase3b_rolling_checkpoint_v1",
                "config_hash": config_hash,
                "source_hash": source_hash,
                "ablation": ablation,
                "seed": seed,
                "available_through": quarter,
                "state": jax.device_get(rolling.state),
                "rng_key": jax.device_get(rolling.rng_key),
                "loss_by_prefix": rolling.loss_by_prefix,
                "optimization_seconds": rolling.total_optimization_seconds,
                "posterior_integration_seconds": integration_seconds,
                "arrays": arrays,
                "last_loss": rolling.loss_by_prefix[-1][-1],
                "convergence_code": "FROZEN_STEP_SCHEDULE_PREFIX_COMPLETE",
                "optimizer_state_present": True,
                "variational_params_present": True,
                "rng_state_present": True,
            },
        )
    if not all(np.isfinite(arrays[name]).all() for name in arrays if name != "alert"):
        raise FloatingPointError("operational rolling output contains non-finite values")
    return OperationalPanelResult(
        **arrays,
        loss_by_prefix=rolling.loss_by_prefix,
        optimization_seconds=rolling.total_optimization_seconds,
        posterior_integration_seconds=integration_seconds,
        total_seconds=perf_counter() - started,
        resumed_from_prefix=resumed,
        posterior_samples=posterior_samples,
    )
