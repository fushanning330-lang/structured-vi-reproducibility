"""Target-preserving Phase3C numerical stabilization helpers.

This module changes coordinates, initialization, precision, and adaptation
settings only.  ``STABILIZED_PROBABILITY_TARGET`` is deliberately the exact
Phase3B callable, so there is no second scientific log-density to drift.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence

import jax
import jax.numpy as jnp
import numpy as np
from jax import random
from numpyro import handlers
from numpyro.diagnostics import effective_sample_size, split_gelman_rubin
from numpyro.infer import Predictive
from numpyro.infer.initialization import init_to_value
from numpyro.infer.util import initialize_model
from scipy.stats import norm, rankdata

from dhbcp_pv.inference.structured_svi import (
    RollingSVIConfig,
    SVIConfig,
    build_structured_guide,
    structured_covariance_diagnostics,
)
from dhbcp_pv.models.full_joint_model import full_joint_model


STABILIZED_PROBABILITY_TARGET = full_joint_model
PATH_SITES = ("x_initial", "base_increment")

DENSE_MASS_BLOCKS: tuple[tuple[str, ...], ...] = (
    (
        "mu",
        "sigma_drug",
        "sigma_event",
        "sigma_pair",
        "raw_drug",
        "raw_event",
        "raw_pair",
        "phi",
    ),
    (
        "delta_emerging",
        "delta_persistent",
        "delta_waning_magnitude",
        "dynamic_sd",
        "duration_means",
        "duration_shapes",
        "emerging_to_persistent_probability",
    ),
    (
        "gamma0",
        "gamma_nonbackground",
        "gamma_x",
        "sigma_serious_drug",
        "sigma_serious_event",
        "raw_serious_drug",
        "raw_serious_event",
    ),
)

GLOBAL_DIAGNOSTIC_SITES: tuple[str, ...] = (
    "mu",
    "sigma_drug",
    "sigma_event",
    "sigma_pair",
    "phi",
    "delta_emerging",
    "delta_persistent",
    "delta_waning_magnitude",
    "dynamic_sd",
    "duration_means",
    "duration_shapes",
    "emerging_to_persistent_probability",
    "gamma0",
    "gamma_nonbackground",
    "gamma_x",
    "sigma_serious_drug",
    "sigma_serious_event",
)


def assert_x64_reference_mode() -> None:
    """Fail before reference inference if JAX was not started in x64 mode."""
    if not bool(jax.config.jax_enable_x64):
        raise RuntimeError(
            "Phase3C reference inference requires JAX_ENABLE_X64=1 before JAX import"
        )
    probe = jnp.asarray([0.0], dtype=jnp.float64)
    if probe.dtype != jnp.float64:
        raise RuntimeError("Phase3C x64 probe was silently downcast")


def validate_dense_mass_contract(
    latent_site_names: Sequence[str] | None = None,
) -> dict[str, object]:
    """Validate the exact three blocks and keep both path sites diagonal."""
    flat = [site for block in DENSE_MASS_BLOCKS for site in block]
    duplicates = sorted({site for site in flat if flat.count(site) > 1})
    path_overlap = sorted(set(flat).intersection(PATH_SITES))
    missing = (
        sorted(set(flat).difference(latent_site_names))
        if latent_site_names is not None
        else []
    )
    return {
        "blocks": [list(block) for block in DENSE_MASS_BLOCKS],
        "duplicates": duplicates,
        "path_sites": list(PATH_SITES),
        "path_sites_excluded": not path_overlap,
        "path_overlap": path_overlap,
        "missing_latent_sites": missing,
        "passed": not duplicates and not path_overlap and not missing,
    }


def _model_arguments(
    y: jnp.ndarray,
    serious: jnp.ndarray,
    expected: jnp.ndarray,
    drug_index: jnp.ndarray,
    event_index: jnp.ndarray,
    n_drugs: int,
    n_events: int,
    *,
    hmax: int,
    ablation: str,
    available_through: int | None,
) -> tuple[tuple[Any, ...], dict[str, Any]]:
    args = (
        jnp.asarray(y),
        jnp.asarray(serious),
        jnp.asarray(expected),
        jnp.asarray(drug_index),
        jnp.asarray(event_index),
        n_drugs,
        n_events,
    )
    kwargs = {
        "hmax": hmax,
        "ablation": ablation,
        "available_through": available_through,
    }
    return args, kwargs


def draw_svi_initial_params(
    rng_key: jax.Array,
    params: Mapping[str, jax.Array],
    y: jnp.ndarray,
    serious: jnp.ndarray,
    expected: jnp.ndarray,
    drug_index: jnp.ndarray,
    event_index: jnp.ndarray,
    n_drugs: int,
    n_events: int,
    *,
    num_chains: int = 4,
    hmax: int = 12,
    ablation: str = "FULL",
    available_through: int | None = None,
) -> tuple[dict[str, jax.Array], dict[str, object]]:
    """Draw independent guide values and convert them to unconstrained NUTS states."""
    assert_x64_reference_mode()
    args, kwargs = _model_arguments(
        y,
        serious,
        expected,
        drug_index,
        event_index,
        n_drugs,
        n_events,
        hmax=hmax,
        ablation=ablation,
        available_through=available_through,
    )
    guide = build_structured_guide(STABILIZED_PROBABILITY_TARGET)
    draw_key, init_key = random.split(rng_key)
    guide_draws = Predictive(guide, params=dict(params), num_samples=num_chains)(
        draw_key, *args, **kwargs
    )
    keys = random.split(init_key, num_chains)
    unconstrained = []
    potential_energies = []
    finite_gradients = []
    support_checks: list[bool] = []
    for chain in range(num_chains):
        values = {name: value[chain] for name, value in guide_draws.items()}
        model_info = initialize_model(
            keys[chain],
            STABILIZED_PROBABILITY_TARGET,
            init_strategy=init_to_value(values=values),
            model_args=args,
            model_kwargs=kwargs,
            validate_grad=True,
        )
        unconstrained.append(model_info.param_info.z)
        potential_energies.append(float(model_info.param_info.potential_energy))
        finite_gradients.append(
            all(bool(jnp.isfinite(value).all()) for value in jax.tree.leaves(model_info.param_info.z_grad))
        )
        conditioned = handlers.trace(
            handlers.substitute(STABILIZED_PROBABILITY_TARGET, data=values)
        ).get_trace(*args, **kwargs)
        support_checks.append(
            all(
                bool(site["fn"].support.check(site["value"]).all())
                for site in conditioned.values()
                if site["type"] == "sample" and not site.get("is_observed", False)
            )
        )
    stacked = jax.tree.map(lambda *values: jnp.stack(values), *unconstrained)
    metadata = {
        "num_chains": num_chains,
        "independent_guide_draws": True,
        "potential_energies": potential_energies,
        "finite_potential_energies": all(np.isfinite(potential_energies)),
        "finite_gradients": finite_gradients,
        "support_checks": support_checks,
        "all_passed": bool(
            all(np.isfinite(potential_energies))
            and all(finite_gradients)
            and all(support_checks)
            and all(bool(jnp.isfinite(value).all()) for value in jax.tree.leaves(stacked))
        ),
    }
    return stacked, metadata


def posterior_scale_diagnostics(params: Mapping[str, jax.Array]) -> dict[str, object]:
    """Audit all explicit variational scale parameters and path covariance."""
    minima: dict[str, float] = {}
    below: list[str] = []
    for name, value in params.items():
        if name.endswith("_scale") or name.endswith("_diagonal"):
            minimum = float(np.min(np.asarray(value)))
            minima[name] = minimum
            if minimum < 1e-6:
                below.append(name)
    covariance = structured_covariance_diagnostics(dict(params))
    return {
        "minimum_by_parameter": minima,
        "below_1e_6": below,
        "none_below_1e_6": not below,
        "structured_covariance": covariance,
        "positive_definite": bool(covariance["positive_definite"]),
    }


def phase3c_rolling_config(selected: SVIConfig, *, max_quarters: int = 40) -> RollingSVIConfig:
    updates = max(10, selected.minimum_steps // 10)
    return RollingSVIConfig(
        max_quarters=max_quarters,
        initial_steps=selected.minimum_steps,
        updates_per_quarter=updates,
        learning_rate=selected.learning_rate,
        gradient_clip_norm=selected.gradient_clip_norm,
        num_elbo_particles=selected.num_elbo_particles,
        early_stop_patience=max(3, min(selected.early_stop_patience, updates // 2)),
        relative_tolerance=selected.relative_tolerance,
        minimum_steps_per_update=1,
    )


def rank_normalize(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    chains, draws = values.shape[:2]
    flattened = values.reshape(chains * draws, -1)
    ranks = rankdata(flattened, axis=0, method="average")
    z = norm.ppf((ranks - 0.375) / (chains * draws + 0.25))
    return z.reshape(values.shape)


def rank_normalized_diagnostics(
    values: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return robust split R-hat, bulk ESS, and tail ESS by component."""
    values = np.asarray(values, dtype=np.float64)
    z = rank_normalize(values)
    rank_rhat = np.asarray(split_gelman_rubin(z))
    folded = np.abs(values - np.median(values, axis=(0, 1), keepdims=True))
    folded_rhat = np.asarray(split_gelman_rubin(rank_normalize(folded)))
    rhat = np.maximum(rank_rhat, folded_rhat)
    bulk = np.asarray(effective_sample_size(z))
    q05 = np.quantile(values, 0.05, axis=(0, 1), keepdims=True)
    q95 = np.quantile(values, 0.95, axis=(0, 1), keepdims=True)
    ess05 = np.asarray(effective_sample_size((values <= q05).astype(np.float64)))
    ess95 = np.asarray(effective_sample_size((values <= q95).astype(np.float64)))
    return rhat, bulk, np.minimum(ess05, ess95)


def summarize_nuts_gate(
    samples: Mapping[str, np.ndarray],
    extra_fields: Mapping[str, np.ndarray],
    *,
    max_tree_depth: int,
) -> dict[str, object]:
    global_rhat: list[float] = []
    global_bulk: list[float] = []
    for site in GLOBAL_DIAGNOSTIC_SITES:
        rhat, bulk, _ = rank_normalized_diagnostics(np.asarray(samples[site]))
        global_rhat.extend(np.asarray(rhat).reshape(-1).tolist())
        global_bulk.extend(np.asarray(bulk).reshape(-1).tolist())
    terminal_x = np.asarray(samples["x"])[..., -1]
    x_rhat, x_bulk, _ = rank_normalized_diagnostics(terminal_x)
    divergences = np.asarray(extra_fields["diverging"], dtype=bool)
    num_steps = np.asarray(extra_fields["num_steps"])
    energy = np.asarray(extra_fields.get("energy"), dtype=np.float64)
    e_bfmi = []
    if energy.ndim == 2:
        for chain in energy:
            variance = np.var(chain, ddof=1)
            e_bfmi.append(float(np.mean(np.diff(chain) ** 2) / variance) if variance > 0 else None)
    finite = all(np.isfinite(np.asarray(value)).all() for value in samples.values())
    return {
        "unresolved_divergences": int(divergences.sum()),
        "divergences_by_chain": divergences.sum(axis=1).astype(int).tolist(),
        "global_hyperparameter_rhat_max": float(np.max(global_rhat)),
        "global_hyperparameter_bulk_ess_min": float(np.min(global_bulk)),
        "selected_x_rhat_95pct": float(np.quantile(np.asarray(x_rhat).reshape(-1), 0.95)),
        "selected_x_bulk_ess_05pct": float(np.quantile(np.asarray(x_bulk).reshape(-1), 0.05)),
        "tree_depth_saturation_rate": float(
            np.mean(num_steps >= (2**max_tree_depth - 1))
        ),
        "e_bfmi_by_chain": e_bfmi,
        "accept_prob_mean_by_chain": (
            np.asarray(extra_fields["accept_prob"]).mean(axis=1).tolist()
            if "accept_prob" in extra_fields
            else None
        ),
        "finite_posterior": bool(finite),
    }


def nuts_gate_flags(diagnostics: Mapping[str, object]) -> dict[str, bool]:
    return {
        "divergences": int(diagnostics["unresolved_divergences"]) == 0,
        "global_rhat": float(diagnostics["global_hyperparameter_rhat_max"]) <= 1.01,
        "global_bulk_ess": float(diagnostics["global_hyperparameter_bulk_ess_min"]) >= 400,
        "selected_x_rhat": float(diagnostics["selected_x_rhat_95pct"]) <= 1.05,
        "selected_x_bulk_ess": float(diagnostics["selected_x_bulk_ess_05pct"]) >= 200,
        "tree_depth": float(diagnostics["tree_depth_saturation_rate"]) <= 0.01,
        "finite": bool(diagnostics["finite_posterior"]),
    }
