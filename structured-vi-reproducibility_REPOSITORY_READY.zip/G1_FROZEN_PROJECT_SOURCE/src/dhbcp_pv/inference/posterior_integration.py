"""Posterior Monte Carlo integration of operational HSMM and decision outputs."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import jax
import jax.numpy as jnp
import numpy as np

from dhbcp_pv.models.full_joint_model import (
    drift_vector,
    reconstruct_x,
    seriousness_state_vector,
    state_emission_log_likelihood,
)
from dhbcp_pv.models.hsmm import forward_filter, substantive_transition_matrix
from dhbcp_pv.models.sticky_hmm import sticky_hmm_filter


@dataclass(frozen=True)
class PosteriorIntegratedResult:
    x_mean: np.ndarray
    x_sd: np.ndarray
    x_q025: np.ndarray
    x_q975: np.ndarray
    state_probability: np.ndarray
    p_change: np.ndarray
    p_persist_h2: np.ndarray
    p_serious: np.ndarray
    p_dangerous: np.ndarray
    p_dangerous_serious: np.ndarray
    delta_expected_loss: np.ndarray
    delta_mcse: np.ndarray
    score: np.ndarray
    alert: np.ndarray
    posterior_samples: int
    operational_filtering: bool = True


def _derived_draws(
    samples: dict[str, jnp.ndarray],
    drug_index: jnp.ndarray,
    event_index: jnp.ndarray,
    n_drugs: int,
    n_events: int,
    *,
    ablation: str,
) -> dict[str, jnp.ndarray]:
    x = jax.vmap(reconstruct_x)(samples["x_initial"], samples["base_increment"])
    n_draws, n_pairs, _ = x.shape
    if ablation == "A_NO_HIERARCHY":
        alpha = jnp.zeros((n_draws, n_drugs))
        beta = jnp.zeros((n_draws, n_events))
        pair_effect = jnp.zeros((n_draws, n_pairs))
    else:
        raw_drug = samples["raw_drug"]
        raw_event = samples["raw_event"]
        alpha = samples["sigma_drug"][:, None] * (
            raw_drug - jnp.mean(raw_drug, axis=1, keepdims=True)
        )
        beta = samples["sigma_event"][:, None] * (
            raw_event - jnp.mean(raw_event, axis=1, keepdims=True)
        )
        pair_effect = samples["sigma_pair"][:, None] * samples["raw_pair"]
    baseline = (
        samples["mu"][:, None]
        + alpha[:, drug_index]
        + beta[:, event_index]
        + pair_effect
    )
    drift = jax.vmap(drift_vector)(
        samples["delta_emerging"],
        samples["delta_persistent"],
        samples["delta_waning_magnitude"],
    )
    if ablation == "A_NO_SERIOUSNESS":
        gamma0 = jnp.zeros(n_draws)
        gamma_state = jnp.zeros((n_draws, 4))
        gamma_x = jnp.zeros(n_draws)
        serious_offset = jnp.zeros((n_draws, n_pairs))
    else:
        gamma0 = samples["gamma0"]
        gamma_state = jax.vmap(seriousness_state_vector)(samples["gamma_nonbackground"])
        gamma_x = samples["gamma_x"]
        serious_drug = samples["sigma_serious_drug"][:, None] * (
            samples["raw_serious_drug"]
            - jnp.mean(samples["raw_serious_drug"], axis=1, keepdims=True)
        )
        serious_event = samples["sigma_serious_event"][:, None] * (
            samples["raw_serious_event"]
            - jnp.mean(samples["raw_serious_event"], axis=1, keepdims=True)
        )
        serious_offset = serious_drug[:, drug_index] + serious_event[:, event_index]
    return {
        "x": x,
        "baseline": baseline,
        "drift": drift,
        "gamma0": gamma0,
        "gamma_state": gamma_state,
        "gamma_x": gamma_x,
        "serious_offset": serious_offset,
    }


@lru_cache(maxsize=48)
def _compiled_integrator(hmax: int, include_seriousness: bool, sticky_hmm: bool):
    def one_pair(
        path: jnp.ndarray,
        count: jnp.ndarray,
        severe: jnp.ndarray,
        drift: jnp.ndarray,
        dynamic_sd: jnp.ndarray,
        duration_means: jnp.ndarray,
        duration_shapes: jnp.ndarray,
        transition_probability: jnp.ndarray,
        gamma0: jnp.ndarray,
        gamma_state: jnp.ndarray,
        gamma_x: jnp.ndarray,
        serious_offset: jnp.ndarray,
    ):
        emission = state_emission_log_likelihood(
            path,
            count,
            severe,
            drift,
            dynamic_sd,
            gamma0,
            gamma_state,
            gamma_x,
            serious_offset,
            include_seriousness=include_seriousness,
        )
        if sticky_hmm:
            hsmm = sticky_hmm_filter(emission, transition_probability)
        else:
            hsmm = forward_filter(
                emission,
                duration_means,
                duration_shapes,
                substantive_transition_matrix(transition_probability),
                hmax=hmax,
                persistence_horizon=2,
            )
        probability = jax.nn.sigmoid(
            gamma0
            + gamma_state[None, :]
            + gamma_x * jnp.maximum(path[:, None], 0.0)
            + serious_offset
        )
        p_serious = jnp.sum(hsmm.filtered_state_probability * probability, axis=1)
        return (
            hsmm.filtered_state_probability,
            hsmm.substantive_change_probability,
            hsmm.persistence_probability_h2,
            p_serious,
        )

    pairs = jax.vmap(
        one_pair,
        in_axes=(0, 0, 0, None, None, None, None, None, None, None, None, 0),
    )

    def draws(
        x: jnp.ndarray,
        y: jnp.ndarray,
        serious: jnp.ndarray,
        drift: jnp.ndarray,
        dynamic_sd: jnp.ndarray,
        duration_means: jnp.ndarray,
        duration_shapes: jnp.ndarray,
        transition_probability: jnp.ndarray,
        gamma0: jnp.ndarray,
        gamma_state: jnp.ndarray,
        gamma_x: jnp.ndarray,
        serious_offset: jnp.ndarray,
    ):
        return jax.vmap(
            lambda path_draw, drift_draw, sd_draw, means_draw, shapes_draw, transition_draw,
            gamma0_draw, gamma_state_draw, gamma_x_draw, offset_draw: pairs(
                path_draw,
                y,
                serious,
                drift_draw,
                sd_draw,
                means_draw,
                shapes_draw,
                transition_draw,
                gamma0_draw,
                gamma_state_draw,
                gamma_x_draw,
                offset_draw,
            )
        )(
            x,
            drift,
            dynamic_sd,
            duration_means,
            duration_shapes,
            transition_probability,
            gamma0,
            gamma_state,
            gamma_x,
            serious_offset,
        )

    return jax.jit(draws)


def integrate_posterior_outputs(
    posterior_samples: dict[str, jnp.ndarray],
    y: jnp.ndarray,
    serious: jnp.ndarray,
    drug_index: jnp.ndarray,
    event_index: jnp.ndarray,
    n_drugs: int,
    n_events: int,
    *,
    hmax: int = 12,
    fn_cost: float = 5.0,
    fp_cost: float = 1.0,
    lambda_severity: float = 1.0,
    ablation: str = "FULL",
) -> PosteriorIntegratedResult:
    """Average sample-conditional HSMM and loss outputs over q(theta,x)."""
    y = jnp.asarray(y)
    serious = jnp.asarray(serious)
    drug_index = jnp.asarray(drug_index, dtype=jnp.int32)
    event_index = jnp.asarray(event_index, dtype=jnp.int32)
    derived = _derived_draws(
        posterior_samples,
        drug_index,
        event_index,
        n_drugs,
        n_events,
        ablation=ablation,
    )
    include_seriousness = ablation != "A_NO_SERIOUSNESS"
    state, change, persistence, p_serious = _compiled_integrator(
        hmax, include_seriousness, ablation == "A_STICKY_HMM"
    )(
        derived["x"],
        y,
        serious,
        derived["drift"],
        posterior_samples["dynamic_sd"],
        posterior_samples["duration_means"],
        posterior_samples["duration_shapes"],
        posterior_samples["emerging_to_persistent_probability"],
        derived["gamma0"],
        derived["gamma_state"],
        derived["gamma_x"],
        derived["serious_offset"],
    )
    # state is [draw,pair,time,state].  Compute loss within each draw before
    # averaging; this avoids the forbidden product-of-posterior-means shortcut.
    p_dangerous_draw = (derived["x"] > 0) * (state[..., 1] + state[..., 2])
    if include_seriousness:
        severity = p_serious
    else:
        severity = jnp.zeros_like(p_serious)
    delta_draw = (
        p_dangerous_draw * fn_cost * (1.0 + lambda_severity * severity)
        - (1.0 - p_dangerous_draw) * fp_cost
    )
    draws = int(derived["x"].shape[0])
    x = np.asarray(derived["x"])
    delta = np.asarray(delta_draw)
    result = PosteriorIntegratedResult(
        x_mean=x.mean(axis=0),
        x_sd=x.std(axis=0, ddof=1),
        x_q025=np.quantile(x, 0.025, axis=0),
        x_q975=np.quantile(x, 0.975, axis=0),
        state_probability=np.asarray(state).mean(axis=0),
        p_change=np.asarray(change).mean(axis=0),
        p_persist_h2=np.asarray(persistence).mean(axis=0),
        p_serious=(
            np.asarray(p_serious).mean(axis=0)
            if include_seriousness
            else np.zeros_like(np.asarray(p_serious).mean(axis=0))
        ),
        p_dangerous=np.asarray(p_dangerous_draw).mean(axis=0),
        p_dangerous_serious=(
            np.asarray(p_dangerous_draw * p_serious).mean(axis=0)
            if include_seriousness
            else np.zeros_like(np.asarray(p_dangerous_draw).mean(axis=0))
        ),
        delta_expected_loss=delta.mean(axis=0),
        delta_mcse=delta.std(axis=0, ddof=1) / np.sqrt(draws),
        score=delta.mean(axis=0),
        alert=delta.mean(axis=0) > 0.0,
        posterior_samples=draws,
    )
    arrays = (
        result.x_mean,
        result.x_sd,
        result.state_probability,
        result.p_change,
        result.p_persist_h2,
        result.p_serious,
        result.p_dangerous,
        result.p_dangerous_serious,
        result.delta_expected_loss,
        result.delta_mcse,
    )
    if not all(np.isfinite(array).all() for array in arrays):
        raise FloatingPointError("posterior integration produced non-finite output")
    if not np.allclose(result.state_probability.sum(axis=-1), 1.0, atol=3e-6):
        raise FloatingPointError("posterior-integrated state probabilities are not normalized")
    if np.any((result.p_dangerous < 0) | (result.p_dangerous > 1)):
        raise FloatingPointError("posterior dangerous probability is outside [0,1]")
    return result


def posterior_parameter_summary(
    posterior_samples: dict[str, jnp.ndarray],
) -> list[dict[str, float | str | int]]:
    """Compact marginal summaries for global and hierarchical parameters."""
    selected = (
        "mu",
        "sigma_drug",
        "sigma_event",
        "sigma_pair",
        "phi",
        "delta_emerging",
        "delta_persistent",
        "delta_waning_magnitude",
        "dynamic_sd",
        "duration_means",
        "duration_shapes",
        "emerging_to_persistent_probability",
        "gamma0",
        "gamma_nonbackground",
        "gamma_x",
        "sigma_serious_drug",
        "sigma_serious_event",
    )
    rows: list[dict[str, float | str | int]] = []
    for name in selected:
        if name not in posterior_samples:
            continue
        values = np.asarray(posterior_samples[name])
        if values.ndim == 1:
            values = values[:, None]
        flattened = values.reshape(values.shape[0], -1)
        for index in range(flattened.shape[1]):
            item = flattened[:, index]
            rows.append(
                {
                    "parameter": name,
                    "index": index,
                    "mean": float(item.mean()),
                    "sd": float(item.std(ddof=1)),
                    "q025": float(np.quantile(item, 0.025)),
                    "q975": float(np.quantile(item, 0.975)),
                    "draws": len(item),
                }
            )
    return rows
