"""Time-structured Gaussian variational guide for the continuous signal path."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.special import gammaln


@dataclass(frozen=True)
class StructuredVIResult:
    x_mean: np.ndarray
    x_sd: np.ndarray
    innovation_mean: np.ndarray
    innovation_sd: np.ndarray
    surrogate_elbo_trace: np.ndarray
    finite: bool
    guide_family: str = "pairwise_gaussian_markov_banded_precision"


def _nb2_log_prob(y: float, mean: float, phi: float) -> float:
    mean = max(float(mean), 1e-12)
    probability = phi / (phi + mean)
    return float(
        gammaln(y + phi)
        - gammaln(phi)
        - gammaln(y + 1.0)
        + phi * np.log(probability)
        + y * np.log1p(-probability)
    )


def fit_structured_vi(
    y: np.ndarray,
    expected: np.ndarray,
    *,
    phi: float = 10.0,
    initial_sd: float = 0.35,
    process_sd: float = 0.20,
) -> StructuredVIResult:
    """Deterministic rolling-prefix Gaussian guide.

    The guide is a first-order Gaussian Markov chain, represented by filtered
    means and innovation scales (equivalently a banded precision matrix).  Each
    quarter uses only observations available through that quarter.
    """
    y = np.asarray(y, dtype=float)
    expected = np.asarray(expected, dtype=float)
    if y.ndim != 1 or expected.shape != y.shape:
        raise ValueError("y and expected must be one-dimensional arrays of equal length")
    if np.any(y < 0) or np.any(expected <= 0):
        raise ValueError("counts must be nonnegative and expected counts strictly positive")
    n_quarters = len(y)
    x_mean = np.zeros(n_quarters, dtype=float)
    x_variance = np.zeros(n_quarters, dtype=float)
    innovation_mean = np.zeros(n_quarters, dtype=float)
    innovation_sd = np.zeros(n_quarters, dtype=float)
    objective = np.zeros(n_quarters, dtype=float)
    previous_mean = 0.0
    previous_variance = initial_sd**2
    cumulative = 0.0
    for quarter in range(n_quarters):
        if quarter == 0:
            prior_mean = 0.0
            prior_variance = initial_sd**2
        else:
            prior_mean = previous_mean
            prior_variance = previous_variance + process_sd**2
        # Anscombe-style stabilized log observed/expected ratio.  Its delta
        # variance supplies a deterministic local quadratic likelihood.
        observation = np.log((y[quarter] + 0.5) / (expected[quarter] + 0.5))
        observation_variance = 1.0 / (y[quarter] + 0.5) + 1.0 / phi
        gain = prior_variance / (prior_variance + observation_variance)
        posterior_mean = prior_mean + gain * (observation - prior_mean)
        posterior_variance = max((1.0 - gain) * prior_variance, 1e-10)
        x_mean[quarter] = posterior_mean
        x_variance[quarter] = posterior_variance
        innovation_mean[quarter] = posterior_mean - (previous_mean if quarter else 0.0)
        innovation_sd[quarter] = np.sqrt(prior_variance)
        mean_count = expected[quarter] * np.exp(posterior_mean + 0.5 * posterior_variance)
        entropy = 0.5 * np.log(2.0 * np.pi * np.e * posterior_variance)
        cumulative += _nb2_log_prob(y[quarter], mean_count, phi) + entropy
        objective[quarter] = cumulative
        previous_mean = posterior_mean
        previous_variance = posterior_variance
    finite = bool(
        np.isfinite(x_mean).all()
        and np.isfinite(x_variance).all()
        and np.isfinite(objective).all()
    )
    if not finite:
        raise FloatingPointError("structured variational guide produced a non-finite value")
    return StructuredVIResult(
        x_mean=x_mean,
        x_sd=np.sqrt(x_variance),
        innovation_mean=innovation_mean,
        innovation_sd=innovation_sd,
        surrogate_elbo_trace=objective,
        finite=True,
    )

