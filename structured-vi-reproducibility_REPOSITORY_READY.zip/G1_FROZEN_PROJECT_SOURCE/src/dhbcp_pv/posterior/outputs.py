"""Build compact, schema-stable Phase 3 operational output tables."""

from __future__ import annotations

import numpy as np
import pandas as pd

from dhbcp_pv.inference.filtering import OperationalFilterResult


def operational_output_frame(
    result: OperationalFilterResult,
    *,
    replicate_id: int,
    scenario: str,
    oa_row: int,
    pair_id: str,
    config_sha256: str,
    seed: int,
) -> pd.DataFrame:
    n = len(result.score)
    probability = result.state_probability
    return pd.DataFrame(
        {
            "replicate_id": replicate_id,
            "scenario": scenario,
            "oa_row": oa_row,
            "pair_id": pair_id,
            "quarter": np.arange(1, n + 1),
            "method": "DHBCP_PV_V2",
            "score": result.score,
            "alert": result.alert,
            "posterior_x_mean": result.x_mean,
            "posterior_x_sd": result.x_sd,
            "p_background": probability[:, 0],
            "p_emerging": probability[:, 1],
            "p_persistent": probability[:, 2],
            "p_waning": probability[:, 3],
            "p_change": result.p_change,
            "p_persist_h2": result.p_persist_h2,
            "p_serious": result.p_serious,
            "delta_expected_loss": result.delta_expected_loss,
            "operational_filtering": True,
            "config_sha256": config_sha256,
            "seed": seed,
        }
    )

