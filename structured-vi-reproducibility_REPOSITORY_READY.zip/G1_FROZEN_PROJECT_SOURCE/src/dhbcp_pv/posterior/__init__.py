"""Posterior summaries and operational output schemas."""

