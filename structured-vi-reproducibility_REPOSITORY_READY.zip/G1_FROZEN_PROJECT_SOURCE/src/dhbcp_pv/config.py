from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]

def load_yaml(path: str | Path) -> dict:
    p = Path(path)
    if not p.is_absolute():
        p = ROOT / p
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)
