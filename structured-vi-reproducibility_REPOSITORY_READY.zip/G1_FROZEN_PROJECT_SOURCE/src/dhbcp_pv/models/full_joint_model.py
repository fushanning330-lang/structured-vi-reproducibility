"""Phase 3B model-conformant full DHBCP-PV V2 probability target.

The discrete explicit-duration state path is marginalized exactly.  Every
remaining latent is continuous and is shared by the NUTS and SVI paths.
"""

from __future__ import annotations

from functools import partial

import jax
import jax.numpy as jnp
import numpyro
import numpyro.distributions as dist

from dhbcp_pv.models.hsmm import forward_filter, substantive_transition_matrix
from dhbcp_pv.models.sticky_hmm import sticky_hmm_filter


DURATION_PRIOR_MEDIANS = jnp.array([6.0, 2.0, 5.0, 3.0])
DURATION_PRIOR_LOG_SDS = jnp.array([0.45, 0.35, 0.45, 0.40])
BASE_INCREMENT_SD = 0.50


def drift_vector(
    delta_emerging: jnp.ndarray,
    delta_persistent: jnp.ndarray,
    delta_waning_magnitude: jnp.ndarray,
) -> jnp.ndarray:
    """Apply the frozen drift sign constraints."""
    return jnp.stack(
        [jnp.asarray(0.0), delta_emerging, delta_persistent, -delta_waning_magnitude]
    )


def seriousness_state_vector(gamma_nonbackground: jnp.ndarray) -> jnp.ndarray:
    """Background is the fixed seriousness reference."""
    return jnp.concatenate([jnp.zeros(1), jnp.asarray(gamma_nonbackground)])


def reconstruct_x(x_initial: jnp.ndarray, base_increment: jnp.ndarray) -> jnp.ndarray:
    """Construct pair-wise paths from the exactly anchored initial value."""
    if base_increment.shape[-1] == 0:
        return x_initial[..., None]
    return jnp.concatenate(
        [x_initial[..., None], x_initial[..., None] + jnp.cumsum(base_increment, axis=-1)],
        axis=-1,
    )


def state_emission_log_likelihood(
    x: jnp.ndarray,
    y: jnp.ndarray,
    serious: jnp.ndarray,
    drift: jnp.ndarray,
    dynamic_sd: jnp.ndarray,
    gamma0: jnp.ndarray,
    gamma_state: jnp.ndarray,
    gamma_x: jnp.ndarray,
    serious_pair_offset: jnp.ndarray,
    *,
    include_seriousness: bool = True,
) -> jnp.ndarray:
    """HSMM state evidence with no duplicated x_initial density.

    At t=1 the emission contains seriousness evidence only.  The true
    Normal(0, 0.35) x_initial prior is a NumPyro sample site and appears once.
    """
    x = jnp.asarray(x)
    y = jnp.asarray(y)
    serious = jnp.asarray(serious)
    first = jnp.zeros((1, 4), dtype=x.dtype)
    if x.shape[0] > 1:
        increment = x[1:] - x[:-1]
        tail = dist.Normal(drift[None, :], dynamic_sd[None, :]).log_prob(increment[:, None])
        dynamic = jnp.concatenate([first, tail], axis=0)
    else:
        dynamic = first
    if not include_seriousness:
        return dynamic
    logit = (
        gamma0
        + gamma_state[None, :]
        + gamma_x * jnp.maximum(x[:, None], 0.0)
        + serious_pair_offset
    )
    serious_log_prob = dist.Binomial(total_count=y[:, None], logits=logit).log_prob(
        serious[:, None]
    )
    return dynamic + serious_log_prob


def _one_pair_hsmm_log_likelihood(
    emission: jnp.ndarray,
    duration_means: jnp.ndarray,
    duration_shapes: jnp.ndarray,
    transition_probability: jnp.ndarray,
    hmax: int,
) -> jnp.ndarray:
    return forward_filter(
        emission,
        duration_means,
        duration_shapes,
        substantive_transition_matrix(transition_probability),
        hmax=hmax,
    ).log_marginal_likelihood


def exact_hsmm_panel_log_likelihood(
    emission: jnp.ndarray,
    duration_means: jnp.ndarray,
    duration_shapes: jnp.ndarray,
    transition_probability: jnp.ndarray,
    *,
    hmax: int,
) -> jnp.ndarray:
    """Sum exact explicit-duration HSMM marginal likelihoods over pairs."""
    one = partial(
        _one_pair_hsmm_log_likelihood,
        duration_means=duration_means,
        duration_shapes=duration_shapes,
        transition_probability=transition_probability,
        hmax=hmax,
    )
    return jnp.sum(jax.vmap(one)(emission))


def full_joint_model(
    y: jnp.ndarray,
    serious: jnp.ndarray,
    expected: jnp.ndarray,
    drug_index: jnp.ndarray,
    event_index: jnp.ndarray,
    n_drugs: int,
    n_events: int,
    *,
    hmax: int = 12,
    ablation: str = "FULL",
    available_through: int | None = None,
) -> None:
    """Complete frozen hierarchy with exact discrete HSMM marginalization."""
    y = jnp.asarray(y)
    serious = jnp.asarray(serious)
    expected = jnp.asarray(expected)
    drug_index = jnp.asarray(drug_index, dtype=jnp.int32)
    event_index = jnp.asarray(event_index, dtype=jnp.int32)
    n_pairs, n_quarters = y.shape

    mu = numpyro.sample("mu", dist.Normal(0.0, 1.0))
    if ablation == "A_NO_HIERARCHY":
        alpha_drug = jnp.zeros(n_drugs)
        beta_event = jnp.zeros(n_events)
        b_pair = jnp.zeros(n_pairs)
    else:
        sigma_drug = numpyro.sample("sigma_drug", dist.HalfNormal(0.5))
        sigma_event = numpyro.sample("sigma_event", dist.HalfNormal(0.5))
        sigma_pair = numpyro.sample("sigma_pair", dist.HalfNormal(0.5))
        raw_drug = numpyro.sample(
            "raw_drug", dist.Normal(0.0, 1.0).expand([n_drugs]).to_event(1)
        )
        raw_event = numpyro.sample(
            "raw_event", dist.Normal(0.0, 1.0).expand([n_events]).to_event(1)
        )
        raw_pair = numpyro.sample(
            "raw_pair", dist.Normal(0.0, 1.0).expand([n_pairs]).to_event(1)
        )
        alpha_drug = sigma_drug * (raw_drug - jnp.mean(raw_drug))
        beta_event = sigma_event * (raw_event - jnp.mean(raw_event))
        b_pair = sigma_pair * raw_pair
    numpyro.deterministic("alpha_drug", alpha_drug)
    numpyro.deterministic("beta_event", beta_event)
    numpyro.deterministic("b_pair", b_pair)

    phi = numpyro.sample("phi", dist.LogNormal(jnp.log(10.0), 0.7))
    delta_emerging = numpyro.sample("delta_emerging", dist.HalfNormal(0.35))
    delta_persistent = numpyro.sample("delta_persistent", dist.Normal(0.0, 0.08))
    delta_waning_magnitude = numpyro.sample("delta_waning_magnitude", dist.HalfNormal(0.35))
    dynamic_sd = numpyro.sample(
        "dynamic_sd", dist.HalfNormal(0.20).expand([4]).to_event(1)
    )
    drift = drift_vector(delta_emerging, delta_persistent, delta_waning_magnitude)
    numpyro.deterministic("drift", drift)

    duration_means = numpyro.sample(
        "duration_means",
        dist.LogNormal(jnp.log(DURATION_PRIOR_MEDIANS), DURATION_PRIOR_LOG_SDS).to_event(1),
    )
    duration_shapes = numpyro.sample(
        "duration_shapes", dist.LogNormal(jnp.log(2.0), 0.5).expand([4]).to_event(1)
    )
    transition_probability = numpyro.sample(
        "emerging_to_persistent_probability", dist.Beta(2.0, 1.0)
    )

    if ablation == "A_NO_SERIOUSNESS":
        gamma0 = jnp.asarray(0.0)
        gamma_state = jnp.zeros(4)
        gamma_x = jnp.asarray(0.0)
        serious_pair_offset = jnp.zeros((n_pairs, 1))
        include_seriousness = False
    else:
        gamma0 = numpyro.sample("gamma0", dist.Normal(-1.5, 1.5))
        gamma_nonbackground = numpyro.sample(
            "gamma_nonbackground", dist.Normal(0.0, 0.5).expand([3]).to_event(1)
        )
        gamma_x = numpyro.sample("gamma_x", dist.HalfNormal(1.0))
        sigma_serious_drug = numpyro.sample("sigma_serious_drug", dist.HalfNormal(0.5))
        sigma_serious_event = numpyro.sample("sigma_serious_event", dist.HalfNormal(0.5))
        raw_serious_drug = numpyro.sample(
            "raw_serious_drug", dist.Normal(0.0, 1.0).expand([n_drugs]).to_event(1)
        )
        raw_serious_event = numpyro.sample(
            "raw_serious_event", dist.Normal(0.0, 1.0).expand([n_events]).to_event(1)
        )
        serious_drug = sigma_serious_drug * (
            raw_serious_drug - jnp.mean(raw_serious_drug)
        )
        serious_event = sigma_serious_event * (
            raw_serious_event - jnp.mean(raw_serious_event)
        )
        gamma_state = seriousness_state_vector(gamma_nonbackground)
        serious_pair_offset = (
            serious_drug[drug_index] + serious_event[event_index]
        )[:, None]
        numpyro.deterministic("serious_drug", serious_drug)
        numpyro.deterministic("serious_event", serious_event)
        include_seriousness = True
    numpyro.deterministic("gamma_state", gamma_state)

    # The true anchor is represented exactly once here.  It is deliberately
    # absent from state_emission_log_likelihood at t=1.
    x_initial = numpyro.sample(
        "x_initial", dist.Normal(0.0, 0.35).expand([n_pairs]).to_event(1)
    )
    if n_quarters > 1:
        increment_base = dist.Normal(0.0, BASE_INCREMENT_SD)
        base_increment = numpyro.sample(
            "base_increment",
            increment_base.expand([n_pairs, n_quarters - 1]).to_event(2),
        )
    else:
        base_increment = jnp.zeros((n_pairs, 0), dtype=x_initial.dtype)
    x = reconstruct_x(x_initial, base_increment)
    numpyro.deterministic("x", x)

    count_baseline = (
        mu + alpha_drug[drug_index] + beta_event[event_index] + b_pair
    )
    count_mean = jnp.maximum(expected, 1e-10) * jnp.exp(count_baseline[:, None] + x)
    count_log_prob = dist.NegativeBinomial2(
        mean=count_mean, concentration=phi
    ).log_prob(y)
    if available_through is not None:
        observed_mask = jnp.arange(n_quarters) < available_through
        count_log_prob = jnp.where(observed_mask[None, :], count_log_prob, 0.0)
    numpyro.factor("count_log_likelihood", jnp.sum(count_log_prob))

    # A rolling invocation is a genuine prefix target.  Future observation
    # values must be unable to affect either the seriousness likelihood or the
    # discrete-state marginal.  The unused future path increments retain their
    # ordinary base prior and integrate to one; only increments that belong to
    # the available prefix are cancelled by the conditional-path correction.
    prefix_length = n_quarters if available_through is None else available_through
    x_prefix = x[:, :prefix_length]
    y_prefix = y[:, :prefix_length]
    serious_prefix = serious[:, :prefix_length]
    emission = jax.vmap(
        lambda path, count, severe, offset: state_emission_log_likelihood(
            path,
            count,
            severe,
            drift,
            dynamic_sd,
            gamma0,
            gamma_state,
            gamma_x,
            offset,
            include_seriousness=include_seriousness,
        )
    )(x_prefix, y_prefix, serious_prefix, serious_pair_offset)
    if ablation == "A_STICKY_HMM":
        hsmm_log_likelihood = jnp.sum(
            jax.vmap(
                lambda value: sticky_hmm_filter(
                    value, transition_probability
                ).log_marginal_likelihood
            )(emission)
        )
    else:
        hsmm_log_likelihood = exact_hsmm_panel_log_likelihood(
            emission,
            duration_means,
            duration_shapes,
            transition_probability,
            hmax=hmax,
        )
    corrected_increment_count = max(prefix_length - 1, 0)
    if corrected_increment_count > 0:
        proposal_log_density = jnp.sum(
            increment_base.log_prob(base_increment[:, :corrected_increment_count])
        )
    else:
        proposal_log_density = jnp.asarray(0.0)
    numpyro.factor(
        "hsmm_and_increment_target_correction",
        hsmm_log_likelihood - proposal_log_density,
    )


def conditional_path_target_log_density(
    x_initial: jnp.ndarray,
    base_increment: jnp.ndarray,
    y: jnp.ndarray,
    serious: jnp.ndarray,
    expected: jnp.ndarray,
    pair_baseline: jnp.ndarray,
    phi: jnp.ndarray,
    drift: jnp.ndarray,
    dynamic_sd: jnp.ndarray,
    duration_means: jnp.ndarray,
    duration_shapes: jnp.ndarray,
    transition_probability: jnp.ndarray,
    gamma0: jnp.ndarray,
    gamma_state: jnp.ndarray,
    gamma_x: jnp.ndarray,
    serious_pair_offset: jnp.ndarray,
    *,
    hmax: int,
) -> jnp.ndarray:
    """Analytically checkable path target used by density regression tests.

    This excludes global-parameter priors and includes the x_initial anchor,
    count likelihood, dynamic/seriousness HSMM marginal exactly once each.
    The convenient increment proposal is analytically cancelled and therefore
    does not appear in the returned target.
    """
    x = reconstruct_x(x_initial, base_increment)
    anchor = jnp.sum(dist.Normal(0.0, 0.35).log_prob(x_initial))
    mean = jnp.maximum(expected, 1e-10) * jnp.exp(pair_baseline[:, None] + x)
    count_log_prob = jnp.sum(dist.NegativeBinomial2(mean=mean, concentration=phi).log_prob(y))
    emission = jax.vmap(
        lambda path, count, severe, offset: state_emission_log_likelihood(
            path,
            count,
            severe,
            drift,
            dynamic_sd,
            gamma0,
            gamma_state,
            gamma_x,
            offset,
        )
    )(x, y, serious, serious_pair_offset)
    hsmm = exact_hsmm_panel_log_likelihood(
        emission,
        duration_means,
        duration_shapes,
        transition_probability,
        hmax=hmax,
    )
    return anchor + count_log_prob + hsmm


PRIMARY_CONTINUOUS_SITES = {
    "mu",
    "sigma_drug",
    "sigma_event",
    "sigma_pair",
    "raw_drug",
    "raw_event",
    "raw_pair",
    "phi",
    "delta_emerging",
    "delta_persistent",
    "delta_waning_magnitude",
    "dynamic_sd",
    "duration_means",
    "duration_shapes",
    "emerging_to_persistent_probability",
    "gamma0",
    "gamma_nonbackground",
    "gamma_x",
    "sigma_serious_drug",
    "sigma_serious_event",
    "raw_serious_drug",
    "raw_serious_event",
    "x_initial",
    "base_increment",
}
