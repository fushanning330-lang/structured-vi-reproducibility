"""True forward-backward diagnostic smoother for the expanded-state HSMM."""

from __future__ import annotations

from dataclasses import dataclass

import jax
import jax.numpy as jnp
import numpy as np
from jax.scipy.special import logsumexp

from dhbcp_pv.models.hsmm import build_expanded_transition, substantive_transition_matrix


@dataclass(frozen=True)
class HSMMSmoothingResult:
    smoothed_state_probability: np.ndarray
    smoothed_expanded_probability: np.ndarray
    log_marginal_likelihood: float
    diagnostic_smoothing: bool = True
    operational_filtering: bool = False


def forward_backward_smoother(
    emission_log_likelihood: jnp.ndarray,
    duration_means: jnp.ndarray,
    duration_shapes: jnp.ndarray,
    substantive_transition: jnp.ndarray | None = None,
    initial_state_probability: jnp.ndarray | None = None,
    *,
    hmax: int = 12,
) -> HSMMSmoothingResult:
    """Run an actual backward pass; output is diagnostic and never operational."""
    emission = jnp.asarray(emission_log_likelihood)
    if substantive_transition is None:
        substantive_transition = substantive_transition_matrix()
    if initial_state_probability is None:
        initial_state_probability = jnp.array([1.0, 0.0, 0.0, 0.0])
    log_transition, _, _ = build_expanded_transition(
        duration_means, duration_shapes, substantive_transition, hmax
    )
    state_index = jnp.repeat(jnp.arange(4), hmax)
    initial = jnp.full(4 * hmax, -jnp.inf)
    for state in range(4):
        probability = initial_state_probability[state]
        initial = initial.at[state * hmax].set(
            jnp.where(probability > 0, jnp.log(probability), -jnp.inf)
        )
    alpha0 = initial + emission[0, state_index]

    def forward_step(previous: jnp.ndarray, current_emission: jnp.ndarray):
        alpha = logsumexp(
            previous[:, None] + log_transition + current_emission[state_index][None, :],
            axis=0,
        )
        return alpha, alpha

    if emission.shape[0] > 1:
        _, alpha_tail = jax.lax.scan(forward_step, alpha0, emission[1:])
        alpha = jnp.concatenate([alpha0[None, :], alpha_tail], axis=0)
    else:
        alpha = alpha0[None, :]
    beta_last = jnp.zeros(4 * hmax)

    def backward_step(next_beta: jnp.ndarray, next_emission: jnp.ndarray):
        beta = logsumexp(
            log_transition + next_emission[state_index][None, :] + next_beta[None, :],
            axis=1,
        )
        return beta, beta

    if emission.shape[0] > 1:
        _, beta_reverse = jax.lax.scan(
            backward_step, beta_last, emission[1:][::-1]
        )
        beta = jnp.concatenate([beta_reverse[::-1], beta_last[None, :]], axis=0)
    else:
        beta = beta_last[None, :]
    log_likelihood = logsumexp(alpha[-1])
    expanded = jnp.exp(alpha + beta - log_likelihood)
    state = jnp.sum(expanded.reshape(emission.shape[0], 4, hmax), axis=2)
    return HSMMSmoothingResult(
        smoothed_state_probability=np.asarray(state),
        smoothed_expanded_probability=np.asarray(expanded),
        log_marginal_likelihood=float(log_likelihood),
    )

