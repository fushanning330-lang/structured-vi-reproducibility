"""Matched sticky-HMM ablation, explicitly distinct from DHBCP-PV V2 HSMM."""

from __future__ import annotations

from dataclasses import dataclass

import jax
import jax.numpy as jnp
from jax.scipy.special import logsumexp

from dhbcp_pv.models.hsmm import substantive_transition_matrix


@dataclass(frozen=True)
class StickyHMMResult:
    filtered_state_probability: jnp.ndarray
    substantive_change_probability: jnp.ndarray
    persistence_probability_h2: jnp.ndarray
    log_marginal_likelihood: jnp.ndarray


def sticky_hmm_filter(
    emission_log_likelihood: jnp.ndarray,
    emerging_to_persistent: jnp.ndarray,
    *,
    sticky_probability: float = 0.80,
) -> StickyHMMResult:
    emission = jnp.asarray(emission_log_likelihood)
    substantive = substantive_transition_matrix(emerging_to_persistent)
    transition = sticky_probability * jnp.eye(4) + (1.0 - sticky_probability) * substantive
    log_transition = jnp.where(transition > 0, jnp.log(jnp.maximum(transition, 1e-30)), -jnp.inf)
    alpha0 = jnp.array([0.0, -jnp.inf, -jnp.inf, -jnp.inf]) + emission[0]
    norm0 = logsumexp(alpha0)
    filtered0 = jnp.exp(alpha0 - norm0)

    def step(previous: jnp.ndarray, current_emission: jnp.ndarray):
        joint = previous[:, None] + log_transition + current_emission[None, :]
        alpha = logsumexp(joint, axis=0)
        norm = logsumexp(alpha)
        filtered = jnp.exp(alpha - norm)
        off_diagonal = ~jnp.eye(4, dtype=bool)
        change = jnp.exp(logsumexp(jnp.where(off_diagonal, joint, -jnp.inf)) - norm)
        return alpha, (filtered, change)

    if emission.shape[0] > 1:
        last, tail = jax.lax.scan(step, alpha0, emission[1:])
        filtered = jnp.concatenate([filtered0[None, :], tail[0]], axis=0)
        change = jnp.concatenate([jnp.zeros(1), tail[1]])
    else:
        last = alpha0
        filtered = filtered0[None, :]
        change = jnp.zeros(1)
    persistence = filtered[:, 2] * sticky_probability**2
    return StickyHMMResult(
        filtered_state_probability=filtered,
        substantive_change_probability=change,
        persistence_probability_h2=persistence,
        log_marginal_likelihood=logsumexp(last),
    )

