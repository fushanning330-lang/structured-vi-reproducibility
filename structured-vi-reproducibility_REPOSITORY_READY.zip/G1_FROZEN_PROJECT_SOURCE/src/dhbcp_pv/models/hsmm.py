"""Exact log-space explicit-duration HSMM filtering with Hmax administrative renewal."""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product

import jax
import jax.numpy as jnp
import numpy as np
from jax.scipy.special import gammaln, logsumexp


STATE_NAMES = ("Background", "Emerging", "Persistent", "Waning")
BACKGROUND, EMERGING, PERSISTENT, WANING = range(4)
NEG_INF = -jnp.inf


@dataclass(frozen=True)
class HSMMResult:
    log_marginal_likelihood: jnp.ndarray
    prefix_log_marginal: jnp.ndarray
    filtered_state_probability: jnp.ndarray
    filtered_expanded_probability: jnp.ndarray
    substantive_change_probability: jnp.ndarray
    administrative_renewal_probability: jnp.ndarray
    persistence_probability_h2: jnp.ndarray
    log_transition: jnp.ndarray
    substantive_transition_mask: jnp.ndarray
    administrative_transition_mask: jnp.ndarray


def _safe_logsumexp(values: jnp.ndarray, axis: int | tuple[int, ...] | None = None) -> jnp.ndarray:
    """Log-sum-exp with a finite derivative when an entire slice is impossible."""
    finite = jnp.isfinite(values)
    any_finite = jnp.any(finite, axis=axis)
    if axis is None:
        safe_values = jnp.where(any_finite, values, 0.0)
    else:
        expanded = any_finite
        axes = (axis,) if isinstance(axis, int) else axis
        for selected_axis in sorted((a % values.ndim for a in axes)):
            expanded = jnp.expand_dims(expanded, selected_axis)
        safe_values = jnp.where(expanded, values, 0.0)
    result = logsumexp(safe_values, axis=axis)
    return jnp.where(any_finite, result, NEG_INF)


def substantive_transition_matrix(emerging_to_persistent: float | jnp.ndarray = 2.0 / 3.0) -> jnp.ndarray:
    q = jnp.asarray(emerging_to_persistent)
    matrix = jnp.zeros((4, 4))
    matrix = matrix.at[BACKGROUND, EMERGING].set(1.0)
    matrix = matrix.at[EMERGING, PERSISTENT].set(q)
    matrix = matrix.at[EMERGING, WANING].set(1.0 - q)
    matrix = matrix.at[PERSISTENT, WANING].set(1.0)
    matrix = matrix.at[WANING, BACKGROUND].set(1.0)
    return matrix


def _shifted_nb_exact_pmf(mean_duration: jnp.ndarray, shape: jnp.ndarray, max_duration: int) -> jnp.ndarray:
    """Exact P(D=d), d=1..max_duration, for D=1+NB(shape,p)."""
    mean_duration = jnp.maximum(jnp.asarray(mean_duration), 1.0001)
    shape = jnp.maximum(jnp.asarray(shape), 1e-4)
    p = shape / (shape + mean_duration - 1.0)
    n = jnp.arange(max_duration, dtype=jnp.float32)
    log_pmf = (
        gammaln(n + shape)
        - gammaln(shape)
        - gammaln(n + 1.0)
        + shape * jnp.log(p)
        + n * jnp.log1p(-p)
    )
    return jnp.exp(log_pmf)


def capped_shifted_nb_duration_pmf(mean_duration: jnp.ndarray, shape: jnp.ndarray, hmax: int) -> jnp.ndarray:
    """Capped PMF on 1..Hmax; final bin is P(D>=Hmax), so rows sum exactly to one."""
    exact = _shifted_nb_exact_pmf(mean_duration, shape, hmax)
    tail_at_hmax = jnp.maximum(1.0 - jnp.sum(exact[:-1]), 1e-12)
    capped = jnp.concatenate([exact[:-1], tail_at_hmax[None]])
    return capped / jnp.sum(capped)


def duration_hazards_and_admin_probability(
    mean_duration: jnp.ndarray, shape: jnp.ndarray, hmax: int
) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    """Return within-support hazards, Hmax administrative renewal probability and capped PMF."""
    exact = _shifted_nb_exact_pmf(mean_duration, shape, hmax)
    survival = 1.0 - jnp.concatenate([jnp.zeros(1), jnp.cumsum(exact[:-1])])
    hazards = jnp.clip(exact / jnp.maximum(survival, 1e-12), 0.0, 1.0)
    tail_ge = jnp.maximum(survival[-1], 1e-12)
    tail_gt = jnp.maximum(tail_ge - exact[-1], 0.0)
    admin_probability = jnp.clip(tail_gt / tail_ge, 0.0, 1.0)
    capped = capped_shifted_nb_duration_pmf(mean_duration, shape, hmax)
    return hazards, admin_probability, capped


def build_expanded_transition(
    duration_means: jnp.ndarray,
    duration_shapes: jnp.ndarray,
    substantive_transition: jnp.ndarray,
    hmax: int,
) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    """Build K*Hmax transition matrix; age Hmax same-state renewal is administrative only."""
    k_states = 4
    n_expanded = k_states * hmax
    transition = jnp.zeros((n_expanded, n_expanded))
    substantive_mask = jnp.zeros((n_expanded, n_expanded), dtype=bool)
    administrative_mask = jnp.zeros((n_expanded, n_expanded), dtype=bool)
    for state in range(k_states):
        hazards, admin_probability, _ = duration_hazards_and_admin_probability(
            duration_means[state], duration_shapes[state], hmax
        )
        for age_index in range(hmax):
            source = state * hmax + age_index
            if age_index < hmax - 1:
                continuation = 1.0 - hazards[age_index]
                target = state * hmax + age_index + 1
                transition = transition.at[source, target].add(continuation)
                end_probability = hazards[age_index]
            else:
                transition = transition.at[source, state * hmax].add(admin_probability)
                administrative_mask = administrative_mask.at[source, state * hmax].set(True)
                end_probability = 1.0 - admin_probability
            for next_state in range(k_states):
                probability = end_probability * substantive_transition[state, next_state]
                transition = transition.at[source, next_state * hmax].add(probability)
                substantive_mask = substantive_mask.at[source, next_state * hmax].set(
                    substantive_transition[state, next_state] > 0
                )
    # Evaluate log only on a strictly positive argument.  JAX differentiates
    # both branches of ``where``; a literal log(0) therefore contaminates the
    # duration gradient even though that branch is masked in the forward pass.
    safe_log_transition = jnp.log(jnp.maximum(transition, jnp.finfo(transition.dtype).tiny))
    log_transition = jnp.where(transition > 0, safe_log_transition, NEG_INF)
    return log_transition, substantive_mask, administrative_mask


def _persistence_horizon_probability(
    expanded_probability: jnp.ndarray,
    transition: jnp.ndarray,
    substantive_mask: jnp.ndarray,
    hmax: int,
    horizon: int,
) -> jnp.ndarray:
    state_index = jnp.repeat(jnp.arange(4), hmax)
    mass = expanded_probability * (state_index == PERSISTENT)
    no_change_transition = transition * (~substantive_mask)
    for _ in range(horizon):
        mass = mass @ no_change_transition
    return jnp.sum(mass * (state_index == PERSISTENT))


def forward_filter(
    emission_log_likelihood: jnp.ndarray,
    duration_means: jnp.ndarray,
    duration_shapes: jnp.ndarray,
    substantive_transition: jnp.ndarray | None = None,
    initial_state_probability: jnp.ndarray | None = None,
    *,
    hmax: int = 12,
    persistence_horizon: int = 2,
) -> HSMMResult:
    """Exact filtering recursion; every output at t uses emissions 1..t only."""
    emissions = jnp.asarray(emission_log_likelihood)
    if emissions.ndim != 2 or emissions.shape[1] != 4:
        raise ValueError("emission_log_likelihood must have shape [T,4]")
    if substantive_transition is None:
        substantive_transition = substantive_transition_matrix()
    if initial_state_probability is None:
        initial_state_probability = jnp.array([1.0, 0.0, 0.0, 0.0])
    log_transition, substantive_mask, administrative_mask = build_expanded_transition(
        jnp.asarray(duration_means), jnp.asarray(duration_shapes), jnp.asarray(substantive_transition), hmax
    )
    transition = jnp.exp(log_transition)
    state_index = jnp.repeat(jnp.arange(4), hmax)
    initial_log_mass = jnp.full((4 * hmax,), NEG_INF)
    for state in range(4):
        initial_log_mass = initial_log_mass.at[state * hmax].set(
            jnp.where(initial_state_probability[state] > 0, jnp.log(initial_state_probability[state]), NEG_INF)
        )
    alpha0 = initial_log_mass + emissions[0, state_index]

    def summarize(alpha: jnp.ndarray) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
        prefix_ll = _safe_logsumexp(alpha)
        expanded = jnp.exp(alpha - prefix_ll)
        state = jnp.sum(expanded.reshape(4, hmax), axis=1)
        persistence = _persistence_horizon_probability(
            expanded, transition, substantive_mask, hmax, persistence_horizon
        )
        return prefix_ll, expanded, persistence

    ll0, expanded0, persistence0 = summarize(alpha0)

    def step(alpha_previous: jnp.ndarray, emission: jnp.ndarray):
        joint = alpha_previous[:, None] + log_transition + emission[state_index][None, :]
        alpha = _safe_logsumexp(joint, axis=0)
        prefix_ll, expanded, persistence = summarize(alpha)
        change_log_mass = _safe_logsumexp(jnp.where(substantive_mask, joint, NEG_INF))
        admin_log_mass = _safe_logsumexp(jnp.where(administrative_mask, joint, NEG_INF))
        p_change = jnp.where(jnp.isfinite(change_log_mass), jnp.exp(change_log_mass - prefix_ll), 0.0)
        p_admin = jnp.where(jnp.isfinite(admin_log_mass), jnp.exp(admin_log_mass - prefix_ll), 0.0)
        state = jnp.sum(expanded.reshape(4, hmax), axis=1)
        return alpha, (prefix_ll, state, expanded, p_change, p_admin, persistence)

    if emissions.shape[0] > 1:
        alpha_last, tail = jax.lax.scan(step, alpha0, emissions[1:])
        prefix_ll = jnp.concatenate([ll0[None], tail[0]])
        state_probability = jnp.concatenate([jnp.sum(expanded0.reshape(4, hmax), axis=1)[None, :], tail[1]], axis=0)
        expanded_probability = jnp.concatenate([expanded0[None, :], tail[2]], axis=0)
        change_probability = jnp.concatenate([jnp.zeros(1), tail[3]])
        admin_probability = jnp.concatenate([jnp.zeros(1), tail[4]])
        persistence_probability = jnp.concatenate([persistence0[None], tail[5]])
    else:
        alpha_last = alpha0
        prefix_ll = ll0[None]
        state_probability = jnp.sum(expanded0.reshape(4, hmax), axis=1)[None, :]
        expanded_probability = expanded0[None, :]
        change_probability = jnp.zeros(1)
        admin_probability = jnp.zeros(1)
        persistence_probability = persistence0[None]
    return HSMMResult(
        log_marginal_likelihood=_safe_logsumexp(alpha_last),
        prefix_log_marginal=prefix_ll,
        filtered_state_probability=state_probability,
        filtered_expanded_probability=expanded_probability,
        substantive_change_probability=change_probability,
        administrative_renewal_probability=admin_probability,
        persistence_probability_h2=persistence_probability,
        log_transition=log_transition,
        substantive_transition_mask=substantive_mask,
        administrative_transition_mask=administrative_mask,
    )


def brute_force_log_likelihood(
    emission_log_likelihood: np.ndarray,
    duration_means: np.ndarray,
    duration_shapes: np.ndarray,
    substantive_transition: np.ndarray | None = None,
    initial_state_probability: np.ndarray | None = None,
    *,
    hmax: int = 3,
) -> float:
    """Enumerate all nonzero expanded-state paths; intended only for T<=8 tests."""
    emissions = np.asarray(emission_log_likelihood, dtype=float)
    substantive_transition = (
        np.asarray(substantive_transition, dtype=float)
        if substantive_transition is not None
        else np.asarray(substantive_transition_matrix())
    )
    initial = (
        np.asarray(initial_state_probability, dtype=float)
        if initial_state_probability is not None
        else np.array([1.0, 0.0, 0.0, 0.0])
    )
    log_transition = np.asarray(
        build_expanded_transition(
            jnp.asarray(duration_means), jnp.asarray(duration_shapes), jnp.asarray(substantive_transition), hmax
        )[0]
    )
    state_index = np.repeat(np.arange(4), hmax)
    paths: list[tuple[int, float]] = []
    for state in range(4):
        if initial[state] > 0:
            expanded = state * hmax
            paths.append((expanded, np.log(initial[state]) + emissions[0, state]))
    for time in range(1, emissions.shape[0]):
        next_paths: list[tuple[int, float]] = []
        for previous, log_weight in paths:
            targets = np.flatnonzero(np.isfinite(log_transition[previous]))
            for target in targets:
                next_paths.append(
                    (target, log_weight + log_transition[previous, target] + emissions[time, state_index[target]])
                )
        paths = next_paths
    weights = np.array([weight for _, weight in paths])
    maximum = np.max(weights)
    return float(maximum + np.log(np.exp(weights - maximum).sum()))
