"""Joint count, dynamic-state, duration and seriousness model for Phase 3."""

from __future__ import annotations

import jax
import jax.numpy as jnp
import numpyro
import numpyro.distributions as dist

from dhbcp_pv.models.hsmm import forward_filter, substantive_transition_matrix


DEFAULT_DRIFT = jnp.array([0.0, 0.25, 0.0, -0.25])
DEFAULT_DYNAMIC_SD = jnp.array([0.20, 0.20, 0.12, 0.20])
DEFAULT_SERIOUS_STATE = jnp.array([0.0, 0.25, 0.35, 0.10])
DEFAULT_DURATION_MEANS = jnp.array([6.0, 2.0, 5.0, 3.0])
DEFAULT_DURATION_SHAPES = jnp.full(4, 2.0)


def negative_binomial_2_log_prob(y: jnp.ndarray, mean: jnp.ndarray, phi: float | jnp.ndarray) -> jnp.ndarray:
    """NB2 log likelihood with E[Y]=mean and Var[Y]=mean+mean^2/phi."""
    return dist.NegativeBinomial2(mean=jnp.maximum(mean, 1e-10), concentration=phi).log_prob(y)


def seriousness_probability(
    x: jnp.ndarray,
    *,
    gamma0: float = -1.5,
    gamma_state: jnp.ndarray = DEFAULT_SERIOUS_STATE,
    gamma_x: float = 0.5,
) -> jnp.ndarray:
    """Return state-specific P(serious | report); Background is the fixed reference."""
    return jax.nn.sigmoid(gamma0 + gamma_state[None, :] + gamma_x * x[:, None])


def joint_emission_log_likelihood(
    x: jnp.ndarray,
    y: jnp.ndarray,
    serious: jnp.ndarray,
    *,
    drift: jnp.ndarray = DEFAULT_DRIFT,
    dynamic_sd: jnp.ndarray = DEFAULT_DYNAMIC_SD,
    gamma0: float = -1.5,
    gamma_state: jnp.ndarray = DEFAULT_SERIOUS_STATE,
    gamma_x: float = 0.5,
    x_initial_sd: float = 0.35,
) -> jnp.ndarray:
    """State emissions for the exactly marginalized HSMM.

    The count likelihood is conditionally independent of the discrete state once
    ``x`` is given and is therefore handled outside this emission matrix.
    """
    x = jnp.asarray(x)
    y = jnp.asarray(y)
    serious = jnp.asarray(serious)
    dynamic_first = dist.Normal(0.0, x_initial_sd).log_prob(x[0]) + jnp.zeros(4)
    if x.shape[0] > 1:
        increments = x[1:] - x[:-1]
        dynamic_tail = dist.Normal(drift[None, :], dynamic_sd[None, :]).log_prob(increments[:, None])
        dynamic = jnp.concatenate([dynamic_first[None, :], dynamic_tail], axis=0)
    else:
        dynamic = dynamic_first[None, :]
    probability = seriousness_probability(
        x, gamma0=gamma0, gamma_state=gamma_state, gamma_x=gamma_x
    )
    serious_log_likelihood = dist.Binomial(total_count=y[:, None], probs=probability).log_prob(
        serious[:, None]
    )
    return dynamic + serious_log_likelihood


def marginalized_joint_log_likelihood(
    x: jnp.ndarray,
    y: jnp.ndarray,
    serious: jnp.ndarray,
    expected: jnp.ndarray,
    *,
    baseline: float | jnp.ndarray = 0.0,
    phi: float = 10.0,
    hmax: int = 12,
    duration_means: jnp.ndarray = DEFAULT_DURATION_MEANS,
    duration_shapes: jnp.ndarray = DEFAULT_DURATION_SHAPES,
) -> jnp.ndarray:
    """Count likelihood plus exact discrete HSMM marginal likelihood."""
    emission = joint_emission_log_likelihood(x, y, serious)
    hsmm = forward_filter(
        emission,
        duration_means,
        duration_shapes,
        substantive_transition_matrix(),
        hmax=hmax,
    )
    count_mean = jnp.maximum(expected, 1e-10) * jnp.exp(baseline + x)
    return jnp.sum(negative_binomial_2_log_prob(y, count_mean, phi)) + hsmm.log_marginal_likelihood


def reference_nuts_model(
    y: jnp.ndarray,
    serious: jnp.ndarray,
    expected: jnp.ndarray,
    *,
    hmax: int = 12,
    phi: float = 10.0,
) -> None:
    """Continuous target used for NUTS with the discrete HSMM marginalized exactly.

    A broad Gaussian increment distribution is used only as a NumPyro proposal
    base and is cancelled by ``target_correction``.  The resulting target is the
    joint count + dynamic HSMM + seriousness density, not an ordinary HMM.
    """
    y = jnp.asarray(y)
    serious = jnp.asarray(serious)
    expected = jnp.asarray(expected)
    n_pairs, n_quarters = y.shape
    x_initial = numpyro.sample(
        "x_initial", dist.Normal(0.0, 0.35).expand([n_pairs]).to_event(1)
    )
    proposal = dist.Normal(0.0, 0.5)
    raw_increment = numpyro.sample(
        "raw_increment", proposal.expand([n_pairs, n_quarters - 1]).to_event(2)
    )
    x = jnp.concatenate(
        [x_initial[:, None], x_initial[:, None] + jnp.cumsum(raw_increment, axis=1)], axis=1
    )
    numpyro.deterministic("x", x)
    emission = jax.vmap(joint_emission_log_likelihood)(x, y, serious)

    def one_hsmm(emission_matrix: jnp.ndarray) -> jnp.ndarray:
        return forward_filter(
            emission_matrix,
            DEFAULT_DURATION_MEANS,
            DEFAULT_DURATION_SHAPES,
            substantive_transition_matrix(),
            hmax=hmax,
        ).log_marginal_likelihood

    hsmm_log_likelihood = jax.vmap(one_hsmm)(emission)
    proposal_log_density = jnp.sum(proposal.log_prob(raw_increment))
    numpyro.factor("target_correction", jnp.sum(hsmm_log_likelihood) - proposal_log_density)
    mean = jnp.maximum(expected, 1e-10) * jnp.exp(x)
    numpyro.sample("count", dist.NegativeBinomial2(mean=mean, concentration=phi), obs=y)

