"""Phase 2 static hierarchical Negative-Binomial reference smoke model.

This file intentionally stops short of pretending the final HSMM inference is implemented.
The first formal modeling milestone is:
1) Negative-Binomial hierarchical observation model under NUTS;
2) validated explicit-duration HSMM marginalization;
3) joint seriousness submodel;
4) posterior decision layer.

This module is an engineering milestone and does not implement or replace the frozen HSMM.
"""

from __future__ import annotations

import numpyro
import numpyro.distributions as dist
from jax import numpy as jnp


def negative_binomial_mean_concentration(mean: jnp.ndarray, concentration: jnp.ndarray) -> tuple[jnp.ndarray, jnp.ndarray]:
    """Convert NB2 mean/concentration to total_count and success probability."""
    probability = concentration / (concentration + mean)
    return concentration, probability


def static_hierarchical_nb_model(
    y: jnp.ndarray,
    m_expected: jnp.ndarray,
    drug_index: jnp.ndarray,
    event_index: jnp.ndarray,
    pair_index: jnp.ndarray,
    n_drugs: int,
    n_events: int,
    n_pairs: int,
) -> None:
    """NB2(mean=M*exp(eta), concentration=phi) with non-centered random effects."""
    mu = numpyro.sample("mu", dist.Normal(0.0, 1.0))
    sigma_drug = numpyro.sample("sigma_drug", dist.HalfNormal(0.5))
    sigma_event = numpyro.sample("sigma_event", dist.HalfNormal(0.5))
    sigma_pair = numpyro.sample("sigma_pair", dist.HalfNormal(0.5))
    z_drug = numpyro.sample("z_drug", dist.Normal(0.0, 1.0).expand([n_drugs]).to_event(1))
    z_event = numpyro.sample("z_event", dist.Normal(0.0, 1.0).expand([n_events]).to_event(1))
    z_pair = numpyro.sample("z_pair", dist.Normal(0.0, 1.0).expand([n_pairs]).to_event(1))
    alpha_drug = sigma_drug * (z_drug - jnp.mean(z_drug))
    beta_event = sigma_event * (z_event - jnp.mean(z_event))
    b_pair = sigma_pair * z_pair
    phi = numpyro.sample("phi", dist.LogNormal(jnp.log(10.0), 0.7))
    eta = mu + alpha_drug[drug_index] + beta_event[event_index] + b_pair[pair_index]
    mean = m_expected * jnp.exp(eta)
    numpyro.deterministic("mean_reports", mean)
    numpyro.sample("obs", dist.NegativeBinomial2(mean=mean, concentration=phi), obs=y)

def model_status() -> dict:
    return {
        "observation_layer": "phase2_static_nb_smoke_implemented",
        "hierarchy": "phase2_noncentered_static_smoke_implemented",
        "hsmm": "specified_not_yet_implemented",
        "seriousness": "specified_not_yet_implemented",
        "decision_layer": "implemented_separately",
        "result_scope": "ENGINEERING_PILOT_NOT_FORMAL",
    }
