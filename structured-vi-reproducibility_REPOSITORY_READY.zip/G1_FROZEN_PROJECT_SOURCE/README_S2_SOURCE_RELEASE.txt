V3 G1 FROZEN PROJECT SOURCE — S2 RELEASE

Purpose
-------
This directory contains the recovered frozen author-generated project source needed to inspect the V3 G1 fitting workflow and its dependencies. It is copied from the historical frozen-source recovery package without rewriting scientific source code. Operating-system metadata, caches, results, raw data, and four unrelated early-phase scripts containing personal absolute paths were excluded.

Key executed-source identities
------------------------------
scripts/86_run_phase3c4v_v3_g1_canary_terminal_semantics_final.py
  SHA256 3491981c1be3dba35e541128ef497119ee7b74d4539f6632e1b85d903ef6ffd4

scripts/87_run_phase3c4v_v3_g1_remaining_matrix.py
  SHA256 24102da589e2c5992754d129c87f49c05f6eb3bbdf4b85af14e215d36cbda815

src/dhbcp_pv/inference/v3_local_block_ar1_guide.py
  SHA256 19a66f8b40bb211a68dfd65993e9235498bb11f5e54594553611fea87561a07f

Recovered dependency identities
-------------------------------
src/dhbcp_pv/models/full_joint_model.py
  SHA256 163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c

src/dhbcp_pv/inference/variational_param_persistence.py
  SHA256 0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803

scripts/51_run_phase3c_nuts.py
  SHA256 1239716a2c73ed1faf3f6085a8bce361553c81c9ad4245bb9149845c45bcff4f

src/dhbcp_pv/sim/hierarchical_phase3b.py
  SHA256 5617a62697337fbdfb2ded19f6a3ef8ce2061d6ab0bf91437272391f14bf3f8a

config/phase3b_tiera_seeds_v1.csv
  SHA256 2054361bc280a975b9694f1de40cad87884da9bf7bd1c9fbbd691faea229c7db

Execution boundary
------------------
The original G1 runners preserve one-shot authorization/consumption guards. Those guards are part of the historical executed source and are intentionally not removed. This directory is therefore an archival source-level release, not an instruction to rerun consumed historical identities. Publication tables and data-derived figures are reproduced through ../reproduce_plos_outputs.py from the supplied derived CSVs.

Verification
------------
SOURCE_IDENTITY_MANIFEST.csv records SHA256 and file size for every file included in this source release. verify_g1_source_hashes.py checks the eight key identities above without running inference or optimization.
