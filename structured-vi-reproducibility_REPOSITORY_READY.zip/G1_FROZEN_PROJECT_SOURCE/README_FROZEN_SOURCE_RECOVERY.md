# DHBCP-PV V3 G1 — Frozen Source Recovery

**Purpose:** author-generated source code, configuration, and run scripts for the
DHBCP-PV / Phase3C4V / V3 G1 experiment (Supporting Information S2 open code release).

**Source tree:** the project root `DHBCP-PV_V2_codebase_V0_1` on the author's local machine (read-only; nothing modified).

**Contents:**
- `src/dhbcp_pv/` — package source (models, inference, sim, posterior, evaluation, decision, baselines, data)
- `scripts/` — run scripts (including 86/87 V3 G1 executors; 51_run_phase3c_nuts.py is imported by 86/87 as `frozen_51`)
- `config/` — frozen configuration and seed matrices
- Root-level: pyproject.toml, requirements-frozen.txt, PROJECT_FREEZE_MANIFEST.json, README.md

**Excluded (per recovery rules):**
- `results/` and `data/` (large run outputs and raw/derived data; 447 MB + 23 GB)
- `__pycache__`, `*.egg-info`, Python environments, caches
- 4 early-phase scripts containing absolute personal paths unrelated to the V3 G1
  scientific path: `40_phase3b_prechange_freeze.py`, `26_build_phase2_handoff.py`,
  `54_finalize_phase3c.py`, `33_build_phase3_handoff.py` (excluded to avoid releasing
  personal absolute paths; they are not imported by the V3 G1 executors)
- No credentials, API keys, or private data are included.

**Verification:** the five frozen dependency files (full_joint_model.py,
variational_param_persistence.py, 51_run_phase3c_nuts.py, hierarchical_phase3b.py,
phase3b_tiera_seeds_v1.csv) are SHA256-verified EXACT MATCH in
`PLOS_G1_ORIGINAL_DEPENDENCIES_RECOVERY/`; v3_local_block_ar1_guide.py matches
`19a66f8b…`; scripts 86/87 internally bind the model/persistence/guide hashes.
