from __future__ import annotations

import os

# These process-global settings must be established before importing JAX.
os.environ.setdefault("JAX_ENABLE_X64", "1")
if "--xla_force_host_platform_device_count" not in os.environ.get("XLA_FLAGS", ""):
    os.environ["XLA_FLAGS"] = (
        os.environ.get("XLA_FLAGS", "") + " --xla_force_host_platform_device_count=4"
    ).strip()

import argparse
import csv
import hashlib
import json
import signal
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
import pandas as pd
import yaml
from jax import random
from numpyro import handlers
from numpyro.infer import MCMC, NUTS, SVI, Trace_ELBO
from numpyro.infer.autoguide import AutoLowRankMultivariateNormal, init_to_median
from numpyro.infer.reparam import NeuTraReparam
from numpyro.optim import ClippedAdam

from dhbcp_pv.inference.phase3c_stabilized import (
    DENSE_MASS_BLOCKS,
    STABILIZED_PROBABILITY_TARGET,
    assert_x64_reference_mode,
    draw_svi_initial_params,
    nuts_gate_flags,
    summarize_nuts_gate,
    validate_dense_mass_contract,
)
from dhbcp_pv.inference.phase3c_chainwise import (
    CHAIN_IDS,
    chain_paths,
    combine_chain_arrays,
    fingerprint_array,
    fingerprint_tree,
    original_nuts_rng_keys,
    select_stacked_chain,
    valid_chain_checkpoint,
)
from dhbcp_pv.inference.structured_svi import SVIConfig, run_structured_svi
from dhbcp_pv.models.full_joint_model import reconstruct_x
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_a_replicate


numpyro.set_host_device_count(4)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, allow_nan=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(value, encoding="utf-8")
    os.replace(temporary, path)


def atomic_npz(path: Path, arrays: dict[str, np.ndarray]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".part")
    with temporary.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    os.replace(temporary, path)


def tree_hash(root: Path) -> str:
    records = []
    for directory in ("src", "scripts", "tests"):
        for path in sorted((root / directory).rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            records.append((path.relative_to(root).as_posix(), sha256(path)))
    digest = hashlib.sha256()
    for name, value in sorted(records):
        digest.update(f"{name}\0{value}\n".encode())
    return digest.hexdigest()


def verify_freeze(root: Path, freeze: dict[str, Any]) -> str:
    actual_tree = tree_hash(root)
    if actual_tree != freeze["source_tree_sha256"]:
        resume_path = root / "results/phase3c/PHASE3C_RESUME_VERIFICATION.json"
        if not resume_path.is_file():
            raise RuntimeError("Phase3C source tree differs from formal freeze without resume authorization")
        resume = json.loads(resume_path.read_text())
        authorized = (
            resume.get("passed") is True
            and resume.get("pre_amendment_source_tree_sha256") == freeze["source_tree_sha256"]
            and resume.get("post_amendment_source_tree_sha256") == actual_tree
            and resume.get("compute_amendment_only") is True
            and resume.get("scientific_target_changed") is False
            and resume.get("thresholds_changed") is False
        )
        if not authorized:
            raise RuntimeError("Phase3C resume source tree is not the authorized compute amendment")
    for relative, expected in freeze["frozen_files"].items():
        path = root / relative
        if path.stat().st_size != expected["bytes"] or sha256(path) != expected["sha256"]:
            raise RuntimeError(f"Phase3C frozen file changed: {relative}")
    return actual_tree


def reference_data(root: Path, cutoff: int) -> tuple[int, tuple[Any, ...], dict[str, Any]]:
    seeds = pd.read_csv(root / "config/phase3b_tiera_seeds_v1.csv")
    seed = int(seeds.loc[seeds.replicate_id == 1, "seed"].iloc[0])
    replicate = generate_tier_a_replicate(seed, n_quarters=40)
    pair_mask = (replicate.drug_index < 10) & (replicate.event_index < 5)
    if int(pair_mask.sum()) != 50:
        raise RuntimeError("frozen reference subset is not 10 drugs x 5 events")
    args = (
        jnp.asarray(replicate.y[pair_mask, :cutoff]),
        jnp.asarray(replicate.serious[pair_mask, :cutoff]),
        jnp.asarray(replicate.expected[pair_mask, :cutoff], dtype=jnp.float64),
        jnp.asarray(replicate.drug_index[pair_mask]),
        jnp.asarray(replicate.event_index[pair_mask]),
        10,
        5,
    )
    kwargs = {"hmax": 12}
    return seed, args, kwargs


def selected_svi_config(root: Path) -> SVIConfig:
    selected = yaml.safe_load((root / "results/phase3c/84_PHASE3C_SELECTED_SVI_CONFIG.yaml").read_text())
    row = selected["selected_schedule"]
    return SVIConfig(
        learning_rate=float(row["learning_rate"]),
        max_steps=int(row["max_steps"]),
        minimum_steps=int(row["minimum_steps"]),
        early_stop_patience=int(row["early_stop_patience"]),
        relative_tolerance=float(row["relative_tolerance"]),
        gradient_clip_norm=float(row["gradient_clip_norm"]),
        num_elbo_particles=int(row["elbo_particles"]),
    )


def load_or_fit_structured_svi(
    root: Path,
    seed: int,
    cutoff: int,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> tuple[dict[str, jax.Array], dict[str, Any]]:
    directory = root / "results/phase3c/checkpoints/nuts_init"
    params_path = directory / f"structured_svi_t{cutoff:02d}.npz"
    metadata_path = directory / f"structured_svi_t{cutoff:02d}.json"
    if params_path.exists() and metadata_path.exists():
        loaded = np.load(params_path)
        return {name: jnp.asarray(loaded[name]) for name in loaded.files}, json.loads(metadata_path.read_text())
    config = selected_svi_config(root)
    fitted = run_structured_svi(
        random.PRNGKey(seed + 3000 + cutoff),
        *args,
        config=config,
        **kwargs,
    )
    if not fitted.finite or fitted.nonfinite_gradient_or_loss_steps:
        raise RuntimeError("Phase3C structured SVI initialization fit is not finite")
    arrays = {name: np.asarray(value) for name, value in fitted.params.items()}
    atomic_npz(params_path, arrays)
    metadata = {
        "version": "phase3c_nuts_structured_svi_init_v1",
        "cutoff": cutoff,
        "initial_loss": fitted.initial_loss,
        "terminal_loss": fitted.terminal_loss,
        "steps": fitted.steps,
        "convergence_code": fitted.convergence_code,
        "finite": fitted.finite,
        "nonfinite_gradient_or_loss_steps": fitted.nonfinite_gradient_or_loss_steps,
        "params_artifact": {
            "path": params_path.relative_to(root).as_posix(),
            "bytes": params_path.stat().st_size,
            "sha256": sha256(params_path),
        },
    }
    atomic_json(metadata_path, metadata)
    return {name: jnp.asarray(value) for name, value in arrays.items()}, metadata


def fit_neutra(
    root: Path,
    seed: int,
    cutoff: int,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> tuple[NeuTraReparam, dict[str, Any]]:
    directory = root / "results/phase3c/checkpoints/neutra"
    params_path = directory / f"neutra_t{cutoff:02d}.npz"
    metadata_path = directory / f"neutra_t{cutoff:02d}.json"
    guide = AutoLowRankMultivariateNormal(
        STABILIZED_PROBABILITY_TARGET,
        rank=32,
        prefix="neutra",
        init_loc_fn=init_to_median(num_samples=5),
    )
    if params_path.exists() and metadata_path.exists():
        loaded = np.load(params_path)
        params = {name: jnp.asarray(loaded[name]) for name in loaded.files}

        # A newly constructed AutoGuide has prototype_trace=None.
        # SVI training initializes it automatically, but checkpoint restore
        # must rebuild the guide prototype before NeuTraReparam is used.
        with handlers.seed(rng_seed=random.PRNGKey(seed + 5000 + cutoff)):
            guide._setup_prototype(*args, **kwargs)

        if guide.prototype_trace is None:
            raise RuntimeError(
                "NeuTra guide prototype initialization failed during checkpoint restore"
            )

        return NeuTraReparam(guide, params), json.loads(metadata_path.read_text())
    svi = SVI(
        STABILIZED_PROBABILITY_TARGET,
        guide,
        ClippedAdam(step_size=0.003, clip_norm=10.0),
        Trace_ELBO(),
    )
    state = svi.init(random.PRNGKey(seed + 5000 + cutoff), *args, **kwargs)
    losses = []
    started = perf_counter()
    for step in range(2000):
        state, loss = svi.stable_update(state, *args, **kwargs)
        value = float(loss)
        if not np.isfinite(value):
            raise FloatingPointError(f"non-finite NeuTra guide loss/gradient at step {step + 1}")
        losses.append(value)
        if (step + 1) % 100 == 0:
            print(f"NeuTra t={cutoff} guide step {step + 1}/2000 loss={value:.3f}", flush=True)
    params = svi.get_params(state)
    jax.block_until_ready(jax.tree.leaves(params)[0])
    atomic_npz(params_path, {name: np.asarray(value) for name, value in params.items()})
    metadata = {
        "version": "phase3c_neutra_guide_v1",
        "cutoff": cutoff,
        "guide": "AutoLowRankMultivariateNormal",
        "rank": 32,
        "steps": 2000,
        "learning_rate": 0.003,
        "initial_loss": losses[0],
        "terminal_loss": losses[-1],
        "finite": True,
        "seconds": perf_counter() - started,
        "params_artifact": {
            "path": params_path.relative_to(root).as_posix(),
            "bytes": params_path.stat().st_size,
            "sha256": sha256(params_path),
        },
    }
    atomic_json(metadata_path, metadata)
    return NeuTraReparam(guide, params), metadata


CHAIN_MANIFEST_COLUMNS = (
    "rung", "cutoff", "chain_id", "status", "warmup", "samples",
    "elapsed_seconds", "artifact_path", "bytes", "sha256", "source_sha256",
    "protocol_sha256", "rng_key_fingerprint", "init_state_fingerprint",
)


class ChainWatchdogTimeout(TimeoutError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def append_execution_log(result: Path, message: str) -> None:
    path = result / "PHASE3C_RESUME_EXECUTION_LOG.md"
    current = path.read_text() if path.exists() else "# Phase3C resume execution log\n\n"
    atomic_text(path, current + f"- `{utc_now()}` {message}\n")


def update_chain_manifest(result: Path, row: dict[str, Any]) -> None:
    path = result / "PHASE3C_CHAIN_CHECKPOINT_MANIFEST.csv"
    rows: list[dict[str, str]] = []
    if path.exists():
        with path.open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
    identity = (str(row["rung"]), str(row["cutoff"]), str(row["chain_id"]))
    rows = [
        existing for existing in rows
        if (existing["rung"], existing["cutoff"], existing["chain_id"]) != identity
    ]
    rows.append({column: row.get(column, "") for column in CHAIN_MANIFEST_COLUMNS})
    rows.sort(key=lambda item: (item["rung"], int(item["cutoff"]), int(item["chain_id"])))
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CHAIN_MANIFEST_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def metadata_manifest_row(metadata: dict[str, Any]) -> dict[str, Any]:
    artifact = metadata.get("chain_artifact") or {}
    return {
        "rung": metadata["rung"],
        "cutoff": metadata["cutoff"],
        "chain_id": metadata["chain_id"],
        "status": metadata["status"],
        "warmup": metadata["warmup_per_chain"],
        "samples": metadata["samples_per_chain"],
        "elapsed_seconds": metadata["seconds_including_host_synchronization"],
        "artifact_path": artifact.get("path", ""),
        "bytes": artifact.get("bytes", ""),
        "sha256": artifact.get("sha256", ""),
        "source_sha256": metadata["source_sha256"],
        "protocol_sha256": metadata["protocol_sha256"],
        "rng_key_fingerprint": metadata["rng_key_fingerprint"],
        "init_state_fingerprint": metadata["init_state_fingerprint"],
    }


def watchdog_handler(signum: int, frame: Any) -> None:
    del signum, frame
    raise ChainWatchdogTimeout("Phase3C per-chain 4-hour watchdog elapsed")


def combine_completed_chains(
    root: Path,
    result: Path,
    checkpoint: Path,
    rung_id: str,
    cutoff: int,
    rung: dict[str, Any],
    source_sha: str,
    protocol_sha: str,
) -> None:
    components: list[dict[str, np.ndarray]] = []
    component_metadata: list[dict[str, Any]] = []
    for chain_id in CHAIN_IDS:
        artifact_path, metadata_path = chain_paths(checkpoint, rung_id, cutoff, chain_id)
        valid, reason = valid_chain_checkpoint(
            artifact_path, metadata_path, rung=rung_id, cutoff=cutoff, chain_id=chain_id
        )
        if not valid:
            raise RuntimeError(f"chain {chain_id} checkpoint is not valid: {reason}")
        loaded = np.load(artifact_path)
        components.append({name: loaded[name] for name in loaded.files})
        component_metadata.append(json.loads(metadata_path.read_text()))

    arrays = combine_chain_arrays(components)
    samples = {name: value for name, value in arrays.items() if not name.startswith("_extra_")}
    extra_fields = {
        name.removeprefix("_extra_"): value
        for name, value in arrays.items() if name.startswith("_extra_")
    }
    diagnostics = summarize_nuts_gate(
        samples, extra_fields, max_tree_depth=int(rung["max_tree_depth"])
    )
    flags = nuts_gate_flags(diagnostics)
    chain_path = checkpoint / f"{rung_id}_t{cutoff:02d}_chains.npz"
    metadata_path = checkpoint / f"{rung_id}_t{cutoff:02d}.json"
    atomic_npz(chain_path, arrays)
    payload = {
        "version": "phase3c_nuts_checkpoint_chainwise_v1",
        "status": "PASS" if all(flags.values()) else "DIAGNOSTIC_FAIL",
        "rung": rung_id,
        "cutoff": cutoff,
        "pairs": 50,
        "cross_classification": "10 drugs x 5 events",
        "chains": 4,
        "chain_order": list(CHAIN_IDS),
        "warmup_per_chain": int(rung["warmup_per_chain"]),
        "samples_per_chain": int(rung["samples_per_chain"]),
        "target_accept_prob": float(rung["target_accept_prob"]),
        "max_tree_depth": int(rung["max_tree_depth"]),
        "x64_enabled_before_backend_initialization": True,
        "sample_float_dtype": str(np.asarray(samples["mu"]).dtype),
        "source_sha256": source_sha,
        "protocol_sha256": protocol_sha,
        "target_preserving_neutra": rung_id == "N3_NEUTRA",
        "execution_scheduling": "four exact chains run sequentially and combined in order",
        "seconds_including_host_synchronization": float(sum(
            item["seconds_including_host_synchronization"] for item in component_metadata
        )),
        "component_chains": [
            {
                "chain_id": item["chain_id"],
                "path": item["chain_artifact"]["path"],
                "bytes": item["chain_artifact"]["bytes"],
                "sha256": item["chain_artifact"]["sha256"],
                "rng_key_fingerprint": item["rng_key_fingerprint"],
                "init_state_fingerprint": item["init_state_fingerprint"],
            }
            for item in component_metadata
        ],
        "diagnostics": diagnostics,
        "pass_flags": flags,
        "minimum_reference_pass": all(flags.values()),
        "chain_artifact": {
            "path": chain_path.relative_to(root).as_posix(),
            "bytes": chain_path.stat().st_size,
            "sha256": sha256(chain_path),
        },
    }
    atomic_json(metadata_path, payload)
    append_execution_log(
        result,
        f"Combined {rung_id} t={cutoff} chains 0,1,2,3; status={payload['status']}; "
        f"artifact SHA-256 `{payload['chain_artifact']['sha256']}`.",
    )
    print(json.dumps(payload, sort_keys=True), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rung", choices=("N1", "N2", "N3_NEUTRA"), required=True)
    parser.add_argument("--cutoff", choices=(12, 24, 40), type=int, required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--chain-id", choices=CHAIN_IDS, type=int)
    mode.add_argument("--combine", action="store_true")
    parsed = parser.parse_args()
    if parsed.rung == "N1":
        raise SystemExit("N1 is audit-only after resume and must not be rerun")

    root = Path(__file__).resolve().parents[1]
    result = root / "results/phase3c"
    freeze = json.loads((result / "82_PHASE3C_PROTOCOL_FREEZE.json").read_text())
    source_sha = verify_freeze(root, freeze)
    assert_x64_reference_mode()

    protocol_path = root / "config/phase3c_nuts_stabilization_v1.yaml"
    protocol_sha = sha256(protocol_path)
    protocol = yaml.safe_load(protocol_path.read_text())
    rung = next(row for row in protocol["ladder"] if row["id"] == parsed.rung)
    checkpoint = result / "checkpoints/nuts"
    checkpoint.mkdir(parents=True, exist_ok=True)

    if parsed.combine:
        combine_completed_chains(
            root, result, checkpoint, parsed.rung, parsed.cutoff, rung, source_sha, protocol_sha
        )
        return

    chain_id = int(parsed.chain_id)
    artifact_path, metadata_path = chain_paths(
        checkpoint, parsed.rung, parsed.cutoff, chain_id
    )
    valid, checkpoint_reason = valid_chain_checkpoint(
        artifact_path, metadata_path,
        rung=parsed.rung, cutoff=parsed.cutoff, chain_id=chain_id,
    )
    if valid:
        metadata = json.loads(metadata_path.read_text())
        update_chain_manifest(result, metadata_manifest_row(metadata))
        append_execution_log(
            result, f"Skipped valid {parsed.rung} t={parsed.cutoff} chain {chain_id}; SHA-256 verified."
        )
        print(json.dumps({"status": "CHECKPOINT_VALID", "metadata": str(metadata_path)}), flush=True)
        return
    if checkpoint_reason != "MISSING":
        raise RuntimeError(
            f"refusing to overwrite incomplete/corrupt chain {chain_id}: {checkpoint_reason}"
        )

    seed, model_args, model_kwargs = reference_data(root, parsed.cutoff)
    trace = handlers.trace(handlers.seed(STABILIZED_PROBABILITY_TARGET, random.PRNGKey(seed))).get_trace(
        *model_args, **model_kwargs
    )
    latent_names = sorted(
        name for name, site in trace.items()
        if site["type"] == "sample" and not site.get("is_observed", False)
    )
    dense_contract = validate_dense_mass_contract(latent_names)
    if not dense_contract["passed"]:
        raise RuntimeError(f"dense-mass contract failed: {dense_contract}")

    neutra: NeuTraReparam | None = None
    all_init_fingerprints: list[str]
    if parsed.rung == "N3_NEUTRA":
        neutra, init_metadata = fit_neutra(
            root, seed, parsed.cutoff, model_args, model_kwargs
        )
        sampling_model = neutra.reparam(STABILIZED_PROBABILITY_TARGET)
        selected_init_params = None
        dense_mass: bool | list[tuple[str, ...]] = False
        default_init_identity = f"N3_NEUTRA_DEFAULT_INIT_FROM_SELECTED_RNG_CHAIN_{chain_id}"
        selected_init_fingerprint = hashlib.sha256(default_init_identity.encode()).hexdigest()
        all_init_fingerprints = []
    else:
        params, svi_metadata = load_or_fit_structured_svi(
            root, seed, parsed.cutoff, model_args, model_kwargs
        )
        stacked_init_params, guide_draw_metadata = draw_svi_initial_params(
            random.PRNGKey(seed + 4000 + parsed.cutoff + 100),
            params,
            *model_args,
            num_chains=4,
            **model_kwargs,
        )
        if not guide_draw_metadata["all_passed"]:
            raise RuntimeError("one or more SVI-derived NUTS initial states failed")
        all_init_fingerprints = [
            fingerprint_tree(select_stacked_chain(stacked_init_params, index))
            for index in CHAIN_IDS
        ]
        selected_init_params = select_stacked_chain(stacked_init_params, chain_id)
        selected_init_fingerprint = fingerprint_tree(selected_init_params)
        init_metadata = {"svi_fit": svi_metadata, "guide_draws": guide_draw_metadata}
        sampling_model = STABILIZED_PROBABILITY_TARGET
        dense_mass = [tuple(block) for block in DENSE_MASS_BLOCKS]

    all_rng_keys = original_nuts_rng_keys(seed, parsed.cutoff)
    selected_rng_key = all_rng_keys[chain_id]
    all_rng_fingerprints = [fingerprint_array(all_rng_keys[index]) for index in CHAIN_IDS]
    selected_rng_fingerprint = fingerprint_array(selected_rng_key)

    kernel = NUTS(
        sampling_model,
        dense_mass=dense_mass,
        target_accept_prob=float(rung["target_accept_prob"]),
        max_tree_depth=int(rung["max_tree_depth"]),
        regularize_mass_matrix=bool(rung.get("regularize_mass_matrix", True)),
    )
    mcmc = MCMC(
        kernel,
        num_warmup=int(rung["warmup_per_chain"]),
        num_samples=int(rung["samples_per_chain"]),
        num_chains=1,
        chain_method="sequential",
        progress_bar=True,
        progress_rate=25,
    )
    started_utc = utc_now()
    append_execution_log(
        result,
        f"Started {parsed.rung} t={parsed.cutoff} chain {chain_id} sequentially; "
        "per-chain watchdog=4h; exact original RNG/init selection verified by fingerprints.",
    )
    print(
        f"START Phase3C {parsed.rung} t={parsed.cutoff} chain={chain_id}: x64=True, "
        f"warmup={rung['warmup_per_chain']}, samples={rung['samples_per_chain']}, watchdog=4h",
        flush=True,
    )
    started = perf_counter()
    previous_handler = signal.signal(signal.SIGALRM, watchdog_handler)
    signal.setitimer(signal.ITIMER_REAL, 4 * 60 * 60)
    try:
        mcmc.run(
            selected_rng_key,
            *model_args,
            init_params=selected_init_params,
            extra_fields=("diverging", "num_steps", "accept_prob", "energy", "potential_energy"),
            **model_kwargs,
        )
        raw_samples = mcmc.get_samples(group_by_chain=True)
        extra_fields = mcmc.get_extra_fields(group_by_chain=True)
        jax.block_until_ready(jax.tree.leaves(raw_samples)[0])
        jax.block_until_ready(jax.tree.leaves(extra_fields)[0])
    except ChainWatchdogTimeout:
        elapsed = perf_counter() - started
        payload = {
            "version": "phase3c_nuts_chain_checkpoint_v1",
            "status": "TIMEOUT",
            "formal_result": False,
            "rung": parsed.rung,
            "cutoff": parsed.cutoff,
            "chain_id": chain_id,
            "warmup_per_chain": int(rung["warmup_per_chain"]),
            "samples_per_chain": int(rung["samples_per_chain"]),
            "target_accept_prob": float(rung["target_accept_prob"]),
            "max_tree_depth": int(rung["max_tree_depth"]),
            "x64_enabled_before_backend_initialization": True,
            "source_sha256": source_sha,
            "protocol_sha256": protocol_sha,
            "rng_key_fingerprint": selected_rng_fingerprint,
            "init_state_fingerprint": selected_init_fingerprint,
            "seconds_including_host_synchronization": elapsed,
            "started_at_utc": started_utc,
            "ended_at_utc": utc_now(),
            "watchdog_limit_seconds": 14400,
            "chain_artifact": None,
            "partial_files_preserved": [
                path.relative_to(root).as_posix()
                for path in checkpoint.glob(f"{parsed.rung}_t{parsed.cutoff:02d}_chain{chain_id}*.part")
            ],
        }
        atomic_json(metadata_path, payload)
        rung_failure_path = checkpoint / f"{parsed.rung}_t{parsed.cutoff:02d}.json"
        if not rung_failure_path.exists():
            atomic_json(rung_failure_path, {
                "version": "phase3c_nuts_rung_result_v1",
                "status": "CHAIN_TIMEOUT",
                "formal_result": False,
                "minimum_reference_pass": False,
                "rung": parsed.rung,
                "cutoff": parsed.cutoff,
                "failed_chain_id": chain_id,
                "diagnostics": {
                    "status": "NOT_COMPUTED_INCOMPLETE_CHAINS",
                    "watchdog_timeout_chain": chain_id,
                    "watchdog_limit_seconds": 14400,
                },
                "chain_artifact": None,
                "chain_metadata_path": metadata_path.relative_to(root).as_posix(),
                "source_sha256": source_sha,
                "protocol_sha256": protocol_sha,
                "ended_at_utc": payload["ended_at_utc"],
            })
        update_chain_manifest(result, metadata_manifest_row(payload))
        append_execution_log(
            result, f"TIMEOUT {parsed.rung} t={parsed.cutoff} chain {chain_id} at 4h; rung stopped."
        )
        print(json.dumps(payload, sort_keys=True), flush=True)
        raise SystemExit(124)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)

    if neutra is not None:
        shared_latent_name = f"{neutra.guide.prefix}_shared_latent"
        if shared_latent_name not in raw_samples:
            raise KeyError(
                f"NeuTra shared latent {shared_latent_name!r} not found; "
                f"available sample keys={sorted(raw_samples.keys())}"
            )
        warped = raw_samples[shared_latent_name]
        flattened = warped.reshape((-1,) + warped.shape[2:])
        transformed = neutra.transform_sample(flattened)
        samples = {
            name: value.reshape((1, int(rung["samples_per_chain"])) + value.shape[1:])
            for name, value in transformed.items()
        }
        flat_initial = samples["x_initial"].reshape(-1, 50)
        flat_increment = samples["base_increment"].reshape(-1, 50, parsed.cutoff - 1)
        x = jax.vmap(reconstruct_x)(flat_initial, flat_increment)
        samples["x"] = x.reshape(1, int(rung["samples_per_chain"]), 50, parsed.cutoff)
    else:
        samples = raw_samples
    samples = jax.device_get(samples)
    extra_fields = jax.device_get(extra_fields)
    elapsed = perf_counter() - started

    arrays = {name: np.asarray(value) for name, value in samples.items()}
    arrays.update({f"_extra_{name}": np.asarray(value) for name, value in extra_fields.items()})
    atomic_npz(artifact_path, arrays)
    preliminary = {
        "divergences": int(np.asarray(extra_fields["diverging"], dtype=bool).sum()),
        "tree_depth_saturation_rate": float(np.mean(
            np.asarray(extra_fields["num_steps"]) >= (2 ** int(rung["max_tree_depth"]) - 1)
        )),
        "finite_posterior": bool(all(np.isfinite(np.asarray(value)).all() for value in samples.values())),
        "formal_four_chain_diagnostics": False,
    }
    payload = {
        "version": "phase3c_nuts_chain_checkpoint_v1",
        "status": "COMPLETE",
        "formal_result": False,
        "rung": parsed.rung,
        "cutoff": parsed.cutoff,
        "chain_id": chain_id,
        "pairs": 50,
        "warmup_per_chain": int(rung["warmup_per_chain"]),
        "samples_per_chain": int(rung["samples_per_chain"]),
        "target_accept_prob": float(rung["target_accept_prob"]),
        "max_tree_depth": int(rung["max_tree_depth"]),
        "x64_enabled_before_backend_initialization": True,
        "sample_float_dtype": str(np.asarray(samples["mu"]).dtype),
        "source_sha256": source_sha,
        "protocol_sha256": protocol_sha,
        "dense_mass_contract": dense_contract,
        "target_preserving_neutra": parsed.rung == "N3_NEUTRA",
        "execution_scheduling": "one exact original chain, sequential",
        "seed_identity": {
            "reference_seed": seed,
            "nuts_base_seed_expression": "reference_seed + 6000 + cutoff",
            "svi_init_key_expression": (
                "reference_seed + 4000 + cutoff + 100" if parsed.rung == "N2" else None
            ),
        },
        "rng_key_fingerprint": selected_rng_fingerprint,
        "all_original_rng_key_fingerprints": all_rng_fingerprints,
        "init_state_fingerprint": selected_init_fingerprint,
        "all_original_init_state_fingerprints": all_init_fingerprints,
        "initialization": init_metadata,
        "seconds_including_host_synchronization": elapsed,
        "started_at_utc": started_utc,
        "ended_at_utc": utc_now(),
        "watchdog_limit_seconds": 14400,
        "preliminary_single_chain_checks": preliminary,
        "chain_artifact": {
            "path": artifact_path.relative_to(root).as_posix(),
            "bytes": artifact_path.stat().st_size,
            "sha256": sha256(artifact_path),
        },
    }
    atomic_json(metadata_path, payload)
    update_chain_manifest(result, metadata_manifest_row(payload))
    append_execution_log(
        result,
        f"Completed {parsed.rung} t={parsed.cutoff} chain {chain_id}; "
        f"SHA-256 `{payload['chain_artifact']['sha256']}`; elapsed={elapsed:.1f}s.",
    )
    print(json.dumps({
        "status": "COMPLETE",
        "rung": parsed.rung,
        "cutoff": parsed.cutoff,
        "chain_id": chain_id,
        "artifact": payload["chain_artifact"],
        "preliminary_single_chain_checks": preliminary,
    }, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
