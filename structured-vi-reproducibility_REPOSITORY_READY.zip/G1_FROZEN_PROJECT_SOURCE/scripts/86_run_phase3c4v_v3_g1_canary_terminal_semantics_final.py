"""Phase3C.4V V3 — V3 G1 CANARY EXECUTION RUNNER FINAL (scripts/85).

Built mechanically from immutable scripts/84 (SHA
c9a86994753fb1baaf0fa1eb306cbbbea6f87cb22b2ad4fcb0c28550f3968aff) per the
human FINAL source review 42ZX (V3_G1_CANARY_FINAL_EXECUTION_CORRECTION_REQUIRED).
Two remaining execution/audit defects are closed:

  DEFECT_1 AUTHORIZATION 42ZW SHA EXACT + STRICT JSON BOOLEANS
    validate_canary_authorization now verifies exact equality of
    auth["binds_sha256"]["42ZW"] to sha256 of the REAL 42ZW artifact
    (results/phase3c4v/preflight/42ZW_V3_G1_CANARY_CORRECTIVE_PREFLIGHT.json,
    frozen SHA a940b3a49790e8ccf8605abfc22cad9d40cc29577231b09316cc44e20f2f7d78).
    Wrong-but-64-char SHA rejected; missing rejected; non-string rejected.
    Boolean fields use STRICT JSON boolean identity: "AUTHORIZED" in auth and
    auth["AUTHORIZED"] is True; "G2_AUTHORIZED"/"G3_AUTHORIZED"/
    "BATCH_AUTHORIZED" in auth and each is False. Reject "true"/"false"/1/0/
    null/missing. Required top-level fields: authorization_scope, AUTHORIZED,
    identity, binds_sha256, G2_AUTHORIZED, G3_AUTHORIZED, BATCH_AUTHORIZED.
  DEFECT_2 RESULT.JSON vs FINAL VALIDATION CONSISTENCY
    _run_canary now writes the initially computed result atomically, then runs
    finalize_result_consistency(): final on-disk validation
    (require_terminal_result=True). On PASS, FINAL_ON_DISK_VALIDATION.json has
    PASS=true and the valid classification is preserved (final disk validation
    is necessary but NOT sufficient for scientific G1 validity). On FAIL, the
    authoritative result.json is atomically DOWNGRADED to
    terminal_status=FAILED_FINAL_ON_DISK_VALIDATION and
    VALID_V3_G1_RUN=false, preserving pre_final_terminal_status /
    pre_final_VALID_V3_G1_RUN and recording exact problems; a readback
    consistency audit confirms no path leaves result VALID=true with final
    validation=false.

Supports ONLY:
  --mode preflight : G1..G50 final corrective checks (G7-G24 authorization
                     dynamic tests; G33-G37 final-consistency dynamic tests).
                     Writes
                     results/phase3c4v/preflight/42ZY_V3_G1_CANARY_FINAL_PREFLIGHT.{json,md}
  --mode canary    : REFUSED unless a FUTURE explicit human V3 canary
                     authorization exists AND its exact content validates.

The ONLY executable scientific identity is (hardcoded):
  V3_V3_ARM_P1_p1_seed1001_t12  (arm=V3_ARM_P1, num_particles=1, seed=1001,
                                 cutoff=12)

Execution mechanics follow the VERIFIED V2 G1 runners (scripts71/73/75) as
engineering reference, adapted to the V3 parameter schema (42ZO/42ZQ/42ZR):
  - guide: V3LocalBlockAR1AutoGuide (V3_LOCAL_BLOCK_AR1_NO_SHARED)
  - Trace_ELBO(num_particles=1); ClippedAdam(0.003, 10.0)
  - max_steps=2000; min_early_stop=500; ckpt=100; es_tol=1e-4; patience=5
  - G1_MIN_LOSS_REDUCTION=0.15; init_to_median(num_samples=5); diag log(0.1);
    local factors 0.01*Normal; raw rho 0; cutoff=12
  - RNG: master PRNGKey(1001) split 4-way; factor split 5-way (key1/2/3 =
    count/dynamic/seriousness, same subkeys as V2 for the same seed)
  - exactly-once RUN_STARTED via os.open(O_CREAT|O_EXCL|O_WRONLY) BEFORE any
    SVI init/update
  - losses.append(float(loss)) after every accepted update; executable
    invariant len(losses) == steps_completed (assert, not a comment)
  - nonfinite policy: stable_update joint finite-objective-and-gradient guard
    (NumPyro 0.21); nonfinite loss recorded, never substituted
  - final params: six canonical V3 params; rho scalar -> (1,) before
    persistence; persisted total 2049
  - persistence: frozen serializer (NPZ + manifest + roundtrip + on-disk
    validation); result.json written LAST

NO batch mode. NO other V3 identity executable. NO SVI in preflight.
NO posterior sampling / IS / MCMC. NO G2/G3. No failed PCA.
"""

import argparse
import ast
import hashlib
import json
import os
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
from numpyro import distributions as dist
from numpyro import handlers
from numpyro.infer import init_to_median

jax.config.update("jax_enable_x64", True)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dhbcp_pv.inference.v3_local_block_ar1_guide import (  # noqa: E402
    V3LocalBlockAR1AutoGuide,
    _rho_from_raw,
    _effective_log_scale,
    _LATENT_DIM,
    LOG_SCALE_ABS_MAX,
)

V3_RUNS = ROOT / "results/phase3c4v_v3/runs"
PREFLIGHT_OUT = ROOT / "results/phase3c4v/preflight"
RUN_STARTED_NAME = "RUN_STARTED"

CANARY_IDENTITY = {
    "identity": "V3_V3_ARM_P1_p1_seed1001_t12",
    "arm": "V3_ARM_P1",
    "num_particles": 1,
    "seed": 1001,
    "cutoff": 12,
}

V3_PARAM_SHAPES = {
    "v3_loc": (708,),
    "v3_diag_log_scale": (708,),
    "v3_F_count_plus_initial": (120, 4),
    "v3_F_dynamic_scale": (16, 4),
    "v3_F_seriousness": (22, 4),
    "v3_raw_temporal_rho": (1,),
}
V3_TOTAL = 2049

TRAINING = {
    "maximum_steps": 2000,
    "minimum_steps_before_early_stopping": 500,
    "checkpoint_interval": 100,
    "early_stop_relative_tolerance": 1e-4,
    "early_stop_patience_checkpoints": 5,
    "learning_rate": 0.003,
    "clip_norm": 10.0,
}
G1_MIN_LOSS_REDUCTION = 0.15

FROZEN_CHAIN = {
    "42ZP": ("results/phase3c4v/preflight/42ZP_V3_LOCAL_BLOCK_AR1_DETERMINISTIC_G0_PREFLIGHT.json",
             "bbc9c7c256c00cf0e4f2656ece4552320c62169b1846da9ab0790ccc21b5d18f"),
    "42ZQ": ("results/phase3c4v_v3/protocol/42ZQ_V3_RAW_RHO_IN_MEMORY_PERSISTENCE_SCHEMA_AMENDMENT.json",
             "fc9b06f227fa01d95b23284e822ec4e178d885bc1a01df6dc04c1cea6b7c9191"),
    "42ZR": ("results/phase3c4v_v3/protocol/42ZR_V3_G1_OPTIMIZATION_PROTOCOL_FREEZE.json",
             "9bbf385ecc7a664236a205c1694bf00ab108d74acf5bad4a56de32d4eb336c72"),
    "42ZS": ("results/phase3c4v/preflight/42ZS_V3_G1_RUNNER_PREFLIGHT.json",
             "a98cb6d68be07244fca984fccf6aa34d81790bfdd085a8c44d24fa92c85e99f7"),
    "42ZT": ("results/phase3c4v_v3/audit/42ZT_V3_G1_RUNNER_SOURCE_AUDIT_EXECUTION_GAP.json",
             "ff07fdd73b30179e792ce9febea7add7f3fe3fd8597eaa43a2e938b88be76953"),
    "42ZU": ("results/phase3c4v/preflight/42ZU_V3_G1_CANARY_EXECUTION_PREFLIGHT.json",
             "b63d4c1bbf9f39b2d3832d025a6cad23ff3d00dab76b5cebe757e7f8187187f6"),
    "42ZV": ("results/phase3c4v_v3/audit/42ZV_V3_G1_CANARY_RUNNER_SECOND_SOURCE_AUDIT.json",
             "303c8cf0f9159e03903c8f507260cfda64b4e8156c135df29aa62f2e17aba203"),
    "42ZW": ("results/phase3c4v/preflight/42ZW_V3_G1_CANARY_CORRECTIVE_PREFLIGHT.json",
             "a940b3a49790e8ccf8605abfc22cad9d40cc29577231b09316cc44e20f2f7d78"),
    "42ZX": ("results/phase3c4v_v3/audit/42ZX_V3_G1_CANARY_FINAL_SOURCE_AUDIT.json",
             "98275fa39db8d5c94f33c830bd5590886ea56aa491b8fca9c8faaeb59f039a27"),
    "42ZZ": ("results/phase3c4v_v3/audit/42ZZ_V3_G1_CANARY_TERMINAL_SEMANTICS_AUDIT.json",
             "c0b7161991704c8c81a7c593c6c1db9588a3b8b07155d42266b9177adae3b542"),
    "42ZY": ("results/phase3c4v/preflight/42ZY_V3_G1_CANARY_FINAL_PREFLIGHT.json",
             "31665d24a3ab9113a0bfcb680b7e31c59b96b2a002ea14c7562bd775f07fb7db"),
    "42ZO": ("results/phase3c4v_v3/protocol/42ZO_V3_LOCAL_BLOCK_AR1_MATHEMATICAL_SPECIFICATION_FREEZE.json",
             "03d490ee31f6d6f823f81f31a71b4865da4896c0c10f640c110430faa43406b6"),
    "guide_v3": ("src/dhbcp_pv/inference/v3_local_block_ar1_guide.py",
                 "19a66f8b40bb211a68dfd65993e9235498bb11f5e54594553611fea87561a07f"),
    "model": ("src/dhbcp_pv/models/full_joint_model.py",
              "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"),
    "serializer": ("src/dhbcp_pv/inference/variational_param_persistence.py",
                   "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"),
    "scripts82": ("scripts/82_run_phase3c4v_v3_g1_validation.py",
                  "d906cb26cea1b60fe214d68cf5f0face7c8b20dccf0efae610e4360e012809a2"),
    "scripts83": ("scripts/83_run_phase3c4v_v3_g1_canary_execution.py",
                  "e96f17fe10a19b8fd3eaf253843e2faa7772f684ef8ba02be8814b253c357dcb"),
    "scripts84": ("scripts/84_run_phase3c4v_v3_g1_canary_execution_corrected.py",
                  "c9a86994753fb1baaf0fa1eb306cbbbea6f87cb22b2ad4fcb0c28550f3968aff"),
    "scripts85": ("scripts/85_run_phase3c4v_v3_g1_canary_final.py",
                  "da5621ccf5afed423c10f05531c6005effe832a0fc2c12d8dabba452528c210c"),
}

# Real 42ZW artifact path for exact live-SHA binding (42ZX DEFECT_1).
REAL_42ZW_PATH = ROOT / "results/phase3c4v/preflight/42ZW_V3_G1_CANARY_CORRECTIVE_PREFLIGHT.json"

# Required bindings in the future V3 canary authorization payload (42ZX).
AUTH_REQUIRED_BINDS = ["42ZR", "42ZU", "42ZW", "guide_v3", "model", "serializer", "runner"]
AUTH_REQUIRED_TOP_FIELDS = ["authorization_scope", "AUTHORIZED", "identity",
                            "binds_sha256", "G2_AUTHORIZED", "G3_AUTHORIZED",
                            "BATCH_AUTHORIZED"]

# 42ZZ terminal-semantics fix: frozen recognized terminal map. Final on-disk
# validation checks terminal recognition + strict VALID-flag consistency; it
# does NOT conflate scientific G1 PASS with artifact/schema validity.
TERMINAL_VALIDITY_MAP = {
    "COMPLETED_G1_VALID_RUN": True,
    "COMPLETED_EARLY_STOPPED_G1_VALID": True,
    "COMPLETED_G1_FAIL_LOSS_REDUCTION": False,
    "FAILED_NONFINITE_LOSS": False,
    "FAILED_INVALID_TERMINAL_STATE": False,
}


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def verify_frozen_chain() -> dict:
    results = {}
    ok = True
    for name, (rel, expected) in FROZEN_CHAIN.items():
        p = ROOT / rel
        if not p.exists():
            results[name] = {"ok": False, "live": None, "expected": expected}
            ok = False
            continue
        live = sha256(p)
        good = live == expected
        ok = ok and good
        results[name] = {"ok": good, "live": live, "expected": expected}
    return {"ok": ok, "results": results}


def dummy_model():
    numpyro.sample("latent", dist.Normal(jnp.zeros(_LATENT_DIM), 1.0).to_event(1))


def identity_consumed() -> bool:
    return (V3_RUNS / CANARY_IDENTITY["identity"] / RUN_STARTED_NAME).exists()


def canary_out_dir() -> Path:
    return V3_RUNS / CANARY_IDENTITY["identity"]


# ---------------------------------------------------------------------------
# Exactly-once RUN_STARTED (real executable O_EXCL; preflight MUST NOT call).
# ---------------------------------------------------------------------------
def acquire_run_started() -> dict:
    """Atomically create RUN_STARTED with O_CREAT|O_EXCL. One-shot semantics."""
    out_dir = canary_out_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    marker = out_dir / RUN_STARTED_NAME
    payload = json.dumps({
        "identity": CANARY_IDENTITY["identity"],
        "arm": CANARY_IDENTITY["arm"],
        "num_particles": CANARY_IDENTITY["num_particles"],
        "seed": CANARY_IDENTITY["seed"],
        "cutoff": CANARY_IDENTITY["cutoff"],
        "status": "V3_RUN_CONSUMED",
        "created_utc": utc_now(),
    }, indent=2, ensure_ascii=False).encode("utf-8")
    try:
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(fd, "wb") as fh:
            fh.write(payload)
        return {"acquired": True, "path": str(marker)}
    except FileExistsError:
        return {"acquired": False, "path": str(marker),
                "reason": "STOP_IDENTITY_ALREADY_CONSUMED"}


# ---------------------------------------------------------------------------
# V3 diagnostics
# ---------------------------------------------------------------------------
def canonical_raw_rho_scalar(x) -> jnp.ndarray:
    """42ZV DEFECT_1 fix: representation-safe scalar extraction.

    Accepts BOTH the in-memory scalar shape () and the one-element shape (1,)
    and returns a 0-d scalar via jnp.reshape(a, ()). NO [0] indexing after
    reshape-to-scalar. Any other shape raises ValueError."""
    a = jnp.asarray(x)
    if a.shape not in ((), (1,)):
        raise ValueError(
            f"v3_raw_temporal_rho must be scalar () or one-element (1,); got shape {a.shape}")
    return jnp.reshape(a, ())


def _all_params_finite(params: dict) -> bool:
    return bool(all(bool(jnp.all(jnp.isfinite(v))) for v in params.values()))


def v3_factor_diagnostics(params: dict) -> dict:
    """V3-specific final diagnostics (six canonical params)."""
    dls = params["v3_diag_log_scale"]
    eff = _effective_log_scale(dls)
    rho = float(_rho_from_raw(canonical_raw_rho_scalar(params["v3_raw_temporal_rho"])))
    below = int(jnp.sum(dls < -LOG_SCALE_ABS_MAX))
    above = int(jnp.sum(dls > LOG_SCALE_ABS_MAX))
    norms = {}
    for n in ("v3_F_count_plus_initial", "v3_F_dynamic_scale", "v3_F_seriousness"):
        F = params[n]
        norms[n.replace("v3_F_", "")] = float(jnp.linalg.norm(F))
    return {
        "rho": rho,
        "diag_effective_min": float(jnp.min(eff)),
        "diag_effective_max": float(jnp.max(eff)),
        "diag_canonical_min": float(jnp.min(dls)),
        "diag_canonical_max": float(jnp.max(dls)),
        "clip_below": below,
        "clip_above": above,
        "clip_proportion": (below + above) / _LATENT_DIM,
        "factor_frobenius_norms": norms,
    }


def classify_terminal(*, early_stop_reason: str, loss_reduction_fraction: float,
                      nonfinite_loss_steps: int, all_params_finite: bool,
                      persistence_pass: bool, required_diagnostics_present: bool):
    """Frozen G1 classification (identical semantics to the verified V2 runner)."""
    if not (all_params_finite and persistence_pass and required_diagnostics_present):
        return "FAILED_INVALID_TERMINAL_STATE", False
    if nonfinite_loss_steps > 0:
        return "FAILED_NONFINITE_LOSS", False
    if loss_reduction_fraction < G1_MIN_LOSS_REDUCTION:
        return "COMPLETED_G1_FAIL_LOSS_REDUCTION", False
    if early_stop_reason == "early_stop_patience":
        return "COMPLETED_EARLY_STOPPED_G1_VALID", True
    return "COMPLETED_G1_VALID_RUN", True


def exit_status_for(terminal_status: str) -> int:
    if terminal_status in ("COMPLETED_G1_VALID_RUN", "COMPLETED_EARLY_STOPPED_G1_VALID"):
        return 0
    if terminal_status == "STOP_IDENTITY_ALREADY_CONSUMED":
        return 3
    if terminal_status in ("FAILED_EXCEPTION_AFTER_RUN_STARTED",
                           "FAILED_FINAL_ON_DISK_VALIDATION"):
        return 4
    return 2


# ---------------------------------------------------------------------------
# On-disk validation (V3 schema: six params, 2049, rho (1,))
# 42ZV DEFECT_2 fix: require_terminal_result=False EXCLUDES result.json from
# the required-file set (pre-result validation); =True requires and validates
# it (final validation). Executable logic.
# ---------------------------------------------------------------------------
def validate_on_disk(out_dir: Path, *, require_terminal_result: bool = True) -> dict:
    problems = []
    ok = True
    # Pre-result required artifacts (result.json excluded when
    # require_terminal_result=False — it is written LAST).
    required = ["RUN_STARTED", "loss_history.csv", "checkpoint_history.json",
                "final_svi_params.npz", "final_svi_params_manifest.json",
                "PARAMETER_PERSISTENCE_VALIDATION.json"]
    if require_terminal_result:
        required.append("result.json")
    for name in required:
        if not (out_dir / name).exists():
            ok = False
            problems.append(f"missing:{name}")
    try:
        with np.load(out_dir / "final_svi_params.npz") as z:
            keys = sorted(z.files)
            if keys != sorted(V3_PARAM_SHAPES.keys()):
                ok = False
                problems.append(f"schema_keys:{keys}")
            total = sum(int(z[k].size) for k in z.files)
            if total != V3_TOTAL:
                ok = False
                problems.append(f"total:{total}")
            if tuple(z["v3_raw_temporal_rho"].shape) != (1,):
                ok = False
                problems.append("rho_shape_not_1")
        man = json.loads((out_dir / "final_svi_params_manifest.json").read_text(encoding="utf-8"))
        if man.get("n_parameters") != 6:
            ok = False
            problems.append("manifest_n_params")
    except Exception as exc:  # noqa: BLE001
        ok = False
        problems.append(f"exception:{repr(exc)}")
    if require_terminal_result:
        try:
            r = json.loads((out_dir / "result.json").read_text(encoding="utf-8"))
            # 42ZZ terminal-semantics fix: recognize the frozen terminal map;
            # scientific-invalid-but-intact runs pass the terminal-schema check.
            ts = r.get("terminal_status")
            if ts not in TERMINAL_VALIDITY_MAP:
                ok = False
                problems.append("terminal_unknown")
            else:
                expected_valid = TERMINAL_VALIDITY_MAP[ts]
                actual_valid = r.get("VALID_V3_G1_RUN")
                if not isinstance(actual_valid, bool) or actual_valid is not expected_valid:
                    ok = False
                    problems.append("terminal_valid_mismatch")
        except Exception:  # noqa: BLE001
            ok = False
            problems.append("result_unreadable")
    return {"PASS": ok, "problems": problems}


def write_terminal_exception(out_dir: Path, *, error_repr: str, started_utc: str,
                             steps_completed: int) -> None:
    failure = {
        "status": "FAILED_EXCEPTION_AFTER_RUN_STARTED",
        "identity": CANARY_IDENTITY["identity"],
        "error_repr": error_repr,
        "started_utc": started_utc,
        "ended_utc": utc_now(),
        "steps_completed": steps_completed,
        "note": "RUN_STARTED identity remains consumed; no automatic rerun.",
    }
    atomic_write_json(out_dir / "FAILURE.json", failure)


# ---------------------------------------------------------------------------
# Final result consistency (42ZX DEFECT_2 / Stage F-G).
# ---------------------------------------------------------------------------
def finalize_result_consistency(result: dict, out_dir: Path) -> tuple:
    """Final on-disk validation after the initial result.json atomic write.

    On PASS: FINAL_ON_DISK_VALIDATION.json PASS=true; the valid classification
    is preserved and result.json gains final_on_disk_validation_PASS=true.
    On FAIL: result.json is atomically DOWNGRADED to
    terminal_status=FAILED_FINAL_ON_DISK_VALIDATION, VALID_V3_G1_RUN=false,
    preserving pre_final_terminal_status / pre_final_VALID_V3_G1_RUN and the
    exact problems; FINAL_ON_DISK_VALIDATION.json records PASS=false. A readback
    consistency audit confirms no path leaves result VALID=true with final
    validation=false. Returns (terminal_status, valid_flag)."""
    od_final = validate_on_disk(out_dir, require_terminal_result=True)
    atomic_write_json(out_dir / "FINAL_ON_DISK_VALIDATION.json", {
        "PASS": od_final["PASS"], "problems": od_final["problems"],
        "created_utc": utc_now(),
        "note": ("final read-only on-disk validation performed AFTER result.json "
                 "atomic write (42ZX DEFECT_2 / Stage F-G)"),
    })
    if od_final["PASS"]:
        # final disk validation is necessary but NOT sufficient: never upgrade
        # an invalid classification; only annotate the PASS.
        result["final_on_disk_validation_PASS"] = True
        atomic_write_json(out_dir / "result.json", result)
        term = result.get("terminal_status")
        valid = bool(result.get("VALID_V3_G1_RUN"))
        # readback consistency audit
        rb = json.loads((out_dir / "result.json").read_text(encoding="utf-8"))
        assert rb.get("terminal_status") == term and bool(rb.get("VALID_V3_G1_RUN")) == valid
        return term, valid
    # FAIL: downgrade the authoritative result.
    pre_term = result.get("terminal_status")
    pre_valid = bool(result.get("VALID_V3_G1_RUN"))
    result["pre_final_terminal_status"] = pre_term
    result["pre_final_VALID_V3_G1_RUN"] = pre_valid
    result["terminal_status"] = "FAILED_FINAL_ON_DISK_VALIDATION"
    result["VALID_V3_G1_RUN"] = False
    result["final_on_disk_validation_PASS"] = False
    result["final_on_disk_validation_problems"] = od_final["problems"]
    atomic_write_json(out_dir / "result.json", result)
    # readback consistency audit
    rb = json.loads((out_dir / "result.json").read_text(encoding="utf-8"))
    assert rb.get("terminal_status") == "FAILED_FINAL_ON_DISK_VALIDATION"
    assert bool(rb.get("VALID_V3_G1_RUN")) is False
    assert rb.get("pre_final_terminal_status") == pre_term
    return "FAILED_FINAL_ON_DISK_VALIDATION", False


# ---------------------------------------------------------------------------
# REAL canary training path (SVI + stable_update loop + persistence).
# ---------------------------------------------------------------------------
def _run_canary() -> str:
    """Execute the V3 canary V3_V3_ARM_P1_p1_seed1001_t12 once. Caller MUST
    have already acquired RUN_STARTED (acquire_run_started) and validated the
    frozen chain and authorization."""
    from numpyro.infer import SVI, Trace_ELBO
    from numpyro.optim import ClippedAdam
    from dhbcp_pv.models.full_joint_model import full_joint_model as TARGET
    from dhbcp_pv.inference.variational_param_persistence import (
        save_params, load_params, validate_params_roundtrip, params_sha256,
    )
    import importlib.util
    spec = importlib.util.spec_from_file_location("frozen_51", ROOT / "scripts/51_run_phase3c_nuts.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    out_dir = canary_out_dir()
    entry = CANARY_IDENTITY
    seed = entry["seed"]
    master = jax.random.PRNGKey(seed)
    prototype_key, factor_init_key, svi_init_key, svi_runtime_key = jax.random.split(master, 4)
    run_started_utc = utc_now()
    run_t0 = time.perf_counter()
    steps_completed = 0
    try:
        data_seed, args, kwargs = mod.reference_data(ROOT, entry["cutoff"])
        guide = V3LocalBlockAR1AutoGuide(
            TARGET, prefix="v3",
            init_loc_fn=init_to_median(num_samples=5),
            factor_init_key=factor_init_key,
        )
        with handlers.seed(rng_seed=prototype_key):
            guide._setup_prototype(*args, **kwargs)
        svi = SVI(
            TARGET, guide,
            ClippedAdam(step_size=TRAINING["learning_rate"], clip_norm=TRAINING["clip_norm"]),
            Trace_ELBO(num_particles=entry["num_particles"]),
        )
        state = svi.init(svi_init_key, *args, **kwargs)
        state = state._replace(rng_key=svi_runtime_key)

        max_steps = TRAINING["maximum_steps"]
        ckpt_interval = TRAINING["checkpoint_interval"]
        min_es_steps = TRAINING["minimum_steps_before_early_stopping"]
        es_tol = TRAINING["early_stop_relative_tolerance"]
        es_patience = TRAINING["early_stop_patience_checkpoints"]

        losses = []
        finite_flags = []
        rho_trajectory = []
        diag_effective_trajectory = []
        diag_canonical_trajectory = []
        clip_occupancy_trajectory = []
        factor_norm_trajectory = []
        ckpt_history = []
        nonfinite_steps = 0
        patience_count = 0
        prev_ckpt_loss = None
        early_stop_reason = "max_steps_reached"

        for step in range(max_steps):
            # NumPyro 0.21 stable_update -> eval_and_stable_update joint
            # finite-objective-and-gradient guard: on guard failure the state
            # is HELD and loss is NaN (recorded, never substituted).
            state, loss = svi.stable_update(state, *args, **kwargs)
            loss = float(loss)
            # FIX (42Q): the exact missing operation — append BEFORE finite check.
            losses.append(loss)
            finite = bool(jnp.isfinite(loss))
            finite_flags.append(finite)
            if not finite:
                nonfinite_steps += 1
            steps_completed = step + 1
            # Executable invariants (real assertions, not comments).
            assert len(losses) == steps_completed, "bookkeeping invariant: len(losses) == steps_completed"
            assert len(finite_flags) == steps_completed, "bookkeeping invariant: len(finite_flags) == steps_completed"

            if (steps_completed % ckpt_interval == 0) or (steps_completed == max_steps):
                params = svi.get_params(state)
                diag = v3_factor_diagnostics(params)
                rho_trajectory.append(diag["rho"])
                diag_effective_trajectory.append([diag["diag_effective_min"], diag["diag_effective_max"]])
                diag_canonical_trajectory.append([diag["diag_canonical_min"], diag["diag_canonical_max"]])
                clip_occupancy_trajectory.append([diag["clip_below"], diag["clip_above"]])
                factor_norm_trajectory.append(diag["factor_frobenius_norms"])
                all_finite = _all_params_finite(params)
                window = [l for l, f in zip(losses[-ckpt_interval:], finite_flags[-ckpt_interval:]) if f]
                assert len(losses) >= 1, "checkpoint invariant: len(losses) >= 1"
                if any(f for f in finite_flags[-ckpt_interval:]):
                    assert window, "checkpoint invariant: window non-empty when finite losses exist"
                ckpt_loss = float(np.mean(window)) if window else float("nan")
                ckpt_history.append({
                    "step": steps_completed, "checkpoint_loss": ckpt_loss,
                    "all_params_finite": all_finite, "rho": diag["rho"],
                    "diag_effective_min": diag["diag_effective_min"],
                    "diag_effective_max": diag["diag_effective_max"],
                    "clip_below": diag["clip_below"], "clip_above": diag["clip_above"],
                })
                if steps_completed >= min_es_steps and prev_ckpt_loss is not None and window:
                    denom = max(abs(prev_ckpt_loss), 1e-12)
                    rel_improve = (prev_ckpt_loss - ckpt_loss) / denom
                    patience_count = patience_count + 1 if rel_improve < es_tol else 0
                    if patience_count >= es_patience:
                        early_stop_reason = "early_stop_patience"
                        break
                if window:
                    prev_ckpt_loss = ckpt_loss

        # ---- loop completion invariants + metrics ----
        assert len(losses) == steps_completed and len(losses) > 0, "loop completion invariant"
        initial_loss = float(losses[0])
        terminal_loss = float(losses[-1])
        loss_red = (initial_loss - terminal_loss) / max(abs(initial_loss), 1e-12)

        # ---- final params + six-canonical extraction ----
        final_params = svi.get_params(state)
        all_params_finite_final = _all_params_finite(final_params)
        param_schema = {k: [int(x) for x in jnp.shape(v)] for k, v in final_params.items()}
        total_elements = int(sum(int(jnp.size(v)) for v in final_params.values()))
        final_diag = v3_factor_diagnostics(final_params)

        # ---- persistence: rho scalar -> (1,) before serialization (42ZQ) ----
        persist_params = {k: np.asarray(v) for k, v in final_params.items()}
        if persist_params["v3_raw_temporal_rho"].ndim == 0:
            persist_params["v3_raw_temporal_rho"] = np.asarray(
                [float(persist_params["v3_raw_temporal_rho"])])
        npz_path = out_dir / "final_svi_params.npz"
        manifest_path = out_dir / "final_svi_params_manifest.json"
        try:
            man = save_params(persist_params, npz_path, manifest_path)
            loaded = load_params(npz_path)
            rt = validate_params_roundtrip(persist_params, npz_path, manifest_path)
            persistence_pass = bool(rt.get("PASS"))
            persistence_artifact = {
                "roundtrip_pass": rt.get("PASS"),
                "n_parameters": man.get("n_parameters"),
                "npz_sha256": man.get("npz_sha256"),
                "params_sha256": params_sha256(persist_params),
                "PERSISTED_RAW_RHO_SHAPE": list(loaded["v3_raw_temporal_rho"].shape),
                "IN_MEMORY_PARAMETER_SEMANTICS": ("scalar"
                                                  if jnp.ndim(final_params["v3_raw_temporal_rho"]) == 0
                                                  else "array"),
            }
        except Exception as exc:  # noqa: BLE001
            persistence_pass = False
            persistence_artifact = {"error": repr(exc), "roundtrip_pass": False}

        # ---- diagnostics artifacts (before result.json) ----
        import csv as _csv
        with open(out_dir / "loss_history.csv", "w", newline="", encoding="utf-8") as f:
            w = _csv.writer(f)
            w.writerow(["step", "loss", "finite"])
            for i, (l, fin) in enumerate(zip(losses, finite_flags), 1):
                w.writerow([i, l, int(fin)])
        atomic_write_json(out_dir / "rho_trajectory.json", {"trajectory": rho_trajectory})
        atomic_write_json(out_dir / "diag_scale_trajectory.json", {
            "effective_min_max": diag_effective_trajectory,
            "canonical_min_max": diag_canonical_trajectory,
        })
        atomic_write_json(out_dir / "clip_boundary_occupancy.json", {
            "checkpoints": clip_occupancy_trajectory,
            "final": {"count_below_neg300": final_diag["clip_below"],
                      "count_above_pos300": final_diag["clip_above"],
                      "proportion_outside": final_diag["clip_proportion"]},
        })
        atomic_write_json(out_dir / "factor_frobenius_history.json", {"trajectory": factor_norm_trajectory})
        atomic_write_json(out_dir / "checkpoint_history.json", {"history": ckpt_history})
        atomic_write_json(out_dir / "PARAMETER_PERSISTENCE_VALIDATION.json", persistence_artifact)

        # ---- PRE-RESULT on-disk validation (42ZV DEFECT_2: result.json NOT
        #      required here; it is written LAST) ----
        od_pre = validate_on_disk(out_dir, require_terminal_result=False)
        required_diagnostics_present = bool(od_pre["PASS"] and losses and finite_flags and ckpt_history)
        on_disk_validation_pre = {"PASS": od_pre["PASS"], "problems": od_pre["problems"]}

        # ---- frozen G1 classification (based on pre-result conditions) ----
        terminal_status, valid_run = classify_terminal(
            early_stop_reason=early_stop_reason,
            loss_reduction_fraction=float(loss_red),
            nonfinite_loss_steps=nonfinite_steps,
            all_params_finite=all_params_finite_final,
            persistence_pass=persistence_pass,
            required_diagnostics_present=required_diagnostics_present,
        )

        # ---- result.json LAST ----
        run_ended_utc = utc_now()
        elapsed = time.perf_counter() - run_t0
        result = {
            "identity": entry["identity"], "arm": entry["arm"],
            "num_particles": entry["num_particles"], "seed": seed, "cutoff": entry["cutoff"],
            "steps_completed": steps_completed,
            "initial_loss": initial_loss, "terminal_loss": terminal_loss,
            "loss_reduction_fraction": float(loss_red),
            "G1_MIN_LOSS_REDUCTION": G1_MIN_LOSS_REDUCTION,
            "nonfinite_loss_steps": nonfinite_steps,
            "all_params_finite": all_params_finite_final,
            "early_stop_reason": early_stop_reason,
            "terminal_status": terminal_status,
            "VALID_V3_G1_RUN": valid_run,
            "RUN_STARTED_CONSUMED": True,
            "required_diagnostics_present": required_diagnostics_present,
            "parameter_persistence_status": "PASS" if persistence_pass else "FAILED",
            "on_disk_validation": {"PASS": od_pre["PASS"], "problems": od_pre["problems"]},
            "pre_result_validation": {"PASS": od_pre["PASS"], "problems": od_pre["problems"]},
            "final_rho": final_diag["rho"],
            "final_diag_scale": {"effective_min": final_diag["diag_effective_min"],
                                 "effective_max": final_diag["diag_effective_max"],
                                 "canonical_min": final_diag["diag_canonical_min"],
                                 "canonical_max": final_diag["diag_canonical_max"]},
            "clip_boundary_occupancy": {"count_below_neg300": final_diag["clip_below"],
                                        "count_above_pos300": final_diag["clip_above"],
                                        "proportion_outside": final_diag["clip_proportion"]},
            "final_factor_frobenius_norms": final_diag["factor_frobenius_norms"],
            "final_parameter_schema": param_schema,
            "total_parameter_elements": total_elements,
            "checkpoint_count": len(ckpt_history),
            "checkpoint_history": ckpt_history,
            "started_utc": run_started_utc, "ended_utc": run_ended_utc,
            "elapsed_seconds": float(elapsed),
            "runner_sha256": sha256(Path(__file__).resolve()),
            "guide_sha256": sha256(ROOT / FROZEN_CHAIN["guide_v3"][0]),
            "model_sha256": sha256(ROOT / FROZEN_CHAIN["model"][0]),
            "serializer_sha256": sha256(ROOT / FROZEN_CHAIN["serializer"][0]),
            "data_seed": int(data_seed),
            "persistence": persistence_artifact,
        }
        atomic_write_json(out_dir / "result.json", result)

        # ---- FINAL consistency: final on-disk validation + downgrade policy
        #      (42ZX DEFECT_2 / Stage F-G). No path may leave result VALID=true
        #      with final validation=false. ----
        term_final, valid_final = finalize_result_consistency(result, out_dir)
        if not valid_final and term_final == "FAILED_FINAL_ON_DISK_VALIDATION":
            print("FINAL_ON_DISK_VALIDATION_FAILED:",
                  result.get("final_on_disk_validation_problems"))
        return term_final
    except Exception as exc:  # noqa: BLE001
        write_terminal_exception(out_dir, error_repr=repr(exc),
                                 started_utc=run_started_utc,
                                 steps_completed=steps_completed)
        return "FAILED_EXCEPTION_AFTER_RUN_STARTED"


# ---------------------------------------------------------------------------
# Strict authorization validator (42ZX DEFECT_1: exact 42ZW SHA + strict JSON
# booleans + required top-level schema)
# ---------------------------------------------------------------------------
def validate_canary_authorization(path) -> dict:
    """Parse and strictly validate the V3 canary authorization payload.

    Returns {"ok": bool, "reason": str, "checks": dict}. 42ZW binding is
    exact (live SHA of the REAL 42ZW artifact). Booleans require exact JSON
    boolean presence and identity. Required top-level fields enforced."""
    p = Path(path)
    if not p.exists():
        return {"ok": False, "reason": "authorization file missing", "checks": {}}
    try:
        auth = json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "reason": f"malformed JSON: {repr(exc)}", "checks": {}}
    if not isinstance(auth, dict):
        return {"ok": False, "reason": "authorization is not a JSON object", "checks": {}}
    checks = {}
    # required top-level fields present
    checks["top_fields"] = all(f in auth for f in AUTH_REQUIRED_TOP_FIELDS)
    checks["scope"] = auth.get("authorization_scope") == "ONE_SHOT_V3_G1_CANARY_ONLY"
    # strict JSON boolean: exact presence + exact bool identity
    checks["AUTHORIZED_true"] = ("AUTHORIZED" in auth
                                 and isinstance(auth["AUTHORIZED"], bool)
                                 and auth["AUTHORIZED"] is True)
    for f in ("G2_AUTHORIZED", "G3_AUTHORIZED", "BATCH_AUTHORIZED"):
        checks[f"{f}_false"] = (f in auth and isinstance(auth[f], bool)
                                and auth[f] is False)
    ident = auth.get("identity")
    checks["identity"] = (isinstance(ident, dict)
                          and ident.get("identity") == CANARY_IDENTITY["identity"]
                          and ident.get("arm") == CANARY_IDENTITY["arm"]
                          and ident.get("num_particles") == CANARY_IDENTITY["num_particles"]
                          and ident.get("seed") == CANARY_IDENTITY["seed"]
                          and ident.get("cutoff") == CANARY_IDENTITY["cutoff"])
    binds = auth.get("binds_sha256")
    if not isinstance(binds, dict):
        checks["binds"] = False
        checks["42ZW_exact"] = False
    else:
        exp = {
            "42ZR": FROZEN_CHAIN["42ZR"][1],
            "42ZU": FROZEN_CHAIN["42ZU"][1],
            "guide_v3": FROZEN_CHAIN["guide_v3"][1],
            "model": FROZEN_CHAIN["model"][1],
            "serializer": FROZEN_CHAIN["serializer"][1],
            "runner": sha256(Path(__file__).resolve()),
        }
        binds_ok = all(isinstance(binds.get(k), str) and binds.get(k) == v
                       for k, v in exp.items())
        # exact 42ZW binding: live SHA of the REAL 42ZW artifact (42ZX DEFECT_1)
        zw_live = sha256(REAL_42ZW_PATH) if REAL_42ZW_PATH.exists() else None
        zw_ok = (isinstance(binds.get("42ZW"), str)
                 and zw_live is not None and binds["42ZW"] == zw_live)
        checks["binds"] = bool(binds_ok and zw_ok)
        checks["42ZW_exact"] = bool(zw_ok)
    ok = all(checks.values())
    bad = [k for k, v in checks.items() if not v]
    return {"ok": ok, "reason": "AUTHORIZED" if ok else "rejected: " + ",".join(bad),
            "checks": checks}


# ---------------------------------------------------------------------------
# Canary command (guarded; NOT executed in this batch)
# 42ZV DEFECT_3 / Stage G order: chain -> authorization content -> unconsumed
# -> RUN_STARTED O_EXCL -> _run_canary. NEVER RUN_STARTED before auth.
# ---------------------------------------------------------------------------
def cmd_canary() -> int:
    auth_path = V3_RUNS.parent / "authorizations" / "V3_G1_CANARY_AUTHORIZATION.json"
    # 1: frozen SHA chain
    chain = verify_frozen_chain()
    if not chain["ok"]:
        print("STOP_SHA_MISMATCH: frozen chain mismatch; canary refused.")
        return 2
    # 2: validate authorization CONTENT (not mere existence)
    va = validate_canary_authorization(auth_path)
    if not va["ok"]:
        print("STOP_NOT_AUTHORIZED: " + va["reason"])
        return 2
    # 3: verify identity currently unconsumed
    if identity_consumed():
        print("STOP_IDENTITY_ALREADY_CONSUMED")
        return 3
    # 4: acquire RUN_STARTED O_EXCL (BEFORE any SVI)
    guard = acquire_run_started()
    if not guard["acquired"]:
        print("STOP_IDENTITY_ALREADY_CONSUMED")
        return 3
    # 5: execute the canary
    print("V3 canary authorization validated; RUN_STARTED acquired; executing...")
    status = _run_canary()
    print("V3 canary terminal status:", status)
    return exit_status_for(status)


# ---------------------------------------------------------------------------
# Preflight E1..E40 (AST-based for E13-E24)
# ---------------------------------------------------------------------------
def _install_svi_probe():
    import numpyro.infer as ni
    counters = {"init": 0, "update": 0, "stable_update": 0}
    orig = {}
    for meth, key in (("init", "init"), ("update", "update"), ("stable_update", "stable_update")):
        orig[meth] = getattr(ni.SVI, meth)

        def make_wrap(k):
            def wrap(self, *a, **kw):
                counters[k] += 1
                return orig[k](self, *a, **kw)
            return wrap
        setattr(ni.SVI, meth, make_wrap(key))
    return counters, orig


def _restore_svi(orig) -> None:
    import numpyro.infer as ni
    for meth, fn in orig.items():
        setattr(ni.SVI, meth, fn)


def ast_canary_path() -> dict:
    """AST-based structural inspection of the REAL executable canary path.
    Only code nodes inside _run_canary / acquire_run_started / cmd_canary are
    inspected (comments and docstrings are excluded by construction)."""
    src = Path(__file__).read_text(encoding="utf-8")
    tree = ast.parse(src)
    fn_run = next(n for n in ast.walk(tree)
                  if isinstance(n, ast.FunctionDef) and n.name == "_run_canary")
    fn_acq = next(n for n in ast.walk(tree)
                  if isinstance(n, ast.FunctionDef) and n.name == "acquire_run_started")
    fn_cmd = next(n for n in ast.walk(tree)
                  if isinstance(n, ast.FunctionDef) and n.name == "cmd_canary")

    def calls_in(fn):
        return [c for c in ast.walk(fn) if isinstance(c, ast.Call)]

    def name_of(c):
        if isinstance(c.func, ast.Name):
            return c.func.id
        if isinstance(c.func, ast.Attribute):
            return c.func.attr
        return None

    def kwarg_int(c, key):
        for kw in c.keywords:
            if kw.arg == key:
                v = kw.value
                if isinstance(v, ast.Constant):
                    return v.value
                if (isinstance(v, ast.Subscript) and isinstance(v.slice, ast.Constant)
                        and isinstance(v.value, ast.Name)):
                    container = {"entry": CANARY_IDENTITY, "TRAINING": TRAINING}.get(v.value.id)
                    if container is not None:
                        return container.get(v.slice.value)
        return None

    def kwarg_float(c, key):
        for kw in c.keywords:
            if kw.arg == key:
                v = kw.value
                if isinstance(v, ast.Constant):
                    return v.value
                if (isinstance(v, ast.Subscript) and isinstance(v.slice, ast.Constant)
                        and isinstance(v.value, ast.Name)):
                    container = {"entry": CANARY_IDENTITY, "TRAINING": TRAINING}.get(v.value.id)
                    if container is not None:
                        return container.get(v.slice.value)
        return None

    run_calls = calls_in(fn_run)
    run_names = [name_of(c) for c in run_calls]
    acq_calls = calls_in(fn_acq)
    cmd_calls = calls_in(fn_cmd)
    cmd_names = [name_of(c) for c in cmd_calls]

    has_svi_ctor = any(n in ("SVI",) for n in run_names)
    trace_elbo_calls = [c for c in run_calls if name_of(c) == "Trace_ELBO"]
    clipped_calls = [c for c in run_calls if name_of(c) == "ClippedAdam"]
    stable_calls = [c for c in run_calls if name_of(c) == "stable_update"]
    losses_init = any(
        isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "losses" for t in n.targets)
        and isinstance(n.value, ast.List) and not n.value.elts
        for n in ast.walk(fn_run) if isinstance(n, ast.Assign))
    losses_append = any(
        isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute)
        and isinstance(c.func.value, ast.Name) and c.func.value.id == "losses"
        and c.func.attr == "append"
        and (isinstance(c.args[0], ast.Call) and isinstance(c.args[0].func, ast.Name)
             and c.args[0].func.id == "float"
             or isinstance(c.args[0], ast.Name) and c.args[0].id == "loss")
        for c in run_calls)
    len_eq_steps = any(
        isinstance(n, (ast.Assert, ast.Compare)) and
        any(isinstance(x, ast.Call) and isinstance(x.func, ast.Name) and x.func.id == "len"
            for x in ast.walk(n.test if isinstance(n, ast.Assert) else n))
        for n in ast.walk(fn_run) if isinstance(n, (ast.Assert, ast.Compare)))
    finite_branch = any(
        isinstance(n, ast.If) and
        any(isinstance(x, ast.Name) and x.id == "finite" for x in ast.walk(n.test))
        for n in ast.walk(fn_run) if isinstance(n, ast.If))
    ckpt_gen = any(
        isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute)
        and isinstance(c.func.value, ast.Name) and c.func.value.id == "ckpt_history"
        and c.func.attr == "append"
        for c in run_calls)
    early_stop = any(
        isinstance(n, ast.If) and
        any(isinstance(x, ast.Name) and x.id == "patience_count" for x in ast.walk(n.test))
        for n in ast.walk(fn_run) if isinstance(n, ast.If))
    o_excl = any(
        isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute)
        and isinstance(c.func.value, ast.Name) and c.func.value.id == "os"
        and c.func.attr == "open"
        and any(isinstance(a, ast.BinOp) for a in c.args)
        for c in acq_calls)
    run_started_before_svi = (
        any(isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == "acquire_run_started"
            for c in cmd_calls)
        and "SVI" not in cmd_names and "stable_update" not in cmd_names
        and any(isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == "_run_canary"
                for c in cmd_calls))

    # Frozen protocol values (42ZR)
    FROZEN_LR = TRAINING["learning_rate"]
    FROZEN_CLIP = TRAINING["clip_norm"]
    trace_elbo_ok = bool(trace_elbo_calls and all(
        (kwarg_int(c, "num_particles") == 1) for c in trace_elbo_calls))
    clipped_ok = bool(clipped_calls and all(
        kwarg_float(c, "step_size") == FROZEN_LR and kwarg_float(c, "clip_norm") == FROZEN_CLIP
        for c in clipped_calls))
    return {
        "has_svi_ctor": has_svi_ctor,
        "trace_elbo_num_particles_1": trace_elbo_ok,
        "clipped_adam_003_10": clipped_ok,
        "losses_init": losses_init,
        "losses_append_float": losses_append,
        "len_eq_steps": len_eq_steps,
        "stable_update_in_loop": bool(stable_calls),
        "finite_branch": finite_branch,
        "ckpt_gen": ckpt_gen,
        "early_stop": early_stop,
        "o_excl_run_started": o_excl,
        "run_started_before_svi": run_started_before_svi,
    }


# ---------------------------------------------------------------------------
# Preflight F1..F50 (42ZW). F12-F19 and F20-F29 are DYNAMIC deterministic


# ---------------------------------------------------------------------------
# Preflight G1..G50 (42ZY). G7-G24 authorization dynamic tests; G33-G37
# final-consistency dynamic tests; all deterministic.
# ---------------------------------------------------------------------------
def _synthetic_authorization(overrides: dict | None = None) -> dict:
    """Deterministic synthetic authorization payload for dynamic tests only.
    Binds the REAL live 42ZW SHA (42ZX DEFECT_1 exact binding)."""
    zw_live = sha256(REAL_42ZW_PATH) if REAL_42ZW_PATH.exists() else "0" * 64
    auth = {
        "authorization_scope": "ONE_SHOT_V3_G1_CANARY_ONLY",
        "AUTHORIZED": True,
        "identity": {
            "identity": CANARY_IDENTITY["identity"],
            "arm": CANARY_IDENTITY["arm"],
            "num_particles": CANARY_IDENTITY["num_particles"],
            "seed": CANARY_IDENTITY["seed"],
            "cutoff": CANARY_IDENTITY["cutoff"],
        },
        "binds_sha256": {
            "42ZR": FROZEN_CHAIN["42ZR"][1],
            "42ZU": FROZEN_CHAIN["42ZU"][1],
            "42ZW": zw_live,
            "guide_v3": FROZEN_CHAIN["guide_v3"][1],
            "model": FROZEN_CHAIN["model"][1],
            "serializer": FROZEN_CHAIN["serializer"][1],
            "runner": sha256(Path(__file__).resolve()),
        },
        "G2_AUTHORIZED": False,
        "G3_AUTHORIZED": False,
        "BATCH_AUTHORIZED": False,
    }
    if overrides:
        for k, v in overrides.items():
            if k == "identity" and isinstance(v, dict):
                auth["identity"].update(v)
            elif k == "binds_sha256" and isinstance(v, dict):
                auth["binds_sha256"].update(v)
            else:
                auth[k] = v
    return auth


def _write_synthetic_auth(payload) -> Path:
    td = Path(tempfile.mkdtemp(prefix="v3_auth_final_test_"))
    p = td / "auth.json"
    p.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    return p



# ---------------------------------------------------------------------------
# Preflight H1..H44 (43A). H7-H18 terminal-semantics DYNAMIC oracles.
# ---------------------------------------------------------------------------
def _build_synthetic_run_dir(*, include_result: bool, terminal: str | None = None,
                             valid: bool | None = None,
                             omit: str | None = None) -> Path:
    """Deterministic synthetic V3 run directory. terminal/valid control the
    result.json classification for the terminal-semantics oracles."""
    td = Path(tempfile.mkdtemp(prefix="v3_term_final_test_"))
    (td / "RUN_STARTED").write_text("x", encoding="utf-8")
    (td / "loss_history.csv").write_text("step,loss,finite\n1,10.0,1\n", encoding="utf-8")
    (td / "checkpoint_history.json").write_text(json.dumps({"history": []}), encoding="utf-8")
    rng = np.random.RandomState(20260907)
    toy_v3 = {
        "v3_loc": rng.normal(0, 1, 708),
        "v3_diag_log_scale": rng.normal(-0.5, 0.1, 708),
        "v3_F_count_plus_initial": rng.normal(0, 0.1, (120, 4)),
        "v3_F_dynamic_scale": rng.normal(0, 0.1, (16, 4)),
        "v3_F_seriousness": rng.normal(0, 0.1, (22, 4)),
        "v3_raw_temporal_rho": np.array([0.2]),
    }
    import importlib.util
    spec = importlib.util.spec_from_file_location("sp",
        str(ROOT / "src/dhbcp_pv/inference/variational_param_persistence.py"))
    sp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(sp)
    sp.save_params(toy_v3, td / "final_svi_params.npz", td / "final_svi_params_manifest.json")
    (td / "PARAMETER_PERSISTENCE_VALIDATION.json").write_text(
        json.dumps({"roundtrip_pass": True}), encoding="utf-8")
    if include_result:
        if terminal is None:
            terminal = "COMPLETED_G1_VALID_RUN"
        if valid is None:
            valid = TERMINAL_VALIDITY_MAP.get(terminal, False)
        result = {"terminal_status": terminal, "VALID_V3_G1_RUN": valid}
        (td / "result.json").write_text(json.dumps(result), encoding="utf-8")
    if omit is not None:
        (td / omit).unlink()
    return td


def run_preflight(counters: dict | None = None) -> dict:
    checks = {}
    rec = lambda n, ok, d: checks.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731
    src = Path(__file__).read_text(encoding="utf-8")
    prod_zone = src.split("def dummy_model")[0] + src.split("def run_preflight")[1]
    chain = verify_frozen_chain()
    astp = ast_canary_path()

    # H1-H4: upstream SHA / 42ZZ / scripts85 / 42ZY
    rec("H1_all_upstream_sha_exact", chain["ok"],
        {"mismatches": [k for k, v in chain["results"].items() if not v["ok"]]})
    zz = json.loads((ROOT / FROZEN_CHAIN["42ZZ"][0]).read_text(encoding="utf-8"))
    rec("H2_42ZZ_exact",
        zz.get("classification") == "V3_G1_CANARY_TERMINAL_SEMANTICS_CORRECTION_REQUIRED",
        {"classification": zz.get("classification")})
    rec("H3_scripts85_preserved", chain["results"]["scripts85"]["ok"],
        {"live": chain["results"]["scripts85"]["live"]})
    zy = json.loads((ROOT / FROZEN_CHAIN["42ZY"][0]).read_text(encoding="utf-8"))
    rec("H4_42ZY_exact_pass",
        zy.get("classification") == "V3_G1_CANARY_FINAL_PREFLIGHT_PASS",
        {"classification": zy.get("classification")})

    # H5-H6: canary unconsumed / no result
    rec("H5_canary_unconsumed", not identity_consumed(), {"consumed": identity_consumed()})
    rec("H6_no_result_exists", not (canary_out_dir() / "result.json").exists(),
        {"result_exists": (canary_out_dir() / "result.json").exists()})

    # H7: terminal validity map exact
    rec("H7_terminal_validity_map_exact",
        TERMINAL_VALIDITY_MAP == {
            "COMPLETED_G1_VALID_RUN": True,
            "COMPLETED_EARLY_STOPPED_G1_VALID": True,
            "COMPLETED_G1_FAIL_LOSS_REDUCTION": False,
            "FAILED_NONFINITE_LOSS": False,
            "FAILED_INVALID_TERMINAL_STATE": False,
        },
        {"map": TERMINAL_VALIDITY_MAP})

    # H8-H18: terminal-semantics DYNAMIC oracles
    cases = [
        ("H8_valid_run_true", "COMPLETED_G1_VALID_RUN", True, True),
        ("H9_early_stopped_valid_true", "COMPLETED_EARLY_STOPPED_G1_VALID", True, True),
        ("H10_loss_reduction_fail_false", "COMPLETED_G1_FAIL_LOSS_REDUCTION", False, True),
        ("H11_nonfinite_fail_false", "FAILED_NONFINITE_LOSS", False, True),
        ("H12_invalid_terminal_state_false", "FAILED_INVALID_TERMINAL_STATE", False, True),
        ("H13_loss_reduction_fail_true", "COMPLETED_G1_FAIL_LOSS_REDUCTION", True, False),
        ("H14_valid_terminal_false", "COMPLETED_G1_VALID_RUN", False, False),
    ]
    for nm, term, valid, expect_pass in cases:
        d = _build_synthetic_run_dir(include_result=True, terminal=term, valid=valid)
        v = validate_on_disk(d, require_terminal_result=True)
        rec(nm, bool(v["PASS"]) == expect_pass,
            {"PASS": v["PASS"], "expect": expect_pass, "problems": v["problems"]})
    # H15: unknown terminal rejected
    d_unk = _build_synthetic_run_dir(include_result=True, terminal="SOME_UNKNOWN_STATUS", valid=False)
    v_unk = validate_on_disk(d_unk, require_terminal_result=True)
    rec("H15_unknown_terminal_rejected",
        (not v_unk["PASS"]) and any("terminal_unknown" in p for p in v_unk["problems"]),
        {"PASS": v_unk["PASS"], "problems": v_unk["problems"]})
    # H16: scientific-invalid intact run does NOT downgrade
    d_intact = _build_synthetic_run_dir(include_result=True,
                                        terminal="COMPLETED_G1_FAIL_LOSS_REDUCTION", valid=False)
    res_intact = {"terminal_status": "COMPLETED_G1_FAIL_LOSS_REDUCTION",
                  "VALID_V3_G1_RUN": False}
    (d_intact / "result.json").write_text(json.dumps(res_intact), encoding="utf-8")
    term_intact, valid_intact = finalize_result_consistency(res_intact, d_intact)
    rec("H16_scientific_invalid_intact_not_downgraded",
        term_intact == "COMPLETED_G1_FAIL_LOSS_REDUCTION" and valid_intact is False,
        {"term": term_intact, "valid": valid_intact})
    # H17: true disk artifact failure DOES downgrade
    d_disk = _build_synthetic_run_dir(include_result=True,
                                      terminal="COMPLETED_G1_FAIL_LOSS_REDUCTION", valid=False,
                                      omit="PARAMETER_PERSISTENCE_VALIDATION.json")
    res_disk = {"terminal_status": "COMPLETED_G1_FAIL_LOSS_REDUCTION",
                "VALID_V3_G1_RUN": False}
    (d_disk / "result.json").write_text(json.dumps(res_disk), encoding="utf-8")
    term_disk, valid_disk = finalize_result_consistency(res_disk, d_disk)
    rb_disk = json.loads((d_disk / "result.json").read_text(encoding="utf-8"))
    rec("H17_true_disk_failure_downgrades",
        term_disk == "FAILED_FINAL_ON_DISK_VALIDATION" and valid_disk is False
        and rb_disk.get("terminal_status") == "FAILED_FINAL_ON_DISK_VALIDATION",
        {"term": term_disk, "valid": valid_disk})
    # H18: pre-final scientific reason preserved on true disk failure
    rec("H18_pre_final_reason_preserved",
        rb_disk.get("pre_final_terminal_status") == "COMPLETED_G1_FAIL_LOSS_REDUCTION"
        and rb_disk.get("pre_final_VALID_V3_G1_RUN") is False,
        {"pre_term": rb_disk.get("pre_final_terminal_status"),
         "pre_valid": rb_disk.get("pre_final_VALID_V3_G1_RUN")})

    # H19-H22: authorization fixes preserved + ordering
    zw_live = sha256(REAL_42ZW_PATH) if REAL_42ZW_PATH.exists() else None
    rec("H19_auth_exact_42ZW_preserved",
        "REAL_42ZW_PATH" in src and "42ZW" in src and zw_live is not None
        and zw_live == FROZEN_CHAIN["42ZW"][1],
        {"live": zw_live, "frozen": FROZEN_CHAIN["42ZW"][1]})
    rec("H20_strict_auth_booleans_preserved",
        'auth["AUTHORIZED"] is True' in src
        and 'auth[f] is False' in src and "isinstance(auth" in src,
        {"present": True})
    rec("H21_auth_before_run_started", astp["run_started_before_svi"],
        {"ast": astp["run_started_before_svi"]})
    rec("H22_run_started_before_svi", astp["run_started_before_svi"],
        {"ast": astp["run_started_before_svi"]})

    # H23-H26: AST executable path
    rec("H23_actual_svi_ctor_exact", astp["has_svi_ctor"], {"ast": astp["has_svi_ctor"]})
    rec("H24_stable_update_loop_exact", astp["stable_update_in_loop"],
        {"ast": astp["stable_update_in_loop"]})
    rec("H25_loss_bookkeeping_exact",
        astp["losses_append_float"] and astp["len_eq_steps"] and astp["losses_init"],
        {"ast": {"append": astp["losses_append_float"], "len_eq": astp["len_eq_steps"],
                 "init": astp["losses_init"]}})
    rec("H26_checkpoint_early_stop_exact",
        astp["ckpt_gen"] and astp["early_stop"]
        and TRAINING["minimum_steps_before_early_stopping"] == 500
        and TRAINING["checkpoint_interval"] == 100
        and TRAINING["early_stop_relative_tolerance"] == 1e-4
        and TRAINING["early_stop_patience_checkpoints"] == 5,
        {"ast": {"ckpt": astp["ckpt_gen"], "es": astp["early_stop"]}})

    # H27-H28: prior fixes preserved
    rec("H27_rho_diagnostic_fix_preserved", "def canonical_raw_rho_scalar" in src,
        {"present": "def canonical_raw_rho_scalar" in src})
    rec("H28_pre_result_validation_preserved",
        "def finalize_result_consistency" in src and "require_terminal_result" in src,
        {"present": True})

    # H29-H32: persistence schema / roundtrip
    rec("H29_six_params_exact",
        sorted(V3_PARAM_SHAPES.keys()) == ["v3_F_count_plus_initial", "v3_F_dynamic_scale",
                                           "v3_F_seriousness", "v3_diag_log_scale",
                                           "v3_loc", "v3_raw_temporal_rho"],
        {"params": sorted(V3_PARAM_SHAPES.keys())})
    total = sum(int(np.prod(s)) for s in V3_PARAM_SHAPES.values())
    rec("H30_2049_elements_exact", total == 2049, {"total": total})
    rec("H31_rho_persisted_1", V3_PARAM_SHAPES["v3_raw_temporal_rho"] == (1,),
        {"persisted_shape": list(V3_PARAM_SHAPES["v3_raw_temporal_rho"])})
    import importlib.util
    spec = importlib.util.spec_from_file_location("sp",
        str(ROOT / "src/dhbcp_pv/inference/variational_param_persistence.py"))
    sp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(sp)
    rng = np.random.RandomState(20260908)
    toy_v3 = {
        "v3_loc": rng.normal(0, 1, 708),
        "v3_diag_log_scale": rng.normal(-0.5, 0.1, 708),
        "v3_F_count_plus_initial": rng.normal(0, 0.1, (120, 4)),
        "v3_F_dynamic_scale": rng.normal(0, 0.1, (16, 4)),
        "v3_F_seriousness": rng.normal(0, 0.1, (22, 4)),
        "v3_raw_temporal_rho": np.array([0.2]),
    }
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        npz = td / "v3.npz"
        man = td / "v3m.json"
        ck = sp.validate_params_roundtrip(toy_v3, npz, man)
        rec_ok = sp.recover_fitted_guide(toy_v3, V3_PARAM_SHAPES)["recoverable"]
        rec("H32_serializer_roundtrip_pass", bool(ck["PASS"]) and bool(rec_ok),
            {"roundtrip_PASS": ck["PASS"], "recover": rec_ok})

    # H33-H35: preflight zero SVI / no RUN_STARTED / no real auth
    probe_ok = bool(counters is None or (counters["init"] == 0 and counters["update"] == 0
                                         and counters["stable_update"] == 0))
    rec("H33_preflight_svi_calls_zero", probe_ok,
        {"counters": counters or {"init": 0, "update": 0, "stable_update": 0}})
    rec("H34_preflight_run_started_zero", not identity_consumed(),
        {"consumed": identity_consumed()})
    auth_real = V3_RUNS.parent / "authorizations" / "V3_G1_CANARY_AUTHORIZATION.json"
    rec("H35_no_real_authorization_created", not auth_real.exists(),
        {"auth_exists": auth_real.exists()})

    # H36-H37: no batch / no other identity
    main_fn = next(n for n in ast.walk(ast.parse(src))
                   if isinstance(n, ast.FunctionDef) and n.name == "main")
    has_batch_choice = any(
        any(isinstance(e, ast.Constant) and e.value == "batch" for e in c.elts)
        for c in ast.walk(main_fn) if isinstance(c, ast.List))
    rec("H36_no_batch", not has_batch_choice, {"batch_present": has_batch_choice})
    other_ident = any(
        ("V3_V3_ARM_P" in line and "seed1001" not in line) or
        ("_seed" in line and "seed1001" not in line and "_t12" in line)
        for line in src.split("def dummy_model")[0].splitlines()
        if "V3_V3_ARM" in line)
    rec("H37_no_other_identity_executable", not other_ident,
        {"other_identity_lines": other_ident})

    # H38-H40: forbidden references
    bad_pca = "failed" + " Phase3C4 " + "PCA"
    rec("H38_no_failed_pca", bad_pca not in src, {"pca": bad_pca in src})
    pats = {"numpyro." + "sample(": "H39a", "importance" + "(": "H39b",
            "NUTS(": "H39c", "HMC(": "H39d", "MCMC(": "H39e"}
    h39_hits = [v for p, v in pats.items() if p in prod_zone]
    rec("H39_no_posterior_sampling_is_mcmc", not h39_hits, {"hits": h39_hits})
    zr = json.loads((ROOT / FROZEN_CHAIN["42ZR"][0]).read_text(encoding="utf-8"))
    rec("H40_no_g2_g3", zr.get("G3_AUTHORIZED") is False,
        {"42ZR_G3": zr.get("G3_AUTHORIZED")})

    # H41-H43: scientific sources unchanged
    rec("H41_scientific_model_unchanged", chain["results"]["model"]["ok"],
        {"live": chain["results"]["model"]["live"]})
    rec("H42_v3_guide_unchanged", chain["results"]["guide_v3"]["ok"],
        {"live": chain["results"]["guide_v3"]["live"]})
    rec("H43_serializer_unchanged", chain["results"]["serializer"]["ok"],
        {"live": chain["results"]["serializer"]["live"]})

    # H44: canary still unconsumed after preflight
    rec("H44_canary_still_unconsumed", not identity_consumed(),
        {"consumed": identity_consumed()})

    ok = all(c["ok"] for c in checks.values())
    return {"ok": ok, "checks": checks, "chain": chain["results"], "ast": astp,
            "terminal_map": TERMINAL_VALIDITY_MAP}


def cmd_preflight() -> int:
    counters, orig = _install_svi_probe()
    try:
        res = run_preflight(counters=counters)
    finally:
        _restore_svi(orig)
    classification = ("V3_G1_CANARY_TERMINAL_SEMANTICS_PREFLIGHT_PASS" if res["ok"]
                      else "V3_G1_CANARY_TERMINAL_SEMANTICS_PREFLIGHT_FAIL")
    payload = {
        "artifact_id": "43A_V3_G1_CANARY_TERMINAL_SEMANTICS_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v_v3",
        "mode": "V3 G1 CANARY TERMINAL SEMANTICS PREFLIGHT (H1..H44; dynamic "
                "terminal-semantics oracles; no SVI, no RUN_STARTED, no canary)",
        "classification": classification,
        "checks": {k: v["ok"] for k, v in res["checks"].items()},
        "check_details": res["checks"],
        "ast_canary_path": res["ast"],
        "terminal_validity_map": res["terminal_map"],
        "sha_chain": res["chain"],
        "svi_runtime_probe": counters,
        "flags": {
            "CANARY_EXECUTED": False,
            "RUN_STARTED_CREATED": False,
            "V3_IDENTITIES_CONSUMED": 0,
            "SVI_USED": False,
            "G3_AUTHORIZED": False,
            "REAL_AUTHORIZATION_CREATED": False,
        },
        "canary_identity": CANARY_IDENTITY["identity"],
        "final_state": ("V3_G1_CANARY_TERMINAL_SEMANTICS_PREFLIGHT_PASS" if res["ok"]
                        else "V3_G1_CANARY_TERMINAL_SEMANTICS_PREFLIGHT_FAIL"),
    }
    out_path = PREFLIGHT_OUT / "43A_V3_G1_CANARY_TERMINAL_SEMANTICS_PREFLIGHT.json"
    atomic_write_json(out_path, payload)
    md = ["# 43A — V3 G1 Canary Terminal Semantics Preflight", "",
          f"Generated: {utc_now()}  |  Mode: H1..H44 (dynamic; no SVI / RUN_STARTED / canary)",
          "", f"**Classification: {classification}**", "", "| Check | Result |", "|---|---|"]
    for k, v in payload["checks"].items():
        md.append(f"| {k} | {'PASS' if v else 'FAIL'} |")
    md += ["", "## SVI runtime probe", ""]
    md.append(f"- init={counters['init']} update={counters['update']} stable_update={counters['stable_update']}")
    md += ["", "## Recognized terminal map", ""]
    for k, v in TERMINAL_VALIDITY_MAP.items():
        md.append(f"- {k} -> VALID={v}")
    md += ["", "## AST canary-path inspection", ""]
    for k, v in res["ast"].items():
        md.append(f"- {k} = {v}")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in res["chain"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", "## Flags", "", "| Flag | Value |", "|---|---|"]
    for k, v in payload["flags"].items():
        md.append(f"| {k} | {v} |")
    md += ["", f"## Final state: **{payload['final_state']}**",
           f"- canary identity = {payload['canary_identity']}"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", "PASS" if res["ok"] else "FAIL")
    return 0 if res["ok"] else 2


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V3 G1 canary execution runner (terminal semantics final)")
    ap.add_argument("--mode", required=True, choices=["preflight", "canary"])
    args = ap.parse_args(argv)
    if args.mode == "preflight":
        return cmd_preflight()
    return cmd_canary()


if __name__ == "__main__":
    sys.exit(main())
