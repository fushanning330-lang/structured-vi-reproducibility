"""Phase3C.4V V3 — DETERMINISTIC G0 PREFLIGHT (scripts/81).

Deterministic implementation tests for the V3_LOCAL_BLOCK_AR1_NO_SHARED guide
(42ZO frozen mathematical specification; 42ZN architecture decision).
NO SVI optimization, NO posterior sampling, NO importance sampling,
NO NUTS/HMC/MCMC, NO random Monte Carlo. Fixed deterministic toy parameters
only.

Checks V3G0.1 .. V3G0.36 (42ZP classification
V3_LOCAL_BLOCK_AR1_DETERMINISTIC_G0_PREFLIGHT_PASS requires ALL PASS).
"""

import hashlib
import json
import re
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
from numpyro import distributions as dist
from numpyro import handlers
from numpyro.distributions import constraints
from numpyro.infer import init_to_median

jax.config.update("jax_enable_x64", True)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dhbcp_pv.inference.v3_local_block_ar1_guide import (  # noqa: E402
    V3LocalBlockAR1AutoGuide,
    V3LocalBlockAR1Distribution,
    _rho_from_raw,
    _effective_log_scale,
    _apply_r_inv,
    _r11,
    _block_index_arrays,
    _LATENT_DIM,
    _N_PAIRS,
    _T_LEN,
    LOG_SCALE_ABS_MAX,
)
from dhbcp_pv.inference.v2_shared_ar1_temporal_guide_g0fix import (  # noqa: E402
    V2SharedAR1TemporalAutoGuide,
)

PREFLIGHT_OUT = ROOT / "results/phase3c4v/preflight"

V3_PARAM_SHAPES = {
    "v3_loc": (708,),
    "v3_diag_log_scale": (708,),
    "v3_F_count_plus_initial": (120, 4),
    "v3_F_dynamic_scale": (16, 4),
    "v3_F_seriousness": (22, 4),
    "v3_raw_temporal_rho": (1,),
}
V3_TOTAL = 2049

FROZEN_CHAIN = {
    "42ZN": ("results/phase3c4v_v3/audit/42ZN_POST_G2_NEXT_ARCHITECTURE_HUMAN_DECISION.json",
             "cba153e8d60c97b2a089116478606d189c97c9727e567dfeec89f7a15714ea5a"),
    "42ZO": ("results/phase3c4v_v3/protocol/42ZO_V3_LOCAL_BLOCK_AR1_MATHEMATICAL_SPECIFICATION_FREEZE.json",
             "03d490ee31f6d6f823f81f31a71b4865da4896c0c10f640c110430faa43406b6"),
    "42ZJ": ("results/phase3c4v_v2/audit/42ZJ_V2_G2_CORRECTED_HUMAN_ADJUDICATION.json",
             "52cfb5afeb37735d0bdbc9e89bb87430e1cb65ceb50aeb46718caf4f13b013e2"),
    "42ZM": ("results/phase3c4v_v2/post_g2_component_diagnostic/42ZM_V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_EVIDENCE.json",
             "9d508673ec9ee8f562bd200fd3b56ceb9a4dc2f4cebc86a027dcc1f2da8e87f6"),
    "guide_v2": ("src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py",
                 "51e23a5c68d34d1d164b20a362cffc4667dedb39da6324426a6674783fa40fdb"),
    "model": ("src/dhbcp_pv/models/full_joint_model.py",
              "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"),
    "serializer": ("src/dhbcp_pv/inference/variational_param_persistence.py",
                   "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"),
}


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def verify_frozen_chain() -> dict:
    results = {}
    ok = True
    for name, (rel, expected) in FROZEN_CHAIN.items():
        p = ROOT / rel
        if not p.exists():
            results[name] = {"ok": False, "live": None, "expected": expected}
            ok = False
            continue
        live = sha256(p)
        good = live == expected
        ok = ok and good
        results[name] = {"ok": good, "live": live, "expected": expected}
    return {"ok": ok, "results": results}


def dummy_model():
    numpyro.sample("latent", dist.Normal(jnp.zeros(_LATENT_DIM), 1.0).to_event(1))


# ---------------------------------------------------------------------------
# Deterministic toy parameter builder (dense-oracle compatible).
# ---------------------------------------------------------------------------
def toy_params(rho_raw: float = 0.2, seed: int = 20260830):
    rng = np.random.RandomState(seed)
    count_idx = np.asarray(_block_index_arrays(_LATENT_DIM)["count_plus_initial"])
    dyn_idx = np.asarray(_block_index_arrays(_LATENT_DIM)["dynamic_scale"])
    ser_idx = np.asarray(_block_index_arrays(_LATENT_DIM)["seriousness"])
    return {
        "loc": jnp.asarray(rng.normal(0, 1, _LATENT_DIM)),
        "diag_log_scale": jnp.asarray(rng.normal(-0.5, 0.1, _LATENT_DIM)),
        "F_count": jnp.asarray(rng.normal(0, 0.1, (count_idx.size, 4))),
        "F_dynamic": jnp.asarray(rng.normal(0, 0.1, (dyn_idx.size, 4))),
        "F_serious": jnp.asarray(rng.normal(0, 0.1, (ser_idx.size, 4))),
        "raw_rho": jnp.asarray(rho_raw),
    }


def build_dense_sigma(tp) -> tuple:
    """Analytic dense Sigma = B_AR1 + U_local U_local^T (dense oracle reference)."""
    s = jnp.exp(_effective_log_scale(tp["diag_log_scale"]))
    rho = _rho_from_raw(tp["raw_rho"])
    U = V3LocalBlockAR1AutoGuide._build_u_local(tp["F_count"], tp["F_dynamic"], tp["F_serious"])
    B = jnp.zeros((_LATENT_DIM, _LATENT_DIM))
    B = B.at[jnp.arange(158), jnp.arange(158)].set(s[0:158] ** 2)
    k = jnp.arange(_T_LEN)
    R11 = rho ** jnp.abs(k[:, None] - k[None, :])
    for p in range(_N_PAIRS):
        base = 158 + p * _T_LEN
        S = jnp.diag(s[base:base + _T_LEN])
        B = B.at[base:base + _T_LEN, base:base + _T_LEN].set(S @ R11 @ S)
    Sigma = B + U @ U.T
    return Sigma, U, s, rho, B


# ---------------------------------------------------------------------------
# Preflight V3G0.1 .. V3G0.36
# ---------------------------------------------------------------------------
def _install_svi_probe():
    import numpyro.infer as ni
    counters = {"init": 0, "update": 0, "stable_update": 0}
    orig = {}
    for meth, key in (("init", "init"), ("update", "update"), ("stable_update", "stable_update")):
        orig[meth] = getattr(ni.SVI, meth)

        def make_wrap(k):
            def wrap(self, *a, **kw):
                counters[k] += 1
                return orig[k](self, *a, **kw)
            return wrap
        setattr(ni.SVI, meth, make_wrap(key))
    return counters, orig


def _restore_svi(orig) -> None:
    import numpyro.infer as ni
    for meth, fn in orig.items():
        setattr(ni.SVI, meth, fn)


def run_preflight(counters: dict | None = None) -> dict:
    checks = {}
    rec = lambda n, ok, d: checks.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731
    src = Path(__file__).read_text(encoding="utf-8")
    # production zone = everything except the dummy_model oracle definition
    prod_zone = src.split("def dummy_model")[0] + src.split("def run_preflight")[1]

    # ---- instantiate V3 guide once (prototype + params) ----
    seed = 1001
    master = jax.random.PRNGKey(seed)
    prototype_key, factor_init_key, svi_init_key, svi_runtime_key = jax.random.split(master, 4)
    g3 = V3LocalBlockAR1AutoGuide(dummy_model, init_loc_fn=init_to_median(num_samples=5),
                                  factor_init_key=factor_init_key)
    with handlers.seed(rng_seed=seed):
        g3()
    with handlers.seed(rng_seed=seed), handlers.trace() as tr:
        d3 = g3._get_posterior()
    names = sorted(k for k in tr if k.startswith("v3_"))
    vals = {n: tr[n]["value"] for n in names}

    # V3G0.1 latent dim
    rec("V3G0.1_latent_dim_708", _LATENT_DIM == 708 and g3.latent_dim == 708,
        {"latent_dim": g3.latent_dim})

    # V3G0.2 exact six parameter names
    expected_names = sorted(V3_PARAM_SHAPES.keys())
    rec("V3G0.2_exact_six_parameter_names", names == expected_names,
        {"names": names, "expected": expected_names})

    # V3G0.3 exact parameter shapes
    shapes = {n: tuple(v.shape) for n, v in vals.items()}
    shapes_ok = all(tuple(v.shape) == V3_PARAM_SHAPES[n] or
                    (n == "v3_raw_temporal_rho" and jnp.ndim(v) == 0)
                    for n, v in vals.items())
    rec("V3G0.3_exact_parameter_shapes", shapes_ok,
        {"shapes": shapes, "expected": V3_PARAM_SHAPES})

    # V3G0.4 total elements 2049
    total = sum(int(np.prod(np.shape(v))) for v in vals.values())
    rec("V3G0.4_total_parameter_elements_2049", total == V3_TOTAL,
        {"total": total, "expected": V3_TOTAL})

    # V3G0.5 U_local shape 708x12
    tp = toy_params()
    U = V3LocalBlockAR1AutoGuide._build_u_local(tp["F_count"], tp["F_dynamic"], tp["F_serious"])
    rec("V3G0.5_U_local_shape_708x12", tuple(U.shape) == (708, 12), {"shape": tuple(U.shape)})

    # V3G0.6-8 masks exact
    idx = {name: np.asarray(jnp.asarray(a)) for name, a in _block_index_arrays(_LATENT_DIM).items()}
    count_ok = (idx["count_plus_initial"].size == 120
                and np.array_equal(np.sort(idx["count_plus_initial"]),
                                   np.concatenate([np.arange(0, 70), np.arange(108, 158)])))
    dyn_ok = (idx["dynamic_scale"].size == 16
              and np.array_equal(np.sort(idx["dynamic_scale"]), np.arange(70, 86)))
    ser_ok = (idx["seriousness"].size == 22
              and np.array_equal(np.sort(idx["seriousness"]), np.arange(86, 108)))
    rec("V3G0.6_count_mask_exact", bool(count_ok), {"count_indices": idx["count_plus_initial"].tolist()})
    rec("V3G0.7_dynamic_mask_exact", bool(dyn_ok), {"dynamic_indices": idx["dynamic_scale"].tolist()})
    rec("V3G0.8_seriousness_mask_exact", bool(ser_ok), {"seriousness_indices": idx["seriousness"].tolist()})

    # V3G0.9 no shared factor parameter (source + params; dynamic assembly)
    shared_pat = "v3_F_" + "shared"
    no_shared_src = shared_pat not in src
    no_shared_params = shared_pat not in names
    rec("V3G0.9_no_shared_factor_parameter", bool(no_shared_src and no_shared_params),
        {"in_params": shared_pat in names, "in_source": shared_pat in src})

    # V3G0.10 no temporal low-rank factor (U temporal rows all zero)
    temp_rows = U[158:708, :]
    rec("V3G0.10_no_temporal_lowrank_factor",
        float(jnp.max(jnp.abs(temp_rows))) == 0.0,
        {"max_abs_temporal_U": float(jnp.max(jnp.abs(temp_rows)))})

    # V3G0.11 rho transform exact
    raw_t = jnp.array(0.3)
    rho_v = _rho_from_raw(raw_t)
    rec("V3G0.11_rho_transform_exact",
        abs(float(rho_v) - 0.99 * float(jnp.tanh(raw_t))) < 1e-15,
        {"rho": float(rho_v), "expected": 0.99 * float(jnp.tanh(raw_t))})

    # V3G0.12 log-scale clip exact +/-300
    eff = _effective_log_scale(jnp.array([-400.0, -300.0, -100.0, 0.0, 100.0, 300.0, 400.0]))
    rec("V3G0.12_log_scale_clip_exact",
        float(jnp.min(eff)) >= -LOG_SCALE_ABS_MAX and float(jnp.max(eff)) <= LOG_SCALE_ABS_MAX
        and float(eff[0]) == -300.0 and float(eff[-1]) == 300.0,
        {"eff": [float(e) for e in eff], "abs_max": LOG_SCALE_ABS_MAX})

    # V3G0.13 AR1 analytic inverse oracle
    rho_a = _rho_from_raw(jnp.array(0.2))
    R11 = np.asarray(_r11(rho_a))
    w = np.random.RandomState(5).normal(0, 1, (50, 11))
    w_j = jnp.asarray(w)
    analytic = np.asarray(_apply_r_inv(w_j, rho_a))
    dense = np.linalg.solve(R11, w).reshape(50, 11) if False else np.linalg.solve(R11, w[:, 0, None])[..., 0] if False else None
    # vectorized dense: apply R11^-1 per block row
    dense_v = np.stack([np.linalg.solve(R11, w[i]) for i in range(50)], axis=0)
    diff = float(np.max(np.abs(analytic - dense_v)))
    rec("V3G0.13_ar1_analytic_inverse_oracle", diff < 1e-9, {"max_diff": diff})

    # V3G0.14 AR1 analytic logdet oracle
    Sigma_d, U_d, s_d, rho_d, B_d = build_dense_sigma(toy_params())
    logdet_analytic = float(2.0 * jnp.sum(_effective_log_scale(toy_params()["diag_log_scale"]))
                            + _N_PAIRS * (_T_LEN - 1) * jnp.log1p(-rho_d ** 2))
    logdet_dense = float(jnp.linalg.slogdet(B_d).logabsdet)
    rec("V3G0.14_ar1_analytic_logdet_oracle", abs(logdet_analytic - logdet_dense) < 1e-6,
        {"analytic": logdet_analytic, "dense": logdet_dense, "diff": abs(logdet_analytic - logdet_dense)})

    # V3G0.15 sampling covariance deterministic oracle: L_B L_B^T + U U^T = Sigma
    # L_B = blockdiag(diag(s[0:158]), L_1..L_50) with L_p = chol(S_p R11 S_p)
    s_full = np.asarray(jnp.exp(_effective_log_scale(toy_params()["diag_log_scale"])))
    rho_d2 = float(rho_d)
    L_B = np.zeros((708, 708))
    L_B[np.arange(158), np.arange(158)] = s_full[0:158]
    kk = np.arange(11)
    R11d = rho_d2 ** np.abs(kk[:, None] - kk[None, :])
    for p in range(50):
        base = 158 + p * 11
        Sp = np.diag(s_full[base:base + 11])
        Lp = np.linalg.cholesky(Sp @ R11d @ Sp)
        L_B[base:base + 11, base:base + 11] = Lp
    LB_LBT = L_B @ L_B.T
    U_d_np = np.asarray(U_d)
    recon = LB_LBT + U_d_np @ U_d_np.T
    sig_np = np.asarray(Sigma_d)
    diff15 = float(np.max(np.abs(recon - sig_np)))
    rec("V3G0.15_sampling_covariance_deterministic_oracle", diff15 < 1e-8,
        {"max_diff_LB_LBT_plus_UUT_vs_Sigma": diff15})

    # V3G0.16 custom log_prob vs dense 708 Gaussian oracle
    z_t = jnp.asarray(np.random.RandomState(11).normal(0, 1, 708))
    dist_c = V3LocalBlockAR1Distribution(tp["loc"], tp["diag_log_scale"], U, tp["raw_rho"])
    lp_custom = float(dist_c.log_prob(z_t))
    Sigma_full = np.asarray(Sigma_d) + 0 * np.eye(708)
    mu_np = np.asarray(tp["loc"])
    z_np = np.asarray(z_t)
    lp_dense = float(dist.MultivariateNormal(tp["loc"], covariance_matrix=Sigma_d).log_prob(z_t))
    diff16 = abs(lp_custom - lp_dense)
    rec("V3G0.16_custom_log_prob_vs_dense_oracle", diff16 < 1e-5,
        {"custom": lp_custom, "dense": lp_dense, "diff": diff16})

    # V3G0.17 Woodbury logdet vs dense oracle (same toy distribution dist_c)
    binv_u17 = dist_c._b_inv_apply(U)
    K17 = jnp.eye(12) + U.T @ binv_u17
    Lk17 = jnp.linalg.cholesky(K17)
    logdet_wood = float(2.0 * jnp.sum(jnp.log(jnp.diag(Lk17))))
    logdet_dense_full = float(jnp.linalg.slogdet(Sigma_d).logabsdet)
    logdet_b_full = float(2.0 * jnp.sum(_effective_log_scale(tp["diag_log_scale"]))
                          + _N_PAIRS * (_T_LEN - 1) * jnp.log1p(-rho_d ** 2))
    logdet_total = logdet_b_full + logdet_wood
    diff17 = abs(logdet_total - logdet_dense_full)
    rec("V3G0.17_woodbury_logdet_vs_dense_oracle", diff17 < 1e-5,
        {"woodbury_total": logdet_total, "dense": logdet_dense_full, "diff": diff17})

    # V3G0.18 Woodbury quadratic vs dense oracle (same toy distribution)
    binv_delta = dist_c._b_inv_apply(z_t - tp["loc"])
    v18 = jnp.einsum("ij,...i->...j", U, binv_delta)
    x18 = dist_c._woodbury_solve(Lk17, v18)
    quad_wood = float(jnp.sum((z_t - tp["loc"]) * binv_delta, axis=-1) - jnp.sum(v18 * x18, axis=-1))
    quad_dense = float((z_np - mu_np) @ np.linalg.solve(Sigma_full, (z_np - mu_np)))
    diff18 = abs(quad_wood - quad_dense)
    rec("V3G0.18_woodbury_quadratic_vs_dense_oracle", diff18 < 1e-5,
        {"woodbury_quad": quad_wood, "dense_quad": quad_dense, "diff": diff18})

    # V3G0.19 K is 12x12 and PD
    K19 = np.asarray(K17)
    ev = np.linalg.eigvalsh(K19)
    rec("V3G0.19_K_12x12_PD", K19.shape == (12, 12) and float(ev[0]) > 0,
        {"shape": K19.shape, "min_eig": float(ev[0])})

    # V3G0.20 no explicit dense 708 inverse
    inv_hits = [p for p in ("jnp.linalg." + "inv(", "np.linalg." + "inv(", "linalg." + "inv(") if p in prod_zone]
    rec("V3G0.20_no_explicit_dense708_inverse", not inv_hits, {"hits": inv_hits})

    # V3G0.21 support transform forward/inverse roundtrip
    from numpyro.distributions.transforms import biject_to
    tf = biject_to(constraints.real_vector)
    v21 = jnp.asarray(np.random.RandomState(21).normal(0, 1, 708))
    v21_rt = tf(tf.inv(v21))
    diff21 = float(jnp.max(jnp.abs(v21_rt - v21)))
    rec("V3G0.21_support_transform_roundtrip", diff21 < 1e-12, {"max_diff": diff21})

    # V3G0.22 pack/unpack/repack exact (via guide._unpack_latent UnpackTransform;
    # pack side bound with the frozen shape_dict — 42I G0C.6 pattern)
    from numpyro.infer.autoguide import _ravel_dict, _ravel_dict_with_shape_dict
    lat = jnp.asarray(np.random.RandomState(22).normal(0, 1, 708))
    unpacked = g3._unpack_latent(lat)
    _, frozen_shape_dict = _ravel_dict(g3._init_locs)

    def repack(unpacked_dict):
        return _ravel_dict_with_shape_dict(unpacked_dict, frozen_shape_dict)

    repacked = repack(unpacked)
    diff22 = float(jnp.max(jnp.abs(repacked - lat)))
    rec("V3G0.22_pack_unpack_repack_exact", diff22 < 1e-12, {"max_diff": diff22})

    # V3G0.23 finite gradients through all six params
    grads_ok = True
    grad_details = {}
    grad_fn = jax.grad(lambda p: d3.log_prob(z_t))

    def make_dist_from(p_name, value):
        d_ = dict(vals)
        d_[p_name] = value
        Uu = V3LocalBlockAR1AutoGuide._build_u_local(
            d_["v3_F_count_plus_initial"], d_["v3_F_dynamic_scale"], d_["v3_F_seriousness"])
        return V3LocalBlockAR1Distribution(d_["v3_loc"], d_["v3_diag_log_scale"], Uu,
                                           jnp.reshape(d_["v3_raw_temporal_rho"], ()))

    for p_name in expected_names:
        base_val = vals[p_name]
        gv = jax.grad(lambda x: make_dist_from(p_name, x).log_prob(z_t))(base_val)
        fin = bool(jnp.all(jnp.isfinite(gv)))
        grads_ok = grads_ok and fin
        grad_details[p_name] = {"finite": fin, "max_abs": float(jnp.max(jnp.abs(gv))) if gv.size else float(jnp.abs(gv))}
    rec("V3G0.23_finite_gradients_all_six_params", grads_ok, grad_details)

    # V3G0.24 scale extreme guard values
    effs = [-1000.0, -400.0, -300.0, -100.0, float(np.log(0.1)), 0.0, 100.0, 300.0, 400.0, 1000.0]
    scale_ok = True
    scale_details = []
    for e in effs:
        eff = float(jnp.clip(e, -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))
        s = float(jnp.exp(eff))
        inv_s = float(jnp.exp(-eff))
        s2 = s * s
        inv_s2 = inv_s * inv_s
        fin = all(np.isfinite(x) for x in (s, inv_s, s2, inv_s2))
        scale_ok = scale_ok and fin
        scale_details.append({"raw": e, "eff": eff, "s": s, "inv_s": inv_s,
                              "s2": s2, "inv_s2": inv_s2, "finite": fin})
    rec("V3G0.24_scale_extreme_guard_values", scale_ok, {"values": scale_details})

    # V3G0.25 rho extreme raw values |rho| <= .99
    raws = [-100.0, -20.0, -5.0, 0.0, 5.0, 20.0, 100.0]
    rho_ok = True
    rho_details = []
    for r in raws:
        rv = float(_rho_from_raw(jnp.array(r)))
        okv = abs(rv) <= 0.99
        rho_ok = rho_ok and okv
        rho_details.append({"raw": r, "rho": rv, "|rho|<=.99": okv})
    rec("V3G0.25_rho_extreme_raw_values", rho_ok, {"values": rho_details})

    # V3G0.26 x64 required
    rec("V3G0.26_x64_required",
        jax.config.jax_enable_x64 and np.dtype(np.float64).itemsize == 8,
        {"x64": jax.config.jax_enable_x64})

    # V3G0.27 RNG master split exact (4-way, deterministic, disjoint)
    m2 = jax.random.split(master, 4)
    keys_equal = all(bool(jnp.array_equal(m2[i], [prototype_key, factor_init_key, svi_init_key, svi_runtime_key][i])) for i in range(4))
    disjoint = len({bytes(np.asarray(m2[i])) for i in range(4)}) == 4
    rec("V3G0.27_rng_master_split_exact", bool(keys_equal and disjoint),
        {"split_order": ["prototype_key", "factor_init_key", "svi_init_key", "svi_runtime_key"]})

    # V3G0.28 factor five-way split exact
    fsub = jax.random.split(factor_init_key, 5)
    fsub_ok = (len(set(bytes(np.asarray(fsub[i])) for i in range(5))) == 5
               and bytes(np.asarray(fsub[0])) != bytes(np.asarray(fsub[1])))
    rec("V3G0.28_factor_five_way_split_exact", bool(fsub_ok),
        {"order": ["shared_reserved_unused", "count_plus_initial", "dynamic_scale",
                   "seriousness", "temporal_reserved_unused"]})

    # V3G0.29 V3 local factor init == V2 same-subkey init arrays
    g2 = V2SharedAR1TemporalAutoGuide(dummy_model, init_loc_fn=init_to_median(num_samples=5),
                                      factor_init_key=factor_init_key)
    with handlers.seed(rng_seed=seed):
        g2()
    with handlers.seed(rng_seed=seed), handlers.trace() as tr2:
        g2._get_posterior()
    parity_ok = True
    parity_detail = {}
    for n in ["v3_F_count_plus_initial", "v3_F_dynamic_scale", "v3_F_seriousness"]:
        v3a = np.asarray(vals[n])
        v2a = np.asarray(tr2["v2_" + n[3:]]["value"])
        same = np.array_equal(v3a, v2a)
        parity_ok = parity_ok and same
        parity_detail[n] = {"exact_equal": bool(same),
                            "maxdiff": float(np.max(np.abs(v3a - v2a)))}
    rec("V3G0.29_v3_v2_same_subkey_factor_init", parity_ok, parity_detail)

    # V3G0.30 serializer compatibility / roundtrip PASS
    import importlib.util
    spec = importlib.util.spec_from_file_location("sp",
        str(ROOT / "src/dhbcp_pv/inference/variational_param_persistence.py"))
    sp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(sp)
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        npz = td / "v3_params.npz"
        man = td / "v3_manifest.json"
        params_np = {n: np.asarray(v) for n, v in vals.items()}
        params_np["v3_raw_temporal_rho"] = np.asarray(vals["v3_raw_temporal_rho"]).reshape(1)
        ck = sp.validate_params_roundtrip(params_np, npz, man)
        rec_ok = sp.recover_fitted_guide(params_np, V3_PARAM_SHAPES)["recoverable"]
        rec("V3G0.30_serializer_compatibility_roundtrip", bool(ck["PASS"]) and bool(rec_ok),
            {"roundtrip_PASS": ck["PASS"], "recover_fitted_guide": rec_ok})

    # V3G0.31 scientific model SHA unchanged
    chain = verify_frozen_chain()
    rec("V3G0.31_scientific_model_sha_unchanged", chain["results"]["model"]["ok"],
        {"live": chain["results"]["model"]["live"]})

    # V3G0.32 V2 guide SHA unchanged
    rec("V3G0.32_v2_guide_sha_unchanged", chain["results"]["guide_v2"]["ok"],
        {"live": chain["results"]["guide_v2"]["live"]})

    # V3G0.33 no failed PCA
    bad_pca = "failed" + " Phase3C4 " + "PCA"
    rec("V3G0.33_no_failed_pca", bad_pca not in src, {"pca_ref_present": bad_pca in src})

    # V3G0.34 no SVI optimization calls
    probe_ok = bool(counters is None or (counters["init"] == 0 and counters["update"] == 0
                                         and counters["stable_update"] == 0))
    rec("V3G0.34_no_svi_optimization_calls", probe_ok,
        {"counters": counters or {"init": 0, "update": 0, "stable_update": 0}})

    # V3G0.35 no posterior sampling / IS / MCMC (source scan, prod zone)
    pats = {"numpyro." + "sample(": "sample", "importance" + "(": "importance",
            "NUTS(": "NUTS", "HMC(": "HMC", "MCMC(": "MCMC"}
    hits35 = [v for p, v in pats.items() if p in prod_zone]
    rec("V3G0.35_no_posterior_sampling_is_mcmc", not hits35, {"hits": hits35})

    # V3G0.36 no G3 execution
    zj = json.loads((ROOT / FROZEN_CHAIN["42ZJ"][0]).read_text(encoding="utf-8"))
    zo = json.loads((ROOT / FROZEN_CHAIN["42ZO"][0]).read_text(encoding="utf-8"))
    g3_auth = (zj.get("G3_AUTHORIZED") is False) and (zo.get("G3_AUTHORIZED") is False)
    rec("V3G0.36_no_g3_execution", bool(g3_auth),
        {"42ZJ_G3_AUTHORIZED": zj.get("G3_AUTHORIZED"), "42ZO_G3_AUTHORIZED": zo.get("G3_AUTHORIZED")})

    ok = all(c["ok"] for c in checks.values())
    return {"ok": ok, "checks": checks, "chain": chain["results"]}


def cmd_preflight() -> int:
    counters, orig = _install_svi_probe()
    try:
        res = run_preflight(counters=counters)
    finally:
        _restore_svi(orig)
    classification = ("V3_LOCAL_BLOCK_AR1_DETERMINISTIC_G0_PREFLIGHT_PASS" if res["ok"]
                      else "V3_LOCAL_BLOCK_AR1_DETERMINISTIC_G0_PREFLIGHT_FAIL")
    payload = {
        "artifact_id": "42ZP_V3_LOCAL_BLOCK_AR1_DETERMINISTIC_G0_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v_v3",
        "mode": "V3 LOCAL-BLOCK AR1 DETERMINISTIC G0 PREFLIGHT (V3G0.1..V3G0.36; "
                "no SVI, no optimization, no sampling)",
        "classification": classification,
        "checks": {k: v["ok"] for k, v in res["checks"].items()},
        "check_details": res["checks"],
        "sha_chain": res["chain"],
        "svi_runtime_probe": counters,
        "flags": {
            "V3_OPTIMIZATION_AUTHORIZED": False,
            "G3_AUTHORIZED": False,
            "V3_OPTIMIZATION_EXECUTED": False,
            "V3_G1_RUN_STARTED_CREATED": False,
            "SVI_USED": False,
            "POSTERIOR_SAMPLING_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "NUTS_HMC_MCMC_USED": False,
            "SCIENTIFIC_TARGET_MODIFIED": False,
            "V2_GUIDE_MODIFIED": False,
        },
        "final_state": ("V3_IMPLEMENTATION_G0_PASS" if res["ok"]
                        else "V3_IMPLEMENTATION_G0_FAIL"),
        "waiting_for": ("STOP_WAITING_FOR_HUMAN_V3_OPTIMIZATION_PROTOCOL_AUTHORIZATION" if res["ok"]
                        else "STOP_WAITING_FOR_HUMAN_CORRECTIVE_REVIEW"),
    }
    out_path = PREFLIGHT_OUT / "42ZP_V3_LOCAL_BLOCK_AR1_DETERMINISTIC_G0_PREFLIGHT.json"
    atomic_write_json(out_path, payload)
    md = ["# 42ZP — V3 Local-Block AR1 Deterministic G0 Preflight", "",
          f"Generated: {utc_now()}  |  Mode: V3 G0 (V3G0.1..V3G0.36; no SVI / optimization / sampling)",
          "", f"**Classification: {classification}**", "", "| Check | Result |", "|---|---|"]
    for k, v in payload["checks"].items():
        md.append(f"| {k} | {'PASS' if v else 'FAIL'} |")
    md += ["", "## SVI runtime probe", ""]
    md.append(f"- init={counters['init']} update={counters['update']} stable_update={counters['stable_update']}")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in res["chain"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", f"## Final state: **{payload['final_state']}**", f"- {payload['waiting_for']}"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", "PASS" if res["ok"] else "FAIL")
    return 0 if res["ok"] else 2


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="V3 deterministic G0 preflight")
    ap.add_argument("--mode", required=True, choices=["preflight"])
    args = ap.parse_args(argv)
    return cmd_preflight()


if __name__ == "__main__":
    sys.exit(main())
