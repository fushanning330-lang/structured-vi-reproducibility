"""Phase3C.4V — parameter-persistent variational validation runner (scripts/64).

FIX_002: full conformance with the frozen scripts/61 execution protocol:
  * Trace_ELBO(num_particles=entry["num_particles"])  (real particle binding)
  * the SAME frozen training loop (2000 steps, ckpt 100, min-before-ES 500,
    rel tol 1e-4, patience 5, stable_update, full instrumentation)
  * ONE-SHOT RUN_STARTED guard written BEFORE SVI.init, refuse rerun
  * prototype setup via `handlers.seed(rng_seed=prototype_key)` + `_setup_prototype`
  * frozen 25B RNG keys (uint32) for all 5 seeds
  * the same G1-style result schema (old diagnostics preserved) PLUS new
    parameter-persistence fields
  * parameter persistence ordering: final_state -> get_params -> save npz ->
    save manifest -> reload -> exact roundtrip -> schema compat ->
    PARAMETER_PERSISTENCE_VALIDATION.json -> diagnostic artifacts -> result.json

FIX_003 (terminal artifact order + failure-status priority):
  * strict on-disk write order: PARAMETER_PERSISTENCE_VALIDATION.json ->
    training_history.npz -> factor_spectrum_history.json ->
    block_budget_history.json -> checkpoint_history.json -> on-disk artifact
    validation -> result.json LAST (result.json is the terminal completion
    artifact)
  * required_diagnostic_artifacts_present verified against REAL files
    (exists, size>0, JSON reopen, npz reopen with losses/finite_flags/
    checkpoint_losses) before any completion result is written
  * independent optimization_status / parameter_persistence_status /
    terminal_status; scientific failure (FAILED_NONFINITE) is NEVER masked
    by a persistence failure
  * VALID_PHASE3C4V_RUN = G1_run_pass AND FITTED_GUIDE_RECOVERABLE AND
    required_diagnostic_artifacts_present (separate from the old G1 gate)

Modes:
  --mode preflight   OFFLINE deterministic dry preflight (STAGE V0). No SVI.
  --mode canary      STAGE V1: ONE canary. BLOCKED until 39_..._CANARY_AUTHORIZATION.
  --mode validation  STAGE V2: remaining cohort. BLOCKED until 40_..._VALIDATION_AUTHORIZATION.

Scientific invariance is absolute (see protocol 36). No failed Phase3C4 PCA is used.
THIS FILE DOES NOT EXECUTE ANY INFERENCE IN PREFLIGHT.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)  # MUST be set before numpyro import

import jax.numpy as jnp
import numpy as np
import numpyro
from numpyro import handlers
from numpyro.infer import SVI, Trace_ELBO
from numpyro.infer.autoguide import AutoLowRankMultivariateNormal
from numpyro.infer.initialization import init_to_median
from numpyro.optim import ClippedAdam

from dhbcp_pv.models.full_joint_model import full_joint_model as STABILIZED_PROBABILITY_TARGET
from dhbcp_pv.inference.v1_structured_lowrank_guide import StructuredLowRankAutoGuide
from dhbcp_pv.inference.variational_param_persistence import (
    save_params, load_params, validate_params_roundtrip, params_sha256,
    recover_fitted_guide,
)

ROOT = Path(__file__).resolve().parents[1]

# --------------------------------------------------------------------------- #
# Frozen identities / config (mirror 25A chain; NEW Phase3C.4V namespace)      #
# --------------------------------------------------------------------------- #
EXPECTED_MODEL_SOURCE_SHA256 = "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"
EXPECTED_GUIDE_SOURCE_SHA256 = "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878"
EXPECTED_SCRIPTS51_SHA256 = "1239716a2c73ed1faf3f6085a8bce361553c81c9ad4245bb9149845c45bcff4f"
EXPECTED_SEED_CSV_SHA256 = "2054361bc280a975b9694f1de40cad87884da9bf7bd1c9fbbd691faea229c7db"
EXPECTED_GENERATOR_SHA256 = "5617a62697337fbdfb2ded19f6a3ef8ce2061d6ab0bf91437272391f14bf3f8a"
EXPECTED_CUTOFF = 12
SEEDS = [1001, 2002, 3003, 4004, 5005]

ARMS = [
    {"arm": "PHASE3C4V_ARM_A", "id": "V0_GLOBAL_LR32",
     "guide_family": "AutoLowRankMultivariateNormal(rank=32)", "num_particles": 1,
     "role": "HISTORICAL FAMILY CONTROL (V0, re-fit with persistence)"},
    {"arm": "PHASE3C4V_ARM_B", "id": "V1_SHARED_PLUS_BLOCK_LR32",
     "guide_family": "StructuredLowRankAutoGuide", "num_particles": 1,
     "role": "ARCHITECTURE VALIDATION V1 p=1 (re-fit with persistence)"},
    {"arm": "PHASE3C4V_ARM_C", "id": "V1_SHARED_PLUS_BLOCK_LR32",
     "guide_family": "StructuredLowRankAutoGuide", "num_particles": 4,
     "role": "PARTICLE VALIDATION V1 p=4 (re-fit with persistence)"},
]

# Frozen training protocol (mirror scripts/61 TRAINING exactly - FIX_002).
TRAINING = {
    "objective": "Trace_ELBO",
    "optimizer": "ClippedAdam",
    "learning_rate": 0.003,
    "clip_norm": 10.0,
    "maximum_steps": 2000,
    "minimum_steps_before_early_stopping": 500,
    "checkpoint_interval": 100,
    "early_stop_relative_tolerance": 1e-4,
    "early_stop_patience_checkpoints": 5,
    "diag_scale_init": 0.1,
    "diag_log_scale_init": -2.302585092994046,
    "shared_factor_init_scale": 0.01,
    "block_factor_init_scale": 0.01,
}

# Frozen semantic block map (must match the guide's _BLOCK_SEGMENTS exactly).
BLOCK_SEGMENTS = {
    "count_plus_initial": [(0, 70), (108, 158)],
    "dynamic_scale": [(70, 86)],
    "seriousness": [(86, 108)],
    "temporal_path": [(158, 708)],
}
BLOCK_ORDER = ["count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]

V0_SCHEMA = {
    "v0_control_loc": (708,),
    "v0_control_cov_factor": (708, 32),
    "v0_control_scale": (708,),
}
V1_SCHEMA = {
    "auto_loc": (708,),
    "auto_diag_log_scale": (708,),
    "auto_F_shared": (708, 16),
    "auto_F_count_plus_initial": (120, 4),
    "auto_F_dynamic_scale": (16, 4),
    "auto_F_seriousness": (22, 4),
    "auto_F_temporal_path": (550, 4),
}
CANARY_IDENTITY = "PHASE3C4V_V1_SHARED_PLUS_BLOCK_LR32_p1_seed1001_t12"

RUNS_DIR_REL = "results/phase3c4v/runs"
PROTOCOL_REL = "results/phase3c4v/protocol/36_PHASE3C4V_PARAMETER_PERSISTENT_VALIDATION_PROTOCOL.json"
PREFLIGHT_ARTIFACT_REL = "results/phase3c4v/preflight/39C_PHASE3C4V_FULL_VALIDATION_GUARD_PREFLIGHT.json"
CANARY_AUTH_REL = "results/phase3c4v/39_EXPLICIT_PHASE3C4V_CANARY_AUTHORIZATION.json"
VALIDATION_AUTH_REL = "results/phase3c4v/40_EXPLICIT_PHASE3C4V_VALIDATION_AUTHORIZATION.json"
POSTRUN_AUDIT_REL = "results/phase3c4v/audit/39A_PHASE3C4V_CANARY_POSTRUN_AUDIT.json"
READY_FULL_VALIDATION_REL = "results/phase3c4v/39B_READY_FOR_EXPLICIT_FULL_VALIDATION_AUTHORIZATION.json"
SERIALIZER_REL = "src/dhbcp_pv/inference/variational_param_persistence.py"

# FIX_004: final validation provenance chain (exact order requirement; 37A fallback
# is NOT permitted for validation mode - only 37B is acceptable)
FINAL_VALIDATION_CHAIN = [
    "36", "37B", "38B", "39", "39A", "39B",
    "runner", "serializer", "model", "guide", "scripts51", "seed_csv", "generator",
]
CANARY_ARTIFACTS = [
    "RUN_STARTED.json", "result.json", "training_history.npz", "checkpoint_history.json",
    "factor_spectrum_history.json", "block_budget_history.json", "final_svi_params.npz",
    "final_svi_params_manifest.json", "PARAMETER_PERSISTENCE_VALIDATION.json",
]

OLD_IMMUTABLE = {
    "results/phase3c4/automation/30_VARIATIONAL_PILOT_G1_AUDIT.json": "a37a20b5aeb4bf7d7cd4d7803f8e3fff110188d8ebfd7d1dbfb4e42aad487267",
    "results/phase3c4/automation/30_VARIATIONAL_PILOT_G1_AUDIT.md": "4090cc66c0c7f1bd7285244296288e13914d3ca2a06c625b5b98483432f2c090",
    "results/phase3c4/automation/31_G2_REPLICATE_STABILITY.json": "bd778dc1df1314b62d4ebfb91bf5f929bef2a964e0cd7d751937d7781b5e9746",
    "results/phase3c4/automation/31_G2_REPLICATE_STABILITY.md": "0ffc3e2b499f57383c7778f2e2671631f3b8b46d6f83f2bb87c904a0bc5a59db",
    "results/phase3c4/automation/35_G2_FITTED_GUIDE_PARAMETER_PERSISTENCE_AUDIT.json": "e2c549efef35b56e88c49424522d557a3ca765522181731fd3a3c9faf44353bd",
    "results/phase3c4/automation/35_G2_FITTED_GUIDE_PARAMETER_PERSISTENCE_AUDIT.md": "5f1e4fe4a099476f20f07be6b3b6c1e965130f363294985b99b2460c71866739",
}
OLD_PILOT_RUNS_REL = "results/phase3c4/pilot_runs"
OLD_PILOT_EXPECTED = {"dirs": 15, "files": 93, "run_started": 15, "result_json": 15, "arm_summary": 3}
OLD_RNG_SCHEDULE_REL = "results/phase3c4/27D_VARIATIONAL_PILOT_RUNNER_DRY_PREFLIGHT.json"


# --------------------------------------------------------------------------- #
def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def run_matrix() -> list:
    entries = []
    for arm in ARMS:
        for seed in SEEDS:
            ident = "PHASE3C4V_{}_p{}_seed{}_{}".format(arm["id"], arm["num_particles"], seed, "t{}".format(EXPECTED_CUTOFF))
            entries.append({
                "arm": arm["arm"], "arm_id": arm["id"], "guide_family": arm["guide_family"],
                "num_particles": arm["num_particles"], "role": arm["role"], "seed": seed,
                "cutoff": EXPECTED_CUTOFF, "identity": ident,
                "output_rel": f"{RUNS_DIR_REL}/{ident}",
                "is_canary": ident == CANARY_IDENTITY,
            })
    return entries


def run_matrix_identity_hash() -> str:
    ids = sorted(e["identity"] for e in run_matrix())
    return hashlib.sha256("|".join(ids).encode("utf-8")).hexdigest()


def frozen_reference_data(root: Path, cutoff: int):
    path = root / "scripts/51_run_phase3c_nuts.py"
    spec = importlib.util.spec_from_file_location("frozen_51", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.reference_data(root, cutoff)


def derive_keys(seed: int) -> dict:
    """Frozen 25B RNG derivation: master=PRNGKey(seed); split(master,4)."""
    master = jax.random.PRNGKey(seed)
    prototype_key, factor_init_key, svi_init_key, svi_runtime_key = jax.random.split(master, 4)
    return {
        "master_key": np.asarray(master).tolist(),
        "prototype_key": np.asarray(prototype_key).tolist(),
        "factor_init_key": np.asarray(factor_init_key).tolist(),
        "svi_init_key": np.asarray(svi_init_key).tolist(),
        "svi_runtime_key": np.asarray(svi_runtime_key).tolist(),
    }


def _check_bindings(root: Path, prereqs: dict, required: list) -> tuple:
    """Every bound name must exist, have path+sha256, and the live file must
    match. Returns (ok, first_failure_reason)."""
    for name in required:
        e = prereqs.get(name)
        if not e or "path" not in e or "sha256" not in e:
            return (False, f"missing prerequisite binding: {name}")
        p = root / e["path"]
        if not p.exists() or sha256(p) != e["sha256"]:
            return (False, f"prerequisite {name} SHA mismatch")
    return (True, None)


def _readiness_39b(root: Path) -> tuple:
    """FIX_004: 39B readiness semantics must hold before validation may run."""
    p = root / READY_FULL_VALIDATION_REL
    if not p.exists():
        return (False, "39B readiness artifact missing")
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return (False, f"39B unreadable: {exc}")
    if d.get("READY_FOR_EXPLICIT_FULL_VALIDATION_AUTHORIZATION") is not True:
        return (False, "39B READY_FOR_EXPLICIT_FULL_VALIDATION_AUTHORIZATION != true")
    if d.get("PHASE3C4V_VALIDATION_AUTHORIZED") is not False:
        return (False, "39B PHASE3C4V_VALIDATION_AUTHORIZED != false")
    if d.get("remaining_validation_identities") != 14:
        return (False, f"39B remaining_validation_identities != 14 (got {d.get('remaining_validation_identities')})")
    if d.get("run_matrix_identity_hash") != run_matrix_identity_hash():
        return (False, "39B run_matrix_identity_hash mismatch")
    return (True, None)


def _readiness_39a(root: Path) -> tuple:
    """FIX_004: 39A audit semantics must hold before validation may run."""
    p = root / POSTRUN_AUDIT_REL
    if not p.exists():
        return (False, "39A audit artifact missing")
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return (False, f"39A unreadable: {exc}")
    if d.get("classification") != "CANARY_PASS_PARAMETER_PERSISTENCE_VALIDATED":
        return (False, f"39A classification != CANARY_PASS_PARAMETER_PERSISTENCE_VALIDATED (got {d.get('classification')})")
    vv = d.get("validation_run_validity", {})
    for key in ("G1_run_pass", "FITTED_GUIDE_RECOVERABLE", "required_diagnostic_artifacts_present", "VALID_PHASE3C4V_RUN"):
        if vv.get(key) is not True:
            return (False, f"39A {key} != true")
    if d.get("canary_identity") != CANARY_IDENTITY:
        return (False, "39A canary_identity mismatch")
    return (True, None)


def _canary_immutability(root: Path) -> tuple:
    """FIX_004: live canary artifacts must still match the SHAs recorded in 39A."""
    p = root / POSTRUN_AUDIT_REL
    if not p.exists():
        return (False, "39A missing; cannot revalidate canary SHAs")
    d = json.loads(p.read_text(encoding="utf-8"))
    art = d.get("artifacts", {})
    canary_dir = root / RUNS_DIR_REL / CANARY_IDENTITY
    if not (canary_dir / "RUN_STARTED.json").exists():
        return (False, "canary RUN_STARTED.json missing (must never be deleted)")
    for name in CANARY_ARTIFACTS:
        rec = art.get(name)
        if not rec or "sha256" not in rec:
            return (False, f"39A has no recorded SHA for {name}")
        live_path = canary_dir / name
        if not live_path.exists():
            return (False, f"live canary artifact missing: {name}")
        if sha256(live_path) != rec["sha256"]:
            return (False, f"canary artifact SHA mismatch for {name}")
    return (True, None)


def _remaining_identities(root: Path) -> tuple:
    """FIX_004: derive run matrix, exclude the consumed canary, assert exactly
    14 remaining, and verify none of them has a RUN_STARTED marker yet."""
    remaining = [e for e in run_matrix() if not e["is_canary"]]
    if len(remaining) != 14:
        return (False, f"remaining identity count != 14 (got {len(remaining)})", remaining)
    consumed = [e["identity"] for e in remaining if (root / e["output_rel"] / "RUN_STARTED.json").exists()]
    if consumed:
        return (False, f"remaining identity already consumed: {consumed}", remaining)
    return (True, None, remaining)


def verify_authorization(root: Path, mode: str):
    auth_rel = CANARY_AUTH_REL if mode == "canary" else VALIDATION_AUTH_REL
    if not (root / auth_rel).exists():
        return ("STOP_NOT_AUTHORIZED", f"authorization artifact missing (expected for {mode}): {auth_rel}")
    try:
        auth = json.loads((root / auth_rel).read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return ("STOP_NOT_AUTHORIZED", f"authorization artifact unreadable: {exc}")
    auth_key = "PHASE3C4V_CANARY_AUTHORIZED" if mode == "canary" else "PHASE3C4V_VALIDATION_AUTHORIZED"
    if not auth.get(auth_key):
        return ("STOP_NOT_AUTHORIZED", f"{auth_key} is not true")
    prereqs = auth.get("prerequisite_sha256", {})
    if mode == "validation":
        # FIX_004: validation mode requires the FINAL provenance chain - no 37A fallback
        ok, reason = _check_bindings(root, prereqs, FINAL_VALIDATION_CHAIN)
        if not ok:
            return ("STOP_NOT_AUTHORIZED", reason)
        if auth.get("run_matrix_identity_hash") != run_matrix_identity_hash():
            return ("STOP_NOT_AUTHORIZED", "run_matrix_identity_hash mismatch")
        ok, reason = _readiness_39b(root)
        if not ok:
            return ("STOP_NOT_AUTHORIZED", reason)
        ok, reason = _readiness_39a(root)
        if not ok:
            return ("STOP_NOT_AUTHORIZED", reason)
        ok, reason = _canary_immutability(root)
        if not ok:
            return ("STOP_NOT_AUTHORIZED", reason)
        ok, reason, _ = _remaining_identities(root)
        if not ok:
            return ("STOP_NOT_AUTHORIZED", reason)
        return ("AUTHORIZED", None)
    # mode == "canary": 37A/37B backward-compatible preflight binding
    preflight_key = "37B" if "37B" in prereqs else ("37A" if "37A" in prereqs else None)
    if preflight_key is None:
        return ("STOP_NOT_AUTHORIZED", "missing 37A/37B preflight binding in authorization artifact")
    required = ["36", preflight_key, "runner", "serializer", "model", "guide", "scripts51", "seed_csv", "generator"]
    ok, reason = _check_bindings(root, prereqs, required)
    if not ok:
        return ("STOP_NOT_AUTHORIZED", reason)
    if auth.get("run_matrix_identity_hash") != run_matrix_identity_hash():
        return ("STOP_NOT_AUTHORIZED", "run_matrix_identity_hash mismatch")
    if auth.get("canary_identity") != CANARY_IDENTITY:
        return ("STOP_NOT_AUTHORIZED", "canary identity mismatch")
    if auth.get("seed") != 1001 or auth.get("num_particles") != 1 or auth.get("cutoff") != 12:
        return ("STOP_NOT_AUTHORIZED", "canary seed/particles/cutoff mismatch")
    return ("AUTHORIZED", None)


def build_guide(arm: dict, factor_init_key=None):
    if arm["guide_family"].startswith("AutoLowRankMultivariateNormal"):
        return AutoLowRankMultivariateNormal(
            STABILIZED_PROBABILITY_TARGET, rank=32, prefix="v0_control",
            init_loc_fn=init_to_median(num_samples=5),
        )
    return StructuredLowRankAutoGuide(
        STABILIZED_PROBABILITY_TARGET, init_loc_fn=init_to_median(num_samples=5),
        factor_init_key=factor_init_key,
    )


def expected_schema(arm: dict) -> dict:
    return V0_SCHEMA if arm["guide_family"].startswith("AutoLowRankMultivariateNormal") else V1_SCHEMA


def dummy_params(arm: dict) -> dict:
    rng = np.random.default_rng(20260818)
    schema = expected_schema(arm)
    return {name: (rng.normal(size=shape) * 0.01).astype(np.float64) for name, shape in schema.items()}


def _all_params_finite(params: dict) -> bool:
    for v in params.values():
        if not bool(jnp_all_finite(v)):
            return False
    return True


def jnp_all_finite(v):
    import jax.numpy as _jnp
    return bool(_jnp.all(_jnp.isfinite(v)))


def _block_index_arrays(dim: int) -> dict:
    return {name: jnp_concat([_jnp_arange(a, b) for a, b in segs]) for name, segs in BLOCK_SEGMENTS.items()}


def jnp_concat(arrs):
    import jax.numpy as _jnp
    return _jnp.concatenate(arrs)


def _jnp_arange(a, b):
    import jax.numpy as _jnp
    return _jnp.arange(a, b)


def low_rank_variance_diagnostics(cov_factor, cov_diag):
    """Identical logic to scripts/61 (factor spectrum + block variance budget)."""
    import jax.numpy as _jnp
    sv = _jnp.linalg.svd(cov_factor, compute_uv=False)
    sv = _jnp.sort(sv)[::-1]
    sv_sq = sv ** 2
    global_lr_var = float(_jnp.sum(sv_sq))
    total_var = global_lr_var + float(_jnp.sum(cov_diag))
    global_lr_fraction = global_lr_var / max(total_var, 1e-30)
    num_rank = int(_jnp.sum(sv > 1e-6 * (sv[0] if sv.shape[0] else 1.0)))
    eff_rank = float(_jnp.exp(-_jnp.sum((sv_sq / max(global_lr_var, 1e-30)) * _jnp.log(sv_sq / max(global_lr_var, 1e-30) + 1e-30))))
    block_idx = _block_index_arrays(cov_factor.shape[0])
    blocks = {}
    for name in BLOCK_ORDER:
        idx = block_idx[name]
        Fb = cov_factor[idx, :]
        blk_lr_var = float(_jnp.sum(Fb ** 2))
        blk_total = blk_lr_var + float(_jnp.sum(cov_diag[idx]))
        blocks[name] = {
            "low_rank_variance_total": blk_lr_var,
            "low_rank_variance_share": blk_lr_var / max(global_lr_var, 1e-30),
            "within_block_low_rank_fraction": blk_lr_var / max(blk_total, 1e-30),
        }
    return {
        "singular_values": [float(x) for x in sv],
        "numerical_rank": num_rank,
        "effective_rank": eff_rank,
        "global_low_rank_variance_fraction": float(global_lr_fraction),
        "blocks": blocks,
    }


# --------------------------------------------------------------------------- #
# ONE-SHOT guard (written BEFORE SVI.init; never auto-deleted, never rerun)    #
# --------------------------------------------------------------------------- #
def _one_shot_guard(out_dir: Path, marker_payload: dict) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    marker = out_dir / "RUN_STARTED.json"
    if marker.exists():
        raise RuntimeError(f"RUN_STARTED marker exists; refusing rerun: {marker}")
    atomic_write_json(marker, marker_payload)
    return marker


# --------------------------------------------------------------------------- #
# FIX_003-B: on-disk required diagnostic artifact validator (pure filesystem). #
# --------------------------------------------------------------------------- #
def _on_disk_diagnostics_ok(out_dir: Path) -> dict:
    """Check that the required diagnostic artifacts physically exist on disk,
    have size > 0, JSON files re-read successfully, and training_history.npz
    reopens and contains losses / finite_flags / checkpoint_losses.

    Pure filesystem check - no inference, no SVI, no optimization.
    """
    detail = {}
    ok = True
    required = [
        "training_history.npz",
        "factor_spectrum_history.json",
        "block_budget_history.json",
        "checkpoint_history.json",
    ]
    for name in required:
        p = out_dir / name
        exists = p.exists()
        size = p.stat().st_size if exists else 0
        detail[name] = {"exists": exists, "size": size}
        if not exists or size <= 0:
            ok = False
    if ok:
        try:
            with np.load(out_dir / "training_history.npz", allow_pickle=False) as z:
                for key in ("losses", "finite_flags", "checkpoint_losses"):
                    present = key in z.files and z[key].size > 0
                    detail[f"npz:{key}"] = present
                    ok = ok and present
        except Exception as exc:  # noqa: BLE001
            detail["npz_reopen_error"] = repr(exc)
            ok = False
    if ok:
        for name in ("factor_spectrum_history.json", "block_budget_history.json", "checkpoint_history.json"):
            try:
                d = json.loads((out_dir / name).read_text(encoding="utf-8"))
                reopen_ok = isinstance(d, dict) and "history" in d
                detail[f"json:{name}:reopen"] = reopen_ok
                ok = ok and reopen_ok
            except Exception as exc:  # noqa: BLE001
                detail[f"json:{name}:reopen"] = False
                detail[f"json:{name}:error"] = repr(exc)
                ok = False
    detail["all_ok"] = ok
    return detail


def _ondisk_validation_dry_test() -> dict:
    """Deterministic temp-filesystem dry test of the on-disk validator (no SVI)."""
    res = {}
    with tempfile.TemporaryDirectory() as td:
        d = Path(td)
        # 1. complete valid set
        np.savez(
            d / "training_history.npz",
            losses=np.asarray([1.0, 2.0], dtype=np.float64),
            finite_flags=np.asarray([True, True], dtype=bool),
            checkpoint_losses=np.asarray([1.5], dtype=np.float64),
        )
        for name in ("factor_spectrum_history.json", "block_budget_history.json", "checkpoint_history.json"):
            (d / name).write_text(json.dumps({"history": [{"step": 100}]}), encoding="utf-8")
        res["valid_set_ok"] = bool(_on_disk_diagnostics_ok(d)["all_ok"])
        # 2. missing one file
        (d / "checkpoint_history.json").unlink()
        res["missing_file_detected"] = not _on_disk_diagnostics_ok(d)["all_ok"]
        # 3. empty file
        (d / "checkpoint_history.json").write_text("", encoding="utf-8")
        res["empty_file_detected"] = not _on_disk_diagnostics_ok(d)["all_ok"]
        # 4. corrupt json
        (d / "checkpoint_history.json").write_text("{not valid json", encoding="utf-8")
        res["corrupt_json_detected"] = not _on_disk_diagnostics_ok(d)["all_ok"]
        # 5. npz missing key
        np.savez(d / "training_history.npz", losses=np.asarray([1.0], dtype=np.float64))
        res["npz_missing_key_detected"] = not _on_disk_diagnostics_ok(d)["all_ok"]
    return res


# --------------------------------------------------------------------------- #
# Future single-run path (guarded; NEVER runs in this task).                   #
# Faithful port of the frozen scripts/61 training loop (FIX_002).              #
# --------------------------------------------------------------------------- #
def _run_single(root: Path, entry: dict, auth_sha: str) -> None:
    """Single Phase3C4V validation run. Reachable ONLY after explicit
    authorization (canary/validation guard) - never in this task."""
    out_dir = root / entry["output_rel"]
    runner_sha_val = sha256(Path(__file__).resolve())
    guide_sha_val = sha256(root / GUIDE_REL)

    # 1. ONE-SHOT GUARD: marker written BEFORE SVI.init; refuses rerun.
    marker_payload = {
        "phase": "Phase 3C.4V",
        "identity": entry["identity"],
        "status": "UNIQUE_PHASE3C4V_RUN_CONSUMED",
        "created_utc": utc_now(),
        "arm": entry["arm"],
        "arm_id": entry["arm_id"],
        "seed": entry["seed"],
        "num_particles": entry["num_particles"],
        "cutoff": entry["cutoff"],
        "runner_sha256": runner_sha_val,
        "guide_sha256": guide_sha_val,
        "protocol36_sha256": sha256(root / PROTOCOL_REL),
        "authorization_artifact_sha256": auth_sha,
        "note": "Creation of this marker permanently consumes the single attempt for this run identity.",
    }
    _one_shot_guard(out_dir, marker_payload)

    # per-run wall-clock instrumentation
    run_started_utc = utc_now()
    run_t0 = time.perf_counter()

    # ===== FROZEN RNG SCHEDULE (25B) =====
    keys = derive_keys(entry["seed"])
    prototype_key = jnp.asarray(keys["prototype_key"], dtype=jnp.uint32)
    factor_init_key = jnp.asarray(keys["factor_init_key"], dtype=jnp.uint32)
    svi_init_key = jnp.asarray(keys["svi_init_key"], dtype=jnp.uint32)
    svi_runtime_key = jnp.asarray(keys["svi_runtime_key"], dtype=jnp.uint32)

    # ===== FROZEN reference_data (scripts/51) =====
    data_seed, args, kwargs = frozen_reference_data(root, entry["cutoff"])

    arm = next(a for a in ARMS if a["arm"] == entry["arm"])
    guide = build_guide(arm, factor_init_key=factor_init_key if arm["arm"] != "PHASE3C4V_ARM_A" else None)

    # A. prototype setup under prototype_key (BEFORE SVI.init)
    with numpyro.handlers.seed(rng_seed=prototype_key):
        guide._setup_prototype(*args, **kwargs)

    svi = SVI(
        STABILIZED_PROBABILITY_TARGET,
        guide,
        ClippedAdam(step_size=TRAINING["learning_rate"], clip_norm=TRAINING["clip_norm"]),
        Trace_ELBO(num_particles=entry["num_particles"]),
    )

    # C. svi.init uses the frozen svi_init_key
    state = svi.init(svi_init_key, *args, **kwargs)

    # D. install the frozen svi_runtime_key before any stable_update
    state = state._replace(rng_key=svi_runtime_key)

    # ===== training loop (stable_update) with full instrumentation =====
    max_steps = TRAINING["maximum_steps"]
    ckpt_interval = TRAINING["checkpoint_interval"]
    min_es_steps = TRAINING["minimum_steps_before_early_stopping"]
    es_tol = TRAINING["early_stop_relative_tolerance"]
    es_patience = TRAINING["early_stop_patience_checkpoints"]

    losses = []
    finite_flags = []
    ckpt_history = []
    factor_spec_history = []
    block_budget_history = []
    nonfinite_steps = 0
    patience_count = 0
    prev_ckpt_loss = None
    early_stop_reason = "max_steps_reached"
    steps_completed = 0

    for step in range(max_steps):
        state, loss = svi.stable_update(state, *args, **kwargs)
        losses.append(float(loss))
        finite = bool(jnp.isfinite(loss))
        finite_flags.append(finite)
        if not finite:
            nonfinite_steps += 1
        steps_completed = step + 1

        if (steps_completed % ckpt_interval == 0) or (steps_completed == max_steps):
            params = svi.get_params(state)
            all_finite = _all_params_finite(params)
            if arm["guide_family"].startswith("AutoLowRankMultivariateNormal"):
                raw_cf = params["v0_control_cov_factor"]
                scale = params["v0_control_scale"]
                cf = raw_cf * scale[..., None]
                cd = scale ** 2
            else:
                cf = guide.build_f_total_from_params(params)
                cd = jnp.exp(params["auto_diag_log_scale"]) ** 2
            diag = low_rank_variance_diagnostics(cf, cd)
            factor_spec_history.append(diag["singular_values"])
            block_budget_history.append(diag["blocks"])
            window = [l for l, f in zip(losses[-ckpt_interval:], finite_flags[-ckpt_interval:]) if f]
            ckpt_loss = float(np.mean(window)) if window else float("nan")
            ckpt_history.append({
                "step": steps_completed,
                "checkpoint_loss": ckpt_loss,
                "all_params_finite": all_finite,
                "global_lr_fraction": diag["global_low_rank_variance_fraction"],
                "numerical_rank": diag["numerical_rank"],
                "effective_rank": float(diag["effective_rank"]),
            })
            if steps_completed >= min_es_steps and prev_ckpt_loss is not None and window:
                denom = max(abs(prev_ckpt_loss), 1e-12)
                rel_improve = (prev_ckpt_loss - ckpt_loss) / denom
                if rel_improve < es_tol:
                    patience_count += 1
                else:
                    patience_count = 0
                if patience_count >= es_patience:
                    early_stop_reason = "early_stop_patience"
                    break
            if window:
                prev_ckpt_loss = ckpt_loss

    # ===== terminal bookkeeping (G1-style; old diagnostics preserved) =====
    initial_loss = float(losses[0])
    terminal_loss = float(losses[-1])
    loss_red = (initial_loss - terminal_loss) / max(abs(initial_loss), 1e-12)
    final_params = svi.get_params(state)
    all_params_finite_final = _all_params_finite(final_params)
    g1_run_pass = bool(
        (nonfinite_steps == 0) and (loss_red >= 0.15) and all_params_finite_final
        and (len(losses) > 0) and (len(ckpt_history) > 0)
    )
    # FIX_003-C: independent SCIENTIFIC status - never masked by persistence failure
    if nonfinite_steps > 0:
        optimization_status = "FAILED_NONFINITE"
    elif early_stop_reason == "early_stop_patience":
        optimization_status = "SUCCESS_EARLY_STOPPED"
    else:
        optimization_status = "SUCCESS_COMPLETED"
    checkpoint_count = len(ckpt_history)
    factor_spectrum_checkpoint_count = len(factor_spec_history)
    block_budget_checkpoint_count = len(block_budget_history)
    run_ended_utc = utc_now()
    elapsed_seconds = float(time.perf_counter() - run_t0)

    # ===== PARAMETER PERSISTENCE (step 1: before any diagnostic/terminal artifact) =====
    params = svi.get_params(state)
    npz_path = out_dir / "final_svi_params.npz"
    manifest_path = out_dir / "final_svi_params_manifest.json"
    try:
        man = save_params(params, npz_path, manifest_path)
        reloaded = load_params(npz_path)
        rt = validate_params_roundtrip(params, npz_path, manifest_path)
        rec = recover_fitted_guide(reloaded, expected_schema(arm))
        persistence_pass = bool(rt.get("PASS") and rec["recoverable"])
        persistence_artifact = {
            "FITTED_GUIDE_RECOVERABLE": rec["recoverable"],
            "roundtrip_pass": rt.get("PASS"),
            "n_parameters": man["n_parameters"],
            "npz_sha256": man["npz_sha256"],
            "params_sha256": params_sha256(params),
            "missing": rec["missing"],
            "shape_mismatch": rec["shape_mismatch"],
        }
    except Exception as exc:  # noqa: BLE001
        persistence_pass = False
        persistence_artifact = {"error": repr(exc), "FITTED_GUIDE_RECOVERABLE": False}
    parameter_persistence_status = "PASS" if persistence_pass else "FAILED"
    atomic_write_json(out_dir / "PARAMETER_PERSISTENCE_VALIDATION.json", persistence_artifact)

    # ===== diagnostic artifacts (step 2: written BEFORE result.json, NEVER replaced) =====
    # FIX_003-A order: training_history.npz -> factor_spectrum_history.json ->
    #                 block_budget_history.json -> checkpoint_history.json
    np.savez(
        out_dir / "training_history.npz",
        losses=np.asarray(losses, dtype=np.float64),
        finite_flags=np.asarray(finite_flags, dtype=bool),
        checkpoint_losses=np.asarray([c["checkpoint_loss"] for c in ckpt_history], dtype=np.float64),
    )
    atomic_write_json(out_dir / "factor_spectrum_history.json", {"history": factor_spec_history})
    atomic_write_json(out_dir / "block_budget_history.json", {"history": block_budget_history})
    atomic_write_json(out_dir / "checkpoint_history.json", {"history": ckpt_history})

    # ===== step 3: ON-DISK required artifact validation (FIX_003-B) =====
    od = _on_disk_diagnostics_ok(out_dir)
    required_diagnostic_artifacts_present = bool(od["all_ok"])
    required_histories_present = bool(
        losses and finite_flags and ckpt_history and factor_spec_history and block_budget_history
        and required_diagnostic_artifacts_present
    )

    # ===== step 4: terminal classification with scientific-failure priority =====
    if optimization_status == "FAILED_NONFINITE" and not persistence_pass:
        terminal_status = "FAILED_NONFINITE_WITH_PARAMETER_PERSISTENCE_FAILURE"
    elif optimization_status == "FAILED_NONFINITE":
        terminal_status = "FAILED_NONFINITE"
    elif not persistence_pass:
        terminal_status = "COMPLETED_OPTIMIZATION_BUT_PARAMETER_PERSISTENCE_FAILED"
    elif not required_diagnostic_artifacts_present:
        terminal_status = "COMPLETED_OPTIMIZATION_BUT_DIAGNOSTIC_ARTIFACT_WRITE_FAILED"
    elif early_stop_reason == "early_stop_patience":
        terminal_status = "EARLY_STOPPED"
    else:
        terminal_status = "COMPLETED"
    # FIX_003-D: separate validation-run validity (never called the old G1 gate)
    valid_phase3c4v_run = bool(
        g1_run_pass and persistence_pass and required_diagnostic_artifacts_present
    )

    # ===== step 5: result.json LAST (terminal completion artifact) =====
    result = {
        "identity": entry["identity"], "arm": entry["arm"], "arm_id": entry["arm_id"],
        "seed": entry["seed"], "num_particles": entry["num_particles"], "cutoff": entry["cutoff"],
        "steps_completed": steps_completed,
        "initial_loss": initial_loss,
        "terminal_loss": terminal_loss,
        "loss_reduction_fraction": float(loss_red),
        "nonfinite_gradient_or_loss_steps": nonfinite_steps,
        "all_params_finite": all_params_finite_final,
        "early_stop_reason": early_stop_reason,
        "optimization_status": optimization_status,
        "parameter_persistence_status": parameter_persistence_status,
        "terminal_status": terminal_status,
        "required_diagnostic_artifacts_present": required_diagnostic_artifacts_present,
        "VALID_PHASE3C4V_RUN": valid_phase3c4v_run,
        "started_utc": run_started_utc, "ended_utc": run_ended_utc,
        "elapsed_seconds": elapsed_seconds,
        "required_histories_present": required_histories_present,
        "checkpoint_count": checkpoint_count,
        "factor_spectrum_checkpoint_count": factor_spectrum_checkpoint_count,
        "block_budget_checkpoint_count": block_budget_checkpoint_count,
        "G1_run_pass": g1_run_pass,
        "checkpoint_history": ckpt_history,
        "runner_sha256": runner_sha_val, "guide_sha256": guide_sha_val,
        "data_seed": int(data_seed),
        "rng_identity": {k: keys[k] for k in ("prototype_key", "factor_init_key", "svi_init_key", "svi_runtime_key")},
        # NEW persistence fields (added on top of the old schema)
        "FITTED_GUIDE_RECOVERABLE": persistence_pass,
        "npz_sha256": persistence_artifact.get("npz_sha256"),
        "params_sha256": persistence_artifact.get("params_sha256"),
    }
    atomic_write_json(out_dir / "result.json", result)


GUIDE_REL = "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py"


# --------------------------------------------------------------------------- #
# OFFLINE PREFLIGHT (STAGE V0) - deterministic, NO inference.                  #
# --------------------------------------------------------------------------- #
def _tok(*parts):
    return "".join(parts)


def preflight(root: Path) -> dict:
    checks = {}
    source_text = Path(__file__).read_text(encoding="utf-8")
    rstart = source_text.index("def _run_single(")
    rend = source_text.index("def preflight(")
    run_path = source_text[rstart:rend]
    # guard + run region (RUN_STARTED.json literal lives inside _one_shot_guard)
    gstart = source_text.index("def _one_shot_guard(")
    run_region = source_text[gstart:rend]

    # 1. frozen source SHAs
    src = {
        "model": (root / "src/dhbcp_pv/models/full_joint_model.py", EXPECTED_MODEL_SOURCE_SHA256),
        "guide": (root / GUIDE_REL, EXPECTED_GUIDE_SOURCE_SHA256),
        "scripts51": (root / "scripts/51_run_phase3c_nuts.py", EXPECTED_SCRIPTS51_SHA256),
        "seed_csv": (root / "config/phase3b_tiera_seeds_v1.csv", EXPECTED_SEED_CSV_SHA256),
        "generator": (root / "src/dhbcp_pv/sim/hierarchical_phase3b.py", EXPECTED_GENERATOR_SHA256),
    }
    for name, (p, exp) in src.items():
        checks[f"{name}_sha256"] = sha256(p)
        checks[f"{name}_sha256_pass"] = sha256(p) == exp
    checks["serializer_path"] = SERIALIZER_REL
    checks["serializer_sha256"] = sha256(root / SERIALIZER_REL)
    checks["runner_path"] = "scripts/64_run_phase3c4v_parameter_persistent_validation.py"
    checks["runner_sha256"] = sha256(root / "scripts/64_run_phase3c4v_parameter_persistent_validation.py")
    proto_path = root / PROTOCOL_REL
    checks["protocol36_sha256"] = sha256(proto_path) if proto_path.exists() else None
    checks["protocol36_sha256_pass"] = proto_path.exists()

    # 2. run matrix
    matrix = run_matrix()
    checks["run_matrix_count"] = len(matrix)
    checks["run_matrix_pass"] = len(matrix) == 15
    checks["seeds_exact_pass"] = SEEDS == [1001, 2002, 3003, 4004, 5005]
    idents = [e["identity"] for e in matrix]
    checks["identity_uniqueness_pass"] = len(set(idents)) == 15
    checks["identity_prefix_phase3c4v_pass"] = all(i.startswith("PHASE3C4V_") for i in idents)
    old_dirs = {p.name for p in (root / OLD_PILOT_RUNS_REL).iterdir() if p.is_dir()} if (root / OLD_PILOT_RUNS_REL).exists() else set()
    checks["identity_no_collision_with_old_pass"] = not (set(idents) & old_dirs) and not any(
        i.startswith(("V0_INSTRUMENTED_", "V1_SHARED_PLUS_BLOCK_LOW_RANK_")) for i in idents
    )
    checks["canary_identity"] = CANARY_IDENTITY
    checks["canary_in_matrix_pass"] = any(e["identity"] == CANARY_IDENTITY for e in matrix)
    checks["run_matrix_identity_hash"] = run_matrix_identity_hash()

    # 3. FIX_002 conformance gates (source binding, no string-only for values)
    checks["trace_elbo_particle_binding_pass"] = (
        "Trace_ELBO(num_particles=entry[\"num_particles\"])" in run_path
    )
    # frozen training loop values + run-path bindings
    tl_ok = (
        TRAINING["maximum_steps"] == 2000
        and TRAINING["minimum_steps_before_early_stopping"] == 500
        and TRAINING["checkpoint_interval"] == 100
        and TRAINING["early_stop_relative_tolerance"] == 1e-4
        and TRAINING["early_stop_patience_checkpoints"] == 5
        and TRAINING["learning_rate"] == 0.003 and TRAINING["clip_norm"] == 10.0
    )
    bind_ok = all(
        s in run_path for s in [
            "max_steps = TRAINING[\"maximum_steps\"]",
            "ckpt_interval = TRAINING[\"checkpoint_interval\"]",
            "min_es_steps = TRAINING[\"minimum_steps_before_early_stopping\"]",
            "es_tol = TRAINING[\"early_stop_relative_tolerance\"]",
            "es_patience = TRAINING[\"early_stop_patience_checkpoints\"]",
            _tok("svi", ".stable_update(state, *args, **kwargs)"),
        ]
    )
    checks["frozen_training_loop_conformance_pass"] = bool(tl_ok and bind_ok)
    checks["early_stopping_exact_pass"] = bool(
        TRAINING["early_stop_relative_tolerance"] == 1e-4
        and TRAINING["early_stop_patience_checkpoints"] == 5
        and "rel_improve = (prev_ckpt_loss - ckpt_loss) / denom" in run_path
    )
    checks["checkpoint_interval_exact_pass"] = bool(
        TRAINING["checkpoint_interval"] == 100 and TRAINING["maximum_steps"] == 2000
        and TRAINING["minimum_steps_before_early_stopping"] == 500
    )
    checks["one_shot_guard_present_pass"] = bool(
        "_one_shot_guard(" in run_path and "refusing rerun" in source_text
        and "UNIQUE_PHASE3C4V_RUN_CONSUMED" in run_path
    )
    checks["run_started_before_svi_init_pass"] = bool(
        run_path.index("_one_shot_guard(") < run_path.index(_tok("svi", ".init("))
    )
    # simulated one-shot guard dry test (filesystem only, no SVI)
    guard_test = {"first_call": False, "second_call_refused": False}
    with tempfile.TemporaryDirectory() as td:
        d = Path(td) / "run"
        m = _one_shot_guard(d, {"status": "UNIQUE_PHASE3C4V_RUN_CONSUMED", "identity": "DRY"})
        guard_test["first_call"] = m.exists()
        try:
            _one_shot_guard(d, {"status": "UNIQUE_PHASE3C4V_RUN_CONSUMED", "identity": "DRY"})
        except RuntimeError:
            guard_test["second_call_refused"] = True
    checks["rerun_refusal_pass"] = bool(
        guard_test["first_call"] and guard_test["second_call_refused"]
        and "refusing rerun" in source_text
    )
    checks["guard_simulated_dry_test"] = guard_test

    required_artifacts = [
        "RUN_STARTED.json", "result.json", "training_history.npz", "checkpoint_history.json",
        "factor_spectrum_history.json", "block_budget_history.json",
        "final_svi_params.npz", "final_svi_params_manifest.json", "PARAMETER_PERSISTENCE_VALIDATION.json",
    ]
    checks["required_per_run_artifact_writer_pass"] = all(a in run_region for a in required_artifacts)

    checks["prototype_setup_conformance_pass"] = bool(
        "handlers.seed(rng_seed=prototype_key)" in run_path
        and "guide._setup_prototype(*args, **kwargs)" in run_path
        and _tok("guide", "(*args, **kwargs)") not in run_path.replace("guide._setup_prototype", "")
    )
    # rng_25b exact mapping (compare derive_keys vs frozen 27D schedule vectors)
    rng_ok = True
    rng_detail = {}
    sched = json.loads((root / OLD_RNG_SCHEDULE_REL).read_text(encoding="utf-8"))["checklist"]["rng_schedule"]
    for seed in SEEDS:
        expected = None
        for ident, kv in sched.items():
            if ident.endswith(f"_seed{seed}_t12"):
                expected = kv
                break
        got = derive_keys(seed)
        match = bool(expected and all(got[k] == expected[k] for k in
                                       ("prototype_key", "factor_init_key", "svi_init_key", "svi_runtime_key")))
        rng_ok = rng_ok and match
        rng_detail[str(seed)] = {"match": match}
    checks["rng_25b_exact_mapping_pass"] = rng_ok
    checks["rng_25b_exact_mapping_detail"] = rng_detail

    # parameter persistence ordering in run path (subset chain)
    def _idx(token):
        return run_path.index(token)

    # match the actual WRITE statements (not bare filenames that also appear in
    # comments/docstrings) - full source-ordering evidence for FIX_003
    order_tokens = [
        "svi.get_params(state)",
        'out_dir / "final_svi_params.npz"',
        'out_dir / "final_svi_params_manifest.json"',
        'atomic_write_json(out_dir / "PARAMETER_PERSISTENCE_VALIDATION.json"',
        'atomic_write_json(out_dir / "result.json"',
    ]
    order_ok = all(_idx(order_tokens[i]) < _idx(order_tokens[i + 1]) for i in range(len(order_tokens) - 1))
    checks["parameter_persistence_ordering_pass"] = bool(order_ok)

    # ---- FIX_003: FULL terminal-artifact write order (real source ordering) ----
    # required chain: PARAMETER_PERSISTENCE_VALIDATION.json < training_history.npz <
    #   factor_spectrum_history.json < block_budget_history.json <
    #   checkpoint_history.json < result.json
    term_tokens = [
        'atomic_write_json(out_dir / "PARAMETER_PERSISTENCE_VALIDATION.json"',
        'out_dir / "training_history.npz"',
        'atomic_write_json(out_dir / "factor_spectrum_history.json"',
        'atomic_write_json(out_dir / "block_budget_history.json"',
        'atomic_write_json(out_dir / "checkpoint_history.json"',
        'atomic_write_json(out_dir / "result.json"',
    ]
    try:
        positions = [_idx(t) for t in term_tokens]
        term_chain_ok = all(positions[i] < positions[i + 1] for i in range(len(positions) - 1))
    except ValueError:
        positions = [-1] * len(term_tokens)
        term_chain_ok = False
    checks["terminal_artifact_order_positions"] = dict(zip(term_tokens, positions))
    checks["diagnostic_artifacts_before_result_pass"] = bool(term_chain_ok)
    # result.json must be the LAST required per-run artifact written
    # (RUN_STARTED.json literal lives inside _one_shot_guard body outside run_path;
    #  anchor on the guard CALL site, which is the first required artifact write)
    all_write_tokens = ["_one_shot_guard(out_dir",
                        'out_dir / "final_svi_params.npz"',
                        'out_dir / "final_svi_params_manifest.json"'] + term_tokens
    try:
        all_pos = {t: run_path.index(t) for t in all_write_tokens}
        result_token = 'atomic_write_json(out_dir / "result.json"'
        result_last = all(all_pos[result_token] > v
                          for t, v in all_pos.items() if t != result_token)
    except ValueError:
        result_last = False
    checks["result_json_terminal_write_last_pass"] = bool(term_chain_ok and result_last)

    # FIX_003-B: on-disk required artifact validation present + dry test
    checks["required_artifact_ondisk_validation_present_pass"] = bool(
        "def _on_disk_diagnostics_ok" in source_text
        and "_on_disk_diagnostics_ok(out_dir)" in run_path
        and "required_diagnostic_artifacts_present" in run_path
        and "required_histories_present" in run_path
        and "losses" in run_path and "finite_flags" in run_path and "checkpoint_losses" in run_path
    )
    od_test = _ondisk_validation_dry_test()
    checks["ondisk_validation_dry_test"] = od_test
    checks["ondisk_validation_dry_test_pass"] = all(od_test.values())

    # FIX_003-C: scientific failure priority preserved (never masked by persistence)
    checks["scientific_failure_priority_preserved_pass"] = bool(
        "optimization_status" in run_path
        and "parameter_persistence_status" in run_path
        and 'optimization_status == "FAILED_NONFINITE" and not persistence_pass' in run_path
        and "FAILED_NONFINITE_WITH_PARAMETER_PERSISTENCE_FAILURE" in run_path
        and 'terminal_status = "FAILED_NONFINITE"' in run_path
        and 'terminal_status = "COMPLETED_OPTIMIZATION_BUT_PARAMETER_PERSISTENCE_FAILED"' in run_path
    )
    checks["persistence_failure_does_not_mask_nonfinite_pass"] = bool(
        'optimization_status == "FAILED_NONFINITE" and not persistence_pass' in run_path
        and "FAILED_NONFINITE_WITH_PARAMETER_PERSISTENCE_FAILURE" in run_path
        and 'terminal_status = "FAILED_NONFINITE"' in run_path
    )
    # FIX_003-D: VALID_PHASE3C4V_RUN (separate from old G1 gate)
    checks["valid_phase3c4v_run_gate_present_pass"] = bool(
        "VALID_PHASE3C4V_RUN" in run_path
        and 'valid_phase3c4v_run = bool(' in run_path
        and "g1_run_pass and persistence_pass and required_diagnostic_artifacts_present" in run_path
    )

    # 4. dummy serializer roundtrip (V0 + V1)
    dummy_results = {}
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        for arm in ARMS:
            params = dummy_params(arm)
            npz_path = td / f"DUMMY_{arm['id']}_params.npz"
            man_path = td / f"DUMMY_{arm['id']}_params_manifest.json"
            rt = validate_params_roundtrip(params, npz_path, man_path)
            rec = recover_fitted_guide(load_params(npz_path), expected_schema(arm))
            leftover = [p.name for p in td.glob("*.tmp*")]
            dummy_results[arm["arm"]] = {
                "roundtrip_pass": bool(rt.get("PASS")), "recoverable": bool(rec["recoverable"]),
                "n_parameters": len(params), "leftover_tmp": leftover,
                "atomic_write_pass": bool(rt.get("PASS") and not leftover),
            }
    checks["dummy_roundtrip"] = dummy_results
    checks["serializer_roundtrip_pass"] = all(v["roundtrip_pass"] for v in dummy_results.values())
    checks["atomic_write_pass"] = all(v["atomic_write_pass"] for v in dummy_results.values())
    checks["recoverability_schema_pass"] = all(v["recoverable"] for v in dummy_results.values())

    # 5. authorization guard (both modes must STOP_NOT_AUTHORIZED now)
    g_canary = verify_authorization(root, "canary")
    g_val = verify_authorization(root, "validation")
    checks["authorization_guard_pass"] = (
        g_canary[0] == "STOP_NOT_AUTHORIZED" and g_val[0] == "STOP_NOT_AUTHORIZED"
    )
    checks["authorization_guard_canary"] = g_canary[0]
    checks["authorization_guard_validation"] = g_val[0]

    # ---- FIX_004: FULL-VALIDATION AUTHORIZATION GUARD HARDENING ----
    # 5a. source binding: validation mode must require the FINAL chain (no 37A fallback)
    #     slice the validation branch only (canary branch may keep preflight_key)
    vstart = source_text.index('if mode == "validation":')
    vend = source_text.index('# mode == "canary":')
    validation_branch = source_text[vstart:vend]
    chain_def_start = source_text.index("FINAL_VALIDATION_CHAIN = [")
    chain_def_end = source_text.index("]\n", chain_def_start) + 2
    chain_def = source_text[chain_def_start:chain_def_end]
    checks["validation_requires_37B_not_37A_pass"] = bool(
        "FINAL_VALIDATION_CHAIN" in validation_branch
        and "preflight_key" not in validation_branch
        and "37A" not in chain_def
        and '"37B"' in chain_def
        and "_check_bindings(root, prereqs, FINAL_VALIDATION_CHAIN)" in validation_branch
    )
    # positive source evidence: validation branch requires each final-chain member
    checks["validation_requires_38B_pass"] = bool(
        "FINAL_VALIDATION_CHAIN" in source_text and "38B" in source_text
        and "_check_bindings(root, prereqs, FINAL_VALIDATION_CHAIN)" in source_text)
    checks["validation_requires_39_pass"] = bool(
        "FINAL_VALIDATION_CHAIN" in source_text and '"39"' in source_text)
    checks["validation_requires_39A_pass"] = bool(
        "FINAL_VALIDATION_CHAIN" in source_text and '"39A"' in source_text)
    checks["validation_requires_39B_pass"] = bool(
        "FINAL_VALIDATION_CHAIN" in source_text and '"39B"' in source_text)
    # 5b. runtime negative test: a 40 authorization with an incomplete chain must
    #     be rejected (simulated in-memory, no file created, no inference)
    def _sim_auth(keys):
        return {"prerequisite_sha256": {k: {"path": "x", "sha256": "0" * 64} for k in keys}}
    neg = {}
    for missing in [["39B"], ["39A"], ["38B"], ["39"], ["37B"]]:
        keys = [k for k in FINAL_VALIDATION_CHAIN if k not in missing]
        ok, _ = _check_bindings(root, _sim_auth(keys)["prerequisite_sha256"], FINAL_VALIDATION_CHAIN)
        neg["missing_" + "_".join(missing)] = (not ok)
    full_ok, _ = _check_bindings(root, _sim_auth(FINAL_VALIDATION_CHAIN)["prerequisite_sha256"], FINAL_VALIDATION_CHAIN)
    neg["full_chain_passes_binding_check"] = (not full_ok)  # False because paths don't exist -> correctly rejected
    checks["authorization_guard_negative_test_pass"] = all(v for k, v in neg.items() if k != "full_chain_passes_binding_check")
    checks["authorization_guard_negative_test_detail"] = neg
    # 5c. live canary post-audit immutability (39A SHAs vs on-disk)
    ok_cim, reason_cim = _canary_immutability(root)
    checks["canary_postaudit_sha_revalidation_pass"] = ok_cim
    checks["canary_postaudit_sha_revalidation_detail"] = reason_cim
    # 5d. 39A readiness semantics revalidation
    ok_39a, reason_39a = _readiness_39a(root)
    checks["canary_validity_revalidation_pass"] = ok_39a
    checks["canary_validity_revalidation_detail"] = reason_39a
    # 5e. 39B readiness semantics revalidation
    ok_39b, reason_39b = _readiness_39b(root)
    checks["readiness_39b_revalidation_pass"] = ok_39b
    checks["readiness_39b_revalidation_detail"] = reason_39b
    # 5f. remaining identity audit: exactly 14, none consumed
    ok_rem, reason_rem, remaining = _remaining_identities(root)
    checks["remaining_identity_count_14_pass"] = bool(ok_rem and len(remaining) == 14)
    checks["remaining_identity_unconsumed_gate_pass"] = ok_rem
    checks["remaining_identity_detail"] = {"count": len(remaining) if ok_rem else None,
                                           "identities": [e["identity"] for e in remaining] if ok_rem else [],
                                           "reason": reason_rem}
    checks["canary_not_in_remaining_pass"] = bool(
        ok_rem and all(not e["is_canary"] for e in remaining))


    # 6. old Phase3C.4 immutability
    imm = {}
    for rel, exp in OLD_IMMUTABLE.items():
        p = root / rel
        live = sha256(p) if p.exists() else None
        imm[rel] = {"expected": exp, "live": live, "pass": live == exp}
    checks["old_phase3c4_immutability_pass"] = all(v["pass"] for v in imm.values())
    checks["old_phase3c4_immutability_detail"] = imm
    old_pilot = root / OLD_PILOT_RUNS_REL
    n_dirs = len([p for p in old_pilot.iterdir() if p.is_dir()]) if old_pilot.exists() else 0
    n_files = len([p for p in old_pilot.rglob("*") if p.is_file()]) if old_pilot.exists() else 0
    n_rs = len(list(old_pilot.rglob("RUN_STARTED.json"))) if old_pilot.exists() else 0
    n_rj = len(list(old_pilot.rglob("result.json"))) if old_pilot.exists() else 0
    n_arm = len(list(old_pilot.glob("*_arm_summary.json"))) if old_pilot.exists() else 0
    checks["old_pilot_runs"] = {"dirs": n_dirs, "files": n_files, "run_started": n_rs, "result_json": n_rj, "arm_summary": n_arm}
    checks["old_pilot_runs_immutable_pass"] = (
        n_dirs == OLD_PILOT_EXPECTED["dirs"] and n_files == OLD_PILOT_EXPECTED["files"]
        and n_rs == OLD_PILOT_EXPECTED["run_started"] and n_rj == OLD_PILOT_EXPECTED["result_json"]
        and n_arm == OLD_PILOT_EXPECTED["arm_summary"]
    )

    # 7. static no-inference audit of the PREFLIGHT body
    pstart = source_text.index("def preflight(")
    pend = source_text.index("def cmd_canary(")
    preflight_body = source_text[pstart:pend]
    forbidden = [
        _tok("SVI", "("), _tok("svi", ".init"), _tok("svi", ".update"),
        _tok("svi", ".stable_update"), _tok("sample_posterior"), _tok("NUTS", "("),
        _tok("HMC", "("), _tok("MCMC", "("), _tok("NeuTraReparam"),
    ]
    hits = [p for p in forbidden if p in preflight_body]
    checks["forbidden_call_patterns_in_preflight"] = hits
    checks["no_inference_in_preflight_pass"] = not hits
    checks["SVI_INIT_CALLED"] = False
    checks["SVI_UPDATE_CALLED"] = False
    checks["SVI_STABLE_UPDATE_CALLED"] = False
    checks["POSTERIOR_SAMPLING"] = False

    gates = [
        "model_sha256_pass", "guide_sha256_pass", "scripts51_sha256_pass",
        "seed_csv_sha256_pass", "generator_sha256_pass", "protocol36_sha256_pass",
        "run_matrix_pass", "seeds_exact_pass", "identity_uniqueness_pass",
        "identity_prefix_phase3c4v_pass", "identity_no_collision_with_old_pass",
        "canary_in_matrix_pass",
        "trace_elbo_particle_binding_pass", "frozen_training_loop_conformance_pass",
        "early_stopping_exact_pass", "checkpoint_interval_exact_pass",
        "one_shot_guard_present_pass", "run_started_before_svi_init_pass",
        "rerun_refusal_pass", "required_per_run_artifact_writer_pass",
        "prototype_setup_conformance_pass", "rng_25b_exact_mapping_pass",
        "parameter_persistence_ordering_pass", "serializer_roundtrip_pass",
        "atomic_write_pass", "recoverability_schema_pass",
        "authorization_guard_pass", "old_phase3c4_immutability_pass",
        "old_pilot_runs_immutable_pass", "no_inference_in_preflight_pass",
        # FIX_003 gates (terminal artifact order + failure status priority)
        "diagnostic_artifacts_before_result_pass",
        "result_json_terminal_write_last_pass",
        "required_artifact_ondisk_validation_present_pass",
        "ondisk_validation_dry_test_pass",
        "scientific_failure_priority_preserved_pass",
        "persistence_failure_does_not_mask_nonfinite_pass",
        "valid_phase3c4v_run_gate_present_pass",
        # FIX_004 gates (full-validation authorization guard hardening)
        "validation_requires_37B_not_37A_pass",
        "validation_requires_38B_pass",
        "validation_requires_39_pass",
        "validation_requires_39A_pass",
        "validation_requires_39B_pass",
        "authorization_guard_negative_test_pass",
        "canary_postaudit_sha_revalidation_pass",
        "canary_validity_revalidation_pass",
        "readiness_39b_revalidation_pass",
        "remaining_identity_count_14_pass",
        "remaining_identity_unconsumed_gate_pass",
        "canary_not_in_remaining_pass",
    ]
    failed = [g for g in gates if not checks.get(g)]
    checks["critical_gates"] = {g: bool(checks.get(g)) for g in gates}
    checks["critical_gates_failed"] = failed
    checks["OVERALL"] = "PASS" if not failed else "FAIL"

    payload = {
        "artifact_id": "39C_PHASE3C4V_FULL_VALIDATION_GUARD_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "stage": "STAGE_V0_OFFLINE_PREFLIGHT",
        "supersedes": "37B_PHASE3C4V_FINAL_TERMINAL_ARTIFACT_ORDER_PREFLIGHT (kept intact)",
        "fix": "FIX_004_PHASE3C4V_FULL_VALIDATION_AUTHORIZATION_GUARD",
        "mode_executed": "preflight",
        "checks": checks,
        "SVI_INIT_CALLED": False,
        "SVI_UPDATE_CALLED": False,
        "SVI_STABLE_UPDATE_CALLED": False,
        "POSTERIOR_SAMPLING": False,
        "optimization_run": False,
        "posterior_inference_run": False,
    }
    atomic_write_json(root / PREFLIGHT_ARTIFACT_REL, payload)
    md = ["# 39C — PHASE3C4V FULL VALIDATION GUARD PREFLIGHT (AFTER FIX_004)",
          "", f"Generated: {utc_now()}  |  Mode: preflight (OFFLINE, no inference)", "",
          f"**OVERALL: {checks['OVERALL']}**", "",
          f"- runner SHA: `{checks['runner_sha256']}`", f"- serializer SHA: `{checks['serializer_sha256']}`",
          f"- protocol36 SHA: `{checks.get('protocol36_sha256')}`",
          f"- canary identity: `{checks['canary_identity']}`", "",
          "| Gate | Result |", "|---|---|"]
    for g in gates:
        md.append(f"| {g} | {'PASS' if checks.get(g) else 'FAIL'} |")
    md.extend(["", "| Flag | Value |", "|---|---|",
               f"| SVI_INIT_CALLED | {payload['SVI_INIT_CALLED']} |",
               f"| SVI_UPDATE_CALLED | {payload['SVI_UPDATE_CALLED']} |",
               f"| SVI_STABLE_UPDATE_CALLED | {payload['SVI_STABLE_UPDATE_CALLED']} |",
               f"| POSTERIOR_SAMPLING | {payload['POSTERIOR_SAMPLING']} |", "",
               "FIX_004 conformance: validation mode requires the FINAL provenance chain "
               "(36/37B/38B/39/39A/39B + runner/serializer/model/guide/scripts51/seed_csv/"
               "generator) with NO 37A fallback; 39B+39A readiness semantics revalidated; "
               "live canary immutability revalidated against 39A SHAs; remaining identities "
               "audited (exactly 14, none consumed, canary excluded); simulated incomplete-"
               "chain negative tests all rejected - deterministic, no SVI."])
    (root / PREFLIGHT_ARTIFACT_REL.replace(".json", ".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("OVERALL:", checks["OVERALL"])
    for g in failed:
        print("  FAILED:", g)
    return checks


# --------------------------------------------------------------------------- #
def cmd_canary(root: Path) -> int:
    status, reason = verify_authorization(root, "canary")
    print(status, "|", reason)
    if status != "AUTHORIZED":
        return 2
    entry = next(e for e in run_matrix() if e["identity"] == CANARY_IDENTITY)
    auth_sha = sha256(root / CANARY_AUTH_REL)
    _run_single(root, entry, auth_sha)  # reachable only after explicit authorization
    return 0


def cmd_validation(root: Path) -> int:
    # FIX_004: verify_authorization(validation) now enforces the FINAL provenance
    # chain (36/37B/38B/39/39A/39B + runner/serializer/model/guide/scripts51/
    # seed_csv/generator), 39B+39A readiness semantics, live canary immutability
    # (39A SHAs vs on-disk), and remaining-identity availability. Only then run.
    status, reason = verify_authorization(root, "validation")
    print(status, "|", reason)
    if status != "AUTHORIZED":
        return 2
    auth_sha = sha256(root / VALIDATION_AUTH_REL)
    ok, reason, remaining = _remaining_identities(root)
    if not ok:
        print("STOP_NOT_AUTHORIZED |", reason)
        return 2
    for entry in remaining:
        # canary is excluded by _remaining_identities (is_canary filtered);
        # one-shot guard inside _run_single refuses any rerun/duplicate.
        _run_single(root, entry, auth_sha)
    return 0


def main() -> None:
    ap = argparse.ArgumentParser(description="Phase3C.4V parameter-persistent validation runner")
    ap.add_argument("--mode", choices=["preflight", "canary", "validation"], default="preflight")
    args = ap.parse_args()
    root = ROOT
    if args.mode == "preflight":
        preflight(root)
    elif args.mode == "canary":
        sys.exit(cmd_canary(root))
    elif args.mode == "validation":
        sys.exit(cmd_validation(root))


if __name__ == "__main__":
    main()
