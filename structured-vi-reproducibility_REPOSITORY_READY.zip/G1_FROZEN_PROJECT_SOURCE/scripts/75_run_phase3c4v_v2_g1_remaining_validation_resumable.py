#!/usr/bin/env python3
"""Phase3C.4V V2 — REMAINING-7 RESUMMABLE VALIDATION EXECUTION RUNNER (scripts/75).

Built from immutable scripts/73 (SHA 8818bb951eedd9e4eb27036078aa873206e9dda0243955ee11466af93b65c21e).
42X confirmed the batch-resume defect in scripts/73:
ALREADY_VALID_CONSUMED_IDENTITY_CAUSES_FALSE_BATCH_STOP_ON_RESTART —
cmd_validation() always iterates from identity1, so a restart after partial
completion hits an already-consumed VALID identity (STOP_IDENTITY_ALREADY_CONSUMED
-> treated as non-VALID -> batch stops). scripts/75 fixes this ENGINEERING-ONLY
issue with RESUME-SAFE state classification; ALL scientific/training semantics
of scripts/73 are preserved EXACTLY.

Resume-safe state per identity (Stage D):
  PENDING_UNCONSUMED                 : RUN_STARTED absent, result.json absent
  COMPLETED_VALID                    : RUN_STARTED + readable result.json with
                                       VALID_V2_G1_RUN=true, terminal in
                                       {COMPLETED_G1_VALID_RUN, COMPLETED_EARLY_STOPPED_G1_VALID},
                                       diagnostics/persistence/on-disk PASS
  CONSUMED_INVALID_OR_INCOMPLETE     : RUN_STARTED present but NOT COMPLETED_VALID

Resume policy (Stage E): COMPLETED_VALID -> SKIP (never rerun, preserved as
evidence); PENDING_UNCONSUMED -> execute; CONSUMED_INVALID_OR_INCOMPLETE ->
STOP THE BATCH before any later identity (requires new human adjudication).
Progress is RECONSTRUCTED from live run directories and never reset.

New authorization artifact (created only after preflight PASS):
  results/phase3c4v_v2/authorizations/V2_G1_REMAINING7_RESUMABLE_VALIDATION_AUTHORIZATION.json
The legacy scripts73 authorization (V2_G1_REMAINING7_VALIDATION_AUTHORIZATION.json)
does NOT authorize scripts75.

The resumable validation batch is launched DETACHED by the USER from a terminal
via `bash scripts/76_launch_v2_g1_remaining7_resumable_detached.sh`.
`bash scripts/74_launch_v2_g1_remaining7_detached.sh` (caffeinate + nohup).

DEFECT FIX MAP:
  DEFECT_1  -> init_loc_fn=numpyro.infer.init_to_median(num_samples=5)
  DEFECT_2  -> G1_MIN_LOSS_REDUCTION = 0.15 defined and enforced
  DEFECT_3  -> classify_terminal(): early-stopped runs get
               COMPLETED_EARLY_STOPPED_G1_VALID / _G1_FAIL; max_steps runs get
               COMPLETED_G1_VALID_RUN / COMPLETED_G1_FAIL_LOSS_REDUCTION
  DEFECT_4  -> NUMPYRO_STABLE_UPDATE_FINITE_OBJECTIVE_AND_GRADIENT_GUARD:
               numpyro 0.21 stable_update -> optim.eval_and_stable_update joint
               finite-objective-and-gradient guard; on failure the optimizer
               state is NOT updated and loss is nan (state-hold semantics made
               explicit + counted as nonfinite step)
  DEFECT_5  -> exception path writes FAILURE.json first, then result.json LAST
               with terminal_status FAILED_EXCEPTION_AFTER_RUN_STARTED,
               VALID_V2_G1_RUN=false, RUN_STARTED_CONSUMED=true
  DEFECT_6  -> acquire_run_started uses os.open(marker, O_WRONLY|O_CREAT|O_EXCL)
               exclusive atomic create; FileExistsError => permanently consumed
  DEFECT_7  -> guard_validation binds SHA256 of the 9 remaining identities
               (identities_sha256) AND requires canary result.json with
               VALID_V2_G1_RUN=true and a G1-valid terminal_status
  DEFECT_8  -> validate_on_disk() verifies the frozen npz schema: exactly 7
               params {v2_loc (708,), v2_diag_log_scale (708,), v2_F_shared
               (708,16), v2_F_count_plus_initial (120,4), v2_F_dynamic_scale
               (16,4), v2_F_seriousness (22,4), v2_raw_temporal_rho (1,)},
               total elements 13377, rho persisted as one-element array,
               manifest npz_sha256 consistency, result.json terminal order
  DEFECT_9  -> exit_status_for(): VALID statuses -> 0,
               STOP_IDENTITY_ALREADY_CONSUMED -> 3, any FAILED/_FAIL -> 4,
               guard refusal -> 2

Modes (--mode preflight | canary | replacement-canary | validation):
  --mode preflight  : J1..J20 deterministic unit tests + protocol/readiness
                      checks ONLY (no SVI). Writes
                      results/phase3c4v/preflight/42R_V2_REPLACEMENT_CANARY_RUNNER_PREFLIGHT.{json,md}
  --mode canary     : historical seed1001 identity; refuses (exit 3) because
                      seed1001 is permanently consumed (RUN_STARTED exists);
                      the seed1001 authorization artifact is historical only.
  --mode replacement-canary : executes the replacement canary identity
                      V2_V2_ARM_P1_p1_seed2002_t12 ONLY if the NEW artifact
                      results/phase3c4v_v2/authorizations/
                      V2_G1_REPLACEMENT_CANARY_AUTHORIZATION.json exists with
                      AUTHORIZED=true, scope=ONE_SHOT_V2_G1_REPLACEMENT_CANARY_ONLY,
                      binding the exact SHA256 of 42J/42N/42P/42Q/42R/guide_fix/
                      scripts70/model/serializer/scripts51/seed CSV/generator.
                      The old seed1001 authorization NEVER authorizes this mode.
  --mode validation : REFUSED unless a FUTURE separate explicit full-validation
                      authorization artifact exists binding the same sources
                      + identities_sha256 of the 8 remaining prospective
                      identities + a VALID canary result. Replacement canary
                      authorization NEVER implies validation authorization.

The future authorized execution path (implemented below, NOT executed in this
task) uses exactly:
  objective     Trace_ELBO(num_particles=entry["num_particles"])
  optimizer     ClippedAdam(step_size=0.003, clip_norm=10.0)
  maximum_steps 2000 | minimum_steps_before_early_stopping 500
  checkpoint_interval 100 | early_stop_relative_tolerance 1e-4
  early_stop_patience_checkpoints 5 | G1_MIN_LOSS_REDUCTION 0.15
  guide         V2SharedAR1TemporalAutoGuide (corrected canonical source)
  target        frozen full_joint_model, cutoff 12
  RNG           master=PRNGKey(seed); split(4) -> prototype_key,
                factor_init_key (guide), svi_init_key (SVI.init),
                svi_runtime_key (training updates ONLY); guide factor split 5-way
  one-shot      results/phase3c4v_v2/runs/<identity>/RUN_STARTED (exclusive
                O_EXCL, BEFORE SVI.init; preflight NEVER creates it)
  persistence   frozen variational_param_persistence.py (save_params/
                validate_params_roundtrip) -> final_svi_params.npz +
                final_svi_params_manifest.json, exact roundtrip required
  terminal      result.json written LAST (success AND exception paths)
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)  # MUST be set before numpyro import

import jax.numpy as jnp
import numpy as np
import numpyro

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

# ---------------------------------------------------------------------------
# Frozen SHA chain (20 sources: 19 frozen artifacts/sources + scripts75 self).
# 42N binds scripts68's SHA; scripts69 binds 42N's SHA (post-42N values);
# scripts75 additionally verifies 42P..42Y + seed3003_result via the
# resumable validation auth binds.
# ---------------------------------------------------------------------------
EXPECTED = {
    "42E": "c50a2bac39d0c5a5c257a0c62f1b94189b4275e08f91621ff6153959fcf33bc5",
    "42F": "e60c654259ef7763bc00c9315ef6cdb214b35fc5270e725aa7a5b90e87df3066",
    "42H": "b3a8ee28d0729fb055b4d45eb8b0a66ae8e0a425905fdde58acd5b51cd7ef363",
    "42I": "7efb62e588de1a83f3618818c1ebd9d150301482e35fcac2f42ce7c3b7f22cc1",
    "42J": "115ebec9ee98aaa81afaca093698179739ca37a820c417c297bb1c36eb953e8f",
    "42K": "c4062492bb863362dadd329a7fa0da71f9ba442e0bc016a975816df12d232b66",
    "42L": "b07694be61b9dfb4609ccd4bb8baa13d8e70c6233035f5214791c56bf07ca267",
    "42M": "3e214a99ae1f9297c43bf38abc6d9ea6b598cc37ae2061801c44c1d5a3a835ce",
    "42N": "7b9c9d100e03a0984688acbe527e1d605202fa84ad43266d09307bcde6c55aeb",
    "guide_fix": "51e23a5c68d34d1d164b20a362cffc4667dedb39da6324426a6674783fa40fdb",
    "scripts66": "1185f5952f70c6dfdf27f7295244ec5a6dd5c907e59c3fd86ab4ecec9ecfc121",
    "scripts67": "1fab70d72ea8046ce7aebd288f50d495fcdc1ac10858f13ac4dc0f123b9fb0bc",
    "model": "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c",
    "v1_guide": "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878",
    "scripts64": "6879309eaf50505da8b923fe4705a48581d21f4c91bf4dfddaaffb98019a0ade",
    "serializer": "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803",
    "scripts51": "1239716a2c73ed1faf3f6085a8bce361553c81c9ad4245bb9149845c45bcff4f",
    "seed_csv": "2054361bc280a975b9694f1de40cad87884da9bf7bd1c9fbbd691faea229c7db",
    "generator": "5617a62697337fbdfb2ded19f6a3ef8ce2061d6ab0bf91437272391f14bf3f8a",
}

FROZEN_PATHS = {
    "42E": "results/phase3c4v/audit/42E_V2_AR1_TEMPORAL_MATHEMATICAL_SPECIFICATION_FREEZE.json",
    "42F": "results/phase3c4v/audit/42F_V2_AR1_NUMERICAL_SAFETY_AMENDMENT.json",
    "42H": "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.json",
    "42I": "results/phase3c4v/preflight/42I_V2_AR1_CORRECTIVE_IMPLEMENTATION_G0_PREFLIGHT.json",
    "42J": "results/phase3c4v/protocol/42J_V2_G1_OPTIMIZATION_PROTOCOL_FREEZE.json",
    "42K": "results/phase3c4v/preflight/42K_V2_G1_RUNNER_READINESS_PREFLIGHT.json",
    "42L": "results/phase3c4v/audit/42L_V2_PRECANARY_HUMAN_ADJUDICATION.json",
    "42M": "results/phase3c4v/preflight/42M_V2_G1_EXECUTION_RUNNER_PREFLIGHT.json",
    "42N": "results/phase3c4v/audit/42N_V2_FINAL_PRECANARY_EXECUTION_SOURCE_AUDIT.json",
    "guide_fix": "src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py",
    "scripts66": "scripts/66_phase3c4v_v2_corrective_deterministic_g0_preflight.py",
    "scripts67": "scripts/67_run_phase3c4v_v2_g1_validation.py",
    "model": "src/dhbcp_pv/models/full_joint_model.py",
    "v1_guide": "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py",
    "scripts64": "scripts/64_run_phase3c4v_parameter_persistent_validation.py",
    "serializer": "src/dhbcp_pv/inference/variational_param_persistence.py",
    "scripts51": "scripts/51_run_phase3c_nuts.py",
    "seed_csv": "config/phase3b_tiera_seeds_v1.csv",
    "generator": "src/dhbcp_pv/sim/hierarchical_phase3b.py",
}

# ---------------------------------------------------------------------------
# Frozen protocol (must match 42J "3_inherited_frozen_protocol" exactly).
# ---------------------------------------------------------------------------
TRAINING = {
    "objective": "Trace_ELBO",
    "optimizer": "ClippedAdam",
    "learning_rate": 0.003,
    "clip_norm": 10.0,
    "maximum_steps": 2000,
    "minimum_steps_before_early_stopping": 500,
    "checkpoint_interval": 100,
    "early_stop_relative_tolerance": 1e-4,
    "early_stop_patience_checkpoints": 5,
    "diag_initial": "log(0.1)",
    "factor_init": "0.01 * Normal(0, I)",
    "rho_raw_init": 0.0,
    "seeds": [1001, 2002, 3003, 4004, 5005],
    "no_phase3c4_pca": True,
    "no_post_hoc_changes": True,
}
CUTOFF = 12
LATENT_DIM = 708
LOG_SCALE_ABS_MAX = 300.0

# DEFECT_2 fix: frozen historical G1 validity criterion.
G1_MIN_LOSS_REDUCTION = 0.15

# DEFECT_4 fix: numpyro 0.21 stable_update -> optim.eval_and_stable_update
# applies the joint finite-objective-and-gradient guard; on guard failure the
# optimizer state is NOT updated and the objective output is set to nan.
NUMPYRO_STABLE_UPDATE_FINITE_OBJECTIVE_AND_GRADIENT_GUARD = (
    "numpyro 0.21 stable_update -> eval_and_stable_update joint guard: "
    "jnp.isfinite(loss) & jnp.isfinite(ravel(grads)).all(); on guard failure "
    "the optimizer state is HELD at the pre-step value and loss is set to nan."
)

# DEFECT_8 fix: frozen V2 parameter schema (42E/42N verified live: 13377 elements).
V2_PARAM_SCHEMA = {
    "v2_loc": (708,),
    "v2_diag_log_scale": (708,),
    "v2_F_shared": (708, 16),
    "v2_F_count_plus_initial": (120, 4),
    "v2_F_dynamic_scale": (16, 4),
    "v2_F_seriousness": (22, 4),
    "v2_raw_temporal_rho": (1,),  # persisted representation (one-element array)
}
V2_TOTAL_ELEMENTS = 13377
EXPECTED_PARAM_NAMES = set(V2_PARAM_SCHEMA.keys())

V2_NS = ROOT / "results/phase3c4v_v2"
V2_RUNS = V2_NS / "runs"
V2_AUTHS = V2_NS / "authorizations"
CANARY_AUTH_PATH = V2_AUTHS / "V2_G1_CANARY_AUTHORIZATION.json"
# Stage J: NEW resumable validation authorization (scripts75). The legacy
# scripts73 authorization V2_G1_REMAINING7_VALIDATION_AUTHORIZATION.json stays
# historical for scripts73 and NEVER authorizes scripts75.
LEGACY_VALIDATION_AUTH_PATH = V2_AUTHS / "V2_G1_REMAINING7_VALIDATION_AUTHORIZATION.json"
VALIDATION_AUTH_PATH = V2_AUTHS / "V2_G1_REMAINING7_RESUMABLE_VALIDATION_AUTHORIZATION.json"
RUN_STARTED_NAME = "RUN_STARTED"

CANARY_IDENTITY = {
    "identity": "V2_V2_ARM_P1_p1_seed1001_t12",
    "arm": "V2_ARM_P1",
    "num_particles": 1,
    "seed": 1001,
    "cutoff": 12,
}
# Historical seed1001 authorization binding (immutable; seed1001 consumed).
CANARY_AUTH_BINDS = ["42J", "42N", "guide_fix", "scripts69", "model", "serializer",
                     "scripts51", "seed_csv", "generator"]

# --- Replacement canary (Stage G/H/I): deterministic next identity from the
# --- ORIGINAL frozen V2_ARM_P1 seed order: seed2002. NO new seeds.
REPLACEMENT_CANARY_IDENTITY = {
    "identity": "V2_V2_ARM_P1_p1_seed2002_t12",
    "arm": "V2_ARM_P1",
    "num_particles": 1,
    "seed": 2002,
    "cutoff": 12,
}
REPLACEMENT_CANARY_AUTH_PATH = V2_AUTHS / "V2_G1_REPLACEMENT_CANARY_AUTHORIZATION.json"
REPLACEMENT_AUTH_BINDS = ["42J", "42N", "42P", "42Q", "42R", "guide_fix", "scripts70",
                          "model", "serializer", "scripts51", "seed_csv", "generator"]

# --- Third canary (Stage B/H): deterministic next identity seed3003. ----
THIRD_CANARY_IDENTITY = {
    "identity": "V2_V2_ARM_P1_p1_seed3003_t12",
    "arm": "V2_ARM_P1",
    "num_particles": 1,
    "seed": 3003,
    "cutoff": 12,
}
THIRD_CANARY_AUTH_PATH = V2_AUTHS / "V2_G1_THIRD_CANARY_AUTHORIZATION.json"
THIRD_AUTH_BINDS = ["42J", "42P", "42Q", "42R", "42S", "42T", "42U", "guide_fix",
                    "scripts71", "model", "serializer", "scripts51", "seed_csv",
                    "generator"]

# Immutable scripts/70 SHA (K1 verifies it is unchanged; scripts/70 is frozen).
SCRIPTS70_EXPECTED_SHA = "6bcbb4ab195beed63bac89f88e2e719b7996f157aba42df29b7c73ccfcc902f0"

# Immutable scripts/71 SHA (the runner that produced the VALID seed3003 canary;
# L3/L6 verify it; scripts/71 is frozen).
SCRIPTS71_EXPECTED_SHA = "743f1d530157d40371f459be5a59a8f820bbb8f15eec557903c70adba7103436"

# Immutable scripts/73 SHA (the fresh-batch runner whose resume defect 42X
# confirmed; M3 verifies it; scripts/73 is frozen).
SCRIPTS73_EXPECTED_SHA = "8818bb951eedd9e4eb27036078aa873206e9dda0243955ee11466af93b65c21e"

# --- Authoritative valid G1 canary reference (Stage C) ---
# The validation authorization REQUIRES this canary's result (seed3003), NEVER
# the historical failed seed1001 result.
VALID_G1_CANARY_IDENTITY = THIRD_CANARY_IDENTITY  # V2_V2_ARM_P1_p1_seed3003_t12

VALIDATION_AUTH_BINDS = ["42J", "42V", "42W", "42X", "42Y", "seed3003_result",
                         "guide_fix", "scripts71", "scripts73", "scripts75",
                         "model", "serializer", "scripts51", "seed_csv",
                         "generator"]
# Future validation must NEVER include seed1001 (consumed), seed2002 (consumed),
# nor seed3003 (valid canary): remaining prospective identities = exactly 7.
VALIDATION_CANARY_EXCLUDED = (CANARY_IDENTITY["identity"],
                              REPLACEMENT_CANARY_IDENTITY["identity"],
                              THIRD_CANARY_IDENTITY["identity"])

# Post-42N audit/preflight artifacts bound by the third-canary authorization.
# They are NOT part of the frozen EXPECTED chain; the guard verifies them by
# LIVE SHA (they are immutable within this batch).
RECOVERY_AUDIT_PATHS = {
    "42P": "results/phase3c4v_v2/audit/42P_V2_G1_CANARY_EXECUTION_RECORD.json",
    "42Q": "results/phase3c4v_v2/audit/42Q_V2_G1_CANARY_ENGINEERING_FAILURE_ROOT_CAUSE.json",
    "42R": "results/phase3c4v/preflight/42R_V2_REPLACEMENT_CANARY_RUNNER_PREFLIGHT.json",
    "42S": "results/phase3c4v_v2/audit/42S_V2_G1_REPLACEMENT_CANARY_EXECUTION_RECORD.json",
    "42T": "results/phase3c4v_v2/audit/42T_V2_G1_PROCESS_TERMINATION_HUMAN_ADJUDICATION.json",
    "42U": "results/phase3c4v/preflight/42U_V2_THIRD_CANARY_DETACHED_EXECUTION_PREFLIGHT.json",
    "42V": "results/phase3c4v_v2/audit/42V_V2_G1_VALID_CANARY_HUMAN_ACCEPTANCE.json",
    "42W": "results/phase3c4v/preflight/42W_V2_G1_REMAINING7_VALIDATION_PREFLIGHT.json",
    "42X": "results/phase3c4v_v2/audit/42X_V2_G1_REMAINING7_BATCH_RESUME_AUDIT.json",
    "42Y": "results/phase3c4v/preflight/42Y_V2_G1_REMAINING7_RESUMABLE_VALIDATION_PREFLIGHT.json",
}

# The VALID seed3003 canary result.json (bound by LIVE SHA in the validation
# authorization; Stage C — NEVER the seed1001 result).
SEED3003_RESULT_REL = "results/phase3c4v_v2/runs/V2_V2_ARM_P1_p1_seed3003_t12/result.json"

# Batch progress artifact (Stage G): engineering metadata only.
BATCH_PROGRESS_PATH = V2_NS / "validation" / "G1_REMAINING7_BATCH_PROGRESS.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def load_json(rel: str):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def _auth_artifact(path: Path):
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {"unreadable": True}


# ---------------------------------------------------------------------------
# Frozen chain / protocol / identity verification.
# ---------------------------------------------------------------------------
def verify_frozen_chain(root: Path, include_self: bool = False) -> dict:
    results = {}
    ok = True
    for name, rel in FROZEN_PATHS.items():
        p = root / rel
        exp = EXPECTED[name]
        live = sha256(p) if p.exists() else "MISSING"
        match = live == exp
        results[name] = {"expected": exp, "live": live, "ok": match}
        ok = ok and match
    if include_self:
        self_sha = sha256(Path(__file__).resolve())
        results["scripts75"] = {"expected": self_sha, "live": self_sha, "ok": True}
    return {"ok": ok, "results": results}


def check_42i_pass(root: Path) -> dict:
    d = load_json(FROZEN_PATHS["42I"])
    return {
        "classification": d.get("classification"),
        "overall": d.get("checks", {}).get("OVERALL"),
        "ok": d.get("classification") == "V2_CORRECTIVE_G0_PREFLIGHT_PASS"
              and d.get("checks", {}).get("OVERALL") == "PASS",
    }


def check_42j_protocol_exact(root: Path) -> dict:
    j42 = load_json(FROZEN_PATHS["42J"])
    proto = j42.get("3_inherited_frozen_protocol", {})
    mismatches = []
    for k, v in TRAINING.items():
        if proto.get(k) != v:
            mismatches.append({"field": k, "42J": proto.get(k), "runner": v})
    ok = not mismatches and j42.get("classification") == "V2_G1_OPTIMIZATION_PROTOCOL_FROZEN"
    return {"ok": ok, "mismatches": mismatches, "classification": j42.get("classification")}


def check_42l_present(root: Path) -> dict:
    p = root / FROZEN_PATHS["42L"]
    if not p.exists():
        return {"ok": False, "reason": "42L missing"}
    d = json.loads(p.read_text(encoding="utf-8"))
    return {
        "ok": d.get("classification") == "V2_PRECANARY_EXECUTION_RUNNER_REQUIRED"
              and d.get("1_adjudication_42I", {}).get("42I_FINAL_RESULT") == "V2_CORRECTIVE_G0_PREFLIGHT_PASS",
        "classification": d.get("classification"),
    }


def check_42m_pass(root: Path) -> dict:
    d = load_json(FROZEN_PATHS["42M"])
    return {
        "classification": d.get("classification"),
        "overall": d.get("checks", {}).get("OVERALL"),
        "ok": d.get("classification") == "V2_G1_EXECUTION_RUNNER_READY_FOR_CANARY_AUTHORIZATION"
              and d.get("checks", {}).get("OVERALL") == "PASS",
    }


def check_42n_present(root: Path) -> dict:
    d = load_json(FROZEN_PATHS["42N"])
    return {
        "classification": d.get("classification"),
        "n_defects": d.get("2_human_source_review", {}).get("n_defects"),
        "ok": d.get("classification") == "V2_G1_EXECUTION_RUNNER_MACHINE_PASS_SOURCE_CORRECTIONS_REQUIRED"
              and d.get("2_human_source_review", {}).get("n_defects") == 9,
    }


def check_run_matrix(root: Path) -> dict:
    j42 = load_json(FROZEN_PATHS["42J"])
    matrix = j42.get("4_run_matrix", {})
    identities = matrix.get("identities", [])
    arms = matrix.get("arms", [])
    by_arm = {}
    for r in identities:
        by_arm.setdefault(r["arm"], []).append(r["seed"])
    canary = j42.get("5_future_canary_identity", {})
    expected = {
        "V2_ARM_P1": (1, [1001, 2002, 3003, 4004, 5005]),
        "V2_ARM_P4": (4, [1001, 2002, 3003, 4004, 5005]),
    }
    ok = len(identities) == 10
    detail = {"total_identities": len(identities)}
    for aname, (np_, seeds_) in expected.items():
        arm = next((a for a in arms if a.get("id") == aname), None)
        seeds = sorted(by_arm.get(aname, []))
        match = arm is not None and arm.get("num_particles") == np_ and seeds == sorted(seeds_)
        ok = ok and match
        detail[aname] = {"num_particles": arm.get("num_particles") if arm else None,
                         "seeds": seeds, "exact": match}
    canary_ok = bool(
        canary.get("identity") == CANARY_IDENTITY["identity"]
        and canary.get("arm") == CANARY_IDENTITY["arm"]
        and canary.get("num_particles") == CANARY_IDENTITY["num_particles"]
        and canary.get("seed") == CANARY_IDENTITY["seed"]
        and canary.get("cutoff") == CANARY_IDENTITY["cutoff"]
        and canary.get("authorized") is False
    )
    detail["canary"] = {"identity": canary.get("identity"), "exact": canary_ok,
                        "authorized": canary.get("authorized")}
    return {"ok": ok and canary_ok, "detail": detail}


def check_zero_consumed(root: Path) -> dict:
    j42 = load_json(FROZEN_PATHS["42J"])
    identities = [r["identity"] for r in j42["4_run_matrix"]["identities"]]
    consumed = []
    if V2_RUNS.exists():
        for ident in identities:
            rd = V2_RUNS / ident
            if (rd / RUN_STARTED_NAME).exists() or (rd / "result.json").exists():
                consumed.append(ident)
    return {"ok": not consumed, "consumed": consumed, "n_consumed": len(consumed)}


def check_auth_state(root: Path) -> dict:
    ca = _auth_artifact(CANARY_AUTH_PATH)
    va = _auth_artifact(VALIDATION_AUTH_PATH)
    j42 = load_json(FROZEN_PATHS["42J"])
    j42_canary = j42.get("1_authorization_state", {}).get("V2_CANARY_AUTHORIZED")
    j42_valid = j42.get("1_authorization_state", {}).get("V2_VALIDATION_AUTHORIZED")
    return {
        "ok": ca is None and va is None and j42_canary is False and j42_valid is False,
        "canary_artifact_present": ca is not None,
        "validation_artifact_present": va is not None,
        "42J_V2_CANARY_AUTHORIZED": j42_canary,
        "42J_V2_VALIDATION_AUTHORIZED": j42_valid,
    }


# ---------------------------------------------------------------------------
# DEFECT_3 / DEFECT_9: pure classification + exit-status mapping (unit-tested).
# ---------------------------------------------------------------------------
def classify_terminal(*, early_stop_reason: str, loss_reduction_fraction: float,
                      nonfinite_loss_steps: int, all_params_finite: bool,
                      persistence_pass: bool,
                      required_diagnostics_present: bool) -> tuple[str, bool]:
    """Frozen G1 terminal classification (DEFECT_3 fix).

    Precedence: nonfinite loss > nonfinite params > persistence > diagnostics >
    early-stop/max-steps G1 loss-reduction gate. Returns (terminal_status,
    VALID_V2_G1_RUN).
    """
    if nonfinite_loss_steps > 0:
        return "FAILED_NONFINITE_LOSS", False
    if not all_params_finite:
        return "FAILED_NONFINITE_PARAMETER", False
    if not persistence_pass:
        return "COMPLETED_OPTIMIZATION_BUT_PARAMETER_PERSISTENCE_FAILED", False
    if not required_diagnostics_present:
        return "COMPLETED_OPTIMIZATION_BUT_DIAGNOSTIC_ARTIFACT_WRITE_FAILED", False
    loss_ok = loss_reduction_fraction >= G1_MIN_LOSS_REDUCTION
    if early_stop_reason == "early_stop_patience":
        if loss_ok:
            return "COMPLETED_EARLY_STOPPED_G1_VALID", True
        return "COMPLETED_EARLY_STOPPED_G1_FAIL", False
    if loss_ok:
        return "COMPLETED_G1_VALID_RUN", True
    return "COMPLETED_G1_FAIL_LOSS_REDUCTION", False


def exit_status_for(terminal_status: str) -> int:
    """DEFECT_9 fix: map terminal status to a process exit code."""
    if terminal_status in ("COMPLETED_G1_VALID_RUN", "COMPLETED_EARLY_STOPPED_G1_VALID"):
        return 0
    if terminal_status == "STOP_IDENTITY_ALREADY_CONSUMED":
        return 3
    return 4  # any FAILED_* / *_FAIL / INVALID terminal status


# ---------------------------------------------------------------------------
# Authorization guards (used by cmd_canary/cmd_validation; negative-tested by
# preflight F14-F16). SHA / source / protocol validation happens BEFORE any
# RUN_STARTED creation; refusal exits non-zero.
# ---------------------------------------------------------------------------
def _chain_ok_for_auth(root: Path) -> bool:
    chain = verify_frozen_chain(root, include_self=True)
    return bool(chain["ok"])


def _auth_binds_ok(auth: dict, binds_names) -> bool:
    binds = auth.get("binds_sha256", {})
    for name in binds_names:
        if name == "scripts75":
            exp = sha256(Path(__file__).resolve())
        elif name == "scripts73":
            exp = sha256(ROOT / "scripts/73_run_phase3c4v_v2_g1_remaining_validation.py")
        elif name == "scripts71":
            exp = sha256(ROOT / "scripts/71_run_phase3c4v_v2_g1_third_canary.py")
        elif name == "scripts70":
            exp = sha256(ROOT / "scripts/70_run_phase3c4v_v2_g1_execution_recovery.py")
        elif name == "scripts69":
            exp = sha256(ROOT / "scripts/69_run_phase3c4v_v2_g1_execution_final.py")
        elif name == "seed3003_result":
            p = ROOT / SEED3003_RESULT_REL
            exp = sha256(p) if p.exists() else None
        elif name in RECOVERY_AUDIT_PATHS:
            # 42P..42Y are bound by LIVE SHA (immutable within this batch);
            # a not-yet-existing artifact (e.g. 42Y while it is being created
            # by the very preflight that runs this code) safely mismatches.
            p = ROOT / RECOVERY_AUDIT_PATHS[name]
            exp = sha256(p) if p.exists() else None
        else:
            exp = EXPECTED.get(name)
        if not exp or binds.get(name) != exp:
            return False
    return True


def _validate_canary_auth_content(auth: dict, root: Path) -> tuple[bool, str]:
    if not bool(auth.get("AUTHORIZED", False)):
        return False, "AUTHORIZED != true"
    if not _auth_binds_ok(auth, CANARY_AUTH_BINDS):
        return False, "canary authorization SHA binding mismatch"
    ident = auth.get("identity", {})
    if not (
        ident.get("identity") == CANARY_IDENTITY["identity"]
        and ident.get("arm") == CANARY_IDENTITY["arm"]
        and ident.get("num_particles") == CANARY_IDENTITY["num_particles"]
        and ident.get("seed") == CANARY_IDENTITY["seed"]
        and ident.get("cutoff") == CANARY_IDENTITY["cutoff"]
    ):
        return False, "canary authorization identity mismatch"
    return True, "AUTHORIZED"


def guard_canary(root: Path) -> dict:
    if not _chain_ok_for_auth(root):
        return {"refused": True, "reason": "STOP_SHA_MISMATCH: frozen chain mismatch before canary guard."}
    auth = _auth_artifact(CANARY_AUTH_PATH)
    if auth is None:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: no V2 G1 canary authorization artifact exists."}
    ok, reason = _validate_canary_auth_content(auth, root)
    if not ok:
        return {"refused": True, "reason": "STOP_NOT_AUTHORIZED: " + reason + "."}
    return {"refused": False, "reason": "AUTHORIZED"}


def _identity_consumed(identity: str) -> bool:
    """True iff RUN_STARTED exists for the given V2 identity (permanent)."""
    return (V2_RUNS / identity / RUN_STARTED_NAME).exists()


def _validate_replacement_auth_content(auth: dict, root: Path) -> tuple[bool, str]:
    """Replacement canary authorization (Stage L): separate artifact, separate
    identity (seed2002), separate scope. The old seed1001 authorization NEVER
    validates here (identity / scope / bind names differ)."""
    if not bool(auth.get("AUTHORIZED", False)):
        return False, "AUTHORIZED != true"
    if auth.get("authorization_scope") != "ONE_SHOT_V2_G1_REPLACEMENT_CANARY_ONLY":
        return False, "authorization_scope != ONE_SHOT_V2_G1_REPLACEMENT_CANARY_ONLY"
    if not _auth_binds_ok(auth, REPLACEMENT_AUTH_BINDS):
        return False, "replacement authorization SHA binding mismatch"
    ident = auth.get("identity", {})
    if not (
        ident.get("identity") == REPLACEMENT_CANARY_IDENTITY["identity"]
        and ident.get("arm") == REPLACEMENT_CANARY_IDENTITY["arm"]
        and ident.get("num_particles") == REPLACEMENT_CANARY_IDENTITY["num_particles"]
        and ident.get("seed") == REPLACEMENT_CANARY_IDENTITY["seed"]
        and ident.get("cutoff") == REPLACEMENT_CANARY_IDENTITY["cutoff"]
    ):
        return False, "replacement authorization identity mismatch"
    if bool(auth.get("ORIGINAL_CANARY_RERUN_ALLOWED", True)):
        return False, "ORIGINAL_CANARY_RERUN_ALLOWED must be false"
    if bool(auth.get("VALIDATION_AUTHORIZED", True)):
        return False, "VALIDATION_AUTHORIZED must be false"
    return True, "AUTHORIZED"


def guard_replacement_canary(root: Path) -> dict:
    if not _chain_ok_for_auth(root):
        return {"refused": True, "reason": "STOP_SHA_MISMATCH: frozen chain mismatch before replacement canary guard."}
    auth = _auth_artifact(REPLACEMENT_CANARY_AUTH_PATH)
    if auth is None:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: no V2 G1 replacement canary authorization artifact exists."}
    ok, reason = _validate_replacement_auth_content(auth, root)
    if not ok:
        return {"refused": True, "reason": "STOP_NOT_AUTHORIZED: " + reason + "."}
    return {"refused": False, "reason": "AUTHORIZED"}


def _validate_third_auth_content(auth: dict, root: Path) -> tuple[bool, str]:
    """Third-canary authorization (Stage H): separate artifact, separate
    identity (seed3003), separate scope. The old seed1001/seed2002
    authorization artifacts NEVER validate here."""
    if not bool(auth.get("AUTHORIZED", False)):
        return False, "AUTHORIZED != true"
    if auth.get("authorization_scope") != "ONE_SHOT_V2_G1_THIRD_CANARY_ONLY":
        return False, "authorization_scope != ONE_SHOT_V2_G1_THIRD_CANARY_ONLY"
    if not _auth_binds_ok(auth, THIRD_AUTH_BINDS):
        return False, "third canary authorization SHA binding mismatch"
    ident = auth.get("identity", {})
    if not (
        ident.get("identity") == THIRD_CANARY_IDENTITY["identity"]
        and ident.get("arm") == THIRD_CANARY_IDENTITY["arm"]
        and ident.get("num_particles") == THIRD_CANARY_IDENTITY["num_particles"]
        and ident.get("seed") == THIRD_CANARY_IDENTITY["seed"]
        and ident.get("cutoff") == THIRD_CANARY_IDENTITY["cutoff"]
    ):
        return False, "third canary authorization identity mismatch"
    if bool(auth.get("SEED1001_RERUN_ALLOWED", True)):
        return False, "SEED1001_RERUN_ALLOWED must be false"
    if bool(auth.get("SEED2002_RERUN_ALLOWED", True)):
        return False, "SEED2002_RERUN_ALLOWED must be false"
    if bool(auth.get("SEED3003_AUTOMATIC_RERUN_ALLOWED", True)):
        return False, "SEED3003_AUTOMATIC_RERUN_ALLOWED must be false"
    if bool(auth.get("VALIDATION_AUTHORIZED", True)):
        return False, "VALIDATION_AUTHORIZED must be false"
    return True, "AUTHORIZED"


def guard_third_canary(root: Path) -> dict:
    if not _chain_ok_for_auth(root):
        return {"refused": True, "reason": "STOP_SHA_MISMATCH: frozen chain mismatch before third canary guard."}
    auth = _auth_artifact(THIRD_CANARY_AUTH_PATH)
    if auth is None:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: no V2 G1 third canary authorization artifact exists."}
    ok, reason = _validate_third_auth_content(auth, root)
    if not ok:
        return {"refused": True, "reason": "STOP_NOT_AUTHORIZED: " + reason + "."}
    return {"refused": False, "reason": "AUTHORIZED"}


def _remaining_identities(root: Path) -> list:
    """Exactly seven future G1 identities in ORIGINAL frozen 42J order with
    the consumed identities (P1 seed1001/2002/3003) removed."""
    j42 = load_json(FROZEN_PATHS["42J"])
    return [r for r in j42["4_run_matrix"]["identities"]
            if r["identity"] not in VALIDATION_CANARY_EXCLUDED]


def _identities_sha256(root: Path) -> str:
    canon = json.dumps(_remaining_identities(root), sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(canon.encode("utf-8")).hexdigest()


def _valid_canary_acceptance_ok(cr: dict) -> tuple[bool, list]:
    """Stage C: the VALID seed3003 canary acceptance criteria. Returns
    (ok, failed_checks). Shared by the validation guard and preflight M19."""
    checks = {
        "identity": cr.get("identity") == VALID_G1_CANARY_IDENTITY["identity"],
        "seed": cr.get("seed") == VALID_G1_CANARY_IDENTITY["seed"],
        "particles": cr.get("num_particles") == VALID_G1_CANARY_IDENTITY["num_particles"],
        "cutoff": cr.get("cutoff") == VALID_G1_CANARY_IDENTITY["cutoff"],
        "terminal_status": cr.get("terminal_status") in (
            "COMPLETED_G1_VALID_RUN", "COMPLETED_EARLY_STOPPED_G1_VALID"),
        "VALID_V2_G1_RUN": bool(cr.get("VALID_V2_G1_RUN", False)),
        "nonfinite_loss_steps": cr.get("nonfinite_loss_steps") == 0,
        "all_params_finite": bool(cr.get("all_params_finite", False)),
        "required_diagnostics_present": bool(cr.get("required_diagnostics_present", False)),
        "parameter_persistence_status": cr.get("parameter_persistence_status") == "PASS",
        "on_disk_validation_PASS": bool(cr.get("on_disk_validation", {}).get("PASS", False)),
        "total_parameter_elements": cr.get("total_parameter_elements") == V2_TOTAL_ELEMENTS,
        "runner_sha256": cr.get("runner_sha256") == SCRIPTS71_EXPECTED_SHA,
        "guide_sha256": cr.get("guide_sha256") == EXPECTED["guide_fix"],
    }
    failed = [k for k, v in checks.items() if not v]
    return (not failed), failed


def _validate_validation_auth_content(auth: dict, root: Path,
                                      canary_result_path: Path | None = None) -> tuple[bool, str]:
    """Stage C/M: validation authorization must reference the VALID seed3003
    canary (NEVER the historical failed seed1001), bind the remaining-7
    identities, and verify the full valid-canary acceptance criteria.

    Scope: ONE_SHOT_V2_G1_REMAINING7_RESUMABLE_VALIDATION_ONLY.
    The legacy scripts73 authorization (different scope/path) does NOT
    validate here."""
    if not bool(auth.get("AUTHORIZED", False)):
        return False, "AUTHORIZED != true"
    if auth.get("authorization_scope") != "ONE_SHOT_V2_G1_REMAINING7_RESUMABLE_VALIDATION_ONLY":
        return False, "authorization_scope != ONE_SHOT_V2_G1_REMAINING7_RESUMABLE_VALIDATION_ONLY"
    if not _auth_binds_ok(auth, VALIDATION_AUTH_BINDS):
        return False, "validation authorization SHA binding mismatch"
    if auth.get("binds_sha256", {}).get("identities_sha256") != _identities_sha256(root):
        return False, "validation authorization identities_sha256 mismatch"
    cpath = Path(canary_result_path) if canary_result_path is not None \
        else (V2_RUNS / VALID_G1_CANARY_IDENTITY["identity"] / "result.json")
    if not cpath.exists():
        return False, ("valid canary result.json missing; validation requires the "
                       "VALID seed3003 canary result")
    try:
        cr = json.loads(cpath.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return False, "valid canary result.json unreadable"
    ok, failed = _valid_canary_acceptance_ok(cr)
    if not ok:
        return False, "valid canary acceptance checks failed: " + ",".join(failed)
    return True, "AUTHORIZED"


def guard_validation(root: Path) -> dict:
    if not _chain_ok_for_auth(root):
        return {"refused": True, "reason": "STOP_SHA_MISMATCH: frozen chain mismatch before validation guard."}
    auth = _auth_artifact(VALIDATION_AUTH_PATH)
    if auth is None:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: no V2 G1 full-validation authorization artifact exists "
                          "(canary authorization NEVER implies validation authorization)."}
    ok, reason = _validate_validation_auth_content(auth, root)
    if not ok:
        return {"refused": True, "reason": "STOP_NOT_AUTHORIZED: " + reason + "."}
    return {"refused": False, "reason": "AUTHORIZED"}


# ---------------------------------------------------------------------------
# One-shot RUN_STARTED guard (DEFECT_6 fix: exclusive atomic O_EXCL create).
# ---------------------------------------------------------------------------
def acquire_run_started(run_dir: Path, identity: str, extra: dict | None = None) -> dict:
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    marker = run_dir / RUN_STARTED_NAME
    payload = {"identity": identity, "status": "V2_RUN_CONSUMED", "created_utc": utc_now()}
    if extra:
        payload.update(extra)
    try:
        fd = os.open(str(marker), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    except FileExistsError:
        return {"acquired": False, "reason": "STOP_IDENTITY_ALREADY_CONSUMED: RUN_STARTED exists; "
                                             "identity is permanently consumed and never rerun."}
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(json.dumps(payload, indent=2) + "\n")
    return {"acquired": True, "reason": "RUN_STARTED created (exclusive one-shot O_EXCL)."}


# ---------------------------------------------------------------------------
# V2 factor diagnostics (deterministic; used at checkpoints in future runs).
# ---------------------------------------------------------------------------
_BLOCK_SEG = {
    "count_plus_initial": [(0, 70), (108, 158)],
    "dynamic_scale": [(70, 86)],
    "seriousness": [(86, 108)],
    "temporal_path": [(158, 708)],
}
_BLOCK_ORDER = ["count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]


def v2_factor_diagnostics(params: dict) -> dict:
    """Deterministic V2 factor spectrum + semantic block covariance budget.

    U = [F_shared | emb(count) | emb(dynamic) | emb(seriousness)] (708, 28);
    effective diag scale s2 = exp(2*clip(v2_diag_log_scale, -300, 300)).
    """
    F_shared = jnp.asarray(params["v2_F_shared"])
    F_count = jnp.asarray(params["v2_F_count_plus_initial"])
    F_dynamic = jnp.asarray(params["v2_F_dynamic_scale"])
    F_serious = jnp.asarray(params["v2_F_seriousness"])
    from dhbcp_pv.inference.v2_shared_ar1_temporal_guide_g0fix import V2SharedAR1TemporalAutoGuide
    U = V2SharedAR1TemporalAutoGuide._build_u(F_shared, F_count, F_dynamic, F_serious)
    sv = jnp.linalg.svdvals(U)
    p = sv ** 2 / jnp.sum(sv ** 2)
    eff_rank = float(jnp.exp(-jnp.sum(p * jnp.where(p > 0, jnp.log(p), 0.0))))
    num_rank = int(jnp.sum(sv > sv[0] * 1e-6))
    u_diag = jnp.sum(U ** 2, axis=1)
    dls = jnp.asarray(params["v2_diag_log_scale"])
    s2 = jnp.exp(2.0 * jnp.clip(dls, -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))
    total = float(jnp.sum(u_diag) + jnp.sum(s2))
    blocks = {}
    for name in _BLOCK_ORDER:
        idx = jnp.concatenate([jnp.arange(a, b) for a, b in _BLOCK_SEG[name]])
        blocks[name] = float(jnp.sum(u_diag[idx]))
    frac = float(jnp.sum(u_diag)) / max(total, 1e-300)
    return {
        "singular_values": [float(x) for x in sv],
        "numerical_rank": num_rank,
        "effective_rank": eff_rank,
        "global_low_rank_variance_fraction": frac,
        "blocks": blocks,
        "factor_frobenius_norms": {
            "F_shared": float(jnp.linalg.norm(F_shared)),
            "F_count_plus_initial": float(jnp.linalg.norm(F_count)),
            "F_dynamic_scale": float(jnp.linalg.norm(F_dynamic)),
            "F_seriousness": float(jnp.linalg.norm(F_serious)),
        },
        "rho": float(0.99 * jnp.tanh(jnp.asarray(params["v2_raw_temporal_rho"]))),
        "diag_effective_min": float(jnp.min(jnp.clip(dls, -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))),
        "diag_effective_max": float(jnp.max(jnp.clip(dls, -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))),
        "diag_canonical_min": float(jnp.min(dls)),
        "diag_canonical_max": float(jnp.max(dls)),
        "clip_below": int(jnp.sum(dls < -LOG_SCALE_ABS_MAX)),
        "clip_above": int(jnp.sum(dls > LOG_SCALE_ABS_MAX)),
    }


def _all_params_finite(params: dict) -> bool:
    return all(bool(jnp.isfinite(jnp.asarray(v)).all()) for v in params.values())


# ---------------------------------------------------------------------------
# DEFECT_8 fix: complete on-disk validation (existence + JSON + npz schema +
# manifest consistency + terminal ordering).
# ---------------------------------------------------------------------------
ON_DISK_MANDATORY = [
    "training_history.npz", "rho_trajectory.json", "diag_scale_trajectory.json",
    "clip_boundary_occupancy.json", "factor_frobenius_history.json",
    "factor_spectrum_history.json", "block_budget_history.json",
    "checkpoint_history.json", "PARAMETER_PERSISTENCE_VALIDATION.json",
    "final_svi_params.npz", "final_svi_params_manifest.json",
]


def validate_on_disk(run_dir: Path, *, require_schema: bool = True,
                     require_terminal_result: bool = False) -> dict:
    run_dir = Path(run_dir)
    problems = []
    for m in ON_DISK_MANDATORY:
        fp = run_dir / m
        if not (fp.exists() and fp.stat().st_size > 0):
            problems.append("missing_or_empty:" + m)
    for jf in ["checkpoint_history.json", "PARAMETER_PERSISTENCE_VALIDATION.json"]:
        fp = run_dir / jf
        if fp.exists():
            try:
                json.loads(fp.read_text(encoding="utf-8"))
            except Exception as exc:  # noqa: BLE001
                problems.append(f"unparseable:{jf}:{exc!r}")
    if require_terminal_result:
        rj = run_dir / "result.json"
        if not (rj.exists() and rj.stat().st_size > 0):
            problems.append("missing_or_empty:result.json")
        else:
            try:
                rdata = json.loads(rj.read_text(encoding="utf-8"))
                if "terminal_status" not in rdata or "VALID_V2_G1_RUN" not in rdata:
                    problems.append("result.json missing terminal fields")
            except Exception as exc:  # noqa: BLE001
                problems.append(f"unparseable:result.json:{exc!r}")
            # terminal order: result.json mtime must be >= every other artifact.
            others = [p for p in run_dir.iterdir()
                      if p.name != "result.json" and p.is_file()]
            r_mt = rj.stat().st_mtime_ns
            stale = [p.name for p in others if p.stat().st_mtime_ns > r_mt]
            if stale:
                problems.append("result.json_not_last:" + ",".join(sorted(stale)))
    if require_schema:
        npz = run_dir / "final_svi_params.npz"
        man = run_dir / "final_svi_params_manifest.json"
        if not npz.exists():
            problems.append("missing:final_svi_params.npz")
        else:
            try:
                with np.load(npz, allow_pickle=False) as z:
                    keys = sorted(z.files)
                    if keys != sorted(V2_PARAM_SCHEMA.keys()):
                        problems.append(f"schema_keys_mismatch:got={keys}")
                    total = 0
                    for k, shape in V2_PARAM_SCHEMA.items():
                        if k not in z:
                            problems.append("missing_param:" + k)
                            continue
                        arr = z[k]
                        total += int(arr.size)
                        if not bool(np.isfinite(arr).all()):
                            problems.append(f"nonfinite_param:{k}")
                        if k == "v2_raw_temporal_rho":
                            if tuple(arr.shape) != (1,):
                                problems.append(f"rho_repr_not_one_element_array:{arr.shape}")
                        elif tuple(arr.shape) != tuple(shape):
                            problems.append(f"shape_mismatch:{k}:got={arr.shape}:expected={shape}")
                    if total != V2_TOTAL_ELEMENTS:
                        problems.append(f"total_elements_mismatch:got={total}:expected={V2_TOTAL_ELEMENTS}")
            except Exception as exc:  # noqa: BLE001
                problems.append(f"npz_read_failed:{exc!r}")
        if man.exists():
            try:
                mdata = json.loads(man.read_text(encoding="utf-8"))
                if mdata.get("n_parameters") != len(V2_PARAM_SCHEMA):
                    problems.append(f"manifest_n_parameters:{mdata.get('n_parameters')}")
                if npz.exists() and mdata.get("npz_sha256") != sha256(npz):
                    problems.append("manifest_npz_sha256_mismatch")
            except Exception as exc:  # noqa: BLE001
                problems.append(f"manifest_unparseable:{exc!r}")
    return {"PASS": not problems, "problems": problems}


# ---------------------------------------------------------------------------
# DEFECT_5 fix: exception terminal writer (FAILURE.json first, then
# result.json LAST with RUN_STARTED_CONSUMED=true).
# ---------------------------------------------------------------------------
def write_terminal_exception(out_dir: Path, *, identity: str, arm: str,
                             num_particles: int, seed: int, cutoff: int,
                             started_utc: str, error_repr: str,
                             steps_completed: int) -> dict:
    out_dir = Path(out_dir)
    ended = utc_now()
    failure = {
        "status": "FAILED_EXCEPTION_AFTER_RUN_STARTED",
        "error": error_repr,
        "error_repr": error_repr,
        "traceback": traceback.format_exc(),
        "started_utc": started_utc, "ended_utc": ended,
        "note": "RUN_STARTED identity remains consumed; no automatic rerun.",
    }
    atomic_write_json(out_dir / "FAILURE.json", failure)
    result = {
        "identity": identity, "arm": arm, "num_particles": num_particles,
        "seed": seed, "cutoff": cutoff,
        "steps_completed": steps_completed,
        "terminal_status": "FAILED_EXCEPTION_AFTER_RUN_STARTED",
        "VALID_V2_G1_RUN": False,
        "RUN_STARTED_CONSUMED": True,
        "started_utc": started_utc, "ended_utc": ended,
        "error": error_repr,
        "runner_sha256": sha256(Path(__file__).resolve()),
    }
    atomic_write_json(out_dir / "result.json", result)  # LAST write invariant
    return result


# ---------------------------------------------------------------------------
# Post-loop recovery artifacts (Stage E). Written immediately after the loop
# ends (and after final_params extraction) so that a LATER engineering
# exception cannot destroy the completed training diagnostics. Diagnostic-only;
# the normal frozen serializer artifacts remain authoritative on success.
# ---------------------------------------------------------------------------
def write_postloop_training_recovery(out_dir: Path, *, identity: str,
                                     steps_completed: int, early_stop_reason: str,
                                     initial_loss: float, terminal_loss: float,
                                     loss_reduction_fraction: float,
                                     nonfinite_steps: int, losses, finite_flags,
                                     created_utc: str) -> dict:
    out_dir = Path(out_dir)
    np.savez(out_dir / "postloop_training_recovery.npz",
             losses=np.asarray(losses, dtype=np.float64),
             finite_flags=np.asarray(finite_flags, dtype=bool))
    payload = {
        "identity": identity,
        "steps_completed": int(steps_completed),
        "early_stop_reason": early_stop_reason,
        "initial_loss": float(initial_loss),
        "terminal_loss": float(terminal_loss),
        "loss_reduction_fraction": float(loss_reduction_fraction),
        "nonfinite_gradient_or_loss_steps": int(nonfinite_steps),
        "created_utc": created_utc,
    }
    atomic_write_json(out_dir / "postloop_training_recovery.json", payload)
    return payload


def write_postloop_final_params_recovery(out_dir: Path, params: dict) -> dict:
    out_dir = Path(out_dir)
    np.savez(out_dir / "postloop_final_params_recovery.npz",
             **{k: np.asarray(v) for k, v in params.items()})
    return {"n_parameters": len(params)}


# ---------------------------------------------------------------------------
# Synthetic run dir builder (unit-test helper for F12/F13; never used on the
# real V2 namespace).
# ---------------------------------------------------------------------------
def build_synthetic_run_dir(run_dir: Path, *, omit: str | None = None,
                            bad_schema: bool = False) -> Path:
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    npz_files = {
        "training_history.npz": {"losses": np.zeros(3), "finite_flags": np.ones(3, dtype=bool)},
    }
    for name, data in npz_files.items():
        if omit != name:
            np.savez(run_dir / name, **data)
    json_files = [
        "rho_trajectory.json", "diag_scale_trajectory.json",
        "clip_boundary_occupancy.json", "factor_frobenius_history.json",
        "factor_spectrum_history.json", "block_budget_history.json",
        "checkpoint_history.json", "PARAMETER_PERSISTENCE_VALIDATION.json",
    ]
    for name in json_files:
        if omit != name:
            (run_dir / name).write_text(json.dumps({"history": []}), encoding="utf-8")
    if omit != "final_svi_params.npz":
        if bad_schema:
            np.savez(run_dir / "final_svi_params.npz",
                     v2_loc=np.zeros(700), v2_diag_log_scale=np.zeros(708),
                     v2_F_shared=np.zeros((708, 16)), v2_F_count_plus_initial=np.zeros((120, 4)),
                     v2_F_dynamic_scale=np.zeros((16, 4)), v2_F_seriousness=np.zeros((22, 4)),
                     v2_raw_temporal_rho=np.zeros(1))
        else:
            np.savez(run_dir / "final_svi_params.npz",
                     v2_loc=np.zeros(708), v2_diag_log_scale=np.zeros(708),
                     v2_F_shared=np.zeros((708, 16)), v2_F_count_plus_initial=np.zeros((120, 4)),
                     v2_F_dynamic_scale=np.zeros((16, 4)), v2_F_seriousness=np.zeros((22, 4)),
                     v2_raw_temporal_rho=np.zeros(1))
        npz_path = run_dir / "final_svi_params.npz"
        manifest = {"n_parameters": 7, "npz_sha256": sha256(npz_path)}
        if omit != "final_svi_params_manifest.json":
            (run_dir / "final_svi_params_manifest.json").write_text(
                json.dumps(manifest), encoding="utf-8")
    if omit != "result.json":
        (run_dir / "result.json").write_text(
            json.dumps({"terminal_status": "COMPLETED_G1_VALID_RUN", "VALID_V2_G1_RUN": True}),
            encoding="utf-8")  # written LAST so mtime order holds
    return run_dir


# ---------------------------------------------------------------------------
# FUTURE AUTHORIZED EXECUTION PATH (implemented; NEVER invoked in this task).
# ---------------------------------------------------------------------------
def _run_identity_future(root: Path, entry: dict, auth_kind: str) -> str:
    """Single V2 G1 run. Reachable ONLY after an explicit future human
    authorization has passed the corresponding guard. Follows the frozen
    Phase3C4V training semantics (scripts/64) with V2-specific diagnostics.

    Sequence: 1 authorization validated (guard) -> 2 frozen SHA chain ->
    3 identity validated -> 4 ensure unconsumed -> 5 RUN_STARTED (O_EXCL) ->
    6 data -> 7 guide (init_to_median(num_samples=5)) -> 8 SVI ->
    9 SVI.init(svi_init_key) -> 10 frozen update loop (svi_runtime_key) ->
    11 checkpoint diagnostics -> 12 final params -> 13 persistence ->
    14 on-disk validation (schema) -> 15 result.json LAST.
    """
    from numpyro.infer import SVI, Trace_ELBO
    from numpyro.optim import ClippedAdam
    from dhbcp_pv.models.full_joint_model import full_joint_model as TARGET
    from dhbcp_pv.inference.v2_shared_ar1_temporal_guide_g0fix import V2SharedAR1TemporalAutoGuide
    from dhbcp_pv.inference.variational_param_persistence import (
        save_params, load_params, validate_params_roundtrip, params_sha256,
    )
    import importlib.util
    spec = importlib.util.spec_from_file_location("frozen_51_69", root / "scripts/51_run_phase3c_nuts.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    out_dir = V2_RUNS / entry["identity"]
    # ---- 1-4: guards + chain validated by caller; identity fixed here ----
    seed = entry["seed"]
    master = jax.random.PRNGKey(seed)
    prototype_key, factor_init_key, svi_init_key, svi_runtime_key = jax.random.split(master, 4)
    prototype_key = jnp.asarray(prototype_key, dtype=jnp.uint32)
    factor_init_key = jnp.asarray(factor_init_key, dtype=jnp.uint32)
    svi_init_key = jnp.asarray(svi_init_key, dtype=jnp.uint32)
    svi_runtime_key = jnp.asarray(svi_runtime_key, dtype=jnp.uint32)

    # ---- 5: one-shot RUN_STARTED BEFORE SVI.init (DEFECT_6: exclusive O_EXCL) ----
    guard = acquire_run_started(out_dir, entry["identity"],
                                extra={"seed": seed, "arm": entry["arm"],
                                       "num_particles": entry["num_particles"],
                                       "cutoff": entry["cutoff"], "auth_kind": auth_kind})
    if not guard["acquired"]:
        return "STOP_IDENTITY_ALREADY_CONSUMED"

    run_started_utc = utc_now()
    run_t0 = time.perf_counter()
    steps_completed = 0
    try:
        # ---- 6: frozen reference data ----
        data_seed, args, kwargs = mod.reference_data(root, entry["cutoff"])
        # ---- 7: guide (DEFECT_1 fix: init_to_median(num_samples=5)) ----
        guide = V2SharedAR1TemporalAutoGuide(
            TARGET, prefix="v2",
            init_loc_fn=numpyro.infer.init_to_median(num_samples=5),
            factor_init_key=factor_init_key,
        )
        with numpyro.handlers.seed(rng_seed=prototype_key):
            guide._setup_prototype(*args, **kwargs)
        # ---- 8-9: SVI + SVI.init with svi_init_key ----
        svi = SVI(
            TARGET, guide,
            ClippedAdam(step_size=TRAINING["learning_rate"], clip_norm=TRAINING["clip_norm"]),
            Trace_ELBO(num_particles=entry["num_particles"]),
        )
        state = svi.init(svi_init_key, *args, **kwargs)
        # ---- 10: training updates derived ONLY from svi_runtime_key ----
        state = state._replace(rng_key=svi_runtime_key)

        max_steps = TRAINING["maximum_steps"]
        ckpt_interval = TRAINING["checkpoint_interval"]
        min_es_steps = TRAINING["minimum_steps_before_early_stopping"]
        es_tol = TRAINING["early_stop_relative_tolerance"]
        es_patience = TRAINING["early_stop_patience_checkpoints"]

        losses = []
        finite_flags = []
        rho_trajectory = []
        diag_effective_trajectory = []
        diag_canonical_trajectory = []
        clip_occupancy_trajectory = []
        factor_norm_trajectory = []
        factor_spectrum_history = []
        block_budget_history = []
        ckpt_history = []
        nonfinite_steps = 0
        patience_count = 0
        prev_ckpt_loss = None
        early_stop_reason = "max_steps_reached"

        for step in range(max_steps):
            # DEFECT_4 fix: stable_update -> eval_and_stable_update joint
            # finite-objective-and-gradient guard. On guard failure the state
            # is HELD at the pre-step value and loss is nan; the step is
            # counted nonfinite (terminal classification FAILED_NONFINITE_LOSS).
            state, loss = svi.stable_update(state, *args, **kwargs)
            loss = float(loss)
            # FIX_1 (42Q root cause): the exact missing operation. The loss
            # MUST be appended here, BEFORE finite evaluation, so `losses`
            # mirrors the per-step loss sequence (ordering: stable_update ->
            # float(loss) -> losses.append(loss) -> finite ->
            # finite_flags.append(finite)).
            losses.append(loss)
            finite = bool(jnp.isfinite(loss))
            finite_flags.append(finite)
            if not finite:
                nonfinite_steps += 1
            steps_completed = step + 1
            # FIX_2: runtime bookkeeping invariants (diagnostics only; no
            # inference change). Asserted cheaply every step.
            assert len(losses) == steps_completed, "bookkeeping invariant: len(losses) == steps_completed"
            assert len(finite_flags) == steps_completed, "bookkeeping invariant: len(finite_flags) == steps_completed"

            if (steps_completed % ckpt_interval == 0) or (steps_completed == max_steps):
                params = svi.get_params(state)
                diag = v2_factor_diagnostics(params)
                factor_spectrum_history.append(diag["singular_values"])
                block_budget_history.append(diag["blocks"])
                rho_trajectory.append(diag["rho"])
                diag_effective_trajectory.append([diag["diag_effective_min"], diag["diag_effective_max"]])
                diag_canonical_trajectory.append([diag["diag_canonical_min"], diag["diag_canonical_max"]])
                clip_occupancy_trajectory.append([diag["clip_below"], diag["clip_above"]])
                factor_norm_trajectory.append(diag["factor_frobenius_norms"])
                all_finite = _all_params_finite(params)
                window = [l for l, f in zip(losses[-ckpt_interval:], finite_flags[-ckpt_interval:]) if f]
                # FIX_2: checkpoint invariants (diagnostics only).
                assert len(losses) >= 1, "checkpoint invariant: len(losses) >= 1"
                if any(f for f in finite_flags[-ckpt_interval:]):
                    assert window, "checkpoint invariant: window must be non-empty when any finite loss exists"
                ckpt_loss = float(np.mean(window)) if window else float("nan")
                ckpt_history.append({
                    "step": steps_completed, "checkpoint_loss": ckpt_loss,
                    "all_params_finite": all_finite,
                    "global_low_rank_variance_fraction": diag["global_low_rank_variance_fraction"],
                    "numerical_rank": diag["numerical_rank"], "effective_rank": diag["effective_rank"],
                    "rho": diag["rho"],
                    "diag_effective_min": diag["diag_effective_min"],
                    "diag_effective_max": diag["diag_effective_max"],
                    "clip_below": diag["clip_below"], "clip_above": diag["clip_above"],
                })
                if steps_completed >= min_es_steps and prev_ckpt_loss is not None and window:
                    denom = max(abs(prev_ckpt_loss), 1e-12)
                    rel_improve = (prev_ckpt_loss - ckpt_loss) / denom
                    patience_count = patience_count + 1 if rel_improve < es_tol else 0
                    if patience_count >= es_patience:
                        early_stop_reason = "early_stop_patience"
                        break
                if window:
                    prev_ckpt_loss = ckpt_loss

        # ---- 11b: POST-LOOP TRAINING RECOVERY (Stage E) ----
        # Written immediately after the loop ends, BEFORE any final diagnostics
        # or persistence that might fail, so a later engineering exception
        # cannot destroy the completed training diagnostics. Diagnostic only;
        # it never affects training.
        assert len(losses) == steps_completed and len(losses) > 0, "loop completion invariant"
        initial_loss = float(losses[0])
        terminal_loss = float(losses[-1])
        loss_red = (initial_loss - terminal_loss) / max(abs(initial_loss), 1e-12)
        recovery_write_ok = True
        recovery_write_warning = None
        try:
            write_postloop_training_recovery(
                out_dir, identity=entry["identity"], steps_completed=steps_completed,
                early_stop_reason=early_stop_reason, initial_loss=initial_loss,
                terminal_loss=terminal_loss, loss_reduction_fraction=float(loss_red),
                nonfinite_steps=nonfinite_steps, losses=losses, finite_flags=finite_flags,
                created_utc=utc_now())
        except Exception as exc:  # noqa: BLE001
            recovery_write_ok = False
            recovery_write_warning = repr(exc)

        # ---- 12: final parameter extraction + diagnostics ----
        final_params = svi.get_params(state)
        all_params_finite_final = _all_params_finite(final_params)
        # ---- 12a: POST-LOOP FINAL PARAMS RECOVERY (Stage E) ----
        # Recovery copy of the seven canonical V2 parameters, written BEFORE
        # complex factor diagnostics. Diagnostic-only; the normal frozen
        # serializer artifacts remain authoritative when persistence succeeds.
        final_params_recovery_ok = True
        final_params_recovery_warning = None
        try:
            write_postloop_final_params_recovery(out_dir, final_params)
        except Exception as exc:  # noqa: BLE001
            final_params_recovery_ok = False
            final_params_recovery_warning = repr(exc)
        param_schema = {k: [int(x) for x in jnp.shape(v)] for k, v in final_params.items()}
        total_elements = int(sum(int(jnp.size(v)) for v in final_params.values()))
        n_outside = int(jnp.sum(jnp.asarray(final_params["v2_diag_log_scale"]) < -LOG_SCALE_ABS_MAX)) + \
            int(jnp.sum(jnp.asarray(final_params["v2_diag_log_scale"]) > LOG_SCALE_ABS_MAX))
        clip_occupancy = {
            "count_below_neg300": int(jnp.sum(jnp.asarray(final_params["v2_diag_log_scale"]) < -LOG_SCALE_ABS_MAX)),
            "count_above_pos300": int(jnp.sum(jnp.asarray(final_params["v2_diag_log_scale"]) > LOG_SCALE_ABS_MAX)),
            "proportion_outside": n_outside / LATENT_DIM,
        }
        final_diag = v2_factor_diagnostics(final_params)

        # ---- 13: persistence via the FROZEN serializer ----
        persist_params = {
            k: np.asarray(v) for k, v in final_params.items()
        }
        # frozen serializer promotes 0-d -> (1,); keep scalar semantics.
        if persist_params["v2_raw_temporal_rho"].ndim == 0:
            persist_params["v2_raw_temporal_rho"] = np.asarray([float(persist_params["v2_raw_temporal_rho"])])
        npz_path = out_dir / "final_svi_params.npz"
        manifest_path = out_dir / "final_svi_params_manifest.json"
        try:
            man = save_params(persist_params, npz_path, manifest_path)
            loaded = load_params(npz_path)
            rt = validate_params_roundtrip(persist_params, npz_path, manifest_path)
            persistence_pass = bool(rt.get("PASS"))
            persistence_artifact = {
                "roundtrip_pass": rt.get("PASS"),
                "n_parameters": man.get("n_parameters"),
                "npz_sha256": man.get("npz_sha256"),
                "params_sha256": params_sha256(persist_params),
                "IN_MEMORY_PARAMETER_SEMANTICS": "scalar" if jnp.ndim(final_params["v2_raw_temporal_rho"]) == 0 else "array",
                "PERSISTED_REPRESENTATION": "one-element array" if persist_params["v2_raw_temporal_rho"].shape == (1,) else "other",
                "loaded_rho_shape": list(loaded["v2_raw_temporal_rho"].shape),
            }
        except Exception as exc:  # noqa: BLE001
            persistence_pass = False
            persistence_artifact = {"error": repr(exc), "roundtrip_pass": False}

        # ---- 11/14: diagnostics artifacts (before result.json) ----
        np.savez(out_dir / "training_history.npz",
                 losses=np.asarray(losses, dtype=np.float64),
                 finite_flags=np.asarray(finite_flags, dtype=bool))
        atomic_write_json(out_dir / "rho_trajectory.json", {"trajectory": rho_trajectory})
        atomic_write_json(out_dir / "diag_scale_trajectory.json", {
            "effective_min_max": diag_effective_trajectory,
            "canonical_min_max": diag_canonical_trajectory,
        })
        atomic_write_json(out_dir / "clip_boundary_occupancy.json", {
            "checkpoints": clip_occupancy_trajectory, "final": clip_occupancy,
        })
        atomic_write_json(out_dir / "factor_frobenius_history.json", {"trajectory": factor_norm_trajectory})
        atomic_write_json(out_dir / "factor_spectrum_history.json", {"history": factor_spectrum_history})
        atomic_write_json(out_dir / "block_budget_history.json", {"history": block_budget_history})
        atomic_write_json(out_dir / "checkpoint_history.json", {"history": ckpt_history})
        atomic_write_json(out_dir / "PARAMETER_PERSISTENCE_VALIDATION.json", persistence_artifact)

        # ---- 14: complete on-disk validation (DEFECT_8: schema + manifest) ----
        od = validate_on_disk(out_dir, require_schema=True, require_terminal_result=False)
        required_diagnostics_present = bool(od["PASS"] and losses and finite_flags and ckpt_history
                                            and factor_spectrum_history and block_budget_history)
        on_disk_validation = {"PASS": od["PASS"], "problems": od["problems"]}

        # ---- DEFECT_2/3: frozen G1 classification ----
        terminal_status, valid_run = classify_terminal(
            early_stop_reason=early_stop_reason,
            loss_reduction_fraction=float(loss_red),
            nonfinite_loss_steps=nonfinite_steps,
            all_params_finite=all_params_finite_final,
            persistence_pass=persistence_pass,
            required_diagnostics_present=required_diagnostics_present,
        )

        # ---- 15: result.json LAST ----
        run_ended_utc = utc_now()
        elapsed = time.perf_counter() - run_t0
        result = {
            "identity": entry["identity"], "arm": entry["arm"],
            "num_particles": entry["num_particles"], "seed": seed, "cutoff": entry["cutoff"],
            "steps_completed": steps_completed,
            "initial_loss": initial_loss, "terminal_loss": terminal_loss,
            "loss_reduction_fraction": float(loss_red),
            "G1_MIN_LOSS_REDUCTION": G1_MIN_LOSS_REDUCTION,
            "nonfinite_loss_steps": nonfinite_steps,
            "all_params_finite": all_params_finite_final,
            "early_stop_reason": early_stop_reason,
            "terminal_status": terminal_status,
            "VALID_V2_G1_RUN": valid_run,
            "RUN_STARTED_CONSUMED": True,
            "required_diagnostics_present": required_diagnostics_present,
            "parameter_persistence_status": "PASS" if persistence_pass else "FAILED",
            "on_disk_validation": on_disk_validation,
            "clip_boundary_occupancy": clip_occupancy,
            "final_diag_scale": {"effective_min": final_diag["diag_effective_min"],
                                 "effective_max": final_diag["diag_effective_max"],
                                 "canonical_min": final_diag["diag_canonical_min"],
                                 "canonical_max": final_diag["diag_canonical_max"]},
            "final_rho": final_diag["rho"],
            "final_factor_frobenius_norms": final_diag["factor_frobenius_norms"],
            "final_factor_singular_values": final_diag["singular_values"],
            "final_global_low_rank_variance_fraction": final_diag["global_low_rank_variance_fraction"],
            "final_block_covariance_budget": final_diag["blocks"],
            "final_parameter_schema": param_schema,
            "total_parameter_elements": total_elements,
            "checkpoint_count": len(ckpt_history),
            "checkpoint_history": ckpt_history,
            "started_utc": run_started_utc, "ended_utc": run_ended_utc,
            "elapsed_seconds": float(elapsed),
            "runner_sha256": sha256(Path(__file__).resolve()),
            "guide_sha256": sha256(root / FROZEN_PATHS["guide_fix"]),
            "postloop_training_recovery_written": recovery_write_ok,
            "postloop_final_params_recovery_written": final_params_recovery_ok,
            "recovery_write_warnings": [recovery_write_warning, final_params_recovery_warning],
            "data_seed": int(data_seed),
            "rng_identity": {
                "prototype_key": np.asarray(prototype_key).tolist(),
                "factor_init_key": np.asarray(factor_init_key).tolist(),
                "svi_init_key": np.asarray(svi_init_key).tolist(),
                "svi_runtime_key": np.asarray(svi_runtime_key).tolist(),
            },
            "persistence": persistence_artifact,
        }
        atomic_write_json(out_dir / "result.json", result)
        return terminal_status
    except Exception as exc:  # noqa: BLE001
        # DEFECT_5 fix: FAILURE.json first, result.json LAST, consumed=true.
        write_terminal_exception(
            out_dir, identity=entry["identity"], arm=entry["arm"],
            num_particles=entry["num_particles"], seed=seed, cutoff=entry["cutoff"],
            started_utc=run_started_utc, error_repr=repr(exc),
            steps_completed=steps_completed)
        return "FAILED_EXCEPTION_AFTER_RUN_STARTED"


# ---------------------------------------------------------------------------
# F3 support: full synthetic classification matrix sweep.
# ---------------------------------------------------------------------------
def classification_matrix_sweep() -> tuple[bool, int, list]:
    """Enumerate {max_steps, early_stop} x {loss_red 0.15, 0.10} x {nonfinite 0,1}
    x {params finite, non} x {persistence pass, fail} x {diag present, absent}
    and assert classify_terminal matches the frozen expectation table."""
    n_cells = 0
    failures = []
    for early_stop in ("max_steps_reached", "early_stop_patience"):
        for loss_red in (0.15, 0.10):
            for nonfinite in (0, 1):
                for pfinite in (True, False):
                    for persist in (True, False):
                        for diag in (True, False):
                            status, valid = classify_terminal(
                                early_stop_reason=early_stop,
                                loss_reduction_fraction=loss_red,
                                nonfinite_loss_steps=nonfinite,
                                all_params_finite=pfinite,
                                persistence_pass=persist,
                                required_diagnostics_present=diag,
                            )
                            if nonfinite > 0:
                                exp = ("FAILED_NONFINITE_LOSS", False)
                            elif not pfinite:
                                exp = ("FAILED_NONFINITE_PARAMETER", False)
                            elif not persist:
                                exp = ("COMPLETED_OPTIMIZATION_BUT_PARAMETER_PERSISTENCE_FAILED", False)
                            elif not diag:
                                exp = ("COMPLETED_OPTIMIZATION_BUT_DIAGNOSTIC_ARTIFACT_WRITE_FAILED", False)
                            elif early_stop == "early_stop_patience":
                                exp = ("COMPLETED_EARLY_STOPPED_G1_VALID", True) if loss_red >= G1_MIN_LOSS_REDUCTION \
                                    else ("COMPLETED_EARLY_STOPPED_G1_FAIL", False)
                            else:
                                exp = ("COMPLETED_G1_VALID_RUN", True) if loss_red >= G1_MIN_LOSS_REDUCTION \
                                    else ("COMPLETED_G1_FAIL_LOSS_REDUCTION", False)
                            n_cells += 1
                            if (status, valid) != exp:
                                failures.append({"cell": {"early_stop": early_stop,
                                                          "loss_red": loss_red,
                                                          "nonfinite": nonfinite,
                                                          "params_finite": pfinite,
                                                          "persistence": persist,
                                                          "diag": diag},
                                                 "got": (status, valid), "expected": exp})
    return (not failures, n_cells, failures)


# ---------------------------------------------------------------------------
# F1..F20 preflight unit tests (NO SVI anywhere in this function).
# ---------------------------------------------------------------------------
def unit_tests_f1_f20(root: Path, counters: dict | None = None) -> dict:
    if counters is None:
        counters = {"init": 0, "update": 0, "stable_update": 0}
    src = Path(__file__).resolve().read_text(encoding="utf-8")
    results = {}

    def rec(name, ok, detail):
        results[name] = {"ok": bool(ok), "detail": detail}

    # F1: DEFECT_1 fix present (exact call).
    rec("F1", "init_to_median(num_samples=5)" in src,
        {"found_in_source": "init_to_median(num_samples=5)" in src})
    # F2: DEFECT_2 fix present (constant defined with frozen value).
    rec("F2", "G1_MIN_LOSS_REDUCTION = 0.15" in src and G1_MIN_LOSS_REDUCTION == 0.15,
        {"value": G1_MIN_LOSS_REDUCTION, "found_in_source": "G1_MIN_LOSS_REDUCTION = 0.15" in src})
    # F3: classification matrix full sweep (64 cells).
    ok3, n3, fails3 = classification_matrix_sweep()
    rec("F3", ok3, {"cells": n3, "failures": fails3})
    # F4: nonfinite -> FAILED_NONFINITE_LOSS (INVALID).
    s4, v4 = classify_terminal(early_stop_reason="max_steps_reached",
                               loss_reduction_fraction=0.9, nonfinite_loss_steps=1,
                               all_params_finite=True, persistence_pass=True,
                               required_diagnostics_present=True)
    rec("F4", s4 == "FAILED_NONFINITE_LOSS" and v4 is False, {"status": s4, "valid": v4})
    # F5: persistence fail -> INVALID.
    s5, v5 = classify_terminal(early_stop_reason="max_steps_reached",
                               loss_reduction_fraction=0.9, nonfinite_loss_steps=0,
                               all_params_finite=True, persistence_pass=False,
                               required_diagnostics_present=True)
    rec("F5", s5 == "COMPLETED_OPTIMIZATION_BUT_PARAMETER_PERSISTENCE_FAILED" and v5 is False,
        {"status": s5, "valid": v5})
    # F6: diagnostic fail -> INVALID.
    s6, v6 = classify_terminal(early_stop_reason="max_steps_reached",
                               loss_reduction_fraction=0.9, nonfinite_loss_steps=0,
                               all_params_finite=True, persistence_pass=True,
                               required_diagnostics_present=False)
    rec("F6", s6 == "COMPLETED_OPTIMIZATION_BUT_DIAGNOSTIC_ARTIFACT_WRITE_FAILED" and v6 is False,
        {"status": s6, "valid": v6})
    # F7: exact 7-param schema (names + shapes).
    schema_ok = set(V2_PARAM_SCHEMA) == EXPECTED_PARAM_NAMES and all(
        tuple(V2_PARAM_SCHEMA[k]) == V2_PARAM_SCHEMA[k] for k in V2_PARAM_SCHEMA)
    rec("F7", schema_ok, {"schema": {k: list(v) for k, v in V2_PARAM_SCHEMA.items()}})
    # F8: total elements == 13377 (computed from schema).
    comp_total = sum(int(np.prod(V2_PARAM_SCHEMA[k])) for k in V2_PARAM_SCHEMA)
    rec("F8", V2_TOTAL_ELEMENTS == 13377 and comp_total == 13377,
        {"constant": V2_TOTAL_ELEMENTS, "computed": comp_total})
    # F9: rho persisted one-element array + canonical scalar semantics.
    rec("F9", V2_PARAM_SCHEMA["v2_raw_temporal_rho"] == (1,)
              and "IN_MEMORY_PARAMETER_SEMANTICS" in src
              and "PERSISTED_REPRESENTATION" in src,
        {"persisted_shape": V2_PARAM_SCHEMA["v2_raw_temporal_rho"]})
    # F10: exclusive RUN_STARTED in temp dir (DEFECT_6).
    with tempfile.TemporaryDirectory() as td:
        r1 = acquire_run_started(Path(td), "unit_test_id", extra={"seed": 1})
        r2 = acquire_run_started(Path(td), "unit_test_id", extra={"seed": 1})
        leftovers = [p.name for p in Path(td).iterdir() if p.name.endswith(".tmp")]
        rec("F10", r1["acquired"] and not r2["acquired"] and not leftovers,
            {"first": r1["acquired"], "second": r2["acquired"],
             "second_reason": r2["reason"], "leftover_tmp": leftovers})
    # F11: exception terminal writer (DEFECT_5).
    with tempfile.TemporaryDirectory() as td:
        out = Path(td)
        (out / "RUN_STARTED").write_text("{}", encoding="utf-8")
        res = write_terminal_exception(out, identity="unit", arm="V2_ARM_P1",
                                       num_particles=1, seed=1, cutoff=12,
                                       started_utc="T0", error_repr="boom", steps_completed=0)
        fail_mt = (out / "FAILURE.json").stat().st_mtime_ns
        res_mt = (out / "result.json").stat().st_mtime_ns
        rec("F11", (out / "FAILURE.json").exists() and (out / "result.json").exists()
                   and res_mt >= fail_mt
                   and res["RUN_STARTED_CONSUMED"] is True
                   and res["VALID_V2_G1_RUN"] is False
                   and res["terminal_status"] == "FAILED_EXCEPTION_AFTER_RUN_STARTED",
            {"failure_exists": (out / "FAILURE.json").exists(),
             "result_exists": (out / "result.json").exists(),
             "result_last": res_mt >= fail_mt,
             "terminal_status": res["terminal_status"],
             "RUN_STARTED_CONSUMED": res["RUN_STARTED_CONSUMED"]})
    # F12: on-disk validator positive (complete synthetic run dir, schema ok).
    with tempfile.TemporaryDirectory() as td:
        build_synthetic_run_dir(Path(td))
        v12 = validate_on_disk(Path(td), require_schema=True, require_terminal_result=True)
        rec("F12", v12["PASS"], {"problems": v12["problems"]})
    # F13: on-disk validator negative (missing artifact; bad schema).
    with tempfile.TemporaryDirectory() as td:
        build_synthetic_run_dir(Path(td), omit="checkpoint_history.json")
        v13a = validate_on_disk(Path(td), require_schema=True, require_terminal_result=True)
    with tempfile.TemporaryDirectory() as td:
        build_synthetic_run_dir(Path(td), bad_schema=True)
        v13b = validate_on_disk(Path(td), require_schema=True, require_terminal_result=True)
    rec("F13", (not v13a["PASS"]) and (not v13b["PASS"]),
        {"missing_artifact_problems": v13a["problems"], "bad_schema_problems": v13b["problems"]})
    # F14: validation guard rejection cases (DEFECT_7; hermetic via
    # _validate_validation_auth_content with synthetic auth dicts + temp canary).
    self_sha = sha256(Path(__file__).resolve())
    good_binds = {name: (self_sha if name == "scripts69" else EXPECTED[name])
                  for name in VALIDATION_AUTH_BINDS}
    f14 = {}
    with tempfile.TemporaryDirectory() as td:
        canary_fail = Path(td) / "canary_result.json"
        canary_fail.write_text(json.dumps({"VALID_V2_G1_RUN": False,
                                           "terminal_status": "FAILED_NONFINITE_LOSS"}),
                               encoding="utf-8")
        auth_wrong_ids = {"AUTHORIZED": True,
                          "binds_sha256": dict(good_binds, identities_sha256="deadbeef"),
                          "requires_canary_result": "VALID_V2_G1_RUN"}
        ok_a, reason_a = _validate_validation_auth_content(auth_wrong_ids, root, canary_fail)
        auth_good_ids_bad_canary = {"AUTHORIZED": True,
                                    "binds_sha256": dict(good_binds, identities_sha256=_identities_sha256(root)),
                                    "requires_canary_result": "VALID_V2_G1_RUN"}
        ok_b, reason_b = _validate_validation_auth_content(auth_good_ids_bad_canary, root, canary_fail)
        canary_pass = Path(td) / "canary_result_ok.json"
        canary_pass.write_text(json.dumps({"VALID_V2_G1_RUN": True,
                                           "terminal_status": "COMPLETED_G1_VALID_RUN"}),
                               encoding="utf-8")
        ok_c, reason_c = _validate_validation_auth_content(auth_good_ids_bad_canary, root, canary_pass)
        f14 = {"wrong_identities_refused": (not ok_a) and "identities_sha256" in reason_a,
               "invalid_canary_refused": (not ok_b) and "canary" in reason_b,
               "valid_auth_accepted_contentwise": ok_c and reason_c == "AUTHORIZED"}
    rec("F14", all(f14.values()), f14)
    # F15: canary guard without auth refuses (live, read-only).
    g15 = guard_canary(root)
    rec("F15", bool(g15["refused"]), {"reason": g15["reason"]})
    # F16: validation guard without auth refuses (live, read-only).
    g16 = guard_validation(root)
    rec("F16", bool(g16["refused"]), {"reason": g16["reason"]})
    # F17: preflight creates NO RUN_STARTED + zero identities consumed (live).
    consumed = check_zero_consumed(root)
    run_started_files = []
    if V2_RUNS.exists():
        run_started_files = [str(p.relative_to(V2_RUNS)) for p in V2_RUNS.rglob(RUN_STARTED_NAME)]
    rec("F17", consumed["n_consumed"] == 0 and not run_started_files,
        {"n_consumed": consumed["n_consumed"], "run_started_files": run_started_files})
    # F18: SVI runtime probe counters zero (proves preflight ran no SVI).
    rec("F18", counters["init"] == 0 and counters["update"] == 0
               and counters["stable_update"] == 0, {"counters": counters})
    # F19: frozen chain all 20 sources ok (incl 42M/42N + scripts69 self).
    chain = verify_frozen_chain(root, include_self=True)
    mism = [k for k, v in chain["results"].items() if not v["ok"]]
    rec("F19", chain["ok"], {"n_sources": len(chain["results"]), "mismatches": mism})
    # F20: scientific target unchanged + no authorization created.
    target_ok = chain["results"]["model"]["ok"]
    auths = check_auth_state(root)
    rec("F20", target_ok and auths["ok"],
        {"target_unchanged": target_ok, "authorization_state_ok": auths["ok"],
         "canary_artifact_present": auths["canary_artifact_present"],
         "validation_artifact_present": auths["validation_artifact_present"]})
    ok = all(v["ok"] for v in results.values())
    return {"ok": ok, "results": results}


# ---------------------------------------------------------------------------
# Source-level presence audit (preflight checks 13-18 + fix-presence gates).
# ---------------------------------------------------------------------------
def source_presence_audit(root: Path) -> dict:
    src = Path(__file__).resolve().read_text(encoding="utf-8")

    def pat(rel):
        return "out_dir / " + '"' + rel + '"'

    checks = {
        "svi_constructor": "SVI(" in src,
        "svi_init_call": "svi.init(" in src,
        "svi_update_call": "svi.update(" in src,
        "svi_stable_update_call": "svi.stable_update(" in src,
        "trace_elbo_particles": 'Trace_ELBO(num_particles=entry["num_particles"])' in src,
        "clippedadam_exact": 'ClippedAdam(step_size=TRAINING["learning_rate"], '
                             'clip_norm=TRAINING["clip_norm"])' in src
                             and TRAINING["learning_rate"] == 0.003 and TRAINING["clip_norm"] == 10.0,
        "persistence_save": "save_params(" in src,
        "persistence_roundtrip": "validate_params_roundtrip(" in src,
        "one_shot_guard": "RUN_STARTED" in src and "acquire_run_started(" in src
                          and "os.O_WRONLY | os.O_CREAT | os.O_EXCL" in src,
        "init_to_median_num_samples_5": "init_to_median(num_samples=5)" in src,
        "g1_min_loss_reduction_defined": "G1_MIN_LOSS_REDUCTION = 0.15" in src,
        "stable_update_guard_constant": "NUMPYRO_STABLE_UPDATE_FINITE_OBJECTIVE_AND_GRADIENT_GUARD" in src,
        "exception_terminal_writer": "write_terminal_exception(" in src,
        "validation_identities_binding": "identities_sha256" in src
                                         and "_remaining_identities(" in src,
        "on_disk_schema_validation": "V2_PARAM_SCHEMA" in src and "V2_TOTAL_ELEMENTS" in src,
        "exit_status_mapping": "exit_status_for(" in src,
    }
    # terminal ordering: the LAST result.json write (success path, inside
    # _run_identity_future) must appear after the FIRST artifact writes.
    # Patterns are assembled dynamically so the audit's own literals cannot
    # self-match.
    i_result = src.rfind("atomic_write_json(" + pat("result.json") + ", result)")
    i_npz = src.find(pat("final_svi_params.npz"))
    i_manifest = src.find(pat("final_svi_params_manifest.json"))
    i_ckpt = src.find(pat("checkpoint_history.json"))
    i_persist = src.find(pat("PARAMETER_PERSISTENCE_VALIDATION.json"))
    checks["result_json_written_last"] = bool(
        i_result > 0 and i_result > i_npz and i_result > i_manifest
        and i_result > i_ckpt and i_result > i_persist
    )
    ok = all(checks.values())
    return {"ok": ok, "checks": checks}


# ---------------------------------------------------------------------------
# Runtime SVI probe (proves preflight invoked no SVI calls).
# ---------------------------------------------------------------------------
def _install_svi_probe():
    import numpyro.infer as _inf
    counters = {"init": 0, "update": 0, "stable_update": 0}
    orig = {}
    for name in counters:
        orig[name] = getattr(_inf.SVI, name)

        def _mk(n):
            def wrapper(self, *a, **k):
                counters[n] += 1
                return orig[n](self, *a, **k)
            return wrapper
        setattr(_inf.SVI, name, _mk(name))
    return counters, orig


def _restore_svi(orig):
    import numpyro.infer as _inf
    for name, fn in orig.items():
        setattr(_inf.SVI, name, fn)


# ---------------------------------------------------------------------------
# Replacement preflight unit tests J1..J20 (NO SVI anywhere in here).
# ---------------------------------------------------------------------------
def unit_tests_j1_j20(root: Path, counters: dict | None = None) -> dict:
    if counters is None:
        counters = {"init": 0, "update": 0, "stable_update": 0}
    src = Path(__file__).resolve().read_text(encoding="utf-8")
    results = {}

    def rec(name, ok, detail):
        results[name] = {"ok": bool(ok), "detail": detail}

    # Dynamic assembly so the tests' own literals cannot self-match.
    LOSSES_APPEND = "losses" + ".append" + "(loss)"
    STABLE_UPD = "state, loss = svi" + ".stable_update(state, *args, **kwargs)"
    LOSS_FLOAT = "loss = float" + "(loss)"
    FINITE_EVAL = "finite = bool" + "(jnp.isfinite(loss))"
    FINITE_APPEND = "finite_flags" + ".append(finite)"

    # J1: production training loop contains the real executable fix.
    rec("J1", LOSSES_APPEND in src, {"found_in_source": LOSSES_APPEND in src})

    # J2: exact ordering inside the loop body:
    # stable_update -> loss=float -> losses.append -> finite -> finite_flags.append.
    # rfind() is used so the loops' OWN code lines (which appear AFTER their
    # comment mentions) are selected, preventing comment self-matching.
    loop_start = src.find(STABLE_UPD)
    pats = [STABLE_UPD, LOSS_FLOAT, LOSSES_APPEND, FINITE_EVAL, FINITE_APPEND]
    idxs = [src.rfind(p, loop_start) for p in pats]
    j2_ok = loop_start >= 0 and all(i >= 0 for i in idxs) and idxs == sorted(idxs)
    rec("J2", j2_ok, {"order_ok": j2_ok, "positions": idxs})

    # J3: synthetic 2000-step bookkeeping loop -> len(losses)=2000, len(flags)=2000.
    syn_losses, syn_flags, syn_steps = [], [], 0
    for step in range(2000):
        lv = float(step * 1e-3)
        syn_losses.append(lv)
        syn_flags.append(bool(np.isfinite(lv)))
        syn_steps = step + 1
    rec("J3", len(syn_losses) == 2000 and len(syn_flags) == 2000 and syn_steps == 2000,
        {"n_losses": len(syn_losses), "n_flags": len(syn_flags), "steps": syn_steps})

    # J4: synthetic checkpoint window at step 100 is non-empty.
    win100 = [l for l, f in zip(syn_losses[-100:], syn_flags[-100:]) if f]
    rec("J4", len(win100) == 100, {"window_len": len(win100)})

    # J5: synthetic checkpoint means are finite when losses finite.
    mean100 = float(np.mean(win100))
    rec("J5", bool(np.isfinite(mean100)), {"mean": mean100})

    # J6: synthetic early-stopping mechanism can actually trigger.
    patience_count, prev_ckpt_loss, triggered = 0, None, False
    es_tol = TRAINING["early_stop_relative_tolerance"]
    es_patience = TRAINING["early_stop_patience_checkpoints"]
    es_min_idx = TRAINING["minimum_steps_before_early_stopping"] // TRAINING["checkpoint_interval"]
    ckpt_means = [1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]
    for i, ckpt in enumerate(ckpt_means):
        if i >= es_min_idx and prev_ckpt_loss is not None:
            denom = max(abs(prev_ckpt_loss), 1e-12)
            rel_improve = (prev_ckpt_loss - ckpt) / denom
            patience_count = patience_count + 1 if rel_improve < es_tol else 0
            if patience_count >= es_patience:
                triggered = True
                break
        prev_ckpt_loss = ckpt
    rec("J6", triggered, {"patience_count": patience_count, "triggered": triggered})

    # J7: initial_loss / terminal_loss extraction succeeds.
    i7 = float(syn_losses[0])
    t7 = float(syn_losses[-1])
    rec("J7", bool(np.isfinite(i7)) and bool(np.isfinite(t7)),
        {"initial_loss": i7, "terminal_loss": t7})

    # J8: loss-reduction calculation succeeds.
    lr8 = (i7 - t7) / max(abs(i7), 1e-12)
    rec("J8", bool(np.isfinite(lr8)), {"loss_reduction_fraction": lr8})

    # J9: post-loop training recovery artifact positive test (temp dir).
    with tempfile.TemporaryDirectory() as td:
        write_postloop_training_recovery(
            Path(td), identity=REPLACEMENT_CANARY_IDENTITY["identity"],
            steps_completed=2000, early_stop_reason="max_steps_reached",
            initial_loss=i7, terminal_loss=t7, loss_reduction_fraction=lr8,
            nonfinite_steps=0, losses=syn_losses, finite_flags=syn_flags,
            created_utc="T0")
        npz_p = Path(td) / "postloop_training_recovery.npz"
        js_p = Path(td) / "postloop_training_recovery.json"
        js = json.loads(js_p.read_text(encoding="utf-8")) if js_p.exists() else {}
        with np.load(npz_p) as z:
            n_loss = int(z["losses"].size)
            n_flags = int(z["finite_flags"].size)
        rec("J9", npz_p.exists() and js_p.exists() and n_loss == 2000 and n_flags == 2000
                 and js.get("steps_completed") == 2000
                 and js.get("loss_reduction_fraction") == float(lr8)
                 and js.get("nonfinite_gradient_or_loss_steps") == 0,
            {"n_losses": n_loss, "n_flags": n_flags, "json_fields": sorted(js.keys())})

    # J10: post-loop final-params recovery schema: 7 params / 13377 elements.
    with tempfile.TemporaryDirectory() as td:
        fake = {k: np.zeros(s) for k, s in V2_PARAM_SCHEMA.items()}
        fake["v2_raw_temporal_rho"] = np.float64(0.0)  # in-memory scalar (0-d)
        write_postloop_final_params_recovery(Path(td), fake)
        with np.load(Path(td) / "postloop_final_params_recovery.npz") as z:
            keys = sorted(z.files)
            total = sum(int(z[k].size) for k in z.files)
        rec("J10", keys == sorted(V2_PARAM_SCHEMA.keys()) and total == V2_TOTAL_ELEMENTS,
            {"n_params": len(keys), "total_elements": total})

    # J11: exception writer includes traceback.
    with tempfile.TemporaryDirectory() as td:
        out = Path(td)
        (out / "RUN_STARTED").write_text("{}", encoding="utf-8")
        try:
            raise RuntimeError("j11-dummy")
        except RuntimeError:
            write_terminal_exception(out, identity="unit", arm="V2_ARM_P1",
                                     num_particles=1, seed=2002, cutoff=12,
                                     started_utc="T0", error_repr="j11-dummy",
                                     steps_completed=0)
        fail = json.loads((out / "FAILURE.json").read_text(encoding="utf-8"))
        rec("J11", "traceback" in fail and "error_repr" in fail
                   and "j11-dummy" in fail.get("error_repr", "")
                   and (out / "result.json").exists(),
            {"failure_keys": sorted(fail.keys()),
             "traceback_present": "traceback" in fail,
             "result_exists": (out / "result.json").exists()})

    # J12: seed1001 RUN_STARTED is recognized as consumed (live).
    consumed1001 = _identity_consumed(CANARY_IDENTITY["identity"])
    rd1001 = V2_RUNS / CANARY_IDENTITY["identity"]
    rec("J12", consumed1001 and (rd1001 / "result.json").exists(),
        {"seed1001_consumed": consumed1001,
         "seed1001_result_exists": (rd1001 / "result.json").exists()})

    # J13: replacement canary identity exactly
    # V2_V2_ARM_P1_p1_seed2002_t12 | particles=1 | seed=2002 | cutoff=12.
    exp13 = {"identity": "V2_V2_ARM_P1_p1_seed2002_t12", "arm": "V2_ARM_P1",
             "num_particles": 1, "seed": 2002, "cutoff": 12}
    rec("J13", REPLACEMENT_CANARY_IDENTITY == exp13, {"identity": REPLACEMENT_CANARY_IDENTITY})

    # J14: old seed1001 authorization does NOT authorize replacement-canary.
    old_auth = _auth_artifact(CANARY_AUTH_PATH)
    if old_auth is not None:
        ok14, reason14 = _validate_replacement_auth_content(old_auth, root)
    else:
        ok14, reason14 = False, "old seed1001 authorization artifact missing"
    rec("J14", old_auth is not None and not ok14,
        {"old_scope": old_auth.get("authorization_scope") if old_auth else None,
         "rejected_reason": reason14})

    # J15: replacement-canary without new authorization refuses (live, read-only).
    g15 = guard_replacement_canary(root)
    rec("J15", bool(g15["refused"]), {"reason": g15["reason"]})

    # J16: validation remains unauthorized (live, read-only).
    g16 = guard_validation(root)
    rec("J16", bool(g16["refused"]), {"reason": g16["reason"]})

    # J17: replacement preflight does not create RUN_STARTED (seed2002).
    rec("J17", not _identity_consumed(REPLACEMENT_CANARY_IDENTITY["identity"]),
        {"seed2002_run_started_exists": _identity_consumed(REPLACEMENT_CANARY_IDENTITY["identity"])})

    # J18: seed2002 remains unconsumed before authorization (live).
    rec("J18", not (V2_RUNS / REPLACEMENT_CANARY_IDENTITY["identity"]).exists(),
        {"seed2002_dir_exists": (V2_RUNS / REPLACEMENT_CANARY_IDENTITY["identity"]).exists()})

    # J19: frozen scientific SHA chain unchanged.
    chain19 = verify_frozen_chain(root, include_self=True)
    mism19 = [k for k, v in chain19["results"].items() if not v["ok"]]
    rec("J19", chain19["ok"], {"n_sources": len(chain19["results"]), "mismatches": mism19})

    # J20: SVI init/update/stable_update runtime counters all zero during preflight.
    rec("J20", counters["init"] == 0 and counters["update"] == 0
               and counters["stable_update"] == 0, {"counters": counters})

    ok = all(v["ok"] for v in results.values())
    return {"ok": ok, "results": results}


def check_recovery_consumed_state(root: Path) -> dict:
    """Remaining-7 context consumption check: seed1001 + seed2002 + seed3003
    consumed (historical, expected), the seven remaining identities all
    unconsumed (required)."""
    j42 = load_json(FROZEN_PATHS["42J"])
    identities = [r["identity"] for r in j42["4_run_matrix"]["identities"]]
    consumed = [i for i in identities if _identity_consumed(i)]
    expected = sorted([CANARY_IDENTITY["identity"],
                       REPLACEMENT_CANARY_IDENTITY["identity"],
                       THIRD_CANARY_IDENTITY["identity"]])
    remaining = _remaining_identities(root)
    remaining_unconsumed = all(not _identity_consumed(r["identity"]) for r in remaining)
    ok = (sorted(consumed) == expected) and remaining_unconsumed
    return {"ok": ok, "consumed": consumed, "n_consumed": len(consumed),
            "n_remaining": len(remaining), "remaining_unconsumed": remaining_unconsumed}


def check_recovery_auth_state(root: Path) -> dict:
    """Resumable-7 context authorization state: seed1001/seed2002/seed3003 auth
    artifacts PRESENT (historical), legacy scripts73 validation auth PRESENT
    (historical), NEW resumable validation auth ABSENT (created only after
    preflight PASS)."""
    ca = _auth_artifact(CANARY_AUTH_PATH)
    ra = _auth_artifact(REPLACEMENT_CANARY_AUTH_PATH)
    ta = _auth_artifact(THIRD_CANARY_AUTH_PATH)
    lva = _auth_artifact(LEGACY_VALIDATION_AUTH_PATH)
    va = _auth_artifact(VALIDATION_AUTH_PATH)
    ok = (ca is not None) and (ra is not None) and (ta is not None) \
        and (lva is not None) and (va is None)
    return {"ok": ok, "canary_artifact_present": ca is not None,
            "replacement_artifact_present": ra is not None,
            "third_artifact_present": ta is not None,
            "legacy_validation_artifact_present": lva is not None,
            "resumable_validation_artifact_present": va is not None}


# ---------------------------------------------------------------------------
# Third-canary preflight unit tests K1..K20 (NO SVI anywhere in here).
# ---------------------------------------------------------------------------
def unit_tests_k1_k20(root: Path, counters: dict | None = None) -> dict:
    if counters is None:
        counters = {"init": 0, "update": 0, "stable_update": 0}
    src = Path(__file__).resolve().read_text(encoding="utf-8")
    results = {}

    def rec(name, ok, detail):
        results[name] = {"ok": bool(ok), "detail": detail}

    LOSSES_APPEND = "losses" + ".append" + "(loss)"
    STABLE_UPD = "state, loss = svi" + ".stable_update(state, *args, **kwargs)"
    LOSS_FLOAT = "loss = float" + "(loss)"
    FINITE_EVAL = "finite = bool" + "(jnp.isfinite(loss))"
    FINITE_APPEND = "finite_flags" + ".append(finite)"

    # K1: scripts70 SHA unchanged (immutable).
    live70 = sha256(ROOT / "scripts/70_run_phase3c4v_v2_g1_execution_recovery.py")
    rec("K1", live70 == SCRIPTS70_EXPECTED_SHA,
        {"expected": SCRIPTS70_EXPECTED_SHA, "live": live70})

    # K2: scripts71 identity = seed3003 exact.
    exp2 = {"identity": "V2_V2_ARM_P1_p1_seed3003_t12", "arm": "V2_ARM_P1",
            "num_particles": 1, "seed": 3003, "cutoff": 12}
    rec("K2", THIRD_CANARY_IDENTITY == exp2, {"identity": THIRD_CANARY_IDENTITY})

    # K3: scientific SHA chain unchanged.
    chain3 = verify_frozen_chain(root, include_self=True)
    mism3 = [k for k, v in chain3["results"].items() if not v["ok"]]
    rec("K3", chain3["ok"], {"n_sources": len(chain3["results"]), "mismatches": mism3})

    # K4: losses.append exists in the production loop path (exact ordering).
    loop_start = src.find(STABLE_UPD)
    pats4 = [STABLE_UPD, LOSS_FLOAT, LOSSES_APPEND, FINITE_EVAL, FINITE_APPEND]
    idxs4 = [src.rfind(p, loop_start) for p in pats4]
    rec("K4", loop_start >= 0 and all(i >= 0 for i in idxs4) and idxs4 == sorted(idxs4),
        {"order_ok": idxs4 == sorted(idxs4), "positions": idxs4})

    # K5: post-loop recovery artifacts implemented (positive temp-dir tests).
    with tempfile.TemporaryDirectory() as td:
        lv = [float(i * 1e-3) for i in range(2000)]
        fg = [True] * 2000
        write_postloop_training_recovery(
            Path(td), identity=THIRD_CANARY_IDENTITY["identity"], steps_completed=2000,
            early_stop_reason="max_steps_reached", initial_loss=0.0, terminal_loss=1.999,
            loss_reduction_fraction=-1.999, nonfinite_steps=0, losses=lv, finite_flags=fg,
            created_utc="T0")
        with np.load(Path(td) / "postloop_training_recovery.npz") as z:
            n5 = (int(z["losses"].size), int(z["finite_flags"].size))
        fake = {k: np.zeros(s) for k, s in V2_PARAM_SCHEMA.items()}
        fake["v2_raw_temporal_rho"] = np.float64(0.0)
        write_postloop_final_params_recovery(Path(td), fake)
        with np.load(Path(td) / "postloop_final_params_recovery.npz") as z:
            n5_params = len(z.files)
            tot5 = sum(int(z[k].size) for k in z.files)
        rec("K5", n5 == (2000, 2000) and n5_params == 7 and tot5 == V2_TOTAL_ELEMENTS,
            {"train_sizes": n5, "final_params": n5_params, "total": tot5})

    # K6: full traceback capture implemented.
    with tempfile.TemporaryDirectory() as td:
        out = Path(td)
        (out / "RUN_STARTED").write_text("{}", encoding="utf-8")
        try:
            raise RuntimeError("k6-dummy")
        except RuntimeError:
            write_terminal_exception(out, identity="unit", arm="V2_ARM_P1",
                                     num_particles=1, seed=3003, cutoff=12,
                                     started_utc="T0", error_repr="k6-dummy",
                                     steps_completed=0)
        fail = json.loads((out / "FAILURE.json").read_text(encoding="utf-8"))
        rec("K6", "traceback" in fail and "error_repr" in fail
                  and "k6-dummy" in fail.get("error_repr", "")
                  and (out / "result.json").exists(),
            {"failure_keys": sorted(fail.keys())})

    # K7: seed1001 consumed (live).
    c1001 = _identity_consumed(CANARY_IDENTITY["identity"])
    rec("K7", c1001, {"seed1001_consumed": c1001})

    # K8: seed2002 consumed (live).
    c2002 = _identity_consumed(REPLACEMENT_CANARY_IDENTITY["identity"])
    rec("K8", c2002, {"seed2002_consumed": c2002})

    # K9: seed3003 unconsumed (live).
    c3003 = _identity_consumed(THIRD_CANARY_IDENTITY["identity"])
    rec("K9", not c3003, {"seed3003_consumed": c3003})

    # K10: old authorizations reject seed3003.
    old1 = _auth_artifact(CANARY_AUTH_PATH)
    old2 = _auth_artifact(REPLACEMENT_CANARY_AUTH_PATH)
    r1 = _validate_third_auth_content(old1, root) if old1 is not None else (False, "old1 missing")
    r2 = _validate_third_auth_content(old2, root) if old2 is not None else (False, "old2 missing")
    rec("K10", old1 is not None and old2 is not None and (not r1[0]) and (not r2[0]),
        {"seed1001_auth_rejects": not r1[0], "seed1001_reason": r1[1],
         "seed2002_auth_rejects": not r2[0], "seed2002_reason": r2[1]})

    # K11: third-canary without new auth rejects (live, read-only).
    g11 = guard_third_canary(root)
    rec("K11", bool(g11["refused"]), {"reason": g11["reason"]})

    # K12: validation unauthorized (live, read-only).
    g12 = guard_validation(root)
    rec("K12", bool(g12["refused"]), {"reason": g12["reason"]})

    # K13: no RUN_STARTED created for seed3003.
    rec("K13", not _identity_consumed(THIRD_CANARY_IDENTITY["identity"]),
        {"seed3003_run_started_exists": _identity_consumed(THIRD_CANARY_IDENTITY["identity"])})

    # K14: no SVI calls during preflight.
    rec("K14", counters["init"] == 0 and counters["update"] == 0
               and counters["stable_update"] == 0, {"counters": counters})

    # K15: original frozen training protocol exact.
    proto_ok = (
        TRAINING["objective"] == "Trace_ELBO"
        and TRAINING["optimizer"] == "ClippedAdam"
        and TRAINING["learning_rate"] == 0.003
        and TRAINING["clip_norm"] == 10.0
        and TRAINING["maximum_steps"] == 2000
        and TRAINING["minimum_steps_before_early_stopping"] == 500
        and TRAINING["checkpoint_interval"] == 100
        and TRAINING["early_stop_relative_tolerance"] == 1e-4
        and TRAINING["early_stop_patience_checkpoints"] == 5
        and G1_MIN_LOSS_REDUCTION == 0.15
        and "init_to_median(num_samples=5)" in src
        and 'Trace_ELBO(num_particles=entry["num_particles"])' in src
        and 'ClippedAdam(step_size=TRAINING["learning_rate"], ' in src
    )
    rec("K15", proto_ok, {"TRAINING": TRAINING, "G1_MIN_LOSS_REDUCTION": G1_MIN_LOSS_REDUCTION})

    # K16: validation remaining identities exactly 7.
    rem = _remaining_identities(root)
    rec("K16", len(rem) == 7, {"n_remaining": len(rem),
                               "identities": [r["identity"] for r in rem]})

    # K17: scripts72 syntax check PASS (bash -n; execution-environment only).
    s72 = ROOT / "scripts/72_launch_v2_seed3003_detached.sh"
    if s72.exists():
        cp = subprocess.run(["bash", "-n", str(s72)], capture_output=True, text=True)
        k17 = cp.returncode == 0
        k17_detail = {"returncode": cp.returncode, "stderr": cp.stderr.strip()}
    else:
        k17, k17_detail = False, "scripts72 missing"
    rec("K17", k17, k17_detail)

    # K18: scripts72 contains caffeinate.
    s72src = s72.read_text(encoding="utf-8") if s72.exists() else ""
    rec("K18", "caffeinate" in s72src, {"found": "caffeinate" in s72src})

    # K19: scripts72 contains nohup.
    rec("K19", "nohup" in s72src, {"found": "nohup" in s72src})

    # K20: scripts72 itself has NOT been executed (no launcher artifacts).
    log_dir = ROOT / "results/phase3c4v_v2/runtime_logs"
    launcher_ran = False
    if log_dir.exists():
        launcher_ran = any((log_dir / n).exists() for n in (
            "seed3003_launcher.pid", "seed3003_console.log",
            "seed3003_runtime.log", "seed3003_launch_timestamp.txt"))
    rec("K20", (not launcher_ran) and (not _identity_consumed(THIRD_CANARY_IDENTITY["identity"])),
        {"launcher_ran": launcher_ran,
         "seed3003_run_started_exists": _identity_consumed(THIRD_CANARY_IDENTITY["identity"])})

    ok = all(v["ok"] for v in results.values())
    return {"ok": ok, "results": results}


# ---------------------------------------------------------------------------
# Remaining-7 validation preflight unit tests L1..L25 (NO SVI anywhere in here).
# ---------------------------------------------------------------------------
def unit_tests_l1_l25(root: Path, counters: dict | None = None) -> dict:
    if counters is None:
        counters = {"init": 0, "update": 0, "stable_update": 0}
    src = Path(__file__).resolve().read_text(encoding="utf-8")
    results = {}

    def rec(name, ok, detail):
        results[name] = {"ok": bool(ok), "detail": detail}

    LOSSES_APPEND = "losses" + ".append" + "(loss)"
    STABLE_UPD = "state, loss = svi" + ".stable_update(state, *args, **kwargs)"
    LOSS_FLOAT = "loss = float" + "(loss)"
    FINITE_EVAL = "finite = bool" + "(jnp.isfinite(loss))"
    FINITE_APPEND = "finite_flags" + ".append(finite)"

    s3003 = ROOT / SEED3003_RESULT_REL
    r3003 = json.loads(s3003.read_text(encoding="utf-8")) if s3003.exists() else {}

    # L1: 42V classification == V2_G1_VALID_CANARY_ACCEPTED.
    v42 = json.loads((ROOT / RECOVERY_AUDIT_PATHS["42V"]).read_text(encoding="utf-8"))
    rec("L1", v42.get("classification") == "V2_G1_VALID_CANARY_ACCEPTED",
        {"classification": v42.get("classification")})

    # L2: seed3003 result exists and is G1 valid.
    valid_terminal = r3003.get("terminal_status") in (
        "COMPLETED_G1_VALID_RUN", "COMPLETED_EARLY_STOPPED_G1_VALID")
    rec("L2", s3003.exists() and valid_terminal and bool(r3003.get("VALID_V2_G1_RUN", False)),
        {"exists": s3003.exists(), "terminal_status": r3003.get("terminal_status"),
         "VALID_V2_G1_RUN": r3003.get("VALID_V2_G1_RUN")})

    # L3: seed3003 runner SHA exact (scripts71).
    rec("L3", r3003.get("runner_sha256") == SCRIPTS71_EXPECTED_SHA,
        {"expected": SCRIPTS71_EXPECTED_SHA, "live": r3003.get("runner_sha256")})

    # L4: seed3003 guide SHA exact.
    rec("L4", r3003.get("guide_sha256") == EXPECTED["guide_fix"],
        {"expected": EXPECTED["guide_fix"], "live": r3003.get("guide_sha256")})

    # L5: seed3003 persistence PASS.
    rec("L5", r3003.get("parameter_persistence_status") == "PASS"
              and bool(r3003.get("on_disk_validation", {}).get("PASS", False)),
        {"persistence": r3003.get("parameter_persistence_status"),
         "on_disk": r3003.get("on_disk_validation")})

    # L6: scripts71 SHA unchanged.
    live71 = sha256(ROOT / "scripts/71_run_phase3c4v_v2_g1_third_canary.py")
    rec("L6", live71 == SCRIPTS71_EXPECTED_SHA,
        {"expected": SCRIPTS71_EXPECTED_SHA, "live": live71})

    # L7: scripts73 scientific protocol exact.
    proto_ok = (
        TRAINING["objective"] == "Trace_ELBO"
        and TRAINING["optimizer"] == "ClippedAdam"
        and TRAINING["learning_rate"] == 0.003
        and TRAINING["clip_norm"] == 10.0
        and TRAINING["maximum_steps"] == 2000
        and TRAINING["minimum_steps_before_early_stopping"] == 500
        and TRAINING["checkpoint_interval"] == 100
        and TRAINING["early_stop_relative_tolerance"] == 1e-4
        and TRAINING["early_stop_patience_checkpoints"] == 5
        and G1_MIN_LOSS_REDUCTION == 0.15
        and "init_to_median(num_samples=5)" in src
        and 'Trace_ELBO(num_particles=entry["num_particles"])' in src
        and 'ClippedAdam(step_size=TRAINING["learning_rate"], ' in src
    )
    rec("L7", proto_ok, {"TRAINING": TRAINING, "G1_MIN_LOSS_REDUCTION": G1_MIN_LOSS_REDUCTION})

    # L8/L9: remaining identities count == 7 and exact 42J-order list.
    rem = _remaining_identities(root)
    expected_order = [
        "V2_V2_ARM_P1_p1_seed4004_t12", "V2_V2_ARM_P1_p1_seed5005_t12",
        "V2_V2_ARM_P4_p4_seed1001_t12", "V2_V2_ARM_P4_p4_seed2002_t12",
        "V2_V2_ARM_P4_p4_seed3003_t12", "V2_V2_ARM_P4_p4_seed4004_t12",
        "V2_V2_ARM_P4_p4_seed5005_t12",
    ]
    got_order = [r["identity"] for r in rem]
    rec("L8", len(rem) == 7, {"n_remaining": len(rem)})
    rec("L9", got_order == expected_order, {"got": got_order, "expected": expected_order})

    # L10: P1 seed1001/2002/3003 excluded.
    excluded = {CANARY_IDENTITY["identity"], REPLACEMENT_CANARY_IDENTITY["identity"],
                THIRD_CANARY_IDENTITY["identity"]}
    rec("L10", not (set(got_order) & excluded), {"excluded": sorted(excluded)})

    # L11: P1 seed4004/5005 unconsumed (live).
    p1_left = [r for r in rem if r["arm"] == "V2_ARM_P1"]
    rec("L11", all(not _identity_consumed(r["identity"]) for r in p1_left),
        {"p1_left_unconsumed": [r["identity"] for r in p1_left]})

    # L12: all five P4 identities unconsumed (live).
    p4 = [r for r in rem if r["arm"] == "V2_ARM_P4"]
    rec("L12", len(p4) == 5 and all(not _identity_consumed(r["identity"]) for r in p4),
        {"p4_unconsumed": [r["identity"] for r in p4]})

    # L13: validation guard references seed3003, NOT seed1001.
    # Patterns assembled dynamically so the test's own literals cannot self-match.
    P_VALID = 'V2_RUNS / VALID_G1_CANARY_IDENTITY["identity"] / ' + '"result.json"'
    P_SEED1001 = 'V2_RUNS / CANARY_IDENTITY["identity"] / ' + '"result.json"'
    uses_valid = P_VALID in src
    uses_seed1001 = P_SEED1001 in src
    rec("L13", uses_valid and (not uses_seed1001),
        {"uses_valid_g1_canary": uses_valid, "uses_seed1001": uses_seed1001})

    # L14: old canary authorizations alone do NOT authorize validation.
    old_auths = [_auth_artifact(CANARY_AUTH_PATH),
                 _auth_artifact(REPLACEMENT_CANARY_AUTH_PATH),
                 _auth_artifact(THIRD_CANARY_AUTH_PATH)]
    rejects = []
    for a in old_auths:
        if a is not None:
            ok_a, reason_a = _validate_validation_auth_content(a, root)
            rejects.append((not ok_a, reason_a))
    rec("L14", len(old_auths) == 3 and all(rej[0] for rej in rejects),
        {"rejections": [r[1] for r in rejects]})

    # L15: validation without new authorization refuses (live, read-only).
    g15 = guard_validation(root)
    rec("L15", bool(g15["refused"]), {"reason": g15["reason"]})

    # L16: losses.append present in production loop path (exact ordering).
    loop_start = src.find(STABLE_UPD)
    pats16 = [STABLE_UPD, LOSS_FLOAT, LOSSES_APPEND, FINITE_EVAL, FINITE_APPEND]
    idxs16 = [src.rfind(p, loop_start) for p in pats16]
    rec("L16", loop_start >= 0 and all(i >= 0 for i in idxs16) and idxs16 == sorted(idxs16),
        {"order_ok": idxs16 == sorted(idxs16)})

    # L17: recovery artifacts present in production path (positive temp test).
    with tempfile.TemporaryDirectory() as td:
        lv = [float(i * 1e-3) for i in range(2000)]
        fg = [True] * 2000
        write_postloop_training_recovery(
            Path(td), identity="unit", steps_completed=2000,
            early_stop_reason="max_steps_reached", initial_loss=0.0,
            terminal_loss=1.999, loss_reduction_fraction=-1.999,
            nonfinite_steps=0, losses=lv, finite_flags=fg, created_utc="T0")
        fake = {k: np.zeros(s) for k, s in V2_PARAM_SCHEMA.items()}
        fake["v2_raw_temporal_rho"] = np.float64(0.0)
        write_postloop_final_params_recovery(Path(td), fake)
        with np.load(Path(td) / "postloop_final_params_recovery.npz") as z:
            n17 = len(z.files)
            tot17 = sum(int(z[k].size) for k in z.files)
        src_ok17 = ("postloop_training_recovery" in src) and ("postloop_final_params_recovery" in src)
        rec("L17", src_ok17 and (Path(td) / "postloop_training_recovery.npz").exists()
                   and n17 == 7 and tot17 == V2_TOTAL_ELEMENTS,
            {"src_present": src_ok17, "final_params": n17, "total": tot17})

    # L18: O_EXCL one-shot guard present.
    rec("L18", "os.O_WRONLY | os.O_CREAT | os.O_EXCL" in src,
        {"found": "os.O_WRONLY | os.O_CREAT | os.O_EXCL" in src})

    # L19: scripts74 bash syntax PASS.
    s74 = ROOT / "scripts/74_launch_v2_g1_remaining7_detached.sh"
    if s74.exists():
        cp = subprocess.run(["bash", "-n", str(s74)], capture_output=True, text=True)
        k19 = cp.returncode == 0
        d19 = {"returncode": cp.returncode, "stderr": cp.stderr.strip()}
    else:
        k19, d19 = False, "scripts74 missing"
    rec("L19", k19, d19)

    # L20: scripts74 contains caffeinate + nohup.
    s74src = s74.read_text(encoding="utf-8") if s74.exists() else ""
    rec("L20", "caffeinate" in s74src and "nohup" in s74src,
        {"caffeinate": "caffeinate" in s74src, "nohup": "nohup" in s74src})

    # L21: scripts74 has not executed (no remaining7 launcher artifacts).
    log_dir = ROOT / "results/phase3c4v_v2/runtime_logs"
    launcher_ran = False
    if log_dir.exists():
        launcher_ran = any((log_dir / n).exists() for n in (
            "remaining7_launcher.pid", "remaining7_console.log",
            "remaining7_runtime.log", "remaining7_launch_timestamp.txt"))
    rec("L21", not launcher_ran, {"launcher_ran": launcher_ran})

    # L22: no SVI calls during preflight.
    rec("L22", counters["init"] == 0 and counters["update"] == 0
               and counters["stable_update"] == 0, {"counters": counters})

    # L23: no new RUN_STARTED generated by preflight (seven remain unconsumed).
    rem_unconsumed = all(not _identity_consumed(r["identity"]) for r in rem)
    rec("L23", rem_unconsumed, {"remaining_unconsumed": rem_unconsumed})

    # L24: scientific target SHA unchanged.
    chain24 = verify_frozen_chain(root, include_self=True)
    rec("L24", chain24["results"]["model"]["ok"],
        {"model_live": chain24["results"]["model"]["live"]})

    # L25: frozen guide SHA unchanged.
    rec("L25", chain24["results"]["guide_fix"]["ok"],
        {"guide_live": chain24["results"]["guide_fix"]["live"]})

    ok = all(v["ok"] for v in results.values())
    return {"ok": ok, "results": results}


# ---------------------------------------------------------------------------
# Resumable-7 preflight unit tests M1..M27 (NO SVI anywhere in here).
# ---------------------------------------------------------------------------
def unit_tests_m1_m27(root: Path, counters: dict | None = None) -> dict:
    if counters is None:
        counters = {"init": 0, "update": 0, "stable_update": 0}
    src = Path(__file__).resolve().read_text(encoding="utf-8")
    results = {}

    def rec(name, ok, detail):
        results[name] = {"ok": bool(ok), "detail": detail}

    LOSSES_APPEND = "losses" + ".append" + "(loss)"
    STABLE_UPD = "state, loss = svi" + ".stable_update(state, *args, **kwargs)"
    LOSS_FLOAT = "loss = float" + "(loss)"
    FINITE_EVAL = "finite = bool" + "(jnp.isfinite(loss))"
    FINITE_APPEND = "finite_flags" + ".append(finite)"

    def _live_sha_for(name: str) -> str:
        if name == "scripts75":
            return sha256(Path(__file__).resolve())
        if name == "scripts73":
            return sha256(ROOT / "scripts/73_run_phase3c4v_v2_g1_remaining_validation.py")
        if name == "scripts71":
            return sha256(ROOT / "scripts/71_run_phase3c4v_v2_g1_third_canary.py")
        if name == "seed3003_result":
            return sha256(ROOT / SEED3003_RESULT_REL)
        if name in RECOVERY_AUDIT_PATHS:
            return sha256(ROOT / RECOVERY_AUDIT_PATHS[name])
        return EXPECTED.get(name) or ""

    def _mk_synth(runs_dir: Path, entry: dict, *, valid: bool = False,
                  run_started: bool = True, result_json: bool = True) -> None:
        rd = runs_dir / entry["identity"]
        rd.mkdir(parents=True, exist_ok=True)
        if run_started:
            (rd / "RUN_STARTED").write_text("{}", encoding="utf-8")
        if result_json:
            if valid:
                res = {
                    "VALID_V2_G1_RUN": True,
                    "terminal_status": "COMPLETED_G1_VALID_RUN",
                    "nonfinite_loss_steps": 0,
                    "all_params_finite": True,
                    "required_diagnostics_present": True,
                    "parameter_persistence_status": "PASS",
                    "on_disk_validation": {"PASS": True},
                    "total_parameter_elements": V2_TOTAL_ELEMENTS,
                    "steps_completed": 2000,
                    "loss_reduction_fraction": 0.5,
                    "identity": entry["identity"],
                    "seed": entry["seed"],
                    "num_particles": entry["num_particles"],
                    "cutoff": entry["cutoff"],
                }
            else:
                res = {"VALID_V2_G1_RUN": False, "terminal_status": "FAILED_NONFINITE_LOSS",
                       "total_parameter_elements": V2_TOTAL_ELEMENTS}
            (rd / "result.json").write_text(json.dumps(res), encoding="utf-8")

    rem = _remaining_identities(root)
    expected_order = [
        "V2_V2_ARM_P1_p1_seed4004_t12", "V2_V2_ARM_P1_p1_seed5005_t12",
        "V2_V2_ARM_P4_p4_seed1001_t12", "V2_V2_ARM_P4_p4_seed2002_t12",
        "V2_V2_ARM_P4_p4_seed3003_t12", "V2_V2_ARM_P4_p4_seed4004_t12",
        "V2_V2_ARM_P4_p4_seed5005_t12",
    ]
    got_order = [r["identity"] for r in rem]

    # M1: 42V accepted.
    v42 = json.loads((ROOT / RECOVERY_AUDIT_PATHS["42V"]).read_text(encoding="utf-8"))
    rec("M1", v42.get("classification") == "V2_G1_VALID_CANARY_ACCEPTED",
        {"classification": v42.get("classification")})

    # M2: 42W PASS.
    w42 = json.loads((ROOT / RECOVERY_AUDIT_PATHS["42W"]).read_text(encoding="utf-8"))
    rec("M2", w42.get("classification") == "V2_G1_REMAINING7_VALIDATION_PREFLIGHT_PASS",
        {"classification": w42.get("classification")})

    # M3: scripts73 SHA unchanged.
    live73 = sha256(ROOT / "scripts/73_run_phase3c4v_v2_g1_remaining_validation.py")
    rec("M3", live73 == SCRIPTS73_EXPECTED_SHA,
        {"expected": SCRIPTS73_EXPECTED_SHA, "live": live73})

    # M4: scientific chain unchanged.
    chain4 = verify_frozen_chain(root, include_self=True)
    mism4 = [k for k, v in chain4["results"].items() if not v["ok"]]
    rec("M4", chain4["ok"], {"mismatches": mism4})

    # M5: exact seven identity list.
    rec("M5", got_order == expected_order, {"got": got_order, "expected": expected_order})

    # M6: no current remaining identity consumed (live).
    rec("M6", all(not _identity_consumed(r["identity"]) for r in rem),
        {"consumed_among_seven": [r["identity"] for r in rem if _identity_consumed(r["identity"])]})

    # M7: fresh-state classification = seven PENDING_UNCONSUMED.
    rec("M7", all(classify_identity_state(r) == "PENDING_UNCONSUMED" for r in rem),
        {"states": [classify_identity_state(r) for r in rem]})

    # M8: synthetic completed-valid skip works (identity1 valid -> execute 2..7).
    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "runs"
        _mk_synth(base, rem[0], valid=True)
        plan8 = compute_batch_plan(rem, runs_dir=base)
        rec("M8", plan8[0][0] == "SKIP_ALREADY_COMPLETED_VALID"
                   and [a for a, _ in plan8[1:]] == ["EXECUTE"] * 6,
            {"plan": [a for a, _ in plan8]})

    # M9: synthetic two-completed-valid resume works (skip 1,2 -> execute 3..7).
    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "runs"
        _mk_synth(base, rem[0], valid=True)
        _mk_synth(base, rem[1], valid=True)
        plan9 = compute_batch_plan(rem, runs_dir=base)
        rec("M9", [a for a, _ in plan9[:2]] == ["SKIP_ALREADY_COMPLETED_VALID"] * 2
                   and [a for a, _ in plan9[2:]] == ["EXECUTE"] * 5,
            {"plan": [a for a, _ in plan9]})

    # M10: synthetic invalid-consumed blocks later execution.
    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "runs"
        _mk_synth(base, rem[0], valid=False)
        plan10 = compute_batch_plan(rem, runs_dir=base)
        rec("M10", plan10 == [("STOP_BLOCKED_BY_CONSUMED_INVALID_OR_INCOMPLETE",
                               "CONSUMED_INVALID_OR_INCOMPLETE")],
            {"plan": [a for a, _ in plan10], "len": len(plan10)})

    # M11: synthetic missing-result RUN_STARTED blocks.
    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "runs"
        _mk_synth(base, rem[0], run_started=True, result_json=False)
        plan11 = compute_batch_plan(rem, runs_dir=base)
        rec("M11", plan11 == [("STOP_BLOCKED_BY_CONSUMED_INVALID_OR_INCOMPLETE",
                               "CONSUMED_INVALID_OR_INCOMPLETE")],
            {"plan": [a for a, _ in plan11]})

    # M12: all-complete case exits cleanly without SVI (plan = all SKIP).
    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "runs"
        for r in rem:
            _mk_synth(base, r, valid=True)
        plan12 = compute_batch_plan(rem, runs_dir=base)
        rec("M12", len(plan12) == 7 and all(a == "SKIP_ALREADY_COMPLETED_VALID" for a, _ in plan12)
                   and all(st == "COMPLETED_VALID" for _, st in plan12),
            {"all_skip": all(a == "SKIP_ALREADY_COMPLETED_VALID" for a, _ in plan12),
             "no_execute": all(a != "EXECUTE" for a, _ in plan12)})

    # M13: progress reconstruction correct.
    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "runs"
        _mk_synth(base, rem[0], valid=True)
        _mk_synth(base, rem[1], valid=True)
        _mk_synth(base, rem[2], valid=False)
        rc = reconstruct_batch_state(root, runs_dir=base)
        rec("M13", rc["planned_count"] == 7 and rc["completed_valid_count"] == 2
                   and rc["consumed_invalid_or_incomplete_count"] == 1
                   and rc["pending_count"] == 4,
            {"planned": rc["planned_count"], "valid": rc["completed_valid_count"],
             "invalid": rc["consumed_invalid_or_incomplete_count"], "pending": rc["pending_count"]})

    # M14: progress does not reset completed-valid history.
    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "runs"
        _mk_synth(base, rem[0], valid=True)
        rc = reconstruct_batch_state(root, runs_dir=base)
        r0 = rc["runs"][0]
        rec("M14", r0["state"] == "COMPLETED_VALID"
                   and r0.get("terminal_status") == "COMPLETED_G1_VALID_RUN"
                   and r0.get("steps_completed") == 2000
                   and r0.get("loss_reduction_fraction") == 0.5
                   and bool(r0.get("result_sha256")),
            {"history_preserved": {k: r0.get(k) for k in
                                   ("state", "terminal_status", "steps_completed",
                                    "loss_reduction_fraction", "result_sha256")}})

    # M15: exact training protocol unchanged.
    proto_ok = (
        TRAINING["objective"] == "Trace_ELBO"
        and TRAINING["optimizer"] == "ClippedAdam"
        and TRAINING["learning_rate"] == 0.003
        and TRAINING["clip_norm"] == 10.0
        and TRAINING["maximum_steps"] == 2000
        and TRAINING["minimum_steps_before_early_stopping"] == 500
        and TRAINING["checkpoint_interval"] == 100
        and TRAINING["early_stop_relative_tolerance"] == 1e-4
        and TRAINING["early_stop_patience_checkpoints"] == 5
        and G1_MIN_LOSS_REDUCTION == 0.15
        and "init_to_median(num_samples=5)" in src
        and 'Trace_ELBO(num_particles=entry["num_particles"])' in src
        and 'ClippedAdam(step_size=TRAINING["learning_rate"], ' in src
    )
    rec("M15", proto_ok, {"TRAINING": TRAINING, "G1_MIN_LOSS_REDUCTION": G1_MIN_LOSS_REDUCTION})

    # M16: losses.append present in production loop path (exact ordering).
    loop_start = src.find(STABLE_UPD)
    pats16 = [STABLE_UPD, LOSS_FLOAT, LOSSES_APPEND, FINITE_EVAL, FINITE_APPEND]
    idxs16 = [src.rfind(p, loop_start) for p in pats16]
    rec("M16", loop_start >= 0 and all(i >= 0 for i in idxs16) and idxs16 == sorted(idxs16),
        {"order_ok": idxs16 == sorted(idxs16)})

    # M17: recovery artifacts present in production path (positive temp test).
    with tempfile.TemporaryDirectory() as td:
        lv = [float(i * 1e-3) for i in range(2000)]
        fg = [True] * 2000
        write_postloop_training_recovery(
            Path(td), identity="unit", steps_completed=2000,
            early_stop_reason="max_steps_reached", initial_loss=0.0,
            terminal_loss=1.999, loss_reduction_fraction=-1.999,
            nonfinite_steps=0, losses=lv, finite_flags=fg, created_utc="T0")
        fake = {k: np.zeros(s) for k, s in V2_PARAM_SCHEMA.items()}
        fake["v2_raw_temporal_rho"] = np.float64(0.0)
        write_postloop_final_params_recovery(Path(td), fake)
        with np.load(Path(td) / "postloop_final_params_recovery.npz") as z:
            n17 = len(z.files)
            tot17 = sum(int(z[k].size) for k in z.files)
        src_ok17 = ("postloop_training_recovery" in src) and ("postloop_final_params_recovery" in src)
        rec("M17", src_ok17 and (Path(td) / "postloop_training_recovery.npz").exists()
                   and n17 == 7 and tot17 == V2_TOTAL_ELEMENTS,
            {"src_present": src_ok17, "final_params": n17, "total": tot17})

    # M18: O_EXCL one-shot guard present.
    rec("M18", "os.O_WRONLY | os.O_CREAT | os.O_EXCL" in src,
        {"found": "os.O_WRONLY | os.O_CREAT | os.O_EXCL" in src})

    # M19: seed3003 valid guard exact (acceptance criteria shared by the
    # validation guard; tested against the REAL seed3003 result + a negative).
    s3003 = ROOT / SEED3003_RESULT_REL
    cr_real = json.loads(s3003.read_text(encoding="utf-8"))
    ok19, failed19 = _valid_canary_acceptance_ok(cr_real)
    cr_bad = dict(cr_real, terminal_status="FAILED_NONFINITE_LOSS", VALID_V2_G1_RUN=False)
    ok19b, _ = _valid_canary_acceptance_ok(cr_bad)
    rec("M19", ok19 and (not failed19) and (not ok19b),
        {"real_acceptance_ok": ok19, "failed_checks": failed19,
         "tampered_rejected": not ok19b})

    # M20: scripts76 bash syntax PASS.
    s76 = ROOT / "scripts/76_launch_v2_g1_remaining7_resumable_detached.sh"
    if s76.exists():
        cp = subprocess.run(["bash", "-n", str(s76)], capture_output=True, text=True)
        k20 = cp.returncode == 0
        d20 = {"returncode": cp.returncode, "stderr": cp.stderr.strip()}
    else:
        k20, d20 = False, "scripts76 missing"
    rec("M20", k20, d20)

    # M21: scripts76 contains caffeinate + nohup.
    s76src = s76.read_text(encoding="utf-8") if s76.exists() else ""
    rec("M21", "caffeinate" in s76src and "nohup" in s76src,
        {"caffeinate": "caffeinate" in s76src, "nohup": "nohup" in s76src})

    # M22: scripts76 has not executed (no remaining7_resumable launcher artifacts).
    log_dir = ROOT / "results/phase3c4v_v2/runtime_logs"
    launcher_ran = False
    if log_dir.exists():
        launcher_ran = any((log_dir / n).exists() for n in (
            "remaining7_resumable_launcher.pid", "remaining7_resumable_console.log",
            "remaining7_resumable_runtime.log", "remaining7_resumable_launch_timestamp.txt"))
    rec("M22", not launcher_ran, {"launcher_ran": launcher_ran})

    # M23: no SVI calls during preflight.
    rec("M23", counters["init"] == 0 and counters["update"] == 0
               and counters["stable_update"] == 0, {"counters": counters})

    # M24: no RUN_STARTED created (live).
    rec("M24", all(not _identity_consumed(r["identity"]) for r in rem),
        {"consumed_among_seven": [r["identity"] for r in rem if _identity_consumed(r["identity"])]})

    # M25: all seven still unconsumed after preflight (live recheck).
    rec("M25", all(not _identity_consumed(r["identity"]) for r in rem),
        {"all_unconsumed": all(not _identity_consumed(r["identity"]) for r in rem)})

    # M26: G2/G3 unauthorized (no G2/G3 authorization artifacts exist).
    g2g3 = []
    if V2_AUTHS.exists():
        g2g3 = [p.name for p in V2_AUTHS.glob("*") if ("G2" in p.name or "G3" in p.name)]
    rec("M26", not g2g3, {"g2g3_auth_artifacts": g2g3})

    # M27: legacy scripts73 authorization does NOT authorize scripts75.
    legacy_auth = _auth_artifact(LEGACY_VALIDATION_AUTH_PATH)
    if legacy_auth is not None:
        ok27, reason27 = _validate_validation_auth_content(legacy_auth, root)
    else:
        ok27, reason27 = False, "legacy auth missing"
    rec("M27", legacy_auth is not None and (not ok27),
        {"legacy_scope": legacy_auth.get("authorization_scope") if legacy_auth else None,
         "rejected_reason": reason27})

    ok = all(v["ok"] for v in results.values())
    return {"ok": ok, "results": results}


# ---------------------------------------------------------------------------
# Preflight (M1..M27 + resumable-7 context readiness; writes 42Y).
# ---------------------------------------------------------------------------
def run_preflight(root: Path, counters: dict | None = None) -> dict:
    chain = verify_frozen_chain(root, include_self=True)
    matrix = check_run_matrix(root)
    consumed = check_recovery_consumed_state(root)
    auths = check_recovery_auth_state(root)
    guards = {
        "validation_refused": bool(guard_validation(root)["refused"]),
        "validation_reason": guard_validation(root)["reason"],
    }
    guards_ok = bool(guards["validation_refused"])
    V2_RUNS.mkdir(parents=True, exist_ok=True)
    V2_AUTHS.mkdir(parents=True, exist_ok=True)
    if counters is None:
        counters = {"init": 0, "update": 0, "stable_update": 0}
    probe = {"SVI_init_called": counters["init"] > 0,
             "SVI_update_called": counters["update"] > 0,
             "SVI_stable_update_called": counters["stable_update"] > 0,
             "counters": counters}
    probe_ok = bool(not probe["SVI_init_called"] and not probe["SVI_update_called"]
                    and not probe["SVI_stable_update_called"])
    unit = unit_tests_m1_m27(root, counters=counters)
    ok = bool(chain["ok"] and matrix["ok"] and consumed["ok"] and auths["ok"]
              and guards_ok and probe_ok and unit["ok"])
    return {
        "ok": ok,
        "chain": chain["results"],
        "run_matrix": matrix["detail"],
        "consumed": consumed,
        "authorizations": auths,
        "negative_guards": guards,
        "unit_tests": unit,
        "svi_runtime_probe": probe,
        "scientific_target_unchanged": chain["results"]["model"]["ok"],
        "namespace": {"runs": str(V2_RUNS), "authorizations": str(V2_AUTHS)},
    }


def cmd_preflight(root: Path) -> int:
    # SVI probe active for the ENTIRE preflight: counters prove zero SVI calls.
    counters, _orig = _install_svi_probe()
    try:
        res = run_preflight(root, counters=counters)
    finally:
        _restore_svi(_orig)
    classification = (
        "V2_G1_REMAINING7_RESUMABLE_VALIDATION_PREFLIGHT_PASS" if res["ok"]
        else "V2_G1_REMAINING7_RESUMABLE_VALIDATION_PREFLIGHT_FAIL"
    )
    c = res["chain"]
    checks = {k: v["ok"] for k, v in res["unit_tests"]["results"].items()}
    checks["OVERALL"] = "PASS" if res["ok"] else "FAIL"
    payload = {
        "artifact_id": "42Y_V2_G1_REMAINING7_RESUMABLE_VALIDATION_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "mode": "V2 G1 REMAINING-7 RESUMABLE VALIDATION PREFLIGHT (M1..M27 "
                "deterministic unit tests; no SVI, no validation execution)",
        "classification": classification,
        "checks": checks,
        "sha_chain": c,
        "run_matrix": res["run_matrix"],
        "consumed_identities": res["consumed"],
        "authorization_state": res["authorizations"],
        "negative_mode_guards": res["negative_guards"],
        "unit_tests": res["unit_tests"]["results"],
        "svi_runtime_probe": res["svi_runtime_probe"],
        "namespace": res["namespace"],
        "flags": {
            "V2_G1_REMAINING7_RESUMABLE_VALIDATION_AUTHORIZED": False,
            "G2_AUTHORIZED": False,
            "G3_AUTHORIZED": False,
            "V2_OPTIMIZATION_EXECUTED": False,
            "NEW_INFERENCE_RUN": False,
            "NEW_OPTIMIZATION_RUN": False,
            "POSTERIOR_DRAWS_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "SCIENTIFIC_TARGET_MODIFIED": False,
            "V1_MODIFIED": False,
            "FAILED_PHASE3C4_PCA_USED": False,
            "RUN_STARTED_CREATED": False,
            "V2_IDENTITIES_CONSUMED": 3,  # P1 seed1001/2002/3003 historical; seven unconsumed
            "SEED1001_CONSUMED": True,
            "SEED2002_CONSUMED": True,
            "SEED3003_CONSUMED": True,
            "REMAINING7_UNCONSUMED": True,
        },
        "created_files": [
            "scripts/75_run_phase3c4v_v2_g1_remaining_validation_resumable.py",
            "scripts/76_launch_v2_g1_remaining7_resumable_detached.sh",
            "results/phase3c4v_v2/audit/42X_V2_G1_REMAINING7_BATCH_RESUME_AUDIT.json",
            "results/phase3c4v_v2/audit/42X_V2_G1_REMAINING7_BATCH_RESUME_AUDIT.md",
            "results/phase3c4v/preflight/42Y_V2_G1_REMAINING7_RESUMABLE_VALIDATION_PREFLIGHT.json",
            "results/phase3c4v/preflight/42Y_V2_G1_REMAINING7_RESUMABLE_VALIDATION_PREFLIGHT.md",
        ],
        "modified_files": [],
        "final_state": ("V2_G1_REMAINING7_RESUMABLE_BATCH_READY_FOR_EXTERNAL_LAUNCH" if res["ok"]
                        else "V2_G1_REMAINING7_RESUMABLE_BATCH_NOT_READY"),
        "waiting_for": ("WAITING_FOR_USER_TERMINAL_LAUNCH" if res["ok"]
                        else "STOP_WAITING_FOR_SCRIPTS75_FIX"),
    }
    out_path = root / "results/phase3c4v/preflight/42Y_V2_G1_REMAINING7_RESUMABLE_VALIDATION_PREFLIGHT.json"
    atomic_write_json(out_path, payload)
    md = ["# 42Y — V2 G1 REMAINING-7 RESUMABLE VALIDATION PREFLIGHT", "",
          f"Generated: {utc_now()}  |  Mode: V2 G1 REMAINING-7 RESUMABLE VALIDATION PREFLIGHT "
          "(M1..M27 unit tests; deterministic checks only; no SVI, no validation execution)", "",
          f"**Classification: {classification}**", "",
          "| Check | Result |", "|---|---|"]
    for k, v in payload["checks"].items():
        md.append(f"| {k} | {'PASS' if v else 'FAIL'} |")
    md += ["", "## SVI runtime probe (preflight)", ""]
    md.append(f"- SVI.init called = {payload['svi_runtime_probe']['counters']['init'] > 0} | "
              f"SVI.update called = {payload['svi_runtime_probe']['counters']['update'] > 0} | "
              f"SVI.stable_update called = {payload['svi_runtime_probe']['counters']['stable_update'] > 0}")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in res["chain"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", "## Negative mode guards", ""]
    md.append(f"- validation: refused={res['negative_guards']['validation_refused']} — "
              f"{res['negative_guards']['validation_reason']}")
    md += ["", "## Flags", "", "| Flag | Value |", "|---|---|"]
    for k, v in payload["flags"].items():
        md.append(f"| {k} | {v} |")
    md += ["", f"## Final state: **{payload['final_state']}**", f"- {payload['waiting_for']}"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", payload["checks"]["OVERALL"])
    return 0 if res["ok"] else 2


def cmd_canary(root: Path) -> int:
    g = guard_canary(root)
    if g["refused"]:
        print(g["reason"])
        return 2
    # Historical seed1001 path: the guard may pass (auth artifact exists) but
    # RUN_STARTED already exists, so _run_identity_future returns
    # STOP_IDENTITY_ALREADY_CONSUMED and the identity is NEVER rerun.
    print("V2 canary authorization validated; executing canary identity...")
    status = _run_identity_future(root, dict(CANARY_IDENTITY), auth_kind="canary")
    print("canary terminal status:", status)
    return exit_status_for(status)  # DEFECT_9 fix


def cmd_replacement_canary(root: Path) -> int:
    g = guard_replacement_canary(root)
    if g["refused"]:
        print(g["reason"])
        return 2
    print("V2 replacement canary authorization validated; executing replacement canary identity...")
    status = _run_identity_future(root, dict(REPLACEMENT_CANARY_IDENTITY),
                                  auth_kind="replacement_canary")
    print("replacement canary terminal status:", status)
    return exit_status_for(status)


def cmd_third_canary(root: Path) -> int:
    g = guard_third_canary(root)
    if g["refused"]:
        print(g["reason"])
        return 2
    print("V2 third canary authorization validated; executing third canary identity...")
    status = _run_identity_future(root, dict(THIRD_CANARY_IDENTITY),
                                  auth_kind="third_canary")
    print("third canary terminal status:", status)
    return exit_status_for(status)


def _write_batch_progress(prog: dict) -> None:
    """Stage G: atomically persist the engineering batch-progress artifact."""
    atomic_write_json(BATCH_PROGRESS_PATH, prog)


# --- Resume-safe state classification (Stage D) ---
def classify_identity_state(identity: dict, runs_dir: Path | None = None) -> str:
    """Classify ONE identity exactly one of:
    PENDING_UNCONSUMED | COMPLETED_VALID | CONSUMED_INVALID_OR_INCOMPLETE."""
    rd = (Path(runs_dir) if runs_dir is not None else V2_RUNS) / identity["identity"]
    if not (rd / RUN_STARTED_NAME).exists():
        return "PENDING_UNCONSUMED"
    res_path = rd / "result.json"
    if not res_path.exists():
        return "CONSUMED_INVALID_OR_INCOMPLETE"
    try:
        cr = json.loads(res_path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return "CONSUMED_INVALID_OR_INCOMPLETE"
    valid = (
        bool(cr.get("VALID_V2_G1_RUN", False))
        and cr.get("terminal_status") in ("COMPLETED_G1_VALID_RUN",
                                          "COMPLETED_EARLY_STOPPED_G1_VALID")
        and cr.get("nonfinite_loss_steps") == 0
        and bool(cr.get("all_params_finite", False))
        and bool(cr.get("required_diagnostics_present", False))
        and cr.get("parameter_persistence_status") == "PASS"
        and bool(cr.get("on_disk_validation", {}).get("PASS", False))
        and cr.get("total_parameter_elements") == V2_TOTAL_ELEMENTS
    )
    return "COMPLETED_VALID" if valid else "CONSUMED_INVALID_OR_INCOMPLETE"


def compute_batch_plan(entries, runs_dir: Path | None = None) -> list:
    """Pure decision layer (hermetically testable; used by cmd_validation):
    per identity in exact order -> SKIP_ALREADY_COMPLETED_VALID /
    STOP_BLOCKED_BY_CONSUMED_INVALID_OR_INCOMPLETE / EXECUTE. A BLOCK truncates
    the plan: nothing after an invalid consumed identity may execute."""
    plan = []
    for e in entries:
        st = classify_identity_state(e, runs_dir)
        if st == "COMPLETED_VALID":
            plan.append(("SKIP_ALREADY_COMPLETED_VALID", st))
        elif st == "CONSUMED_INVALID_OR_INCOMPLETE":
            plan.append(("STOP_BLOCKED_BY_CONSUMED_INVALID_OR_INCOMPLETE", st))
            break
        else:
            plan.append(("EXECUTE", st))
    return plan


def reconstruct_batch_state(root: Path, runs_dir: Path | None = None) -> dict:
    """Stage G: rebuild progress from live run directories; NEVER reset
    completed-valid history."""
    rd_base = Path(runs_dir) if runs_dir is not None else V2_RUNS
    remaining = _remaining_identities(root)
    runs = []
    valid_count = invalid_count = pending_count = 0
    for e in remaining:
        st = classify_identity_state(e, rd_base)
        rec = {"identity": e["identity"], "state": st}
        if st == "COMPLETED_VALID":
            cr = json.loads((rd_base / e["identity"] / "result.json").read_text(encoding="utf-8"))
            rec.update({
                "terminal_status": cr.get("terminal_status"),
                "VALID_V2_G1_RUN": bool(cr.get("VALID_V2_G1_RUN", False)),
                "steps_completed": cr.get("steps_completed"),
                "loss_reduction_fraction": cr.get("loss_reduction_fraction"),
                "result_sha256": sha256(rd_base / e["identity"] / "result.json"),
            })
            valid_count += 1
        elif st == "CONSUMED_INVALID_OR_INCOMPLETE":
            rp = rd_base / e["identity"] / "result.json"
            rec["terminal_status"] = (json.loads(rp.read_text(encoding="utf-8"))
                                      .get("terminal_status")) if rp.exists() else "NO_RESULT_JSON"
            invalid_count += 1
        else:
            pending_count += 1
        runs.append(rec)
    return {
        "planned_count": len(remaining),
        "completed_valid_count": valid_count,
        "consumed_invalid_or_incomplete_count": invalid_count,
        "pending_count": pending_count,
        "remaining_unconsumed": pending_count,
        "runs": runs,
        "reconstructed_utc": utc_now(),
    }


def cmd_validation(root: Path) -> int:
    """Stage F/H: SEQUENTIAL resume-safe one-shot batch over the exactly-seven
    remaining identities (42J order).

    - COMPLETED_VALID        -> SKIP_ALREADY_COMPLETED_VALID, continue
    - CONSUMED_INVALID_OR_INCOMPLETE -> STOP the batch (non-zero); execute
      NOTHING after it (requires new human adjudication)
    - PENDING_UNCONSUMED     -> execute the exact frozen _run_identity_future
      once; after the run re-read the result; non-VALID stops the batch.
    No automatic rerun; no parallel runs. Progress is reconstructed at startup
    and atomically updated after each completed run."""
    g = guard_validation(root)
    if g["refused"]:
        print(g["reason"])
        return 2
    remaining = _remaining_identities(root)
    print("V2 resumable-7 validation authorization validated; "
          "executing SEQUENTIALLY (resume-safe)...")
    print("planned identities:", [r["identity"] for r in remaining])
    batch_start = utc_now()
    prog = reconstruct_batch_state(root)
    prog["started_utc"] = batch_start
    prog["stopped_after"] = None
    prog["stop_reason"] = None
    _write_batch_progress(prog)
    statuses = []
    for entry in remaining:
        st = classify_identity_state(entry)
        if st == "COMPLETED_VALID":
            print("SKIP_ALREADY_COMPLETED_VALID", entry["identity"])
            continue
        if st == "CONSUMED_INVALID_OR_INCOMPLETE":
            print("STOP_BLOCKED_BY_CONSUMED_INVALID_OR_INCOMPLETE", entry["identity"])
            prog["stopped_after"] = entry["identity"]
            prog["stop_reason"] = ("CONSUMED_INVALID_OR_INCOMPLETE; requires NEW human "
                                   "adjudication before later identities may continue")
            _write_batch_progress(prog)
            return 4
        # PENDING_UNCONSUMED: execute exactly once.
        start_utc = utc_now()
        status = _run_identity_future(root, entry, auth_kind="validation")
        end_utc = utc_now()
        statuses.append(status)
        valid = status in ("COMPLETED_G1_VALID_RUN", "COMPLETED_EARLY_STOPPED_G1_VALID")
        rd = V2_RUNS / entry["identity"]
        res = {}
        if (rd / "result.json").exists():
            try:
                res = json.loads((rd / "result.json").read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                res = {}
        info = {
            "identity": entry["identity"],
            "RUN_STARTED_consumed": (rd / RUN_STARTED_NAME).exists(),
            "terminal_status": status,
            "VALID_V2_G1_RUN": bool(res.get("VALID_V2_G1_RUN", False)),
            "steps_completed": res.get("steps_completed"),
            "loss_reduction_fraction": res.get("loss_reduction_fraction"),
            "nonfinite_loss_steps": res.get("nonfinite_loss_steps"),
            "parameter_persistence_status": res.get("parameter_persistence_status"),
            "result_sha256": sha256(rd / "result.json") if (rd / "result.json").exists() else None,
            "started_utc": start_utc,
            "ended_utc": end_utc,
        }
        # Reconstruct from disk (preserves history) and attach run timestamps.
        prog = reconstruct_batch_state(root)
        prog["started_utc"] = batch_start
        prog["stopped_after"] = None
        prog["stop_reason"] = None
        for r in prog["runs"]:
            if r["identity"] == entry["identity"]:
                r.update(info)
        _write_batch_progress(prog)
        print("validation terminal status:", status)
        if not valid:
            prog["stopped_after"] = entry["identity"]
            prog["stop_reason"] = ("non-VALID terminal status; batch stopped "
                                   "(no automatic continue, no automatic rerun)")
            _write_batch_progress(prog)
            return max((exit_status_for(s) for s in statuses), default=4)
    if not statuses:
        print("BATCH_ALREADY_COMPLETE: all seven identities are COMPLETED_VALID; no SVI executed.")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V2 G1 third-canary execution runner")
    ap.add_argument("--mode", required=True,
                    choices=["preflight", "canary", "replacement-canary",
                             "third-canary", "validation"])
    args = ap.parse_args(argv)
    if args.mode == "preflight":
        return cmd_preflight(ROOT)
    if args.mode == "canary":
        return cmd_canary(ROOT)
    if args.mode == "replacement-canary":
        return cmd_replacement_canary(ROOT)
    if args.mode == "third-canary":
        return cmd_third_canary(ROOT)
    return cmd_validation(ROOT)


if __name__ == "__main__":
    sys.exit(main())
