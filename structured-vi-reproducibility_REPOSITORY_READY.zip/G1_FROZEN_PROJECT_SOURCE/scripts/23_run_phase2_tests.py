from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    results_dir = root / "results/phase2"
    results_dir.mkdir(parents=True, exist_ok=True)
    suite = unittest.defaultTestLoader.discover(str(root / "tests"))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    integration = {}
    for name in (
        "33_PHASE2_ETL_QA.json",
        "34_PHASE2_NO_LEAKAGE_TESTS.json",
        "38_PHASE2_REFERENCE_MODEL_SMOKE.json",
        "39_PHASE2_SIMULATION_SMOKE.json",
    ):
        path = results_dir / name
        if not path.exists():
            integration[name] = {"exists": False, "passed": False}
            continue
        payload = json.loads(path.read_text(encoding="utf-8"))
        integration[name] = {
            "exists": True,
            "passed": payload.get("status") == "PASS" or payload.get("passed") is True,
        }
    manifest = root / "data/manifests/phase2_processed_artifacts.csv"
    integration[manifest.name] = {"exists": manifest.exists(), "passed": manifest.exists()}
    report = {
        "status": "PASS" if result.wasSuccessful() and all(item["passed"] for item in integration.values()) else "FAIL",
        "unit_tests": {
            "run": result.testsRun,
            "failures": len(result.failures),
            "errors": len(result.errors),
            "skipped": len(result.skipped),
            "passed": result.wasSuccessful(),
        },
        "integration_artifacts": integration,
        "result_scope": "ENGINEERING_PHASE2_NOT_FORMAL",
    }
    (results_dir / "40_PHASE2_TEST_RESULTS.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2))
    if report["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
