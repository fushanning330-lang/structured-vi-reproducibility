from __future__ import annotations
import argparse, csv, hashlib, urllib.request
from datetime import datetime, timezone
from pathlib import Path

BASE = "https://fis.fda.gov/content/Exports/faers_ascii_{year}q{quarter}.zip"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()

def fetch(url: str, dest: Path) -> None:
    if dest.exists():
        return
    part = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "DHBCP-PV-V2/0.1"})
    with urllib.request.urlopen(req, timeout=180) as r, part.open("wb") as f:
        while True:
            chunk = r.read(1024 * 1024)
            if not chunk:
                break
            f.write(chunk)
    part.replace(dest)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start-year", type=int, default=2015)
    ap.add_argument("--end-year", type=int, default=2025)
    ap.add_argument("--include-2026", action="store_true",
                    help="Exploratory only: downloads 2026Q1-Q2 available at the data lock.")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    root = Path(__file__).resolve().parents[1]
    out = root / "data/raw/faers"
    out.mkdir(parents=True, exist_ok=True)
    manifest = root / "data/manifests/fda_download_manifest.csv"
    rows = []

    requests = [(y,q) for y in range(args.start_year, args.end_year+1) for q in range(1,5)]
    if args.include_2026:
        requests += [(2026,1),(2026,2)]

    for year, q in requests:
        url = BASE.format(year=year, quarter=q)
        dest = out / f"faers_ascii_{year}q{q}.zip"
        print(url)
        if args.dry_run:
            continue
        fetch(url, dest)
        rows.append({
            "year": year, "quarter": q, "url": url,
            "retrieved_utc": datetime.now(timezone.utc).isoformat(),
            "bytes": dest.stat().st_size,
            "sha256": sha256(dest),
        })

    if rows:
        exists = manifest.exists()
        with manifest.open("a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=rows[0].keys())
            if not exists:
                w.writeheader()
            w.writerows(rows)

if __name__ == "__main__":
    main()
