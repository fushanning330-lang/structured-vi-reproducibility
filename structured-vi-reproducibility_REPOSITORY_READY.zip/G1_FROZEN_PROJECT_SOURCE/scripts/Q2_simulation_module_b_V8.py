"""Q2 supplementary simulation — Module B executor V8 (AR1 autodiff-safety amended).

Artifact: Q2_simulation_module_b_V8.py
Frozen: 2026-08-23 (V8 AR1 autodiff-safety amendment). PRE-STRESS-TEST / PRE-EXECUTION.
REAL execution of the 239 eligible official identities and any future
ENGINEERING-ONLY stress test both REQUIRE separate authorizations; neither is
performed here or in preflight.

V8 amendments vs V7 (V7 retained as historical artifact):
  (A1) AR1 ZERO-LAG AUTODIFF-SAFE BUILDER: scientific definition UNCHANGED
       (B[i,j] = rho**|i-j| within each AR1 block + floor*I). The differentiable
       power expression NEVER evaluates exponent=0: lag (int32), safe_lag =
       max(lag, 1), pow_part = rho**safe_lag (exponent>=1), vals = where(lag==0,
       1.0, pow_part). Fixes the deterministic JAX autodiff defect where generic
       power at (rho=0, exponent=0) produces a NaN derivative, which
       contaminated rho in V7 and caused ST01 (T01/P1/91001) nonfinite_elbo at
       step 2 (root cause identified by ChatGPT adjudication:
       Q2_SIMULATION_V7_ENGINEERING_STRESS_FAIL_ROOT_CAUSE_IDENTIFIED_AR1_ZERO_LAG_AUTODIFF).
  (A2) OFFICIAL OUTPUT NAMESPACE: V8 official output directory is
       results/q2_supplementary_simulation/module_b_v8/ (freshness guard applies
       only there). The historical V6.1 module_b/ directory (with
       MB_T01_P1_1001 failure evidence) is preserved immutable and is never read
       or reused by V8.
  (A3) ELIGIBILITY HISTORY EXTENDED: Q2_SIMULATION_ELIGIBILITY_MATRIX_V8.csv
       preserves MB_T01_P1_1001 (CONSUMED_ENGINEERING_FAILURE_V6_1) AND records
       ST01/seed91001 as CONSUMED_ENGINEERING_FAILURE_V7_STRESS (engineering-only,
       not a scientific identity, must_not_rerun). Official scheduler = 239
       eligible (execute_v8=true). No replacement/backfill.

All V7 safety amendments retained (unchanged): rho = 0.999*tanh(raw_rho);
floor = 1e-3 + softplus(raw_floor) (initial effective floor == 1.0); global
gradient-norm clip 10 + Adam lr 0.003 via optax_to_numpyro; P1=1 / P4=4
particles; finite-ELBO guard; checkpoint finite guards; slogdet guard;
post_fit_validation; known_target_metric_construction; staged fit_one; no
nan_to_num; no epsilon added to scientific metrics.

All prior scientific design unchanged: 6 targets, latent_dim=60, rank=4,
AR1 + rank4 guide, trace shares 0.05/0.15/0.30, conditioning scenarios,
target & official optimizer seeds, Stage I/II metrics, known-target metrics,
early stopping, R-prefix definitions, no significance tests, no universal
threshold. G1/G2/G3 untouched; no FAERS.

V6.1 governance retained: official-output freshness guard, persistence
no-overwrite, failure record + batch STOP policy.

Environment: project .venv (jax 0.11.0, numpyro 0.21.0, optax 0.2.8).
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

from jax import config as jax_config
jax_config.update("jax_enable_x64", True)

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
import numpyro.distributions as dist
import optax
from jax.nn import softplus as jnp_softplus
from numpyro.infer import SVI, Trace_ELBO
from numpyro.optim import optax_to_numpyro

from Q2_simulation_target_generator_V4 import (
    LATENT_DIM, RANK, AR1_BLOCK_DIM, AR1_N_BLOCKS, make_target, TARGET_MAP,
)
from Q2_simulation_metrics_V4 import (
    mean_vector_l2_error_to_target, covariance_error_to_target,
    analytic_gaussian_kl, low_rank_trace_share, component_relative_frobenius,
)

# ---------------------------------------------------------------------------
# frozen hyperparameters (must match Protocol Freeze V7 / Config V7)
# ---------------------------------------------------------------------------
OPT = {
    "lr": 0.003,
    "clip_norm": 10.0,          # GLOBAL gradient-norm clip (frozen)
    "max_steps": 2000,
    "checkpoint_interval": 100,
    "min_early_stop_step": 500,  # no early stop before step 500
    "relative_tolerance": 1e-4,
    "patience": 5,               # counted by checkpoint
    "minimum_loss_reduction": 0.15,
}

# (N1)/(N2) numerical-safety parameterization constants (frozen)
RHO_SCALE = 0.999                # rho = RHO_SCALE * tanh(raw_rho); |rho| < 0.999
FLOOR_EPS = 1e-3                 # floor = FLOOR_EPS + softplus(raw_floor); floor > 1e-3
FLOOR_INIT = 1.0                 # initial effective floor exactly 1.0

OPT_TX = optax.chain(
    optax.clip_by_global_norm(OPT["clip_norm"]),
    optax.adam(OPT["lr"]),
)
OPTIMIZER = optax_to_numpyro(OPT_TX)

TARGET_SEEDS = {"T01": 70001, "T02": 70002, "T03": 70003,
                "T04": 70004, "T05": 70005, "T06": 70006}
PARTICLE_MAP = {"P1": 1, "P4": 4}

ELIGIBILITY_CSV = "results/q2_supplementary_simulation/Q2_SIMULATION_ELIGIBILITY_MATRIX_V8.csv"


def _inverse_softplus(y: float) -> float:
    """inverse-softplus: raw = log(exp(y) - 1) (float64)."""
    return float(np.log(np.expm1(float(y))))


def _effective_floor(raw_floor: jax.Array | float) -> jax.Array:
    """floor = FLOOR_EPS + softplus(raw_floor)."""
    return FLOOR_EPS + jnp_softplus(jnp.asarray(raw_floor, dtype=jnp.float64))


def _effective_rho(raw_rho: jax.Array | float) -> jax.Array:
    """rho = RHO_SCALE * tanh(raw_rho)."""
    return RHO_SCALE * jnp.tanh(jnp.asarray(raw_rho, dtype=jnp.float64))


# ---------------------------------------------------------------------------
# failure governance
# ---------------------------------------------------------------------------
class EngineeringFailure(Exception):
    """Exception carrying the failure stage and extra diagnostics."""

    def __init__(self, stage: str, message: str, **extra):
        super().__init__(message)
        self.stage = stage
        self.extra = extra


def engineering_failure_record(row: dict, stage: str, exc: Exception) -> dict:
    conditioning = row["conditioning"]
    share = float(row["trace_share"])
    particles = row["particles"]
    optimizer_seed = int(row["seed"])
    try:
        target_id = next(k for k, v in TARGET_MAP.items() if v == (conditioning, share))
    except StopIteration:
        target_id = "UNRESOLVED"
    rec = {
        "run_id": f"MB_{target_id}_{particles}_{optimizer_seed:04d}",
        "particles": particles,
        "num_particles": PARTICLE_MAP.get(particles),
        "optimizer_seed": optimizer_seed,
        "target_id": target_id,
        "target_seed": TARGET_SEEDS.get(target_id),
        "conditioning": conditioning,
        "trace_share": share,
        "replicate_prefix": row.get("replicate_prefix", ""),
        "scenario": row.get("scenario", "synthetic_gaussian_vi"),
        "stage": stage,
        "exception_type": type(exc).__name__,
        "exception_message": str(exc),
        "status": "ENGINEERING_FAILED",
        "steps": 0,
    }
    if isinstance(exc, EngineeringFailure) and exc.extra:
        rec.update(exc.extra)
    return rec


# ---------------------------------------------------------------------------
# well-specified guide / model (NumPyro), built per run via closures
# ---------------------------------------------------------------------------
def build_B_q_jnp(rho: jax.Array, floor: jax.Array, d: int = LATENT_DIM,
                  block_dim: int = AR1_BLOCK_DIM) -> jax.Array:
    """B_q AR1 block as JAX (differentiable): rho**|i-j| within blocks + floor*I.

    V8 AR1 ZERO-LAG AUTODIFF-SAFE FORM (scientific definition UNCHANGED:
    B[i,j] = rho**|i-j| within each block, + floor*I).

    The differentiable power expression NEVER evaluates exponent=0: lag is
    int32; safe_lag = max(lag, 1); pow_part = rho ** safe_lag (exponent >= 1);
    vals = where(lag == 0, 1.0, pow_part). This avoids the NaN derivative of
    generic power at (rho=0, exponent=0) that contaminated the optimizer state
    in V7 (root cause of the ST01 nonfinite_elbo at step 2).
    """
    n_blocks = d // block_dim
    rows, cols = [], []
    for b in range(n_blocks):
        s = b * block_dim
        for i in range(block_dim):
            for j in range(block_dim):
                rows.append(s + i); cols.append(s + j)
    i_idx = jnp.asarray(rows, dtype=jnp.int32)
    j_idx = jnp.asarray(cols, dtype=jnp.int32)
    lag = jnp.abs(i_idx - j_idx).astype(jnp.int32)          # int32 lag (0 on diagonal)
    safe_lag = jnp.maximum(lag, 1)                          # NEVER exponent 0
    pow_part = jnp.power(rho, safe_lag.astype(jnp.float64))  # rho ** safe_lag, safe_lag >= 1
    vals = jnp.where(lag == 0, jnp.ones_like(pow_part), pow_part)   # lag==0 -> 1.0
    B = jnp.zeros((d, d))
    B = B.at[i_idx, j_idx].set(vals)
    B = B + floor * jnp.eye(d)
    return B


def make_model(Sigma_star: np.ndarray):
    S = jnp.asarray(Sigma_star, dtype=jnp.float64)
    d = S.shape[0]

    def _model():
        numpyro.sample("z", dist.MultivariateNormal(jnp.zeros(d), covariance_matrix=S))
    return _model


def make_guide(U_init: np.ndarray, m_init: np.ndarray, raw_floor_init: float):
    """Per-run guide q(z)=N(m, Sigma_q), Sigma_q = B_q_AR1 + U U^T.

    (N1) rho = 0.999 * tanh(raw_rho); (N2) floor = 1e-3 + softplus(raw_floor),
    raw_floor initialized so effective floor == FLOOR_INIT.
    """
    U0 = jnp.asarray(U_init, dtype=jnp.float64)
    m0 = jnp.asarray(m_init, dtype=jnp.float64)
    d = m0.shape[0]

    def _guide():
        m = numpyro.param("m", m0)
        raw_rho = numpyro.param("raw_rho", jnp.array(0.0))
        raw_floor = numpyro.param("raw_floor", jnp.array(raw_floor_init))
        U = numpyro.param("U", U0)
        rho = _effective_rho(raw_rho)
        floor = _effective_floor(raw_floor)
        B = build_B_q_jnp(rho, floor, d)
        Sigma_q = B + U @ U.T
        Sigma_q = 0.5 * (Sigma_q + Sigma_q.T)
        numpyro.sample("z", dist.MultivariateNormal(m, covariance_matrix=Sigma_q))
    return _guide


def _guide_to_covariance(params: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Reconstruct (m_q, B_q, U_q, Sigma_q) from NumPyro params (float64).

    Dimension inferred from m_q (d=60 for official identities; tiny d for tests).
    """
    m_q = np.asarray(params["m"], dtype=np.float64)
    d = m_q.shape[0]
    raw_rho = np.asarray(params["raw_rho"], dtype=np.float64)
    raw_floor = np.asarray(params["raw_floor"], dtype=np.float64)
    U_q = np.asarray(params["U"], dtype=np.float64)
    B_q = np.asarray(build_B_q_jnp(_effective_rho(raw_rho), _effective_floor(raw_floor), d=d),
                     dtype=np.float64)
    Sigma_q = B_q + U_q @ U_q.T
    return m_q, B_q, U_q, Sigma_q


# ---------------------------------------------------------------------------
# (N3) finite-state guards
# ---------------------------------------------------------------------------
def _all_finite(*arrays) -> bool:
    return all(np.all(np.isfinite(np.asarray(a, dtype=np.float64))) for a in arrays)


def _checkpoint_finite_guard(params, B_q, Sigma_q, kl, step, last_finite) -> None:
    """Verify all params + B_q + Sigma_q + analytic_KL finite and slogdet OK."""
    bad = []
    for k, v in params.items():
        if not np.all(np.isfinite(np.asarray(v, dtype=np.float64))):
            bad.append(f"param_{k}")
    if not _all_finite(B_q):
        bad.append("B_q")
    if not _all_finite(Sigma_q):
        bad.append("Sigma_q")
    if not np.isfinite(kl):
        bad.append("analytic_kl")
    sign_s, logdet_s = np.linalg.slogdet(Sigma_q)
    if not (sign_s > 0 and np.isfinite(logdet_s)):
        bad.append("slogdet_sign_or_logdet")
    if bad:
        raise EngineeringFailure(
            "nonfinite_checkpoint",
            f"non-finite state at step {step}: {bad}",
            steps_completed=int(step),
            last_finite_checkpoint=int(last_finite["checkpoint"]),
            last_finite_loss=float(last_finite["loss"]),
            last_finite_analytic_kl=float(last_finite["kl"]),
        )


def _post_fit_validation(m_q, B_q, U_q, Sigma_q) -> None:
    """(N4) post_fit_validation stage: final fit state must be finite and PD."""
    bad = []
    if not _all_finite(m_q, B_q, U_q, Sigma_q):
        bad.append("nonfinite_final_state")
    sign_s, logdet_s = np.linalg.slogdet(Sigma_q)
    if not (sign_s > 0 and np.isfinite(logdet_s)):
        bad.append("slogdet_sign_or_logdet")
    if bad:
        raise EngineeringFailure("post_fit_validation", f"post-fit validation failed: {bad}")


# ---------------------------------------------------------------------------
# per-run fit (REAL execution path — not run in preflight)
# ---------------------------------------------------------------------------
def fit_one(row: dict) -> dict:
    """Fit exactly one seed-matrix row with staged failure attribution.

    Stages: target_resolution -> target_construction -> svi_fit (with (N3)
    guards) -> post_fit_validation -> known_target_metric_construction.
    Any failure raises EngineeringFailure(stage, ...) and the batch STOPS.
    """
    particles = PARTICLE_MAP[row["particles"]]
    conditioning = row["conditioning"]
    share = float(row["trace_share"])
    optimizer_seed = int(row["seed"])

    # stage: target_resolution
    try:
        target_id = next(k for k, v in TARGET_MAP.items() if v == (conditioning, share))
    except StopIteration as e:
        raise EngineeringFailure("target_resolution", f"no frozen target for {conditioning}/{share}") from e

    # stage: target_construction
    try:
        target = make_target(conditioning, share, TARGET_SEEDS[target_id])
        Sigma_star = np.asarray(target["Sigma_star"], dtype=np.float64)
    except Exception as e:
        raise EngineeringFailure("target_construction", str(e)) from e

    rng = np.random.default_rng(optimizer_seed)
    U_init = rng.standard_normal((LATENT_DIM, RANK)) * 0.05
    m_init = rng.standard_normal(LATENT_DIM) * 0.05
    raw_floor_init = _inverse_softplus(FLOOR_INIT - FLOOR_EPS)   # effective floor = FLOOR_INIT

    # stage: svi_fit (with (N3) guards)
    last_finite = {"checkpoint": 0, "loss": float("nan"), "kl": float("nan")}
    steps = 0
    loss_history = []
    best_loss = None
    patience_count = 0
    try:
        rng_key = jax.random.PRNGKey(optimizer_seed)
        svi = SVI(make_model(Sigma_star), make_guide(U_init, m_init, raw_floor_init),
                  OPTIMIZER, Trace_ELBO(num_particles=particles))
        state = svi.init(rng_key)
        for step in range(1, OPT["max_steps"] + 1):
            state, loss = svi.update(state)
            steps = step
            loss_f = float(loss)
            if not np.isfinite(loss_f):
                raise EngineeringFailure(
                    "nonfinite_elbo",
                    f"MC ELBO loss non-finite at step {step}: {loss_f}",
                    steps_completed=step,
                    last_finite_checkpoint=int(last_finite["checkpoint"]),
                    last_finite_loss=float(last_finite["loss"]),
                    last_finite_analytic_kl=float(last_finite["kl"]),
                )
            if step >= OPT["min_early_stop_step"] and step % OPT["checkpoint_interval"] == 0:
                params = svi.get_params(state)
                m_q, B_q, U_q, Sigma_q = _guide_to_covariance(params)
                kl = analytic_gaussian_kl(m_q, Sigma_q, np.zeros(LATENT_DIM), Sigma_star)
                # (N3) checkpoint finite guard (raises EngineeringFailure if bad)
                _checkpoint_finite_guard(params, B_q, Sigma_q, kl, step, last_finite)
                last_finite = {"checkpoint": step, "loss": loss_f, "kl": float(kl)}
                loss_history.append({"step": step, "mc_elbo_loss": loss_f, "analytic_kl": float(kl)})
                if best_loss is None:
                    best_loss = float(kl); patience_count = 0
                else:
                    improvement = best_loss - float(kl)
                    threshold = max(OPT["minimum_loss_reduction"],
                                    OPT["relative_tolerance"] * abs(best_loss))
                    if improvement >= threshold:
                        best_loss = float(kl); patience_count = 0
                    else:
                        patience_count += 1
                if patience_count >= OPT["patience"]:
                    break
    except EngineeringFailure:
        raise
    except Exception as e:
        raise EngineeringFailure("svi_fit", str(e),
                                 steps_completed=steps,
                                 last_finite_checkpoint=int(last_finite["checkpoint"]),
                                 last_finite_loss=float(last_finite["loss"]),
                                 last_finite_analytic_kl=float(last_finite["kl"])) from e

    # final params from UPDATED state
    params = svi.get_params(state)
    m_q, B_q, U_q, Sigma_q = _guide_to_covariance(params)
    L_q = U_q @ U_q.T
    rho = float(_effective_rho(params["raw_rho"]))
    floor = float(_effective_floor(params["raw_floor"]))

    # stage: post_fit_validation
    _post_fit_validation(m_q, B_q, U_q, Sigma_q)

    # stage: known_target_metric_construction
    try:
        known_target = {
            "mean_vector_l2_error_to_target": mean_vector_l2_error_to_target(m_q, np.zeros(LATENT_DIM)),
            "covariance_error_to_target": covariance_error_to_target(Sigma_q, Sigma_star),
            "analytic_gaussian_kl": analytic_gaussian_kl(m_q, Sigma_q, np.zeros(LATENT_DIM), Sigma_star),
        }
        record = {
            "run_id": f"MB_{target_id}_{row['particles']}_{optimizer_seed:04d}",
            "particles": row["particles"],
            "num_particles": particles,
            "optimizer_seed": optimizer_seed,
            "target_id": target_id,
            "target_seed": TARGET_SEEDS[target_id],
            "conditioning": conditioning,
            "trace_share": share,
            "replicate_prefix": row.get("replicate_prefix", ""),
            "scenario": row.get("scenario", "synthetic_gaussian_vi"),
            "status": "COMPLETED",
            "steps": steps,
            "rho": rho,
            "diagonal_floor": floor,
            "m_q": m_q,
            "U_q": U_q,
            "Sigma_q": Sigma_q,
            "B_q": B_q,
            "L_q": L_q,
            "known_target": known_target,
            "low_rank_trace_share": low_rank_trace_share(L_q, Sigma_q),
            "B_relative_frobenius_to_target": component_relative_frobenius(B_q, target["B_star"]),
            "L_relative_frobenius_to_target": component_relative_frobenius(L_q, target["U_star"] @ target["U_star"].T),
            "loss_history": loss_history,
            "dtype": str(Sigma_q.dtype),
            "shapes": {"m_q": list(m_q.shape), "U_q": list(U_q.shape),
                       "Sigma_q": list(Sigma_q.shape)},
        }
    except EngineeringFailure:
        raise
    except Exception as e:
        raise EngineeringFailure("known_target_metric_construction", str(e)) from e
    return record


# ---------------------------------------------------------------------------
# persistence (G4: no overwrite; G3: freshness guard)
# ---------------------------------------------------------------------------
def persist_run(record: dict, out_dir: Path) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    run_id = record["run_id"]
    npz_path = out_dir / f"{run_id}.npz"
    json_path = out_dir / f"{run_id}.json"
    if npz_path.exists() or json_path.exists():
        raise EngineeringFailure(
            "persistence_preexisting_identity",
            f"{run_id} already persisted: npz={npz_path.exists()} json={json_path.exists()} (no overwrite)")
    np.savez(npz_path, m_q=record["m_q"], U_q=record["U_q"], Sigma_q=record["Sigma_q"],
             B_q=record["B_q"], L_q=record["L_q"])
    meta = {k: v for k, v in record.items() if not isinstance(v, np.ndarray)}
    meta["m_q_shape"] = list(record["m_q"].shape)
    meta["U_q_shape"] = list(record["U_q"].shape)
    json_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    return {"npz": str(npz_path), "json": str(json_path)}


def persist_failure(record: dict, out_dir: Path) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{record['run_id']}.json"
    if json_path.exists():
        raise EngineeringFailure(
            "persistence_preexisting_identity",
            f"{record['run_id']}.json already exists (no overwrite)")
    json_path.write_text(json.dumps(record, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    return {"json": str(json_path)}


def check_official_output_fresh(out_dir: Path) -> None:
    out_dir = Path(out_dir)
    existing = []
    if out_dir.exists():
        for pat in ("MB_*.json", "MB_*.npz",
                    "module_b_manifest.json", "module_b_batch_stopped.json"):
            existing.extend(sorted(out_dir.glob(pat)))
    if existing:
        names = [p.name for p in existing[:10]]
        more = f" (+{len(existing) - 10} more)" if len(existing) > 10 else ""
        raise RuntimeError(
            f"OFFICIAL_OUTPUT_NOT_FRESH_ABORT: {len(existing)} pre-existing artifact(s) "
            f"in {out_dir}: {names}{more}")


# ---------------------------------------------------------------------------
# (N5) eligibility scheduler: dry schedule = 239, seed1001 never enters
# ---------------------------------------------------------------------------
def build_dry_schedule(seed_matrix_csv: str | Path,
                       eligibility_csv: str | Path = ELIGIBILITY_CSV) -> dict:
    elig = {}
    with open(eligibility_csv, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            elig[r["run_id"]] = r["execute_v8"].strip().lower() == "true"
    rows = []
    with open(seed_matrix_csv, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r["module"] != "B":
                continue
            share = float(r["trace_share"])
            target_id = next(k for k, v in TARGET_MAP.items() if v == (r["conditioning"], share))
            run_id = f"MB_{target_id}_{r['particles']}_{int(r['seed']):04d}"
            if not elig.get(run_id, False):
                continue                       # consumed identity excluded
            rows.append({
                "run_id": run_id,
                "particles": r["particles"],
                "conditioning": r["conditioning"],
                "trace_share": r["trace_share"],
                "seed": int(r["seed"]),
                "replicate_prefix": r["replicate_prefix"],
                "scenario": r["scenario"],
            })
    unique = len({r["run_id"] for r in rows})
    # seed1001 / consumed identities must never enter the scheduler
    assert not any(r["run_id"] == "MB_T01_P1_1001" for r in rows), "consumed identity in schedule"
    return {
        "planned_identities": len(rows),
        "unique_identities": unique,
        "executed_if_authorized": len(rows),
        "consumed_excluded": 240 - len(rows),
        "rows": rows,
    }


def main() -> None:
    """REAL Module B batch (239 eligible) — REQUIRES execution authorization. NOT run in preflight."""
    out = Path("results/q2_supplementary_simulation/module_b_v8")
    check_official_output_fresh(out)
    schedule = build_dry_schedule("results/q2_supplementary_simulation/Q2_SIMULATION_SEED_MATRIX.csv")
    assert schedule["planned_identities"] == 239
    assert schedule["unique_identities"] == 239
    manifest = []
    for row in schedule["rows"]:
        try:
            rec = fit_one(row)
            persist_run(rec, out)
            manifest.append(rec["run_id"])
        except EngineeringFailure as e:
            fail = engineering_failure_record(row, e.stage, e)
            persist_failure(fail, out)
            (out / "module_b_batch_stopped.json").write_text(
                json.dumps({"artifact": "Q2_MODULE_B_BATCH_STOPPED_V8",
                            "reason": "engineering failure; batch stopped; await adjudication",
                            "failed_identity": fail}, indent=2, ensure_ascii=False, default=float),
                encoding="utf-8")
            print(f"BATCH STOPPED at identity {fail['run_id']} (stage={e.stage}); "
                  f"completed_before_stop={len(manifest)}")
            break
        except Exception as e:  # unexpected exception outside fit_one contract
            fail = engineering_failure_record(row, "batch_unknown", e)
            persist_failure(fail, out)
            (out / "module_b_batch_stopped.json").write_text(
                json.dumps({"artifact": "Q2_MODULE_B_BATCH_STOPPED_V8",
                            "reason": "unexpected exception; batch stopped; await adjudication",
                            "failed_identity": fail}, indent=2, ensure_ascii=False, default=float),
                encoding="utf-8")
            print(f"BATCH STOPPED at identity {fail['run_id']} (stage=batch_unknown); "
                  f"completed_before_stop={len(manifest)}")
            break
    (out / "module_b_manifest.json").write_text(
        json.dumps({"artifact": "Q2_MODULE_B_MANIFEST_V8",
                    "runs": manifest, "count": len(manifest)}, indent=2), encoding="utf-8")
    print(f"module_b batch manifest: {len(manifest)} completed runs -> {out}")


if __name__ == "__main__":
    main()
