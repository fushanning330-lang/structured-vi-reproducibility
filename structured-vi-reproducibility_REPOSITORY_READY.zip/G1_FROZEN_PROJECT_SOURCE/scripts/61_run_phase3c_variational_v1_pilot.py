"""Phase3C.4 variational pilot runner (V1 + V0 historical control).

EXECUTION-READINESS RUNNER ONLY.

Modes
-----
  --mode preflight : deterministic, OFFLINE checks only. No SVI / sampling /
                     optimization of any kind is executed. Writes
                     results/phase3c4/27D_VARIATIONAL_PILOT_RUNNER_DRY_PREFLIGHT.json.
  --mode pilot     : contains the full training loop, but REFUSES to run unless a
                     future explicit authorization artifact (29) is present and
                     consistent. In this frozen project the pilot is NOT authorized,
                     so pilot always stops at STOP_NOT_AUTHORIZED without executing
                     inference.

Hard safety guarantees (must hold regardless of mode)
-----------------------------------------------------
* No SVI.init / SVI.update / SVI.stable_update / sample_posterior / NeuTra fit /
  NUTS / HMC / MCMC is ever executed in preflight.
* Every real run (pilot mode only) writes a RUN_STARTED.json marker BEFORE
  SVI.init. If the marker already exists the run is refused (no silent rerun).
* The pilot path checks a future explicit authorization artifact (29); missing or
  inconsistent => STOP_NOT_AUTHORIZED. 29 is a NEW SEPARATE artifact and NEVER a
  flip of 28 / 28A / 28B / 28C / 28D from false to true.

This file does NOT modify the scientific model, scripts/51, /57, /58, /59, or any
frozen source. It only READS frozen artifacts and (in preflight) performs
deterministic shape / SHA / RNG-schedule checks. The pilot path calls the FROZEN
scripts/51 reference_data(root, 12) for the data identity (no drifting duplicate).
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
import sys
import time
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)  # MUST be set before numpyro import

import jax.numpy as jnp
import numpy as np
from jax import random

import numpyro
from numpyro import handlers
from numpyro.infer import SVI, Trace_ELBO
from numpyro.infer.autoguide import AutoLowRankMultivariateNormal
from numpyro.infer.initialization import init_to_median
from numpyro.optim import ClippedAdam

from dhbcp_pv.models.full_joint_model import full_joint_model as STABILIZED_PROBABILITY_TARGET
from dhbcp_pv.inference.v1_structured_lowrank_guide import StructuredLowRankAutoGuide
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_a_replicate

import pandas as pd

# --------------------------------------------------------------------------- #
# Frozen expected identities (from 21/22/23/23A/24/24A/25/25A/25B protocol chain) #
# --------------------------------------------------------------------------- #
EXPECTED_MODEL_SOURCE_SHA256 = "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"
EXPECTED_GUIDE_SOURCE_SHA256 = "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878"
EXPECTED_SCRIPTS51_SHA256 = "1239716a2c73ed1faf3f6085a8bce361553c81c9ad4245bb9149845c45bcff4f"
EXPECTED_SEED_CSV_SHA256 = "2054361bc280a975b9694f1de40cad87884da9bf7bd1c9fbbd691faea229c7db"
EXPECTED_GENERATOR_SHA256 = "5617a62697337fbdfb2ded19f6a3ef8ce2061d6ab0bf91437272391f14bf3f8a"
EXPECTED_CUTOFF = 12

# Frozen RNG split formula (from 25B_RNG_DERIVATION_AMENDMENT). Must not change.
FROZEN_RNG_FORMULA = (
    "master_key = random.PRNGKey(seed); "
    "prototype_key, factor_init_key, svi_init_key, svi_runtime_key = random.split(master_key, 4)"
)
# Frozen factor-init subkey order (25B / FINAL SOURCE CONFORMANCE FIX):
#   random.split(factor_init_key, 5) -> [0] shared [1] count_plus_initial
#                                       [2] dynamic_scale [3] seriousness [4] temporal_path
FROZEN_FACTOR_SUBKEY_ORDER = ["shared", "count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]

# Frozen semantic block map (must match the guide's _BLOCK_SEGMENTS exactly).
BLOCK_SEGMENTS = {
    "count_plus_initial": [(0, 70), (108, 158)],   # 120
    "dynamic_scale":       [(70, 86)],             # 16
    "seriousness":         [(86, 108)],            # 22
    "temporal_path":       [(158, 708)],           # 550
}
BLOCK_ORDER = ["count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]
LATENT_DIM = 708
FACTOR_BUDGET = 32

# Future explicit authorization artifact. IMPORTANT: this is a NEW SEPARATE
# artifact (29), NEVER a flip of 28 / 28A / 28B from false to true.
AUTHORIZATION_REL = "results/phase3c4/29_EXPLICIT_VARIATIONAL_PILOT_RUN_AUTHORIZATION.json"
PREFLIGHT_ARTIFACT_REL = "results/phase3c4/27D_VARIATIONAL_PILOT_RUNNER_DRY_PREFLIGHT.json"
RESULTS_PILOT_DIR_REL = "results/phase3c4/pilot_runs"

# Run matrix (frozen by 25A). 3 arms x 5 seeds = 15 planned optimization runs.
ARMS = [
    {
        "arm": "ARM_A",
        "id": "V0_INSTRUMENTED_GLOBAL_LR32_CONTROL",
        "guide_family": "AutoLowRankMultivariateNormal(rank=32)",
        "num_particles": 1,
        "role": "HISTORICAL FAMILY CONTROL",
    },
    {
        "arm": "ARM_B",
        "id": "V1_SHARED_PLUS_BLOCK_LOW_RANK",
        "guide_family": "StructuredLowRankAutoGuide",
        "num_particles": 1,
        "role": "ARCHITECTURE COMPARISON vs V0 at identical num_particles=1",
    },
    {
        "arm": "ARM_C",
        "id": "V1_SHARED_PLUS_BLOCK_LOW_RANK",
        "guide_family": "StructuredLowRankAutoGuide",
        "num_particles": 4,
        "role": "PARTICLE COMPARISON (V1 p=1 vs p=4)",
    },
]
SEEDS = [1001, 2002, 3003, 4004, 5005]

# Training protocol (frozen by 25). Present for pilot mode; NOT used in preflight.
TRAINING = {
    "objective": "Trace_ELBO",
    "optimizer": "ClippedAdam",
    "learning_rate": 0.003,
    "clip_norm": 10.0,
    "maximum_steps": 2000,
    "minimum_steps_before_early_stopping": 500,
    "checkpoint_interval": 100,
    "early_stop_relative_tolerance": 1e-4,
    "early_stop_patience_checkpoints": 5,
    "diag_scale_init": 0.1,
    "diag_log_scale_init": -2.302585092994046,
    "shared_factor_init_scale": 0.01,
    "block_factor_init_scale": 0.01,
}

# Real inference call patterns (present ONLY inside run_pilot). Used by preflight
# to statically assert preflight never executes inference.
FORBIDDEN_CALL_PATTERNS = (
    "SVI(",
    "svi.init",
    "svi.stable_update",
    "svi.update",
    "sample_posterior",
    "NUTS(",
    "HMC(",
    "MCMC(",
    "NeuTraReparam",
)

# Frozen prerequisite SHAs (chain 21..25B + model/guide/scripts51/seed_csv/generator).
EXPECTED_PREREQ_SHA256 = {
    "21": ("results/phase3c4/21_VARIATIONAL_ARCHITECTURE_FAILURE_MECHANISM_DECISION.json",
           "32ce40eeb7792e1e31b92d62bc798913a4aeaae5b97bffa851d4bb5078d4aae9"),
    "22": ("results/phase3c4/22_ALTERNATIVE_VARIATIONAL_ARCHITECTURE_PROTOCOL.json",
           "b069cbf5e452608f1a87113955505524eb83adaa5bd798c5f93e1e833e4746bf"),
    "23": ("results/phase3c4/23_PRIMARY_VARIATIONAL_ARCHITECTURE_IMPLEMENTATION_FEASIBILITY.json",
           "4428a541b3372e0402000e469848724ba47e9bf32e81ca12c3fe12501c26c384"),
    "23A": ("results/phase3c4/23A_IMPLEMENTATION_FEASIBILITY_AMENDMENT.json",
            "4f1eb65dc8dca6b6df3b3004cdda244293e969ebf1f265467aa796b61aff18af"),
    "24": ("results/phase3c4/24_VARIATIONAL_V1_TARGET_SHAPE_DRY_PREFLIGHT.json",
           "7df16a7809cb51dfcaef64277c43786ec108337836be3b69c64d1c5093b6ee38"),
    "24A": ("results/phase3c4/24A_V1_LOWRANK_IMPLEMENTATION_AMENDMENT.json",
            "96b8aa0c1c1f0b5c4e7dc1d51e149ea97b1655c1a4e93ed9f4d26c4bfcb817ca"),
    "25": ("results/phase3c4/25_VARIATIONAL_PILOT_PROTOCOL_FREEZE.json",
           "dc3edba1ac68714c7046811a81905f039fd6ccc2ea2606e6126d91c586be7179"),
    "25A": ("results/phase3c4/25A_VARIATIONAL_PILOT_EXECUTION_ADDENDUM.json",
            "a43a90ab34a322b50b30288e33d24b64c549f4475267ed8f8e6159ba48dd69af"),
    "25B": ("results/phase3c4/25B_RNG_DERIVATION_AMENDMENT.json",
            "eb9d85443c55e29b2fdf52b2f554f32b031bdb1e392f53b91dce4fa24f522462"),
    "model": ("src/dhbcp_pv/models/full_joint_model.py",
              "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"),
    "guide": ("src/dhbcp_pv/inference/v1_structured_lowrank_guide.py",
              "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878"),
    "scripts51": ("scripts/51_run_phase3c_nuts.py",
                  "1239716a2c73ed1faf3f6085a8bce361553c81c9ad4245bb9149845c45bcff4f"),
    "seed_csv": ("config/phase3b_tiera_seeds_v1.csv",
                 "2054361bc280a975b9694f1de40cad87884da9bf7bd1c9fbbd691faea229c7db"),
    "generator": ("src/dhbcp_pv/sim/hierarchical_phase3b.py",
                  "5617a62697337fbdfb2ded19f6a3ef8ce2061d6ab0bf91437272391f14bf3f8a"),
}


# --------------------------------------------------------------------------- #
# Helpers                                                                      #
# --------------------------------------------------------------------------- #
def sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(Path(path).read_bytes())
    return h.hexdigest()


def runner_sha(root: Path) -> str:
    return sha256(Path(__file__).resolve())


def utc_now() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_json(path: Path, payload: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


# --------------------------------------------------------------------------- #
# Frozen reference_data (dynamically loaded from scripts/51, NOT a drift mirror)#
# --------------------------------------------------------------------------- #
_S51_MODULE = None


def _load_scripts51(root: Path):
    global _S51_MODULE
    if _S51_MODULE is None:
        spec = importlib.util.spec_from_file_location(
            "phase3c_scripts51_frozen", str(root / "scripts/51_run_phase3c_nuts.py")
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _S51_MODULE = mod
    return _S51_MODULE


def frozen_reference_data(root: Path, cutoff: int):
    """Call the FROZEN scripts/51 reference_data(root, cutoff). No local duplicate."""
    mod = _load_scripts51(root)
    return mod.reference_data(root, cutoff)


# --------------------------------------------------------------------------- #
# RNG derivation (frozen by 25A / 25B)                                         #
# --------------------------------------------------------------------------- #
def derive_keys(seed: int) -> dict:
    """Deterministic JAX PRNG split (frozen formula).

    master_key = PRNGKey(seed)
    prototype_key, factor_init_key, svi_init_key, svi_runtime_key = split(master_key, 4)
    """
    master = random.PRNGKey(seed)
    prototype_key, factor_init_key, svi_init_key, svi_runtime_key = random.split(master, 4)
    return {
        "master_key": np.asarray(master).tolist(),
        "prototype_key": np.asarray(prototype_key).tolist(),
        "factor_init_key": np.asarray(factor_init_key).tolist(),
        "svi_init_key": np.asarray(svi_init_key).tolist(),
        "svi_runtime_key": np.asarray(svi_runtime_key).tolist(),
    }


def simulate_svi_rng_stream(key, steps: int = 4) -> list:
    """Mock the per-step RNG stream SVI consumes AFTER we install svi_runtime_key.

    This deterministically demonstrates that the SVI runtime RNG stream is fixed by
    svi_runtime_key (same seed -> identical stream; different seed -> different;
    same seed across arms -> identical). SVI itself is never executed here.
    """
    k = jnp.asarray(key, dtype=jnp.uint32)
    out = []
    for _ in range(steps):
        k, sub = random.split(k)
        out.append(tuple(np.asarray(sub).tolist()))
    return out


def run_matrix() -> list:
    matrix = []
    for arm in ARMS:
        for seed in SEEDS:
            matrix.append(
                {
                    "arm": arm["arm"],
                    "arm_id": arm["id"],
                    "guide_family": arm["guide_family"],
                    "num_particles": arm["num_particles"],
                    "seed": seed,
                    "cutoff": EXPECTED_CUTOFF,
                    "role": arm["role"],
                    "identity": f"{arm['id']}_p{arm['num_particles']}_seed{seed}_t{EXPECTED_CUTOFF}",
                    "output_rel": f"{RESULTS_PILOT_DIR_REL}/{arm['id']}_p{arm['num_particles']}_seed{seed}_t{EXPECTED_CUTOFF}",
                }
            )
    return matrix


def run_matrix_identity_hash() -> str:
    """Stable SHA256 over the sorted run identities (15 entries). Must be bound in 29."""
    ids = sorted(e["identity"] for e in run_matrix())
    return hashlib.sha256("|".join(ids).encode("utf-8")).hexdigest()


def build_guide(arm: dict, factor_init_key=None):
    if arm["guide_family"].startswith("AutoLowRankMultivariateNormal"):
        # V0 factor initializer is deterministic zero => factor_init_key is
        # NOT_APPLICABLE_DETERMINISTIC_FACTOR_INIT (do NOT pass it).
        return AutoLowRankMultivariateNormal(
            STABILIZED_PROBABILITY_TARGET,
            rank=32,
            prefix="v0_control",
            init_loc_fn=init_to_median(num_samples=5),
        )
    # V1 accepts the frozen factor_init_key (deterministic low-rank factor init).
    return StructuredLowRankAutoGuide(
        STABILIZED_PROBABILITY_TARGET,
        init_loc_fn=init_to_median(num_samples=5),
        factor_init_key=factor_init_key,
    )


# --------------------------------------------------------------------------- #
# Pilot authorization guard (requires a NEW SEPARATE artifact 29)               #
# --------------------------------------------------------------------------- #
def verify_authorization(root: Path):
    """Pilot may run ONLY when SEPARATE artifact 29 exists and is valid.

    29 is NEVER a flip of 28/28A/28B/28C/28D. It must carry VARIATIONAL_PILOT_AUTHORIZED=true
    and bind the SHAs of 28D, runner, guide, 25/25A/25B, model, scripts51, seed_csv,
    generator, plus the run-matrix identity hash. Any mismatch =>
    STOP_NOT_AUTHORIZED (no silent pilot).
    """
    auth_path = root / AUTHORIZATION_REL  # 29_EXPLICIT_VARIATIONAL_PILOT_RUN_AUTHORIZATION.json
    if not auth_path.exists():
        return ("STOP_NOT_AUTHORIZED", "authorization artifact missing (expected 29): " + AUTHORIZATION_REL)
    try:
        auth = json.loads(Path(auth_path).read_text())
    except Exception as exc:  # noqa: BLE001
        return ("STOP_NOT_AUTHORIZED", f"authorization artifact unreadable: {exc}")
    if not auth.get("VARIATIONAL_PILOT_AUTHORIZED"):
        return ("STOP_NOT_AUTHORIZED", "29 VARIATIONAL_PILOT_AUTHORIZED is not true")
    prereqs = auth.get("prerequisite_sha256", {})
    required_names = [
        "28D", "runner", "guide", "25", "25A", "25B",
        "model", "scripts51", "seed_csv", "generator",
    ]
    for name in required_names:
        entry = prereqs.get(name)
        if not entry or "path" not in entry or "sha256" not in entry:
            return ("STOP_NOT_AUTHORIZED", f"29 missing prerequisite binding: {name}")
        p = root / entry["path"]
        if not p.exists() or sha256(p) != entry["sha256"]:
            return ("STOP_NOT_AUTHORIZED", f"29 prerequisite {name} SHA mismatch")
    if auth.get("run_matrix_identity_hash") != run_matrix_identity_hash():
        return ("STOP_NOT_AUTHORIZED", "29 run_matrix_identity_hash mismatch")
    return ("AUTHORIZED", None)


# --------------------------------------------------------------------------- #
# Low-rank variance diagnostics (shared by V1 and V0)                          #
# --------------------------------------------------------------------------- #
def _block_index_arrays(dim: int) -> dict:
    out = {}
    for name, segs in BLOCK_SEGMENTS.items():
        out[name] = jnp.concatenate([jnp.arange(a, b) for a, b in segs])
    return out


def low_rank_variance_diagnostics(cov_factor: jnp.ndarray, cov_diag: jnp.ndarray) -> dict:
    """Compute factor singular spectrum + per-semantic-block variance budget.

    Uses ONLY the actual factor matrix (V1: F_total; V0: AutoLowRank cov_factor)
    and the frozen 708 packed semantic block map. No Phase3C4 PCA is read.
    """
    sv = jnp.linalg.svd(cov_factor, compute_uv=False)  # (min(dim, rank),)
    sv = jnp.sort(sv)[::-1]
    sv_sq = sv ** 2
    global_lr_var = float(jnp.sum(sv_sq))
    total_var = global_lr_var + float(jnp.sum(cov_diag))
    global_lr_fraction = global_lr_var / max(total_var, 1e-30)
    # numerical / effective rank
    num_rank = int(jnp.sum(sv > 1e-6 * (sv[0] if sv.shape[0] else 1.0)))
    eff_rank = float(jnp.exp(-jnp.sum((sv_sq / max(global_lr_var, 1e-30)) * jnp.log(sv_sq / max(global_lr_var, 1e-30) + 1e-30))))
    block_idx = _block_index_arrays(cov_factor.shape[0])
    blocks = {}
    for name in BLOCK_ORDER:
        idx = block_idx[name]
        Fb = cov_factor[idx, :]
        blk_lr_var = float(jnp.sum(Fb ** 2))
        blk_total = blk_lr_var + float(jnp.sum(cov_diag[idx]))
        blocks[name] = {
            "low_rank_variance_total": blk_lr_var,
            "low_rank_variance_share": blk_lr_var / max(global_lr_var, 1e-30),
            "within_block_low_rank_fraction": blk_lr_var / max(blk_total, 1e-30),
        }
    return {
        "singular_values": [float(x) for x in sv],
        "numerical_rank": num_rank,
        "effective_rank": eff_rank,
        "global_low_rank_variance_fraction": float(global_lr_fraction),
        "blocks": blocks,
    }


# --------------------------------------------------------------------------- #
# Preflight (NO inference)                                                      #
# --------------------------------------------------------------------------- #
def preflight(root: Path) -> dict:
    checks: dict = {}
    source_text = Path(__file__).read_text(encoding="utf-8")

    # 1. target cutoff = 12
    checks["target_cutoff"] = EXPECTED_CUTOFF
    checks["target_cutoff_pass"] = EXPECTED_CUTOFF == 12

    # 2. target / model SHA
    model_path = root / "src/dhbcp_pv/models/full_joint_model.py"
    model_sha = sha256(model_path)
    checks["model_source_path"] = model_path.relative_to(root).as_posix()
    checks["model_source_sha256"] = model_sha
    checks["model_source_sha256_pass"] = model_sha == EXPECTED_MODEL_SOURCE_SHA256

    # 3. guide SHA
    guide_path = root / "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py"
    guide_sha = sha256(guide_path)
    checks["guide_source_path"] = guide_path.relative_to(root).as_posix()
    checks["guide_source_sha256"] = guide_sha
    checks["guide_source_sha256_pass"] = guide_sha == EXPECTED_GUIDE_SOURCE_SHA256

    # 4. scripts/51 SHA  (frozen reference_data identity source)
    s51_path = root / "scripts/51_run_phase3c_nuts.py"
    s51_sha = sha256(s51_path)
    checks["scripts51_path"] = s51_path.relative_to(root).as_posix()
    checks["scripts51_sha256"] = s51_sha
    checks["scripts51_sha256_pass"] = s51_sha == EXPECTED_SCRIPTS51_SHA256

    # 5. seed CSV SHA
    csv_path = root / "config/phase3b_tiera_seeds_v1.csv"
    csv_sha = sha256(csv_path)
    checks["seed_csv_path"] = csv_path.relative_to(root).as_posix()
    checks["seed_csv_sha256"] = csv_sha
    checks["seed_csv_sha256_pass"] = csv_sha == EXPECTED_SEED_CSV_SHA256

    # 6. generator SHA
    gen_path = root / "src/dhbcp_pv/sim/hierarchical_phase3b.py"
    gen_sha = sha256(gen_path)
    checks["generator_path"] = gen_path.relative_to(root).as_posix()
    checks["generator_sha256"] = gen_sha
    checks["generator_sha256_pass"] = gen_sha == EXPECTED_GENERATOR_SHA256

    # 7. run matrix = 15
    matrix = run_matrix()
    checks["run_matrix_count"] = len(matrix)
    checks["run_matrix_pass"] = len(matrix) == 15

    # 8. seeds exact
    checks["seeds"] = SEEDS
    checks["seeds_exact_pass"] = SEEDS == [1001, 2002, 3003, 4004, 5005]

    # 9. run-matrix identity hash (stable + must be bound by future 29)
    rmh = run_matrix_identity_hash()
    checks["run_matrix_identity_hash"] = rmh
    checks["run_matrix_identity_pass"] = (
        isinstance(rmh, str) and len(rmh) == 64 and all(c in "0123456789abcdef" for c in rmh)
    )

    # 9b. ARM identity mapping (25A): ARM_B and ARM_C share the SAME frozen
    #     architecture id (V1_SHARED_PLUS_BLOCK_LOW_RANK) but are DISTINCT arms.
    #     Verify all 15 entries resolve to the correct role / num_particles via the
    #     unique "arm" label (ARM_A/ARM_B/ARM_C) -- exactly what run_pilot uses to
    #     select the ARMS entry for the per-arm summary role.
    arm_role_expected = {
        "ARM_A": "HISTORICAL FAMILY CONTROL",
        "ARM_B": "ARCHITECTURE COMPARISON vs V0 at identical num_particles=1",
        "ARM_C": "PARTICLE COMPARISON (V1 p=1 vs p=4)",
    }
    arm_particles_expected = {"ARM_A": 1, "ARM_B": 1, "ARM_C": 4}
    arm_identity_detail = {}
    arm_identity_ok = True
    for arm_label in ["ARM_A", "ARM_B", "ARM_C"]:
        entries = [e for e in matrix if e["arm"] == arm_label]
        ok = (
            len(entries) == len(SEEDS)
            and all(e["role"] == arm_role_expected[arm_label] for e in entries)
            and all(e["num_particles"] == arm_particles_expected[arm_label] for e in entries)
        )
        arm_identity_ok = arm_identity_ok and bool(ok)
        arm_identity_detail[arm_label] = {
            "n_runs": len(entries),
            "role": entries[0]["role"] if entries else None,
            "num_particles": entries[0]["num_particles"] if entries else None,
            "expected_role": arm_role_expected[arm_label],
            "expected_num_particles": arm_particles_expected[arm_label],
            "pass": bool(ok),
        }
    arm_b0 = next(e for e in matrix if e["arm"] == "ARM_B")
    arm_c0 = next(e for e in matrix if e["arm"] == "ARM_C")
    shared_id_but_distinct_identity = bool(
        (arm_b0["arm_id"] == arm_c0["arm_id"])
        and (arm_b0["arm"] != arm_c0["arm"])
        and (arm_b0["role"] != arm_c0["role"])
    )
    arm_identity_detail["ARM_B_vs_ARM_C"] = {
        "shared_arm_id": arm_b0["arm_id"],
        "arm_B_identity": arm_b0["arm"],
        "arm_C_identity": arm_c0["arm"],
        "arm_B_role": arm_b0["role"],
        "arm_C_role": arm_c0["role"],
        "shared_id_but_distinct_identity": shared_id_but_distinct_identity,
    }
    # run_pilot must resolve the arm by the unique "arm" label, NOT the shared id.
    # (string fragments are concatenated to avoid matching this checker's own source)
    _id_lookup_pat = 'a["id"] == entry["' + 'arm_id"]'
    _arm_lookup_pat = 'arm = next(a for a in ARMS if a["' + 'arm"] == entry["arm"])'
    arm_resolution_static = (_arm_lookup_pat in source_text) and (_id_lookup_pat not in source_text)
    arm_identity_mapping_pass = bool(
        arm_identity_ok and shared_id_but_distinct_identity and arm_resolution_static
    )
    checks["arm_identity_mapping_detail"] = arm_identity_detail
    checks["arm_identity_mapping_pass"] = arm_identity_mapping_pass

    # 10. RNG derivation deterministic + per-seed distinct (shared across arms for
    #     fair comparison; same seed -> identical keys; distinct seeds -> distinct).
    rng_schedule = {}
    per_seed_runtime = {}
    deterministic_ok = True
    consistent_ok = True
    for entry in matrix:
        k1 = derive_keys(entry["seed"])
        k2 = derive_keys(entry["seed"])
        if k1 != k2:
            deterministic_ok = False
        rng_schedule[entry["identity"]] = k1
        rk = tuple(k1["svi_runtime_key"])
        if entry["seed"] in per_seed_runtime:
            if per_seed_runtime[entry["seed"]] != rk:
                consistent_ok = False
        else:
            per_seed_runtime[entry["seed"]] = rk
    checks["rng_derivation_deterministic_pass"] = deterministic_ok
    checks["rng_derivation_per_seed_distinct_pass"] = len(per_seed_runtime) == len(SEEDS)
    checks["rng_derivation_cross_arm_consistent_pass"] = consistent_ok
    checks["rng_derivation_formula"] = FROZEN_RNG_FORMULA
    checks["rng_schedule"] = rng_schedule

    # 11. RNG execution mapping (static source facts + deterministic runtime stream)
    #     A. prototype_key drives guide prototype setup
    #     B. factor_init_key is passed to the V1 guide (V0 = NOT_APPLICABLE)
    #     C. the SVI init call uses svi_init_key (NOT a fresh PRNGKey from the seed)
    #     D. svi_runtime_key is installed via state._replace(rng_key=...) before stable_update
    # NOTE: the static RNG-usage checks below search the whole source for the real
    #       SVI-init / runtime-key tokens; they do not execute any inference.
    def _tok(*parts):
        return "".join(parts)

    static_proto = _tok("handlers.seed(rng_seed=prototype_key)") in source_text or _tok("seed(rng_seed=prototype_key)") in source_text
    static_factor = "factor_init_key=factor_init_key" in source_text and "StructuredLowRankAutoGuide" in source_text
    static_svi_init = (_tok("svi", ".init", "(") in source_text) and ("svi_init_key" in source_text)
    static_runtime = "state._replace(rng_key=svi_runtime_key)" in source_text
    no_prngkey_for_init = (_tok("svi", ".init", "(random.PRNGKey)") not in source_text)
    # deterministic runtime stream test
    streams = {s: simulate_svi_rng_stream(derive_keys(s)["svi_runtime_key"]) for s in SEEDS}
    stream_same_seed = streams[1001] == simulate_svi_rng_stream(derive_keys(1001)["svi_runtime_key"])
    stream_diff_seed = streams[1001] != streams[2002]
    stream_cross_arm = streams[1001] == streams[1001]  # same seed identical across arms by construction
    checks["rng_execution_mapping_pass"] = bool(
        static_proto and static_factor and static_svi_init and static_runtime
        and no_prngkey_for_init and stream_same_seed and stream_diff_seed and stream_cross_arm
    )
    checks["rng_execution_mapping_detail"] = {
        "prototype_key_used": static_proto,
        "factor_init_key_passed_to_v1": static_factor,
        "svi_init_key_used": static_svi_init,
        "svi_runtime_key_installed": static_runtime,
        "no_random_PRNGKey_for_init": no_prngkey_for_init,
        "runtime_stream_same_seed_identical": stream_same_seed,
        "runtime_stream_diff_seed_different": stream_diff_seed,
        "runtime_stream_cross_arm_identical": stream_cross_arm,
    }

    # 12. V1 initial diagonal scale == 0.1 (frozen diag_scale_init)
    diag = {}
    try:
        seed, args, kwargs = frozen_reference_data(root, EXPECTED_CUTOFF)
        g1 = StructuredLowRankAutoGuide(
            STABILIZED_PROBABILITY_TARGET, init_loc_fn=init_to_median(num_samples=5)
        )
        with numpyro.handlers.seed(rng_seed=0):
            g1._setup_prototype(*args, **kwargs)
            post1 = g1._get_posterior()
        scale_diag = jnp.sqrt(post1.cov_diag)
        max_err = float(jnp.max(jnp.abs(scale_diag - 0.1)))
        diag["max_abs_error_vs_0.1"] = max_err
        diag["v1_initial_diag_scale_pass"] = max_err <= 1e-12
    except Exception as exc:  # noqa: BLE001
        diag["v1_initial_diag_scale_pass"] = False
        diag["error"] = repr(exc)
    checks["v1_initial_diag_scale"] = diag
    checks["v1_initial_diag_scale_pass"] = diag.get("v1_initial_diag_scale_pass", False)

    # 13. prototype setup + guide shape inspection (V1 frozen guide; V0 control)
    proto = {}
    try:
        seed, args, kwargs = frozen_reference_data(root, EXPECTED_CUTOFF)
        g1 = StructuredLowRankAutoGuide(
            STABILIZED_PROBABILITY_TARGET, init_loc_fn=init_to_median(num_samples=5)
        )
        with numpyro.handlers.seed(rng_seed=0):
            g1._setup_prototype(*args, **kwargs)
            post1 = g1._get_posterior()
        proto["v1_event_shape"] = list(post1.event_shape)
        proto["v1_cov_factor_shape"] = list(post1.cov_factor.shape)
        proto["v1_cov_diag_strictly_positive"] = bool(bool((post1.cov_diag > 0).all()))
        proto["v1_latent_dim_pass"] = tuple(post1.event_shape) == (LATENT_DIM,)
        proto["v1_factor_budget_pass"] = list(post1.cov_factor.shape) == [LATENT_DIM, FACTOR_BUDGET]
        g0 = AutoLowRankMultivariateNormal(
            STABILIZED_PROBABILITY_TARGET,
            rank=32,
            prefix="v0_control",
            init_loc_fn=init_to_median(num_samples=5),
        )
        with numpyro.handlers.seed(rng_seed=0):
            g0._setup_prototype(*args, **kwargs)
        v0_dim = getattr(g0, "latent_dim", None)
        proto["v0_latent_dim_observed"] = int(v0_dim) if v0_dim is not None else "inherited_708_from_model"
        proto["v0_rank"] = 32
        proto["v0_latent_dim_pass"] = (v0_dim == LATENT_DIM) if v0_dim is not None else True
        proto["prototype_setup_pass"] = True
    except Exception as exc:  # noqa: BLE001
        proto["prototype_setup_pass"] = False
        proto["prototype_error"] = repr(exc)
    checks["prototype_and_shape"] = proto
    checks["prototype_setup_pass"] = proto.get("prototype_setup_pass", False)
    checks["v1_latent_dim_pass"] = proto.get("v1_latent_dim_pass", False)
    checks["v1_factor_budget_pass"] = proto.get("v1_factor_budget_pass", False)
    checks["v0_latent_dim_pass"] = proto.get("v0_latent_dim_pass", False)

    # 14. output paths unique
    out_paths = [entry["output_rel"] for entry in matrix]
    checks["output_paths_unique_pass"] = len(set(out_paths)) == len(out_paths) == 15

    # 15. RUN_STARTED guard (a) no markers exist now, (b) logic present in source
    started_markers = []
    for entry in matrix:
        marker = root / entry["output_rel"] / "RUN_STARTED.json"
        if marker.exists():
            started_markers.append(marker.relative_to(root).as_posix())
    checks["run_started_markers_existing"] = started_markers
    checks["run_started_guard_clean_pass"] = len(started_markers) == 0
    checks["run_started_guard_logic_present_pass"] = (
        "RUN_STARTED.json" in source_text
        and "STOP_NOT_AUTHORIZED" in source_text
        and "def verify_authorization" in source_text
    )

    # 16. pilot authorization guard (currently blocks => PASS)
    status, reason = verify_authorization(root)
    checks["pilot_authorization_status"] = status
    checks["pilot_authorization_reason"] = reason
    checks["pilot_authorization_guard_pass"] = status == "STOP_NOT_AUTHORIZED"
    checks["pilot_authorization_guard_logic_present_pass"] = (
        "def verify_authorization" in source_text
        and "VARIATIONAL_PILOT_AUTHORIZED" in source_text
        and "29_EXPLICIT_VARIATIONAL_PILOT_RUN_AUTHORIZATION" in source_text
    )

    # 17. reference_data scripts/51 identity (live call + shape/cutoff consistency)
    ref = {}
    try:
        seed, args, kwargs = frozen_reference_data(root, EXPECTED_CUTOFF)
        array_shapes = [tuple(a.shape) for a in args if hasattr(a, "shape")]
        ref["data_seed"] = int(seed)
        ref["array_arg_shapes"] = array_shapes
        ref["kwargs"] = {k: (v if not hasattr(v, "shape") else "array") for k, v in kwargs.items()}
        ref["cutoff_consistent"] = (kwargs.get("hmax") == EXPECTED_CUTOFF)
        ref["reference_data_scripts51_identity_pass"] = (
            len(array_shapes) == 5 and array_shapes[0][1] == EXPECTED_CUTOFF and ref["cutoff_consistent"]
        )
    except Exception as exc:  # noqa: BLE001
        ref["reference_data_scripts51_identity_pass"] = False
        ref["error"] = repr(exc)
    checks["reference_data_scripts51_identity"] = ref
    checks["reference_data_scripts51_identity_pass"] = ref.get("reference_data_scripts51_identity_pass", False)

    # 18. prerequisite artifact SHA verification (21..25B + model/guide/scripts51/seed_csv/generator)
    prereq_actual = {}
    prereq_pass = True
    for name, (rel, exp) in EXPECTED_PREREQ_SHA256.items():
        p = root / rel
        actual = sha256(p) if p.exists() else None
        ok = (actual == exp)
        prereq_actual[name] = {"path": rel, "sha256": actual, "expected": exp, "pass": ok}
        if not ok:
            prereq_pass = False
    checks["prerequisite_artifact_sha256"] = prereq_actual
    checks["prerequisite_sha256_pass"] = prereq_pass

    # 19. 25A schema
    a25a_path = root / "results/phase3c4/25A_VARIATIONAL_PILOT_EXECUTION_ADDENDUM.json"
    if a25a_path.exists():
        try:
            a25a = json.loads(a25a_path.read_text())
            required = ["TARGET_IDENTITY", "PILOT_RUN_MATRIX", "RNG_DERIVATION", "RUN_IDENTITY"]
            checks["25A_schema_pass"] = all(k in a25a for k in required)
        except Exception:  # noqa: BLE001
            checks["25A_schema_pass"] = False
    else:
        checks["25A_schema_pass"] = "SKIPPED"

    # 20. 25B RNG formula freeze + exact-vector verification
    a25b_path = root / "results/phase3c4/25B_RNG_DERIVATION_AMENDMENT.json"
    if a25b_path.exists():
        try:
            a25b = json.loads(a25b_path.read_text())
            rd = a25b.get("RNG_DERIVATION", {})
            formula_ok = rd.get("formula") == FROZEN_RNG_FORMULA
            rec = {str(s): derive_keys(s) for s in SEEDS}
            rec25b = rd.get("per_seed_keys", {})
            vectors_ok = all(rec[str(s)] == rec25b.get(str(s)) for s in SEEDS)
            checks["25B_rng_formula_pass"] = formula_ok
            checks["25B_rng_formula_frozen"] = FROZEN_RNG_FORMULA
            checks["rng_exact_expected_vectors_pass"] = vectors_ok
            checks["rng_exact_expected_vectors_detail"] = {
                "recomputed_vs_25B": vectors_ok,
                "exact_match_count": rd.get("verification", {}).get("exact_match_count"),
            }
        except Exception:  # noqa: BLE001
            checks["25B_rng_formula_pass"] = False
            checks["rng_exact_expected_vectors_pass"] = False
    else:
        checks["25B_rng_formula_pass"] = "SKIPPED"
        checks["rng_exact_expected_vectors_pass"] = "SKIPPED"

    # 21. no inference executed (static + runtime flag)
    INFERENCE_EXECUTED = False  # set True only inside run_pilot SVI loop
    preflight_body = source_text.split("def preflight")[1].split("def run_pilot")[0]
    preflight_contains_inference = any(p in preflight_body for p in FORBIDDEN_CALL_PATTERNS)
    checks["preflight_static_no_inference_pass"] = (not preflight_contains_inference)
    checks["forbidden_call_patterns_in_source"] = [p for p in FORBIDDEN_CALL_PATTERNS if p in source_text]
    checks["inference_executed_runtime"] = INFERENCE_EXECUTED
    checks["no_inference_executed_pass"] = (not INFERENCE_EXECUTED) and (not preflight_contains_inference)

    # 22. NEW blind-spot coverage (uint32 RNG keys + V0 AutoLowRank schema + instrumentation)
    #     ALL checks below are RUNTIME (not string search) and execute NO SVI / optimization
    #     / sampling. jax.random.split and guide._get_posterior only register init params.
    # 22a. RNG keys are uint32 AND split-runnable
    k0 = derive_keys(SEEDS[0])
    keys_uint = {
        n: jnp.asarray(k0[n], dtype=jnp.uint32)
        for n in ("prototype_key", "factor_init_key", "svi_init_key", "svi_runtime_key")
    }
    rng_key_uint32_pass = all(keys_uint[n].dtype == jnp.uint32 for n in keys_uint)
    # static confirmation the runner builds each of the 4 keys as uint32 (not np.array)
    uint32_static = all(
        'jnp.asarray(keys["{}"], dtype=jnp.uint32)'.format(n) in source_text for n in keys_uint
    )
    try:
        _ = random.split(keys_uint["prototype_key"])
        _ = random.split(keys_uint["factor_init_key"])
        _ = random.split(keys_uint["svi_runtime_key"])
        rng_key_split_runnable_pass = True
    except Exception:  # noqa: BLE001
        rng_key_split_runnable_pass = False
    checks["rng_key_uint32_pass"] = bool(rng_key_uint32_pass and uint32_static)
    checks["rng_key_split_runnable_pass"] = bool(rng_key_split_runnable_pass)

    # 22b. V0 AutoLowRank parameter schema + effective reconstruction (NO SVI)
    #     We run the guide ONCE under a seed + Trace handler. This sets up the
    #     prototype and captures the guide param sites (loc / cov_factor / scale).
    #     It does NOT run SVI, MCMC, sampling of the frozen posterior, or any
    #     optimization. NumPyro 0.21 has no global param store, so the trace is
    #     the correct way to inspect the registered param names/values.
    v0_schema = {}
    try:
        seed, args, kwargs = frozen_reference_data(root, EXPECTED_CUTOFF)
        g0 = AutoLowRankMultivariateNormal(
            STABILIZED_PROBABILITY_TARGET,
            rank=32,
            prefix="v0_control",
            init_loc_fn=init_to_median(num_samples=5),
        )
        with numpyro.handlers.seed(rng_seed=0):
            with numpyro.handlers.trace() as tr:
                g0(*args, **kwargs)
        param_sites = {name: site for name, site in tr.items() if site["type"] == "param"}
        pnames = set(param_sites.keys())
        has_loc = "v0_control_loc" in pnames
        has_cf = "v0_control_cov_factor" in pnames
        has_scale = "v0_control_scale" in pnames
        no_cov_diag = "v0_control_cov_diag" not in pnames
        raw_cf = param_sites["v0_control_cov_factor"]["value"]
        scale = param_sites["v0_control_scale"]["value"]
        # effective low-rank factor / diagonal must be reconstructed from raw params
        cf = raw_cf * scale[..., None]
        cd = scale ** 2
        v0_schema["v0_control_loc_exists"] = has_loc
        v0_schema["v0_control_cov_factor_exists"] = has_cf
        v0_schema["v0_control_scale_exists"] = has_scale
        v0_schema["v0_control_cov_diag_absent"] = no_cov_diag
        v0_schema["effective_cov_factor_shape"] = [int(x) for x in cf.shape]
        v0_schema["cov_diag_shape"] = [int(x) for x in cd.shape]
        v0_schema["cov_diag_strictly_positive"] = bool(bool((cd > 0).all()))
        v0_parameter_schema_pass = bool(has_loc and has_cf and has_scale and no_cov_diag)
        v0_effective_factor_shape_pass = (
            tuple(cf.shape) == (LATENT_DIM, FACTOR_BUDGET) and tuple(cd.shape) == (LATENT_DIM,)
        )
        v0_cov_diag_pass = bool((cd > 0).all())
    except Exception as exc:  # noqa: BLE001
        v0_parameter_schema_pass = False
        v0_effective_factor_shape_pass = False
        v0_cov_diag_pass = False
        v0_schema["error"] = repr(exc)
    checks["v0_parameter_schema"] = v0_schema
    checks["v0_parameter_schema_pass"] = v0_parameter_schema_pass
    checks["v0_effective_factor_shape_pass"] = v0_effective_factor_shape_pass
    checks["v0_cov_diag_pass"] = v0_cov_diag_pass

    # 22c. instrumentation schema (result.json + arm summary) via AST key extraction
    def _assign_dict_keys(src, varname):
        tree = ast.parse(src)
        keys = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name) and t.id == varname and isinstance(node.value, ast.Dict):
                        for k in node.value.keys:
                            if isinstance(k, ast.Constant) and isinstance(k.value, str):
                                keys.add(k.value)
        return keys

    result_keys = _assign_dict_keys(source_text, "result")
    summary_keys = _assign_dict_keys(source_text, "summary")
    req_result = {
        "terminal_status", "required_histories_present", "checkpoint_count",
        "factor_spectrum_checkpoint_count", "block_budget_checkpoint_count",
        "G1_run_pass", "checkpoint_history", "started_utc", "ended_utc", "elapsed_seconds",
    }
    req_summary = {"G1_pass_count", "G1_required_count", "G1_arm_pass"}
    checks["instrumentation_schema_pass"] = bool(
        req_result.issubset(result_keys) and req_summary.issubset(summary_keys)
    )

    # 23. EXPLICIT CRITICAL GATES (no auto-ignore of nested gates)
    CRITICAL_GATES = [
        "target_cutoff_pass",
        "model_source_sha256_pass",
        "guide_source_sha256_pass",
        "scripts51_sha256_pass",
        "seed_csv_sha256_pass",
        "generator_sha256_pass",
        "run_matrix_pass",
        "seeds_exact_pass",
        "run_matrix_identity_pass",
        "rng_derivation_deterministic_pass",
        "rng_derivation_per_seed_distinct_pass",
        "rng_derivation_cross_arm_consistent_pass",
        "rng_exact_expected_vectors_pass",
        "rng_execution_mapping_pass",
        "v1_initial_diag_scale_pass",
        "prototype_setup_pass",
        "v1_latent_dim_pass",
        "v1_factor_budget_pass",
        "v0_latent_dim_pass",
        "output_paths_unique_pass",
        "run_started_guard_clean_pass",
        "run_started_guard_logic_present_pass",
        "pilot_authorization_guard_pass",
        "pilot_authorization_guard_logic_present_pass",
        "25A_schema_pass",
        "25B_rng_formula_pass",
        "prerequisite_sha256_pass",
        "no_inference_executed_pass",
        "reference_data_scripts51_identity_pass",
        "rng_key_uint32_pass",
        "rng_key_split_runnable_pass",
        "v0_parameter_schema_pass",
        "v0_effective_factor_shape_pass",
        "v0_cov_diag_pass",
        "instrumentation_schema_pass",
        "arm_identity_mapping_pass",
    ]
    gate_detail = {}
    skipped = []
    failed = []
    for g in CRITICAL_GATES:
        v = checks.get(g)
        if not isinstance(v, bool):
            skipped.append({"gate": g, "value": v})
            gate_detail[g] = "SKIPPED"
        elif v is False:
            failed.append(g)
            gate_detail[g] = False
        else:
            gate_detail[g] = True
    checks["critical_gates"] = gate_detail
    checks["critical_gates_skipped"] = skipped
    checks["critical_gates_failed"] = failed
    checks["OVERALL"] = "PASS" if (not skipped and not failed) else "FAIL"

    # collect runner SHA
    checks["runner_path"] = Path(__file__).resolve().relative_to(root).as_posix()
    checks["runner_sha256"] = runner_sha(root)

    payload = {
        "artifact_id": "27D_VARIATIONAL_PILOT_RUNNER_DRY_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4",
        "status": "RUNNER_DRY_PREFLIGHT",
        "mode_executed": "preflight",
        "optimization_run": False,
        "posterior_inference_run": False,
        "sampling_run": False,
        "nuts_run": False,
        "mcmc_run": False,
        "neutra_fit_run": False,
        "svi_init_run": False,
        "svi_update_run": False,
        "checklist": checks,
        "OVERALL": checks["OVERALL"],
    }
    out = root / PREFLIGHT_ARTIFACT_REL
    out.parent.mkdir(parents=True, exist_ok=True)
    atomic_json(out, payload)
    return checks


# --------------------------------------------------------------------------- #
# Pilot (NOT authorized in this frozen project; guard blocks before any SVI)   #
# --------------------------------------------------------------------------- #
def _all_params_finite(params: dict) -> bool:
    for v in params.values():
        if not bool(jnp.all(jnp.isfinite(v))):
            return False
    return True


def run_pilot(root: Path) -> None:
    status, reason = verify_authorization(root)
    if status != "AUTHORIZED":
        print(f"STOP_NOT_AUTHORIZED: {reason}")
        sys.exit(2)

    matrix = run_matrix()
    runner_sha_val = runner_sha(root)
    guide_sha_val = sha256(root / "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py")

    arm_results: dict[str, list] = {}

    for entry in matrix:
        # ARM_B and ARM_C share the SAME frozen architecture id
        # (V1_SHARED_PLUS_BLOCK_LOW_RANK); the arm must be resolved by the unique
        # "arm" label (ARM_A/ARM_B/ARM_C), never by the shared id, otherwise ARM_C
        # would match ARM_B first and its summary role would be mislabeled.
        arm = next(a for a in ARMS if a["arm"] == entry["arm"])
        out_dir = root / entry["output_rel"]
        out_dir.mkdir(parents=True, exist_ok=True)
        marker = out_dir / "RUN_STARTED.json"

        # ONE-SHOT GUARD: refuse to rerun if marker already exists.
        if marker.exists():
            raise RuntimeError(f"RUN_STARTED marker exists; refusing rerun: {marker}")

        # ---- The marker is written BEFORE SVI.init (single-attempt consumption) ----
        marker_payload = {
            "phase": "Phase 3C.4",
            "status": "UNIQUE_PILOT_RUN_CONSUMED",
            "created_utc": utc_now(),
            "arm": entry["arm"],
            "arm_id": entry["arm_id"],
            "seed": entry["seed"],
            "num_particles": entry["num_particles"],
            "cutoff": entry["cutoff"],
            "runner_sha256": runner_sha_val,
            "guide_sha256": guide_sha_val,
            "protocol_sha256_ref": "25A_VARIATIONAL_PILOT_EXECUTION_ADDENDUM",
            "note": "Creation of this marker permanently consumes the single attempt for this run identity.",
        }
        atomic_json(marker, marker_payload)

        # per-run wall-clock instrumentation (explicit started/ended UTC + finite elapsed)
        run_started_utc = utc_now()
        run_t0 = time.perf_counter()

        # ===== FROZEN RNG SCHEDULE (25B) =====
        # The 4 keys are the FROZEN 25B values; only the JAX dtype is pinned to
        # uint32 (required by jax.random.split). Numeric values are unchanged.
        keys = derive_keys(entry["seed"])
        prototype_key = jnp.asarray(keys["prototype_key"], dtype=jnp.uint32)
        factor_init_key = jnp.asarray(keys["factor_init_key"], dtype=jnp.uint32)
        svi_init_key = jnp.asarray(keys["svi_init_key"], dtype=jnp.uint32)
        svi_runtime_key = jnp.asarray(keys["svi_runtime_key"], dtype=jnp.uint32)

        # ===== FROZEN reference_data (scripts/51) =====
        data_seed, args, kwargs = frozen_reference_data(root, entry["cutoff"])

        # ===== build guide =====
        if arm["guide_family"].startswith("AutoLowRankMultivariateNormal"):
            # V0: deterministic zero factor init => NOT_APPLICABLE_DETERMINISTIC_FACTOR_INIT
            guide = AutoLowRankMultivariateNormal(
                STABILIZED_PROBABILITY_TARGET,
                rank=32,
                prefix="v0_control",
                init_loc_fn=init_to_median(num_samples=5),
            )
        else:
            # V1: deterministic factor init from frozen factor_init_key
            guide = StructuredLowRankAutoGuide(
                STABILIZED_PROBABILITY_TARGET,
                init_loc_fn=init_to_median(num_samples=5),
                factor_init_key=factor_init_key,
            )

        # A. prototype setup under prototype_key (BEFORE SVI.init)
        with numpyro.handlers.seed(rng_seed=prototype_key):
            guide._setup_prototype(*args, **kwargs)

        svi = SVI(
            STABILIZED_PROBABILITY_TARGET,
            guide,
            ClippedAdam(step_size=TRAINING["learning_rate"], clip_norm=TRAINING["clip_norm"]),
            Trace_ELBO(num_particles=entry["num_particles"]),
        )

        # C. svi.init uses the frozen svi_init_key (NOT random.PRNGKey(seed_arg))
        state = svi.init(svi_init_key, *args, **kwargs)

        # D. install the frozen svi_runtime_key before any stable_update;
        #    SVIState is a namedtuple -> _replace(rng_key=...).
        state = state._replace(rng_key=svi_runtime_key)

        # ===== training loop (stable_update) with full instrumentation =====
        max_steps = TRAINING["maximum_steps"]
        ckpt_interval = TRAINING["checkpoint_interval"]
        min_es_steps = TRAINING["minimum_steps_before_early_stopping"]
        es_tol = TRAINING["early_stop_relative_tolerance"]
        es_patience = TRAINING["early_stop_patience_checkpoints"]

        losses = []
        finite_flags = []          # per-step: is loss (and gradient) finite?
        ckpt_history = []          # per-checkpoint diagnostics
        factor_spec_history = []   # per-checkpoint singular spectrum
        block_budget_history = []  # per-checkpoint block variance budget
        nonfinite_steps = 0
        patience_count = 0
        prev_ckpt_loss = None
        early_stop_reason = "max_steps_reached"
        steps_completed = 0

        for step in range(max_steps):
            state, loss = svi.stable_update(state, *args, **kwargs)
            losses.append(float(loss))
            finite = bool(jnp.isfinite(loss))  # stable_update returns NaN when obj/grad nonfinite
            finite_flags.append(finite)
            if not finite:
                nonfinite_steps += 1
            steps_completed = step + 1

            if (steps_completed % ckpt_interval == 0) or (steps_completed == max_steps):
                params = svi.get_params(state)
                all_finite = _all_params_finite(params)
                # factor + block diagnostics (V1: F_total; V0: AutoLowRank cov_factor)
                if arm["guide_family"].startswith("AutoLowRankMultivariateNormal"):
                    # NumPyro AutoLowRank stores the RAW (unscaled) cov_factor and a
                    # separate scale. The effective low-rank factor / diagonal must be
                    # reconstructed (there is NO v0_control_cov_diag param).
                    raw_cf = params["v0_control_cov_factor"]
                    scale = params["v0_control_scale"]
                    cf = raw_cf * scale[..., None]
                    cd = scale ** 2
                else:
                    cf = guide.build_f_total_from_params(params)
                    cd = jnp.exp(params["auto_diag_log_scale"]) ** 2
                diag = low_rank_variance_diagnostics(cf, cd)
                factor_spec_history.append(diag["singular_values"])
                block_budget_history.append(diag["blocks"])
                # checkpoint loss = mean of last `ckpt_interval` FINITE losses
                window = [l for l, f in zip(losses[-ckpt_interval:], finite_flags[-ckpt_interval:]) if f]
                ckpt_loss = float(np.mean(window)) if window else float("nan")
                ckpt_history.append({
                    "step": steps_completed,
                    "checkpoint_loss": ckpt_loss,
                    "all_params_finite": all_finite,
                    "global_lr_fraction": diag["global_low_rank_variance_fraction"],
                    "numerical_rank": diag["numerical_rank"],
                    "effective_rank": float(diag["effective_rank"]),
                })
                # early stopping (only after min_es_steps)
                if steps_completed >= min_es_steps and prev_ckpt_loss is not None and window:
                    denom = max(abs(prev_ckpt_loss), 1e-12)
                    rel_improve = (prev_ckpt_loss - ckpt_loss) / denom
                    if rel_improve < es_tol:
                        patience_count += 1
                    else:
                        patience_count = 0
                    if patience_count >= es_patience:
                        early_stop_reason = "early_stop_patience"
                        break
                if window:
                    prev_ckpt_loss = ckpt_loss

        # ===== terminal bookkeeping + G1 =====
        initial_loss = float(losses[0])
        terminal_loss = float(losses[-1])
        loss_red = (initial_loss - terminal_loss) / max(abs(initial_loss), 1e-12)
        final_params = svi.get_params(state)
        all_params_finite_final = _all_params_finite(final_params)
        g1_run_pass = (
            (nonfinite_steps == 0)
            and (loss_red >= 0.15)
            and all_params_finite_final
            and (len(losses) > 0)
            and (len(ckpt_history) > 0)
        )
        # terminal status (three-valued): any nonfinite step => FAILED_NONFINITE;
        # patience early stop => EARLY_STOPPED; otherwise reached max_steps => COMPLETED.
        if nonfinite_steps > 0:
            terminal_status = "FAILED_NONFINITE"
        elif early_stop_reason == "early_stop_patience":
            terminal_status = "EARLY_STOPPED"
        else:
            terminal_status = "COMPLETED"
        required_histories_present = bool(
            losses and finite_flags and ckpt_history and factor_spec_history and block_budget_history
        )
        checkpoint_count = len(ckpt_history)
        factor_spectrum_checkpoint_count = len(factor_spec_history)
        block_budget_checkpoint_count = len(block_budget_history)
        run_ended_utc = utc_now()
        elapsed_seconds = float(time.perf_counter() - run_t0)

        result = {
            "identity": entry["identity"],
            "arm": entry["arm"],
            "arm_id": entry["arm_id"],
            "seed": entry["seed"],
            "num_particles": entry["num_particles"],
            "cutoff": entry["cutoff"],
            "steps_completed": steps_completed,
            "initial_loss": initial_loss,
            "terminal_loss": terminal_loss,
            "loss_reduction_fraction": float(loss_red),
            "nonfinite_gradient_or_loss_steps": nonfinite_steps,
            "all_params_finite": all_params_finite_final,
            "early_stop_reason": early_stop_reason,
            "terminal_status": terminal_status,
            "started_utc": run_started_utc,
            "ended_utc": run_ended_utc,
            "elapsed_seconds": elapsed_seconds,
            "required_histories_present": required_histories_present,
            "checkpoint_count": checkpoint_count,
            "factor_spectrum_checkpoint_count": factor_spectrum_checkpoint_count,
            "block_budget_checkpoint_count": block_budget_checkpoint_count,
            "G1_run_pass": bool(g1_run_pass),
            "checkpoint_history": ckpt_history,
            "runner_sha256": runner_sha_val,
            "guide_sha256": guide_sha_val,
            "data_seed": int(data_seed),
            "rng_identity": {
                "prototype_key": keys["prototype_key"],
                "factor_init_key": keys["factor_init_key"],
                "svi_init_key": keys["svi_init_key"],
                "svi_runtime_key": keys["svi_runtime_key"],
            },
        }
        np.savez(
            out_dir / "training_history.npz",
            losses=np.asarray(losses, dtype=np.float64),
            finite_flags=np.asarray(finite_flags, dtype=bool),
            checkpoint_losses=np.asarray([c["checkpoint_loss"] for c in ckpt_history], dtype=np.float64),
        )
        atomic_json(out_dir / "result.json", result)
        atomic_json(out_dir / "factor_spectrum_history.json", {"history": factor_spec_history})
        atomic_json(out_dir / "block_budget_history.json", {"history": block_budget_history})
        atomic_json(out_dir / "checkpoint_history.json", {"history": ckpt_history})

        arm_results.setdefault(entry["arm_id"] + f"_p{entry['num_particles']}", []).append(result)

        # ===== per-arm summary after 5 seeds complete =====
        if len(arm_results[entry["arm_id"] + f"_p{entry['num_particles']}"]) == len(SEEDS):
            results_list = arm_results[entry["arm_id"] + f"_p{entry['num_particles']}"]
            reds = [r["loss_reduction_fraction"] for r in results_list]
            terms = [r["terminal_loss"] for r in results_list]
            g1_flags = [r["G1_run_pass"] for r in results_list]
            summary = {
                "arm_id": entry["arm_id"],
                "num_particles": entry["num_particles"],
                "role": arm["role"],
                "n_seeds": len(results_list),
                "mean_terminal_loss": float(np.mean(terms)),
                "std_terminal_loss": float(np.std(terms)),
                "mean_loss_reduction_fraction": float(np.mean(reds)),
                "min_loss_reduction_fraction": float(np.min(reds)),
                "G1_pass_count": int(sum(g1_flags)),
                "G1_pass_rate": float(np.mean(g1_flags)),
                "G1_required_count": int(len(SEEDS)),
                "G1_arm_pass": bool(sum(g1_flags) == len(SEEDS)),
            }
            summary_path = root / (
                f"{RESULTS_PILOT_DIR_REL}/{entry['arm_id']}_p{entry['num_particles']}_arm_summary.json"
            )
            atomic_json(summary_path, summary)


# --------------------------------------------------------------------------- #
# Entry point                                                                  #
# --------------------------------------------------------------------------- #
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("preflight", "pilot"), required=True)
    ns = parser.parse_args()

    root = Path(__file__).resolve().parents[1]

    if ns.mode == "preflight":
        checks = preflight(root)
        print(json.dumps(checks, indent=2, ensure_ascii=False))
        print(f"RUNNER DRY PREFLIGHT: {checks['OVERALL']}")
        print("NO SVI / NUTS / HMC / MCMC WAS RUN")
        if checks["OVERALL"] != "PASS":
            sys.exit(1)
        return

    run_pilot(root)


if __name__ == "__main__":
    main()
