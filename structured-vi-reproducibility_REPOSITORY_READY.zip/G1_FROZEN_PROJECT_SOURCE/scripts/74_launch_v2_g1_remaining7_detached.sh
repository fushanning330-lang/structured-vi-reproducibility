#!/usr/bin/env bash
# scripts/74_launch_v2_g1_remaining7_detached.sh — EXECUTION-ENVIRONMENT ONLY.
#
# Launches the V2 G1 remaining-7 SEQUENTIAL validation batch DETACHED from any
# foreground/WorkBuddy command lifecycle, using macOS caffeinate + nohup, so
# the batch survives terminal / session teardown.
#
# This script NEVER modifies inference, the model, the guide, the runner, or
# any frozen source. It only validates preconditions and launches.
#
# Execute (from the repository root or anywhere):
#   bash scripts/74_launch_v2_g1_remaining7_detached.sh
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

AUTH="results/phase3c4v_v2/authorizations/V2_G1_REMAINING7_VALIDATION_AUTHORIZATION.json"
VALID_RESULT="results/phase3c4v_v2/runs/V2_V2_ARM_P1_p1_seed3003_t12/result.json"
LOG_DIR="results/phase3c4v_v2/runtime_logs"

# 1. refuse if the validation authorization is missing
if [ ! -f "$AUTH" ]; then
  echo "FATAL: remaining-7 validation authorization missing: $AUTH" >&2
  exit 1
fi

# 2. refuse if the VALID seed3003 canary result is missing
if [ ! -f "$VALID_RESULT" ]; then
  echo "FATAL: VALID seed3003 canary result missing: $VALID_RESULT" >&2
  exit 1
fi

# 3. refuse if scripts73 is missing
if [ ! -f "scripts/73_run_phase3c4v_v2_g1_remaining_validation.py" ]; then
  echo "FATAL: scripts/73_run_phase3c4v_v2_g1_remaining_validation.py missing." >&2
  exit 1
fi

# 4. refuse if all seven identities are already consumed
ALL_CONSUMED=1
for ID in \
  V2_V2_ARM_P1_p1_seed4004_t12 \
  V2_V2_ARM_P1_p1_seed5005_t12 \
  V2_V2_ARM_P4_p4_seed1001_t12 \
  V2_V2_ARM_P4_p4_seed2002_t12 \
  V2_V2_ARM_P4_p4_seed3003_t12 \
  V2_V2_ARM_P4_p4_seed4004_t12 \
  V2_V2_ARM_P4_p4_seed5005_t12 ; do
  if [ ! -f "results/phase3c4v_v2/runs/$ID/RUN_STARTED" ]; then
    ALL_CONSUMED=0
    break
  fi
done
if [ "$ALL_CONSUMED" -eq 1 ]; then
  echo "FATAL: all seven remaining identities are already consumed; nothing to run." >&2
  exit 1
fi

# 5. create the runtime log directory
mkdir -p "$LOG_DIR"

# 6. detached launch: caffeinate keeps the host awake; nohup detaches the
#    batch from this shell; /usr/bin/time -l records max RSS at exit.
LAUNCH_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
nohup caffeinate -dimsu /usr/bin/time -l \
  .venv/bin/python \
  scripts/73_run_phase3c4v_v2_g1_remaining_validation.py \
  --mode validation \
  > "$LOG_DIR/remaining7_console.log" \
  2> "$LOG_DIR/remaining7_runtime.log" &
LAUNCHER_PID=$!
echo "$LAUNCHER_PID" > "$LOG_DIR/remaining7_launcher.pid"
echo "$LAUNCH_UTC" > "$LOG_DIR/remaining7_launch_timestamp.txt"

echo "Launched V2 G1 remaining-7 sequential validation (detached)."
echo "launcher_pid=$LAUNCHER_PID launch_utc=$LAUNCH_UTC"
echo "console_log=$LOG_DIR/remaining7_console.log"
echo "runtime_log=$LOG_DIR/remaining7_runtime.log"
echo "monitor: tail -f $LOG_DIR/remaining7_runtime.log"
