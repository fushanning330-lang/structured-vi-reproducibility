"""Q2 supplementary simulation — frozen target generator (shared).

Artifact: Q2_simulation_target_generator.py
Frozen: 2026-08-23 (protocol repair, V2). PRE-EXECUTION; no fitting here.

This module implements the FROZEN Module B target construction exactly as
specified in Q2_SIMULATION_PROTOCOL_FREEZE_V2 / Q2_SIMULATION_CONFIG_V2.yaml.

Determinism contract:
  - Each target identity (T01..T06) has ONE frozen target_seed.
  - Target randomness is generated ONLY from the target_seed.
  - Optimizer seeds NEVER enter target generation (separation enforced by
    Q2_SIMULATION_TARGET_MATRIX.csv and asserted in the executor).
  - All arithmetic float64.

No FAERS import/access. No G1/G2/G3 call.
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# Frozen construction parameters (must match Q2_SIMULATION_CONFIG_V2.yaml)
# ---------------------------------------------------------------------------
LATENT_DIM = 60
RANK = 4

# AR1 block layout (frozen): latent dims partitioned into contiguous blocks.
AR1_BLOCK_DIM = 12
AR1_N_BLOCKS = LATENT_DIM // AR1_BLOCK_DIM  # 5 blocks of 12

# Conditioning-specific frozen values.
CONDITIONING_PARAMS = {
    "well_conditioned": {
        "rho": 0.3,            # AR1 coefficient inside each block
        "diagonal_floor": 1.0, # diagonal floor added to every coordinate
        "target_cond_lo": 1.0,
        "target_cond_hi": 1e2,
    },
    "moderately_ill_conditioned": {
        "rho": 0.99,           # near-unit AR1 coefficient -> high conditioning
        "diagonal_floor": 0.05,
        "target_cond_lo": 1e2,
        "target_cond_hi": 1e6,
    },
}

# Frozen trace-share scenarios (Module B).
TRACE_SHARE_SCENARIOS = (0.05, 0.15, 0.30)

# Engineering numerical equality tolerance (NOT a scientific stability threshold).
ENG_TOL = 1e-6

TARGET_SEEDS = {  # frozen in Q2_SIMULATION_TARGET_MATRIX.csv
    "T01": 70001, "T02": 70002, "T03": 70003,
    "T04": 70004, "T05": 70005, "T06": 70006,
}
# target_id -> (conditioning, trace_share)
TARGET_MAP = {
    "T01": ("well_conditioned", 0.05),
    "T02": ("well_conditioned", 0.15),
    "T03": ("well_conditioned", 0.30),
    "T04": ("moderately_ill_conditioned", 0.05),
    "T05": ("moderately_ill_conditioned", 0.15),
    "T06": ("moderately_ill_conditioned", 0.30),
}


def build_B_AR1(conditioning: str, rng: np.random.Generator | None = None) -> np.ndarray:
    """Frozen AR1 residual block.

    Layout: `AR1_N_BLOCKS` contiguous blocks of size `AR1_BLOCK_DIM`; each block is
    the stationary AR1 covariance with unit innovation variance, i.e.
    B[i, j] = rho ** |i - j| within the block (positive definite for |rho| < 1),
    plus a diagonal floor `diagonal_floor` on every coordinate.

    `rng` is accepted for interface symmetry but B* is deterministic from the
    conditioning parameters alone (no randomness in B*).
    """
    assert conditioning in CONDITIONING_PARAMS, conditioning
    p = CONDITIONING_PARAMS[conditioning]
    rho = p["rho"]; dfloor = p["diagonal_floor"]
    B = np.zeros((LATENT_DIM, LATENT_DIM), dtype=np.float64)
    for b in range(AR1_N_BLOCKS):
        s = b * AR1_BLOCK_DIM
        idx = np.arange(s, s + AR1_BLOCK_DIM)
        for i in range(AR1_BLOCK_DIM):
            for j in range(AR1_BLOCK_DIM):
                B[idx[i], idx[j]] += rho ** abs(i - j)
    B += dfloor * np.eye(LATENT_DIM)
    return B


def build_U_star(conditioning: str, target_seed: int) -> tuple[np.ndarray, float]:
    """Frozen U* construction.

    - Draw raw Gaussian matrix G ~ N(0, I) of shape (LATENT_DIM, RANK) from the
      target_seed RNG (seeded locally, independent of optimizer seeds).
    - Orthonormalize columns via QR (householder, numpy default) -> Q of shape
      (LATENT_DIM, RANK) with orthonormal columns.
    - Scale by s so that the trace share tr(U* U*^T)/tr(B* + U* U*^T) equals the
      frozen target share for this target_id.

    Returns (U_star, scale).
    """
    rng = np.random.default_rng(target_seed)
    G = rng.standard_normal((LATENT_DIM, RANK))
    Q, _ = np.linalg.qr(G)
    Q = Q[:, :RANK]
    # trace-share achieved by scaling: share = s^2 tr(QQ^T) / (tr(B)+ s^2 tr(QQ^T))
    B = build_B_AR1(conditioning)
    trB = np.trace(B)
    trQQ = np.trace(Q @ Q.T)  # = RANK for exactly orthonormal Q
    # share target for this target_id:
    # (T01/T04 -> 0.05, T02/T05 -> 0.15, T03/T06 -> 0.30) — caller passes share
    return Q, trB, trQQ


def trace_share_scale(share: float, trB: float, trQQ: float) -> float:
    """Exact scale s solving share = s^2 trQQ / (trB + s^2 trQQ)."""
    assert 0.0 < share < 1.0
    denom = (1.0 - share) * trQQ
    assert denom > 0.0
    return float(np.sqrt((share * trB) / denom))


def make_target(conditioning: str, share: float, target_seed: int) -> dict:
    """Frozen Module B target: {target_seed, B_star, U_star, Sigma_star, share, scale}.

    Deterministic given (conditioning, share, target_seed).
    """
    B = build_B_AR1(conditioning)
    rng = np.random.default_rng(target_seed)
    Q, _ = np.linalg.qr(rng.standard_normal((LATENT_DIM, RANK)))
    Q = Q[:, :RANK]
    trB = np.trace(B)
    trQQ = np.trace(Q @ Q.T)
    s = trace_share_scale(share, trB, trQQ)
    U = s * Q
    Sigma = B + U @ U.T
    # frozen validation: symmetry, PSD, achieved share
    assert np.allclose(Sigma, Sigma.T, atol=ENG_TOL)
    ev = np.linalg.eigvalsh(Sigma)
    assert ev.min() > -ENG_TOL, "Sigma* not PSD at engineering tolerance"
    achieved = np.trace(U @ U.T) / np.trace(Sigma)
    assert abs(achieved - share) < 0.01, f"achieved share {achieved} != target {share}"
    return {
        "target_seed": target_seed,
        "conditioning": conditioning,
        "share_target": share,
        "B_star": B,
        "U_star": U,
        "Sigma_star": Sigma,
        "scale": s,
        "achieved_share": achieved,
        "cond_number": float(np.linalg.cond(Sigma)),
    }
