from __future__ import annotations

import json
from pathlib import Path

from dhbcp_pv.sim.generator import PHASE2_SCENARIOS, run_phase2_pilot_suite


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    results = root / "results/phase2"
    results.mkdir(parents=True, exist_ok=True)
    frame = run_phase2_pilot_suite()
    truth_fields = {
        "true_state",
        "true_change_quarter",
        "true_persistence_duration",
        "true_log_rr",
        "true_serious_probability",
        "is_true_signal",
    }
    checks = {
        "all_scenarios_present": set(frame.scenario) == set(PHASE2_SCENARIOS),
        "expected_rows": len(frame) == len(PHASE2_SCENARIOS) * 20 * 40 * 3,
        "truth_fields_present": truth_fields.issubset(frame.columns),
        "counts_nonnegative": bool((frame.y_reports >= 0).all() and (frame.s_serious >= 0).all()),
        "serious_not_above_reports": bool((frame.s_serious <= frame.y_reports).all()),
        "probabilities_bounded": bool(frame.true_serious_probability.between(0, 1).all()),
        "engineering_label_only": set(frame.result_scope) == {"ENGINEERING_PILOT_NOT_FORMAL"},
    }
    summary = {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "result_scope": "ENGINEERING_PILOT_NOT_FORMAL",
        "formal_results": False,
        "checks": checks,
        "rows": int(len(frame)),
        "scenario_summaries": frame.groupby("scenario", sort=True).agg(
            rows=("y_reports", "size"),
            total_reports=("y_reports", "sum"),
            total_serious=("s_serious", "sum"),
            mean_expected=("m_expected", "mean"),
        ).reset_index().to_dict("records"),
    }
    frame.to_parquet(results / "phase2_simulation_pilot.parquet", index=False, compression="zstd")
    (results / "39_PHASE2_SIMULATION_SMOKE.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"status": summary["status"], "rows": summary["rows"]}, indent=2))


if __name__ == "__main__":
    main()
