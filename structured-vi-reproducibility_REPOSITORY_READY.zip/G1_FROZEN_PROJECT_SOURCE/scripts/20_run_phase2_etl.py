from __future__ import annotations

import json
from pathlib import Path

from dhbcp_pv.data.faers_etl import run_phase2_etl


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    result = run_phase2_etl(root)
    print(json.dumps({
        "qa_status": result["qa"]["status"],
        "no_leakage_passed": result["no_leakage"]["passed"],
        "artifacts": len(result["artifacts"]),
    }, indent=2))


if __name__ == "__main__":
    main()
