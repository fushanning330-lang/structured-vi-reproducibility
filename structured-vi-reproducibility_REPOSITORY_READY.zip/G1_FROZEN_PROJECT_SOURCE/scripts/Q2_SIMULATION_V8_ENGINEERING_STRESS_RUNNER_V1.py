"""V8 single-use engineering-only full-length stress-test runner.

NOT SCIENTIFIC EVIDENCE.
Runs exactly four new V8 engineering identities.
Never invokes the official 239-identity scheduler.
"""

from __future__ import annotations
import hashlib
import json
from pathlib import Path

from Q2_simulation_module_b_V8 import (
    EngineeringFailure,
    engineering_failure_record,
    fit_one,
    persist_failure,
    persist_run,
)

EXPECTED_SOURCE_SHA256 = {
    "Q2_simulation_target_generator_V4.py": "daf890ec155ac6a1a2887e8c65bed035ec5b2c96e897647a69e23870cd8054bf",
    "Q2_simulation_metrics_V4.py": "7a008dbdcc8cb5cf82be11d9816507ad1e43f58ca0bbe80606bb160b33da9144",
    "Q2_simulation_module_b_V8.py": "39900bf608d9cb914c394010e7764a0add887c663d96166aee51209960a5fa94",
}

STRESS_ROWS = [
    {"stress_id":"V8ST01","particles":"P1","conditioning":"well_conditioned","trace_share":"0.05","seed":92001,"replicate_prefix":"ENGINEERING_ONLY","scenario":"ENGINEERING_STRESS_V8ST01"},
    {"stress_id":"V8ST02","particles":"P4","conditioning":"well_conditioned","trace_share":"0.05","seed":92002,"replicate_prefix":"ENGINEERING_ONLY","scenario":"ENGINEERING_STRESS_V8ST02"},
    {"stress_id":"V8ST03","particles":"P1","conditioning":"moderately_ill_conditioned","trace_share":"0.30","seed":92003,"replicate_prefix":"ENGINEERING_ONLY","scenario":"ENGINEERING_STRESS_V8ST03"},
    {"stress_id":"V8ST04","particles":"P4","conditioning":"moderately_ill_conditioned","trace_share":"0.30","seed":92004,"replicate_prefix":"ENGINEERING_ONLY","scenario":"ENGINEERING_STRESS_V8ST04"},
]

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_sources() -> dict:
    here = Path(__file__).resolve().parent
    out = {}
    for name, expected in EXPECTED_SOURCE_SHA256.items():
        p = here / name
        if not p.exists():
            raise RuntimeError(f"FROZEN_SOURCE_MISSING: {p}")
        actual = sha256(p)
        out[name] = {"expected":expected,"actual":actual,"match":actual==expected}
        if actual != expected:
            raise RuntimeError(f"FROZEN_SOURCE_SHA_MISMATCH: {name}")
    return out

def ensure_fresh(out: Path) -> None:
    pats = ("MB_*.json","MB_*.npz","stress_manifest.json","stress_batch_stopped.json")
    existing = []
    if out.exists():
        for pat in pats:
            existing.extend(sorted(out.glob(pat)))
    if existing:
        raise RuntimeError("V8_ENGINEERING_STRESS_OUTPUT_NOT_FRESH_ABORT: " +
                           ", ".join(p.name for p in existing[:20]))

def main() -> None:
    source_hashes = verify_sources()
    out = Path("results/q2_supplementary_simulation/engineering_stress_test_v8")
    ensure_fresh(out)
    out.mkdir(parents=True, exist_ok=True)

    attempted, completed, failed = [], [], []

    for row in STRESS_ROWS:
        attempted.append(row["stress_id"])
        try:
            rec = fit_one(row)
            rec["stress_id"] = row["stress_id"]
            rec["engineering_only"] = True
            rec["scientific_evidence_eligible"] = False
            persist_run(rec, out)
            completed.append({"stress_id":row["stress_id"],"run_id":rec["run_id"],
                              "status":"COMPLETED","steps":rec["steps"]})
        except EngineeringFailure as exc:
            fail = engineering_failure_record(row, exc.stage, exc)
            fail.update({"stress_id":row["stress_id"],"engineering_only":True,
                         "scientific_evidence_eligible":False})
            persist_failure(fail, out)
            failed.append(fail)
            (out/"stress_batch_stopped.json").write_text(
                json.dumps({
                    "artifact":"Q2_SIMULATION_V8_ENGINEERING_STRESS_BATCH_STOPPED",
                    "classification":"ENGINEERING_ONLY_NOT_FOR_SCIENTIFIC_ANALYSIS",
                    "reason":"engineering failure; STOP; no rerun; await ChatGPT adjudication",
                    "failed_identity":fail,
                    "completed_before_stop":len(completed)
                }, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
            break
        except Exception as exc:
            fail = engineering_failure_record(row, "stress_runner_unknown", exc)
            fail.update({"stress_id":row["stress_id"],"engineering_only":True,
                         "scientific_evidence_eligible":False})
            persist_failure(fail, out)
            failed.append(fail)
            (out/"stress_batch_stopped.json").write_text(
                json.dumps({
                    "artifact":"Q2_SIMULATION_V8_ENGINEERING_STRESS_BATCH_STOPPED",
                    "classification":"ENGINEERING_ONLY_NOT_FOR_SCIENTIFIC_ANALYSIS",
                    "reason":"unexpected engineering exception; STOP; no rerun; await ChatGPT adjudication",
                    "failed_identity":fail,
                    "completed_before_stop":len(completed)
                }, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
            break

    manifest = {
        "artifact":"Q2_SIMULATION_V8_ENGINEERING_STRESS_MANIFEST",
        "classification":"ENGINEERING_ONLY_NOT_FOR_SCIENTIFIC_ANALYSIS",
        "scientific_evidence_eligible":False,
        "planned":4,
        "attempted":len(attempted),
        "completed":len(completed),
        "failed":len(failed),
        "attempted_stress_ids":attempted,
        "completed_runs":completed,
        "failed_runs":failed,
        "frozen_source_sha256":source_hashes,
        "batch_status":"PASS_ALL_4" if len(completed)==4 and not failed else "STOPPED_ON_FAILURE",
        "governance":{
            "one_attempt_per_stress_identity":True,
            "no_rerun":True,
            "no_replacement":True,
            "stop_on_first_failure":True,
            "not_for_manuscript":True
        }
    }
    (out/"stress_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False, default=float),
        encoding="utf-8")
    print(json.dumps({
        "stress_test":manifest["batch_status"],
        "attempted":manifest["attempted"],
        "completed":manifest["completed"],
        "failed":manifest["failed"],
        "output_dir":str(out)
    }, indent=2))

if __name__ == "__main__":
    main()
