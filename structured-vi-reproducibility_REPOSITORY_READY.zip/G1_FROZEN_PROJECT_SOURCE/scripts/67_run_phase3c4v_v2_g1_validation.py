#!/usr/bin/env python3
"""Phase3C.4V V2 — FUTURE V2 G1 VALIDATION RUNNER (scripts/67).

Modes (argparse: --mode preflight|canary|validation):

  --mode preflight   : deterministic source / protocol / readiness checks
                       ONLY. This is the ONLY mode allowed to run now.
                       Writes:
                         results/phase3c4v/preflight/42K_V2_G1_RUNNER_READINESS_PREFLIGHT.{json,md}

  --mode canary      : REFUSED (STOP_NOT_AUTHORIZED, exit 2) unless a FUTURE
                       separate explicit human canary authorization artifact
                       exists at results/phase3c4v_v2/authorizations/ with
                       AUTHORIZED=true and correct protocol binding.

  --mode validation  : REFUSED (STOP_NOT_AUTHORIZED, exit 2) unless a FUTURE
                       separate explicit human full-validation authorization
                       artifact exists with AUTHORIZED=true.

NO authorization artifacts are created by this runner. The V2 execution path
beyond the authorization guards is NOT implemented in this batch and raises
explicitly, so no SVI / optimization can run. One-shot RUN_STARTED guards and
a NEW isolated V2 run namespace (results/phase3c4v_v2/) are provided; the
consumed V0/V1 Phase3C4V run directories are never written to and old run
identities are never reused.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# ---------------------------------------------------------------------------
# Frozen SHAs (live-verified chain at 42K generation time).
# ---------------------------------------------------------------------------
EXPECTED = {
    "42E": "c50a2bac39d0c5a5c257a0c62f1b94189b4275e08f91621ff6153959fcf33bc5",
    "42F": "e60c654259ef7763bc00c9315ef6cdb214b35fc5270e725aa7a5b90e87df3066",
    "42H": "b3a8ee28d0729fb055b4d45eb8b0a66ae8e0a425905fdde58acd5b51cd7ef363",
    "42I": "7efb62e588de1a83f3618818c1ebd9d150301482e35fcac2f42ce7c3b7f22cc1",
    "42J": "115ebec9ee98aaa81afaca093698179739ca37a820c417c297bb1c36eb953e8f",
    "guide_fix": "51e23a5c68d34d1d164b20a362cffc4667dedb39da6324426a6674783fa40fdb",
    "scripts66": "1185f5952f70c6dfdf27f7295244ec5a6dd5c907e59c3fd86ab4ecec9ecfc121",
    "model": "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c",
    "v1_guide": "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878",
    "scripts64": "6879309eaf50505da8b923fe4705a48581d21f4c91bf4dfddaaffb98019a0ade",
    "serializer": "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803",
    "scripts51": "1239716a2c73ed1faf3f6085a8bce361553c81c9ad4245bb9149845c45bcff4f",
    "seed_csv": "2054361bc280a975b9694f1de40cad87884da9bf7bd1c9fbbd691faea229c7db",
    "generator": "5617a62697337fbdfb2ded19f6a3ef8ce2061d6ab0bf91437272391f14bf3f8a",
}

FROZEN_PATHS = {
    "42E": "results/phase3c4v/audit/42E_V2_AR1_TEMPORAL_MATHEMATICAL_SPECIFICATION_FREEZE.json",
    "42F": "results/phase3c4v/audit/42F_V2_AR1_NUMERICAL_SAFETY_AMENDMENT.json",
    "42H": "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.json",
    "42I": "results/phase3c4v/preflight/42I_V2_AR1_CORRECTIVE_IMPLEMENTATION_G0_PREFLIGHT.json",
    "42J": "results/phase3c4v/protocol/42J_V2_G1_OPTIMIZATION_PROTOCOL_FREEZE.json",
    "guide_fix": "src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py",
    "scripts66": "scripts/66_phase3c4v_v2_corrective_deterministic_g0_preflight.py",
    "model": "src/dhbcp_pv/models/full_joint_model.py",
    "v1_guide": "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py",
    "scripts64": "scripts/64_run_phase3c4v_parameter_persistent_validation.py",
    "serializer": "src/dhbcp_pv/inference/variational_param_persistence.py",
    "scripts51": "scripts/51_run_phase3c_nuts.py",
    "seed_csv": "config/phase3b_tiera_seeds_v1.csv",
    "generator": "src/dhbcp_pv/sim/hierarchical_phase3b.py",
}

V2_NS = ROOT / "results/phase3c4v_v2"
V2_RUNS = V2_NS / "runs"
V2_AUTHS = V2_NS / "authorizations"
CANARY_AUTH_PATH = V2_AUTHS / "V2_G1_CANARY_AUTHORIZATION.json"
VALIDATION_AUTH_PATH = V2_AUTHS / "V2_G1_VALIDATION_AUTHORIZATION.json"

RUN_STARTED_NAME = "RUN_STARTED"


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


# ---------------------------------------------------------------------------
# Authorization guards (shared by cmd_* and verified by preflight).
# ---------------------------------------------------------------------------
def _load_auth_artifact(path: Path):
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {"unreadable": True}


def guard_canary(root: Path) -> dict:
    """Return {'refused': bool, 'reason': str} for --mode canary."""
    auth = _load_auth_artifact(CANARY_AUTH_PATH)
    if auth is None:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: no V2 G1 canary authorization artifact exists "
                          "(results/phase3c4v_v2/authorizations/V2_G1_CANARY_AUTHORIZATION.json). "
                          "Canary is NOT authorized in this task."}
    if not bool(auth.get("AUTHORIZED", False)):
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: V2 G1 canary authorization artifact exists but "
                          "AUTHORIZED != true."}
    p42j = json.loads((root / FROZEN_PATHS["42J"]).read_text(encoding="utf-8"))
    if auth.get("binds", {}).get("42J") != p42j.get("artifact_id"):
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: canary authorization does not bind 42J protocol freeze."}
    return {"refused": False, "reason": "AUTHORIZED"}


def guard_validation(root: Path) -> dict:
    """Return {'refused': bool, 'reason': str} for --mode validation."""
    auth = _load_auth_artifact(VALIDATION_AUTH_PATH)
    if auth is None:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: no V2 G1 full-validation authorization artifact exists "
                          "(results/phase3c4v_v2/authorizations/V2_G1_VALIDATION_AUTHORIZATION.json)."}
    if not bool(auth.get("AUTHORIZED", False)):
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: V2 G1 validation authorization artifact exists but "
                          "AUTHORIZED != true."}
    return {"refused": False, "reason": "AUTHORIZED"}


# ---------------------------------------------------------------------------
# One-shot RUN_STARTED guard (future V2 execution path).
# ---------------------------------------------------------------------------
def acquire_run_started(run_dir: Path, identity: str) -> dict:
    """One-shot guard: creates RUN_STARTED atomically; refuses if present."""
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    marker = run_dir / RUN_STARTED_NAME
    if marker.exists():
        return {"acquired": False, "reason": "RUN_STARTED already exists; identity is consumed and never rerun."}
    try:
        payload = {"identity": identity, "started_utc": utc_now()}
        tmp = run_dir / (RUN_STARTED_NAME + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        tmp.replace(marker)
        return {"acquired": True, "reason": "RUN_STARTED created (one-shot consumed)."}
    except Exception as exc:  # noqa: BLE001
        return {"acquired": False, "reason": repr(exc)}


# ---------------------------------------------------------------------------
# Preflight checks.
# ---------------------------------------------------------------------------
def verify_frozen_chain(root: Path) -> dict:
    results = {}
    ok = True
    for name, rel in FROZEN_PATHS.items():
        p = root / rel
        exp = EXPECTED[name]
        live = sha256(p) if p.exists() else "MISSING"
        match = live == exp
        results[name] = {"expected": exp, "live": live, "ok": match}
        ok = ok and match
    return {"ok": ok, "results": results}


def check_42i_pass(root: Path) -> dict:
    p = root / FROZEN_PATHS["42I"]
    d = json.loads(p.read_text(encoding="utf-8"))
    return {
        "classification": d.get("classification"),
        "overall": d.get("checks", {}).get("OVERALL"),
        "ok": d.get("classification") == "V2_CORRECTIVE_G0_PREFLIGHT_PASS"
              and d.get("checks", {}).get("OVERALL") == "PASS",
    }


def check_run_matrix(root: Path) -> dict:
    p42j = json.loads((root / FROZEN_PATHS["42J"]).read_text(encoding="utf-8"))
    matrix = p42j.get("4_run_matrix", {})
    identities = matrix.get("identities", [])
    arms = matrix.get("arms", [])
    by_arm = {}
    for r in identities:
        by_arm.setdefault(r["arm"], []).append(r["seed"])
    canary = p42j.get("5_future_canary_identity", {})
    expected = {
        "total_identities": 10,
        "arms": {"V2_ARM_P1": {"particles": 1, "seeds": [1001, 2002, 3003, 4004, 5005]},
                 "V2_ARM_P4": {"particles": 4, "seeds": [1001, 2002, 3003, 4004, 5005]}},
    }
    ok = True
    detail = {"total_identities": len(identities)}
    for aname, spec in expected["arms"].items():
        arm = next((a for a in arms if a.get("id") == aname), None)
        seeds = by_arm.get(aname, [])
        ok = ok and arm is not None and arm.get("num_particles") == spec["particles"]
        ok = ok and sorted(seeds) == sorted(spec["seeds"])
        detail[aname] = {"num_particles": arm.get("num_particles") if arm else None,
                         "seeds": sorted(seeds)}
    ok = ok and len(identities) == expected["total_identities"]
    ok = ok and bool(canary and canary.get("identity") == "V2_V2_ARM_P1_p1_seed1001_t12"
                     and canary.get("num_particles") == 1 and canary.get("seed") == 1001
                     and canary.get("cutoff") == 12)
    detail["canary"] = {
        "identity": canary.get("identity"),
        "authorized": canary.get("authorized"),
    }
    ok = ok and canary.get("authorized") is False
    detail["canary_authorized_false"] = bool(canary.get("authorized") is False)
    return {"ok": ok, "detail": detail}


def check_no_consumed_identities(root: Path) -> dict:
    p42j = json.loads((root / FROZEN_PATHS["42J"]).read_text(encoding="utf-8"))
    identities = [r["identity"] for r in p42j["4_run_matrix"]["identities"]]
    consumed = []
    if V2_RUNS.exists():
        for ident in identities:
            rd = V2_RUNS / ident
            if (rd / RUN_STARTED_NAME).exists() or (rd / "result.json").exists():
                consumed.append(ident)
    return {"ok": not consumed, "consumed": consumed,
            "n_consumed": len(consumed), "namespace": str(V2_RUNS)}


def check_authorizations_absent(root: Path) -> dict:
    canary_auth = _load_auth_artifact(CANARY_AUTH_PATH)
    validation_auth = _load_auth_artifact(VALIDATION_AUTH_PATH)
    p42j = json.loads((root / FROZEN_PATHS["42J"]).read_text(encoding="utf-8"))
    canary_false = bool(p42j.get("1_authorization_state", {}).get("V2_CANARY_AUTHORIZED") is False)
    val_false = bool(p42j.get("1_authorization_state", {}).get("V2_VALIDATION_AUTHORIZED") is False)
    return {
        "ok": canary_auth is None and validation_auth is None and canary_false and val_false,
        "canary_auth_artifact": canary_auth is None,
        "validation_auth_artifact": validation_auth is None,
        "42J_V2_CANARY_AUTHORIZED": p42j.get("1_authorization_state", {}).get("V2_CANARY_AUTHORIZED"),
        "42J_V2_VALIDATION_AUTHORIZED": p42j.get("1_authorization_state", {}).get("V2_VALIDATION_AUTHORIZED"),
    }


def check_negative_guards(root: Path) -> dict:
    """Runner canary/validation modes MUST refuse; preflight asserts the
    refusal WITHOUT executing either mode past the authorization guard."""
    c = guard_canary(root)
    v = guard_validation(root)
    return {
        "ok": bool(c["refused"] and v["refused"]),
        "canary_refused": bool(c["refused"]),
        "canary_reason": c["reason"],
        "validation_refused": bool(v["refused"]),
        "validation_reason": v["reason"],
    }


def run_preflight(root: Path) -> dict:
    chain = verify_frozen_chain(root)
    i42 = check_42i_pass(root)
    matrix = check_run_matrix(root)
    consumed = check_no_consumed_identities(root)
    auths = check_authorizations_absent(root)
    guards = check_negative_guards(root)
    # establish the isolated V2 namespace (no run identities consumed)
    V2_RUNS.mkdir(parents=True, exist_ok=True)
    V2_AUTHS.mkdir(parents=True, exist_ok=True)
    ok = chain["ok"] and i42["ok"] and matrix["ok"] and consumed["ok"] \
        and auths["ok"] and guards["ok"]
    return {
        "ok": ok,
        "chain": chain["results"],
        "42I": i42,
        "run_matrix": matrix["detail"],
        "consumed": {"n_consumed": consumed["n_consumed"], "consumed": consumed["consumed"],
                     "namespace": consumed["namespace"]},
        "authorizations": auths,
        "negative_guards": guards,
        "namespace_established": {"runs": str(V2_RUNS), "authorizations": str(V2_AUTHS)},
    }


def cmd_preflight(root: Path) -> int:
    res = run_preflight(root)
    classification = (
        "V2_G1_RUNNER_READY_FOR_HUMAN_CANARY_AUTHORIZATION" if res["ok"]
        else "V2_G1_RUNNER_NOT_READY"
    )
    payload = {
        "artifact_id": "42K_V2_G1_RUNNER_READINESS_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "mode": "V2 G1 RUNNER READINESS PREFLIGHT (deterministic source/protocol/readiness checks only; "
                "no SVI, no optimization, no canary, no validation)",
        "classification": classification,
        "checks": {
            "frozen_sha_chain": res["ok"] and all(v["ok"] for v in res["chain"].values()),
            "42I_pass": res["42I"]["ok"],
            "run_matrix_exactly_10": res["run_matrix"]["total_identities"] == 10,
            "canary_identity_exactly_one": bool(res["run_matrix"].get("canary")),
            "no_v2_identity_consumed": res["consumed"]["n_consumed"] == 0,
            "canary_authorization_absent_or_false": res["authorizations"]["canary_auth_artifact"],
            "validation_authorization_absent_or_false": res["authorizations"]["validation_auth_artifact"],
            "canary_mode_refuses": res["negative_guards"]["canary_refused"],
            "validation_mode_refuses": res["negative_guards"]["validation_refused"],
            "OVERALL": "PASS" if res["ok"] else "FAIL",
        },
        "sha_chain": res["chain"],
        "42I": res["42I"],
        "run_matrix": res["run_matrix"],
        "consumed_identities": res["consumed"],
        "authorization_state": res["authorizations"],
        "negative_mode_guards": res["negative_guards"],
        "namespace": res["namespace_established"],
        "flags": {
            "V2_CANARY_AUTHORIZED": False,
            "V2_VALIDATION_AUTHORIZED": False,
            "V2_OPTIMIZATION_EXECUTED": False,
            "NEW_INFERENCE_RUN": False,
            "NEW_OPTIMIZATION_RUN": False,
            "POSTERIOR_DRAWS_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "G3_AUTHORIZED": False,
            "SCIENTIFIC_TARGET_MODIFIED": False,
            "V1_MODIFIED": False,
            "FAILED_PHASE3C4_PCA_USED": False,
        },
        "created_files": [
            "scripts/67_run_phase3c4v_v2_g1_validation.py",
            "results/phase3c4v/preflight/42K_V2_G1_RUNNER_READINESS_PREFLIGHT.json",
            "results/phase3c4v/preflight/42K_V2_G1_RUNNER_READINESS_PREFLIGHT.md",
        ],
        "modified_files": [],
        "final_state": ("V2_PREOPTIMIZATION_ENGINEERING_COMPLETE" if res["ok"]
                        else "V2_PREOPTIMIZATION_ENGINEERING_INCOMPLETE"),
        "waiting_for": ("STOP_WAITING_FOR_HUMAN_CANARY_AUTHORIZATION" if res["ok"]
                        else "STOP_WAITING_FOR_RUNNER_READINESS_FIX"),
    }
    out_path = root / "results/phase3c4v/preflight/42K_V2_G1_RUNNER_READINESS_PREFLIGHT.json"
    atomic_write_json(out_path, payload)
    md = ["# 42K — V2 G1 RUNNER READINESS PREFLIGHT", "",
          f"Generated: {utc_now()}  |  Mode: V2 G1 RUNNER READINESS PREFLIGHT "
          "(no SVI, no optimization, no canary, no validation)", "",
          f"**Classification: {classification}**", "",
          "| Check | Result |", "|---|---|"]
    for k, v in payload["checks"].items():
        md.append(f"| {k} | {'PASS' if v else 'FAIL'} |")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in res["chain"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", "## Negative mode guards", ""]
    md.append(f"- canary mode: refused={res['negative_guards']['canary_refused']} — {res['negative_guards']['canary_reason']}")
    md.append(f"- validation mode: refused={res['negative_guards']['validation_refused']} — {res['negative_guards']['validation_reason']}")
    md += ["", "## Flags", "", "| Flag | Value |", "|---|---|"]
    for k, v in payload["flags"].items():
        md.append(f"| {k} | {v} |")
    md += ["", f"## Final state: **{payload['final_state']}**", f"- {payload['waiting_for']}"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", payload["checks"]["OVERALL"])
    return 0 if res["ok"] else 2


def cmd_canary(root: Path) -> int:
    g = guard_canary(root)
    if g["refused"]:
        print(g["reason"])
        return 2
    # Beyond the guard: V2 G1 execution is NOT implemented in this batch.
    raise NotImplementedError(
        "V2_G1_EXECUTION_NOT_IMPLEMENTED_IN_THIS_BATCH: the canary SVI path requires a "
        "future authorized runner implementation; nothing was executed."
    )


def cmd_validation(root: Path) -> int:
    g = guard_validation(root)
    if g["refused"]:
        print(g["reason"])
        return 2
    raise NotImplementedError(
        "V2_G1_EXECUTION_NOT_IMPLEMENTED_IN_THIS_BATCH: the validation SVI path requires a "
        "future authorized runner implementation; nothing was executed."
    )


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Future V2 G1 validation runner (preflight only now)")
    ap.add_argument("--mode", required=True, choices=["preflight", "canary", "validation"])
    args = ap.parse_args(argv)
    if args.mode == "preflight":
        return cmd_preflight(ROOT)
    if args.mode == "canary":
        return cmd_canary(ROOT)
    return cmd_validation(ROOT)


if __name__ == "__main__":
    sys.exit(main())
