#!/usr/bin/env python
"""Phase 3C.1 direct-path target-equivalence checks and short geometry pilot."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping

os.environ.setdefault("JAX_ENABLE_X64", "1")
os.environ.setdefault("XLA_FLAGS", "--xla_force_host_platform_device_count=4")

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
import yaml
from jax import random
from numpyro import handlers
from numpyro.infer import MCMC, NUTS

from dhbcp_pv.inference.phase3c1_direct_path import (
    direct_path_reference_model,
    direct_path_to_original_coordinates,
    original_coordinates_to_direct_path,
)
from dhbcp_pv.inference.phase3c_stabilized import (
    DENSE_MASS_BLOCKS,
    assert_x64_reference_mode,
)
from dhbcp_pv.models.full_joint_model import full_joint_model, reconstruct_x
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_a_replicate


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
    os.replace(tmp, path)


def atomic_npz(path: Path, arrays: Mapping[str, np.ndarray]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    os.replace(tmp, path)


def reference_data(root: Path, cutoff: int = 12):
    seeds = pd.read_csv(root / "config/phase3b_tiera_seeds_v1.csv")
    seed = int(seeds.loc[seeds.replicate_id == 1, "seed"].iloc[0])
    replicate = generate_tier_a_replicate(seed, n_quarters=40)
    pair_mask = (replicate.drug_index < 10) & (replicate.event_index < 5)
    if int(pair_mask.sum()) != 50:
        raise RuntimeError("frozen reference subset is not 10 drugs x 5 events")
    args = (
        jnp.asarray(replicate.y[pair_mask, :cutoff]),
        jnp.asarray(replicate.serious[pair_mask, :cutoff]),
        jnp.asarray(replicate.expected[pair_mask, :cutoff], dtype=jnp.float64),
        jnp.asarray(replicate.drug_index[pair_mask]),
        jnp.asarray(replicate.event_index[pair_mask]),
        10,
        5,
    )
    kwargs = {"hmax": 12}
    return seed, args, kwargs


def trace_log_joint(model, key, params, args, kwargs) -> float:
    wrapped = handlers.substitute(handlers.seed(model, key), data=params)
    trace = handlers.trace(wrapped).get_trace(*args, **kwargs)
    total = jnp.asarray(0.0, dtype=jnp.float64)
    for site in trace.values():
        if site.get("type") != "sample":
            continue
        fn = site.get("fn")
        value = site.get("value")
        if fn is None:
            continue
        total = total + jnp.sum(fn.log_prob(value))
    return float(total)


def original_latent_draw(key, args, kwargs) -> dict[str, jax.Array]:
    trace = handlers.trace(handlers.seed(full_joint_model, key)).get_trace(*args, **kwargs)
    return {
        name: site["value"]
        for name, site in trace.items()
        if site.get("type") == "sample"
        and not site.get("is_observed", False)
        and not name.startswith("count_log_likelihood")
        and not name.startswith("hsmm_and_increment_target_correction")
    }


def run_equivalence(root: Path) -> dict[str, Any]:
    assert_x64_reference_mode()
    seed, args, kwargs = reference_data(root, cutoff=12)

    # Smaller deterministic slices keep the equivalence test fast while
    # exercising the complete global model plus exact HSMM target.
    small_args = (
        args[0][:2, :4],
        args[1][:2, :4],
        args[2][:2, :4],
        jnp.asarray([0, 1]),
        jnp.asarray([0, 1]),
        2,
        2,
    )

    errors = []
    rows = []
    for index in range(5):
        key = random.PRNGKey(seed + 81000 + index)
        params_original = original_latent_draw(key, small_args, kwargs)

        x0 = params_original["x_initial"]
        inc = params_original["base_increment"]
        x_path = original_coordinates_to_direct_path(x0, inc)

        params_reparam = {
            name: value
            for name, value in params_original.items()
            if name not in {"x_initial", "base_increment"}
        }
        params_reparam["x_path_coord"] = x_path

        original = trace_log_joint(
            full_joint_model,
            random.PRNGKey(991 + index),
            params_original,
            small_args,
            kwargs,
        )
        reparam = trace_log_joint(
            direct_path_reference_model,
            random.PRNGKey(991 + index),
            params_reparam,
            small_args,
            kwargs,
        )
        error = abs(original - reparam)
        errors.append(error)
        rows.append(
            {
                "index": index,
                "original_log_joint": original,
                "reparam_log_joint": reparam,
                "absolute_error": error,
            }
        )

        # Independent algebraic inverse check.
        rx0, rinc = direct_path_to_original_coordinates(x_path)
        if not bool(jnp.allclose(rx0, x0, atol=1e-12, rtol=0)):
            raise RuntimeError("x_initial inverse transform failed")
        if not bool(jnp.allclose(rinc, inc, atol=1e-12, rtol=0)):
            raise RuntimeError("increment inverse transform failed")

    payload = {
        "version": "phase3c1_direct_path_equivalence_v1",
        "created_utc": utc_now(),
        "scientific_target_changed": False,
        "n_test_points": len(rows),
        "max_absolute_error": max(errors),
        "tolerance": 1e-6,
        "passed": max(errors) <= 1e-6,
        "rows": rows,
    }
    out = root / "results/phase3c1/01_TARGET_EQUIVALENCE.json"
    atomic_json(out, payload)
    print(json.dumps(payload, indent=2))
    if not payload["passed"]:
        raise SystemExit("TARGET EQUIVALENCE: FAIL")
    print("TARGET EQUIVALENCE: PASS")
    return payload


def ebfmi(energy: np.ndarray) -> float:
    energy = np.asarray(energy, dtype=float).reshape(-1)
    variance = np.var(energy, ddof=1)
    if len(energy) < 2 or variance <= 0:
        return float("nan")
    return float(np.mean(np.diff(energy) ** 2) / variance)


def original_chain_rng_key(seed: int, cutoff: int, chain_id: int):
    # Same identity used by Phase3C chain runner.
    keys = random.split(random.PRNGKey(seed + 6000 + cutoff), 4)
    return keys[chain_id]


def run_pilot(root: Path, chain_id: int) -> dict[str, Any]:
    assert_x64_reference_mode()
    cfg = yaml.safe_load(
        (root / "config/phase3c1_direct_path_pilot_v1.yaml").read_text()
    )
    cutoff = int(cfg["reference"]["cutoff"])
    seed, args, kwargs = reference_data(root, cutoff=cutoff)
    p = cfg["pilot"]

    dense_mass = [tuple(block) for block in DENSE_MASS_BLOCKS]

    kernel = NUTS(
        direct_path_reference_model,
        dense_mass=dense_mass,
        target_accept_prob=float(p["target_accept_prob"]),
        max_tree_depth=int(p["max_tree_depth"]),
        regularize_mass_matrix=bool(p["regularize_mass_matrix"]),
    )
    mcmc = MCMC(
        kernel,
        num_warmup=int(p["warmup"]),
        num_samples=int(p["samples"]),
        num_chains=1,
        chain_method="sequential",
        progress_bar=True,
        progress_rate=25,
    )

    key = original_chain_rng_key(seed, cutoff, chain_id)
    started = perf_counter()
    mcmc.run(
        key,
        *args,
        extra_fields=(
            "diverging",
            "num_steps",
            "accept_prob",
            "energy",
            "potential_energy",
        ),
        **kwargs,
    )
    raw = mcmc.get_samples(group_by_chain=True)
    extra = mcmc.get_extra_fields(group_by_chain=True)
    jax.block_until_ready(jax.tree.leaves(raw)[0])

    # Restore original scientific path coordinates for diagnostics.
    direct = raw["x_path_coord"]
    x0, inc = direct_path_to_original_coordinates(direct)
    x = direct  # by definition these are the direct path levels

    samples = dict(raw)
    samples["x_initial"] = x0
    samples["base_increment"] = inc
    samples["x"] = x

    arrays = {name: np.asarray(value) for name, value in samples.items()}
    arrays.update({f"_extra_{name}": np.asarray(value) for name, value in extra.items()})

    divergences = int(np.asarray(extra["diverging"], dtype=bool).sum())
    finite = all(np.isfinite(v).all() for v in arrays.values())
    bfmi_value = ebfmi(np.asarray(extra["energy"])[0])
    max_tree_depth = int(p["max_tree_depth"])
    saturation_threshold = 2 ** max_tree_depth - 1
    num_steps = np.asarray(extra["num_steps"])[0]
    tree_sat = float(np.mean(num_steps >= saturation_threshold))
    accept_mean = float(np.mean(np.asarray(extra["accept_prob"])[0]))

    gate = cfg["pilot_gate"]
    passed = bool(
        divergences == int(gate["divergences"])
        and finite is bool(gate["finite_posterior"])
        and bfmi_value >= float(gate["ebfmi_min"])
        and tree_sat <= float(gate["tree_depth_saturation_rate_max"])
    )

    result_dir = root / "results/phase3c1/pilot"
    artifact = result_dir / f"DIRECT_PATH_t{cutoff:02d}_chain{chain_id}.npz"
    atomic_npz(artifact, arrays)

    payload = {
        "version": "phase3c1_direct_path_pilot_result_v1",
        "created_utc": utc_now(),
        "status": "PASS_PROMISING" if passed else "FAIL_NOT_PROMISING",
        "scientific_target_changed": False,
        "chain_id": chain_id,
        "cutoff": cutoff,
        "warmup": int(p["warmup"]),
        "samples": int(p["samples"]),
        "target_accept_prob": float(p["target_accept_prob"]),
        "max_tree_depth": max_tree_depth,
        "divergences": divergences,
        "finite_posterior": finite,
        "ebfmi": bfmi_value,
        "tree_depth_saturation_rate": tree_sat,
        "mean_accept_prob": accept_mean,
        "elapsed_seconds": perf_counter() - started,
        "artifact": {
            "path": artifact.relative_to(root).as_posix(),
            "bytes": artifact.stat().st_size,
            "sha256": sha256(artifact),
        },
        "pilot_gate": gate,
        "passed": passed,
    }
    meta = artifact.with_suffix(".json")
    atomic_json(meta, payload)
    print(json.dumps(payload, indent=2))
    print("PHASE3C1 PILOT:", payload["status"])
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        choices=("equivalence", "pilot"),
        required=True,
    )
    parser.add_argument("--chain-id", type=int, choices=(0, 1, 2, 3), default=1)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]

    if args.mode == "equivalence":
        run_equivalence(root)
    else:
        eq = root / "results/phase3c1/01_TARGET_EQUIVALENCE.json"
        if not eq.exists():
            raise SystemExit("Run --mode equivalence first.")
        data = json.loads(eq.read_text())
        if not data.get("passed"):
            raise SystemExit("Target equivalence did not pass.")
        run_pilot(root, args.chain_id)


if __name__ == "__main__":
    main()
