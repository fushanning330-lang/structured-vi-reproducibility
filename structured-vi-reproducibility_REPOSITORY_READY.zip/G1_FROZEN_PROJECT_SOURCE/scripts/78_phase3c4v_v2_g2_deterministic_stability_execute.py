"""Phase3C.4V V2 — G2 DETERMINISTIC STABILITY ANALYSIS EXECUTION RUNNER (scripts/78).

Authoritative sources (all SHA-bound below):
  - 42Z  V2 G1 FINAL COHORT CLOSEOUT (G1_EVALUABLE_RUNS_ALL_VALID_ENGINEERING_ATTRITION_REQUIRES_HUMAN_COHORT_ADJUDICATION)
  - 42ZA V2 G2 REPLICATE POSTERIOR STABILITY PROTOCOL FREEZE (V2_G2_REPLICATE_POSTERIOR_STABILITY_PROTOCOL_FROZEN)
  - 42ZB V2 G2 DETERMINISTIC ANALYSIS PREFLIGHT PASS
  - 42ZC V2 G1 COHORT HUMAN ADJUDICATION AND G2 AUTHORIZATION BASIS
        (G2_ALLOWED_ON_EVALUABLE_COHORT=true; P1 n=3, P4 n=5, attrition=2)
  - 42ZD V2 G2 DETERMINISTIC EXECUTION SPECIFICATION FREEZE (this runner's
        metric realizations are exactly those frozen there)
  - artifact22 (validation hierarchy G2) / artifact36 (g2_followup_metrics)
  - guide_fix / model / serializer / scripts77 (frozen)

MODES:
  --mode preflight : N1..N26 deterministic checks ONLY. No scientific G2
                     result is computed. Writes
                     results/phase3c4v/preflight/42ZE_V2_G2_EXECUTION_PREFLIGHT.{json,md}
  --mode execute   : deterministic G2 analysis over the 8 evaluable fitted
                     runs. READ-ONLY w.r.t. the run directories. Requires a
                     PASSING 42ZE artifact on disk (conditional human
                     authorization). Runs exactly once: if 42ZF already exists
                     it REFUSES (G2_ALREADY_EXECUTED) to prevent overwrite.

NO SVI. NO posterior sampling. NO importance sampling. NO NUTS/HMC/MCMC.
NO random draws of any kind. No quantitative G2 threshold exists (42ZA/42ZD);
classification is only G2_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION or
G2_EXECUTION_INCOMPLETE.
"""

import argparse
import csv
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# Frozen identity cohort (42ZC/42ZA): exactly 8 evaluable runs.
# ---------------------------------------------------------------------------
EVALUABLE = [
    "V2_V2_ARM_P1_p1_seed3003_t12",
    "V2_V2_ARM_P1_p1_seed4004_t12",
    "V2_V2_ARM_P1_p1_seed5005_t12",
    "V2_V2_ARM_P4_p4_seed1001_t12",
    "V2_V2_ARM_P4_p4_seed2002_t12",
    "V2_V2_ARM_P4_p4_seed3003_t12",
    "V2_V2_ARM_P4_p4_seed4004_t12",
    "V2_V2_ARM_P4_p4_seed5005_t12",
]
P1_IDS = [i for i in EVALUABLE if "_P1_" in i]     # exactly 3
P4_IDS = [i for i in EVALUABLE if "_P4_" in i]     # exactly 5
UNUSABLE_P1 = ["V2_V2_ARM_P1_p1_seed1001_t12", "V2_V2_ARM_P1_p1_seed2002_t12"]

RUNS_DIR = ROOT / "results/phase3c4v_v2/runs"
G2_OUT = ROOT / "results/phase3c4v_v2/g2"
PREFLIGHT_OUT = ROOT / "results/phase3c4v/preflight"

# Frozen constants (42E/42H/42F)
LATENT_DIM = 708
FACTOR_DIM = 28
TOTAL_ELEMENTS = 13377
LOG_SCALE_ABS_MAX = 300.0
RHO_MAX = 0.99

# Semantic blocks (42ZD frozen indices; identical to guide _BLOCK_SEGMENTS)
SEMANTIC_BLOCKS = [
    {"name": "count_plus_initial", "dim": 120, "indices": list(range(0, 70)) + list(range(108, 158))},
    {"name": "dynamic_scale", "dim": 16, "indices": list(range(70, 86))},
    {"name": "seriousness", "dim": 22, "indices": list(range(86, 108))},
    {"name": "temporal_path", "dim": 550, "indices": list(range(158, 708))},
]
BLOCK_OF_COORD = {}
for _b in SEMANTIC_BLOCKS:
    for _i in _b["indices"]:
        BLOCK_OF_COORD[_i] = _b["name"]

# ---------------------------------------------------------------------------
# Frozen SHA chain bound by this runner (42ZD values for 42ZC/42ZD).
# ---------------------------------------------------------------------------
FROZEN_CHAIN = {
    "42Z": ("results/phase3c4v_v2/audit/42Z_V2_G1_FINAL_COHORT_CLOSEOUT.json",
            "af525c61863eca94923b098f4c29049091f136620ab1575cc9670eabe2259c3b"),
    "42ZA": ("results/phase3c4v_v2/protocol/42ZA_V2_G2_REPLICATE_POSTERIOR_STABILITY_PROTOCOL_FREEZE.json",
             "0b76b1a2fa7d56d7f328e1e9b929ceead194363199dcd537d26503866720f53e"),
    "42ZB": ("results/phase3c4v/preflight/42ZB_V2_G2_DETERMINISTIC_ANALYSIS_PREFLIGHT.json",
             "a472b1097bf3027ec7b6a9b02f5774f3ae74740a8a2fa11180af966bd2227452"),
    "42ZC": ("results/phase3c4v_v2/audit/42ZC_V2_G1_COHORT_HUMAN_ADJUDICATION_AND_G2_AUTHORIZATION_BASIS.json",
             "c2636eda117e6e77516b06a3acb4ae9187eb76b4d91cbd01ee218354d6f1e9b6"),
    "42ZD": ("results/phase3c4v_v2/protocol/42ZD_V2_G2_DETERMINISTIC_EXECUTION_SPECIFICATION_FREEZE.json",
             "47fd48f39a39a73737946e976fa047f91e5a3d03fbf2f3c784021f0c229670e0"),
    "artifact22": ("results/phase3c4/22_ALTERNATIVE_VARIATIONAL_ARCHITECTURE_PROTOCOL.json",
                   "b069cbf5e452608f1a87113955505524eb83adaa5bd798c5f93e1e833e4746bf"),
    "artifact36": ("results/phase3c4v/protocol/36_PHASE3C4V_PARAMETER_PERSISTENT_VALIDATION_PROTOCOL.json",
                   "573990f00893bccf14a0e9bb6f45b1199650fc3542ad0617c685d81143feda27"),
    "guide_fix": ("src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py",
                  "51e23a5c68d34d1d164b20a362cffc4667dedb39da6324426a6674783fa40fdb"),
    "model": ("src/dhbcp_pv/models/full_joint_model.py",
              "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"),
    "serializer": ("src/dhbcp_pv/inference/variational_param_persistence.py",
                   "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"),
    "scripts77": ("scripts/77_phase3c4v_v2_g2_deterministic_stability_analysis.py",
                  "31c180baa3a8afff7d8b39907a469a01107c6e1d7d334b3b6618936ffd055296"),
}


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def verify_frozen_chain() -> dict:
    results = {}
    ok = True
    for name, (rel, expected) in FROZEN_CHAIN.items():
        p = ROOT / rel
        if not p.exists():
            results[name] = {"ok": False, "live": None, "expected": expected}
            ok = False
            continue
        live = sha256(p)
        good = live == expected
        ok = ok and good
        results[name] = {"ok": good, "live": live, "expected": expected}
    return {"ok": ok, "results": results}


# ---------------------------------------------------------------------------
# Parameter loading + analytic Sigma construction (42ZD metric realizations).
# ---------------------------------------------------------------------------
PARAM_KEYS = ["v2_loc", "v2_diag_log_scale", "v2_F_shared", "v2_F_count_plus_initial",
              "v2_F_dynamic_scale", "v2_F_seriousness", "v2_raw_temporal_rho"]
PARAM_SHAPES = {"v2_loc": (708,), "v2_diag_log_scale": (708,), "v2_F_shared": (708, 16),
                "v2_F_count_plus_initial": (120, 4), "v2_F_dynamic_scale": (16, 4),
                "v2_F_seriousness": (22, 4), "v2_raw_temporal_rho": (1,)}


def load_params(ident: str) -> dict:
    rd = RUNS_DIR / ident
    npz = rd / "final_svi_params.npz"
    if not npz.exists():
        raise FileNotFoundError(f"final_svi_params.npz missing for {ident}")
    with np.load(npz) as z:
        out = {k: np.asarray(z[k], dtype=np.float64) for k in PARAM_KEYS}
    for k in PARAM_KEYS:
        if out[k].shape != PARAM_SHAPES[k]:
            raise ValueError(f"{ident}: param {k} shape {out[k].shape} != {PARAM_SHAPES[k]}")
    return out


def build_sigma(params: dict) -> tuple[np.ndarray, np.ndarray]:
    """Analytic Sigma = B + U U^T and diag(Sigma) = s^2 + rowsum(U^2).

    B: blockdiag(diag(s[0:158]^2), B_1..B_50); B_p = S_p R_11(rho) S_p with
    R_11[i,j] = rho^|i-j| (11x11 AR(1)), S_p = diag(s[temporal block p]).
    U: (708,28) factor matrix exactly as guide _build_u.
    """
    s = np.exp(np.clip(params["v2_diag_log_scale"], -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))
    raw_rho = float(params["v2_raw_temporal_rho"][0])
    rho = RHO_MAX * np.tanh(raw_rho)

    U = np.zeros((LATENT_DIM, FACTOR_DIM), dtype=np.float64)
    U[:, :16] = params["v2_F_shared"]
    idx = {}
    for b in SEMANTIC_BLOCKS:
        idx[b["name"]] = np.asarray(b["indices"], dtype=np.int64)
    U[idx["count_plus_initial"], 16:20] = params["v2_F_count_plus_initial"]
    U[idx["dynamic_scale"], 20:24] = params["v2_F_dynamic_scale"]
    U[idx["seriousness"], 24:28] = params["v2_F_seriousness"]

    B = np.zeros((LATENT_DIM, LATENT_DIM), dtype=np.float64)
    B[np.arange(158), np.arange(158)] = s[:158] ** 2
    k = np.arange(11)
    R11 = rho ** np.abs(k[:, None] - k[None, :])
    for p in range(50):
        base = 158 + p * 11
        S = np.diag(s[base:base + 11])
        B[base:base + 11, base:base + 11] = S @ R11 @ S

    Sigma = B + U @ U.T
    diag_vec = s ** 2 + np.sum(U * U, axis=1)
    return Sigma, diag_vec


# ---------------------------------------------------------------------------
# Deterministic metric primitives (42ZD realizations; Cholesky-solve order
# corrected per the scripts77 oracle finding: invG = solve(L.T, solve(L, I))).
# ---------------------------------------------------------------------------
def projection_matrix(F: np.ndarray) -> np.ndarray:
    F = np.asarray(F, dtype=np.float64)
    G = F.T @ F
    L = np.linalg.cholesky(G)
    invG = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(G.shape[0])))
    return F @ invG @ F.T


def principal_angles(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    Qa, _ = np.linalg.qr(A, mode="reduced")
    Qb, _ = np.linalg.qr(B, mode="reduced")
    _, sv, _ = np.linalg.svd(Qa.T @ Qb)
    return np.arccos(np.clip(sv, -1.0, 1.0))


def procrustes_compare(F_i: np.ndarray, F_j: np.ndarray) -> tuple[float, float]:
    F_i = np.asarray(F_i, dtype=np.float64)
    F_j = np.asarray(F_j, dtype=np.float64)
    u, _, vt = np.linalg.svd(F_i.T @ F_j)
    Q = u @ vt  # orthogonal Procrustes rotation
    raw = float(np.linalg.norm(F_i - F_j @ Q, ord="fro"))
    denom = float(np.sqrt(np.linalg.norm(F_i, ord="fro") * np.linalg.norm(F_j, ord="fro")))
    norm = raw / denom if denom > 0 else float("nan")
    return raw, norm


def desc_summary(values) -> dict:
    a = np.asarray(values, dtype=np.float64)
    mean = float(np.nanmean(a)) if a.size else float("nan")
    sd = float(np.nanstd(a, ddof=0)) if a.size > 1 else 0.0
    cv = sd / mean if mean != 0 and np.isfinite(mean) else float("nan")
    return {"mean": mean, "sd": sd, "cv": cv,
            "min": float(np.nanmin(a)) if a.size else float("nan"),
            "max": float(np.nanmax(a)) if a.size else float("nan"),
            "n": int(a.size)}


def seed_of(ident: str) -> int:
    for tok in ident.split("_"):
        if tok.isdigit():
            return int(tok)
    return -1


def arm_of(ident: str) -> str:
    return "P1" if "_P1_" in ident else "P4"


# ---------------------------------------------------------------------------
# SVI runtime probe (preflight only; proves zero SVI calls).
# ---------------------------------------------------------------------------
def _install_svi_probe():
    import numpyro.infer as ni
    counters = {"init": 0, "update": 0, "stable_update": 0}
    orig = {}
    for meth, key in (("init", "init"), ("update", "update"), ("stable_update", "stable_update")):
        orig[meth] = getattr(ni.SVI, meth)

        def make_wrap(k):
            def wrap(self, *a, **kw):
                counters[k] += 1
                return orig[k](self, *a, **kw)
            return wrap
        setattr(ni.SVI, meth, make_wrap(key))
    return counters, orig


def _restore_svi(orig) -> None:
    import numpyro.infer as ni
    for meth, fn in orig.items():
        setattr(ni.SVI, meth, fn)


# ---------------------------------------------------------------------------
# Preflight: N1..N26 (no scientific G2 results computed).
# ---------------------------------------------------------------------------
def _toy_params():
    rng = np.random.RandomState(20260820)
    n = LATENT_DIM
    count_idx = np.asarray(SEMANTIC_BLOCKS[0]["indices"], dtype=np.int64)  # 120
    dyn_idx = np.asarray(SEMANTIC_BLOCKS[1]["indices"], dtype=np.int64)    # 16
    ser_idx = np.asarray(SEMANTIC_BLOCKS[2]["indices"], dtype=np.int64)    # 22
    return {
        "v2_loc": rng.normal(0, 1, n),
        "v2_diag_log_scale": rng.normal(-0.5, 0.1, n),
        "v2_F_shared": rng.normal(0, 0.1, (n, 16)),
        "v2_F_count_plus_initial": rng.normal(0, 0.1, (count_idx.size, 4)),
        "v2_F_dynamic_scale": rng.normal(0, 0.1, (dyn_idx.size, 4)),
        "v2_F_seriousness": rng.normal(0, 0.1, (ser_idx.size, 4)),
        "v2_raw_temporal_rho": np.array([0.2]),
    }


def run_preflight(counters: dict | None = None) -> dict:
    checks = {}
    rec = lambda n, ok, d: checks.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731
    src = Path(__file__).read_text(encoding="utf-8")

    # N1-N4: identities
    on_disk = sorted(p.name for p in RUNS_DIR.iterdir() if p.is_dir())
    id_ok = all((RUNS_DIR / i / "result.json").exists() for i in EVALUABLE)
    rec("N1_exact_8_identities", id_ok, {"n": len(EVALUABLE), "identities": EVALUABLE})
    rec("N2_P1_n_3", len(P1_IDS) == 3, {"P1": P1_IDS})
    rec("N3_P4_n_5", len(P4_IDS) == 5, {"P4": P4_IDS})
    rec("N4_unusable_p1_excluded",
        all(i not in EVALUABLE for i in UNUSABLE_P1)
        and all((RUNS_DIR / i / "RUN_STARTED").exists() for i in UNUSABLE_P1),
        {"unusable": UNUSABLE_P1, "in_evaluable": [i for i in UNUSABLE_P1 if i in EVALUABLE],
         "consumed_on_disk": [i for i in UNUSABLE_P1 if (RUNS_DIR / i / "RUN_STARTED").exists()]})

    # N5-N8: per-run schema/finiteness/x64
    schema_ok = True
    finite_ok = True
    shape_problems = []
    for ident in EVALUABLE:
        params = load_params(ident)
        n_params = len(params)
        n_total = sum(int(p.size) for p in params.values())
        if n_params != 7 or n_total != TOTAL_ELEMENTS:
            schema_ok = False
            shape_problems.append(f"{ident}: {n_params}params/{n_total}")
        for k, v in params.items():
            if not np.all(np.isfinite(v)):
                finite_ok = False
                shape_problems.append(f"{ident}: nonfinite {k}")
    rec("N5_exact_7_params_each", schema_ok, {"problems": shape_problems})
    rec("N6_total_13377_each", schema_ok, {"total": TOTAL_ELEMENTS})
    rec("N7_all_params_finite", finite_ok, {"problems": shape_problems})
    rec("N8_x64", np.dtype(np.float64).itemsize == 8 and np.issubdtype(np.float64, np.floating),
        {"float64_itemsize": np.dtype(np.float64).itemsize})

    # N9: covariance symmetric/PD on real runs (analytic)
    cov_ok = True
    cov_detail = []
    for ident in EVALUABLE:
        Sigma, diagv = build_sigma(load_params(ident))
        sym = float(np.max(np.abs(Sigma - Sigma.T)))
        ev = np.linalg.eigvalsh(Sigma)
        pd = float(ev[0])
        if sym > 1e-8 or pd <= 0:
            cov_ok = False
            cov_detail.append(f"{ident}: sym_diff={sym:.2e} min_eig={pd:.2e}")
    rec("N9_covariance_symmetric_PD", cov_ok, {"detail": cov_detail or "all OK"})

    # N10: marginal diagonal analytic-vs-dense oracle (toy)
    toy = _toy_params()
    Sigma_t, diag_t = build_sigma(toy)
    diag_match = float(np.max(np.abs(np.diag(Sigma_t) - diag_t)))
    rec("N10_marginal_diag_analytic_vs_dense_oracle", diag_match < 1e-10,
        {"toy_max_diag_diff": diag_match})

    # N11: projection implementation oracle (toy; idempotent/symmetric/fixes F
    #      and matches explicit inverse) — independent small factor matrix.
    Ut = np.random.RandomState(7).normal(0, 0.1, (8, 7))
    P = projection_matrix(Ut)
    P_ref = Ut @ np.linalg.inv(Ut.T @ Ut) @ Ut.T
    p_ok = (float(np.max(np.abs(P - P_ref))) < 1e-8
            and float(np.max(np.abs(P @ P - P))) < 1e-8
            and float(np.max(np.abs(P - P.T))) < 1e-8
            and float(np.max(np.abs(P @ Ut - Ut))) < 1e-8)
    rec("N11_projection_implementation_oracle", p_ok,
        {"max_diff_vs_inv": float(np.max(np.abs(P - P_ref))),
         "idempotent_diff": float(np.max(np.abs(P @ P - P)))})

    # N12: principal-angle oracle (toy; orthogonal spaces => angles pi/2)
    A = np.eye(4)[:, :2]   # 4x2: span(e1, e2)
    B = np.eye(4)[:, 2:]   # 4x2: span(e3, e4) orthogonal to A
    ang = principal_angles(A, B)
    ang_ok = (ang.shape == (2,) and float(np.max(np.abs(ang - np.pi / 2))) < 1e-8)
    rec("N12_principal_angle_oracle", ang_ok,
        {"orthogonal_angles": [float(a) for a in ang]})

    # N13: Procrustes oracle (toy; F_j = F_i Q => raw ~ 0)
    F_i = np.random.RandomState(3).normal(0, 1, (10, 3))
    u, _, vt = np.linalg.svd(F_i.T @ (F_i @ np.eye(3)))
    Q = u @ vt
    F_j = F_i @ Q
    raw_p, norm_p = procrustes_compare(F_i, F_j)
    proc_ok = raw_p < 1e-8
    rec("N13_procrustes_oracle", proc_ok, {"raw_residual_rotated": raw_p, "normalized": norm_p})

    # N14: block-allocation sums reconcile to trace(Sigma) (toy)
    tr = float(np.trace(Sigma_t))
    block_sum = 0.0
    for b in SEMANTIC_BLOCKS:
        block_sum += float(np.sum(diag_t[np.asarray(b["indices"])]))
    rec("N14_block_allocation_reconciles_to_trace", abs(block_sum - tr) < 1e-8,
        {"block_sum": block_sum, "trace": tr})

    # N15: semantic indices exact (dims 120/16/22/550, union = all 708)
    all_idx = np.concatenate([np.asarray(b["indices"], dtype=np.int64) for b in SEMANTIC_BLOCKS])
    dims = [b["dim"] for b in SEMANTIC_BLOCKS]
    idx_ok = (dims == [120, 16, 22, 550]
              and all_idx.shape[0] == 708
              and np.array_equal(np.sort(all_idx), np.arange(708)))
    rec("N15_semantic_indices_exact", idx_ok,
        {"dims": dims, "n_union": int(all_idx.shape[0])})

    # N16: pair counts exact
    rec("N16_pair_counts_exact",
        len(P1_IDS) * (len(P1_IDS) - 1) // 2 == 3 and len(P4_IDS) * (len(P4_IDS) - 1) // 2 == 10,
        {"P1_pairs": 3, "P4_pairs": 10})

    # N17: no failed-PCA reference (dynamic assembly avoids self-match)
    bad_pca = "failed" + " Phase3C4 " + "PCA"
    rec("N17_no_failed_pca_reference", bad_pca not in src,
        {"pca_ref_present": bad_pca in src})

    # N18: no SVI (probe counters during entire preflight)
    probe_ok = bool(counters is None or (counters["init"] == 0 and counters["update"] == 0
                                         and counters["stable_update"] == 0))
    rec("N18_no_svi", probe_ok, {"counters": counters or {"init": 0, "update": 0, "stable_update": 0}})

    # N19-N21: no posterior sampling / importance sampling / MCMC (source scan;
    #          patterns assembled dynamically so the scan cannot self-match)
    pat_sample = "numpyro." + "sample("
    pat_importance = "importance" + "("
    pat_nuts = "NUT" + "S("
    pat_hmc = "HM" + "C("
    pat_mcmc = "MCM" + "C("
    rec("N19_no_posterior_sampling", pat_sample not in src, {"hits": [p for p in (pat_sample,) if p in src]})
    rec("N20_no_importance_sampling", pat_importance not in src,
        {"hits": [p for p in (pat_importance,) if p in src]})
    rec("N21_no_nuts_hmc_mcmc", all(p not in src for p in (pat_nuts, pat_hmc, pat_mcmc)),
        {"hits": [p for p in (pat_nuts, pat_hmc, pat_mcmc) if p in src]})

    # N22: no G2 threshold (source scan, dynamic assembly)
    t_pat = ["G2_" + "PASS_THRESHOLD", "G2_" + "FAIL_THRESHOLD", "win" + "ner",
             "post-hoc" + " stability cutoff"]
    hits = [p for p in t_pat if p in src]
    rec("N22_no_g2_threshold", not hits, {"hits": hits})

    # N23: source SHA chain exact
    chain = verify_frozen_chain()
    rec("N23_source_sha_chain_exact", chain["ok"],
        {"mismatches": [k for k, v in chain["results"].items() if not v["ok"]]})

    # N24: no fitted result modified (SHA snapshot before/after preflight)
    snap_before = {}
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_before[ident] = {"result": sha256(rd / "result.json"),
                              "npz": sha256(rd / "final_svi_params.npz")}
    # (preflight writes nothing into run dirs; re-snapshot to prove)
    snap_after = {}
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_after[ident] = {"result": sha256(rd / "result.json"),
                             "npz": sha256(rd / "final_svi_params.npz")}
    rec("N24_no_fitted_result_modified", snap_before == snap_after,
        {"identical": snap_before == snap_after})

    # N25: output namespace clean before execute
    g2_clean = (not G2_OUT.exists()) or (not any(G2_OUT.iterdir()))
    rec("N25_output_namespace_clean_before_execute", g2_clean,
        {"g2_dir_exists": G2_OUT.exists(),
         "existing": sorted(p.name for p in G2_OUT.iterdir()) if G2_OUT.exists() else []})

    # N26: G3 unauthorized (42ZC bound + source has no G3 authorization)
    zc = json.loads((ROOT / FROZEN_CHAIN["42ZC"][0]).read_text(encoding="utf-8"))
    g3_ok = (zc.get("G3_AUTHORIZED") is False)
    rec("N26_G3_unauthorized", g3_ok, {"42ZC_G3_AUTHORIZED": zc.get("G3_AUTHORIZED")})

    ok = all(c["ok"] for c in checks.values())
    return {"ok": ok, "checks": checks, "chain": chain["results"]}


def cmd_preflight() -> int:
    counters, orig = _install_svi_probe()
    try:
        res = run_preflight(counters=counters)
    finally:
        _restore_svi(orig)
    classification = ("V2_G2_EXECUTION_PREFLIGHT_PASS" if res["ok"]
                      else "V2_G2_EXECUTION_PREFLIGHT_FAIL")
    payload = {
        "artifact_id": "42ZE_V2_G2_EXECUTION_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "mode": "V2 G2 DETERMINISTIC ANALYSIS EXECUTION PREFLIGHT (N1..N26; "
                "no scientific G2 results computed)",
        "classification": classification,
        "checks": {k: v["ok"] for k, v in res["checks"].items()},
        "check_details": res["checks"],
        "sha_chain": res["chain"],
        "svi_runtime_probe": counters,
        "flags": {
            "G2_EXECUTED": False,
            "G2_POSTERIOR_DRAWS_USED": False,
            "G2_NEW_INFERENCE_USED": False,
            "SVI_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "NUTS_HMC_MCMC_USED": False,
            "G3_AUTHORIZED": False,
        },
        "final_state": ("V2_G2_EXECUTION_PREFLIGHT_PASS" if res["ok"]
                        else "V2_G2_EXECUTION_PREFLIGHT_FAIL"),
    }
    out_path = PREFLIGHT_OUT / "42ZE_V2_G2_EXECUTION_PREFLIGHT.json"
    atomic_write_json(out_path, payload)
    md = ["# 42ZE — V2 G2 Execution Preflight", "",
          f"Generated: {utc_now()}  |  Mode: V2 G2 DETERMINISTIC ANALYSIS EXECUTION PREFLIGHT (N1..N26; no scientific G2 results)",
          "", f"**Classification: {classification}**", "", "| Check | Result |", "|---|---|"]
    for k, v in payload["checks"].items():
        md.append(f"| {k} | {'PASS' if v else 'FAIL'} |")
    md += ["", "## SVI runtime probe", ""]
    md.append(f"- init={counters['init']} update={counters['update']} stable_update={counters['stable_update']}")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in res["chain"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", f"## Final state: **{payload['final_state']}**"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", "PASS" if res["ok"] else "FAIL")
    return 0 if res["ok"] else 2


# ---------------------------------------------------------------------------
# Execute: deterministic G2 analysis (exactly once; read-only w.r.t. runs).
# ---------------------------------------------------------------------------
def _within_arm_pairs(ids):
    pairs = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            pairs.append((ids[i], ids[j]))
    return pairs


def compute_all(ident: str):
    params = load_params(ident)
    Sigma, diagv = build_sigma(params)
    loc = params["v2_loc"]
    s = np.exp(np.clip(params["v2_diag_log_scale"], -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))
    U = np.zeros((LATENT_DIM, FACTOR_DIM), dtype=np.float64)
    U[:, :16] = params["v2_F_shared"]
    idx = {}
    for b in SEMANTIC_BLOCKS:
        idx[b["name"]] = np.asarray(b["indices"], dtype=np.int64)
    U[idx["count_plus_initial"], 16:20] = params["v2_F_count_plus_initial"]
    U[idx["dynamic_scale"], 20:24] = params["v2_F_dynamic_scale"]
    U[idx["seriousness"], 24:28] = params["v2_F_seriousness"]
    rho = RHO_MAX * np.tanh(float(params["v2_raw_temporal_rho"][0]))
    return {
        "loc": loc, "diag": diagv, "U": U, "rho": rho,
        "trace": float(np.trace(Sigma)),
        "block_total": {b["name"]: float(np.sum(diagv[np.asarray(b["indices"])])) for b in SEMANTIC_BLOCKS},
    }


def cmd_execute() -> int:
    # Guard: exactly-once semantics (42ZF must not exist yet).
    zf_json = G2_OUT / "42ZF_V2_G2_DETERMINISTIC_STABILITY_EVIDENCE.json"
    if zf_json.exists():
        print("G2_ALREADY_EXECUTED: 42ZF exists; refusing to overwrite. "
              "G2 execute is exactly-once.")
        return 3
    # Guard: conditional human authorization requires a PASSING 42ZE on disk.
    ze = PREFLIGHT_OUT / "42ZE_V2_G2_EXECUTION_PREFLIGHT.json"
    if not ze.exists():
        print("STOP_NOT_AUTHORIZED: 42ZE preflight artifact missing; "
              "G2 execute requires V2_G2_EXECUTION_PREFLIGHT_PASS first.")
        return 2
    ze_data = json.loads(ze.read_text(encoding="utf-8"))
    if ze_data.get("classification") != "V2_G2_EXECUTION_PREFLIGHT_PASS":
        print("STOP_NOT_AUTHORIZED: 42ZE is not PASS; G2 execute refused.")
        return 2
    # Guard: frozen chain exact.
    chain = verify_frozen_chain()
    if not chain["ok"]:
        print("STOP_SHA_MISMATCH: frozen chain mismatch; G2 execute refused.")
        return 2

    t0 = time.time()
    # SHA snapshot of fitted artifacts BEFORE (read-only proof).
    snap_before = {}
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_before[ident] = {"result": sha256(rd / "result.json"),
                              "npz": sha256(rd / "final_svi_params.npz")}

    data = {ident: compute_all(ident) for ident in EVALUABLE}

    # ---- metric 1: location L2 (within-arm pairs) ----
    loc_rows = []
    loc_by_arm = {"P1": [], "P4": []}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in _within_arm_pairs(ids):
            d = float(np.linalg.norm(data[i]["loc"] - data[j]["loc"]))
            loc_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                             "seed_i": seed_of(i), "seed_j": seed_of(j),
                             "location_l2_distance": d})
            loc_by_arm[arm].append(d)

    # ---- metric 2: marginal scale CV (per arm x coordinate) ----
    cv_rows = []
    cv_summary = {"P1": [], "P4": []}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        mat = np.vstack([data[ident]["diag"] for ident in ids])  # (n,708)
        sd_vec = np.sqrt(mat)
        mean = np.mean(sd_vec, axis=0)
        sd = np.std(sd_vec, axis=0)
        with np.errstate(divide="ignore", invalid="ignore"):
            cv = np.where(mean != 0, sd / mean, np.nan)
        for coord in range(LATENT_DIM):
            cv_rows.append({"arm": arm, "latent_index": coord,
                            "semantic_block": BLOCK_OF_COORD[coord],
                            "mean_marginal_sd": float(mean[coord]),
                            "sd_marginal_sd": float(sd[coord]),
                            "cv_marginal_sd": float(cv[coord]),
                            "min_marginal_sd": float(np.min(sd_vec[:, coord])),
                            "max_marginal_sd": float(np.max(sd_vec[:, coord]))})
        cv_summary[arm] = [float(v) for v in cv if np.isfinite(v)]

    # ---- metric 3: factor subspace principal angles ----
    ang_rows = []
    ang_by_arm = {"P1": [], "P4": []}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in _within_arm_pairs(ids):
            angles = principal_angles(data[i]["U"], data[j]["U"])
            for a_i, a in enumerate(angles):
                ang_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                                 "seed_i": seed_of(i), "seed_j": seed_of(j),
                                 "angle_index": a_i,
                                 "angle_radians": float(a),
                                 "angle_degrees": float(np.degrees(a))})
            ang_by_arm[arm].extend([float(a) for a in angles])

    # ---- metric 4: projection matrix distance ----
    proj_rows = []
    proj_by_arm = {"P1": [], "P4": []}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in _within_arm_pairs(ids):
            Pi = projection_matrix(data[i]["U"])
            Pj = projection_matrix(data[j]["U"])
            d = float(np.linalg.norm(Pi - Pj, ord="fro"))
            proj_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                              "seed_i": seed_of(i), "seed_j": seed_of(j),
                              "projection_frobenius_distance": d})
            proj_by_arm[arm].append(d)

    # ---- metric 5: Procrustes (raw + symmetric normalized) ----
    proc_rows = []
    proc_by_arm = {"P1": {"raw": [], "norm": []}, "P4": {"raw": [], "norm": []}}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in _within_arm_pairs(ids):
            raw, norm = procrustes_compare(data[i]["U"], data[j]["U"])
            proc_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                              "seed_i": seed_of(i), "seed_j": seed_of(j),
                              "raw_residual": raw,
                              "symmetric_normalized_residual": norm})
            proc_by_arm[arm]["raw"].append(raw)
            proc_by_arm[arm]["norm"].append(norm)

    # ---- metric 6: block covariance allocation ----
    block_rows = []
    block_by_arm = {arm: {b["name"]: [] for b in SEMANTIC_BLOCKS}
                    for arm in ("P1", "P4")}
    for ident in EVALUABLE:
        arm = arm_of(ident)
        for b in SEMANTIC_BLOCKS:
            tot = data[ident]["block_total"][b["name"]]
            frac = tot / data[ident]["trace"]
            block_rows.append({"arm": arm, "identity": ident, "seed": seed_of(ident),
                               "semantic_block": b["name"],
                               "block_total_variance": tot,
                               "block_fraction_of_total_variance": frac})
            block_by_arm[arm][b["name"]].append(frac)

    # ---- metric 7: rho variation ----
    rho_rows = []
    rho_by_arm = {"P1": [], "P4": []}
    for ident in EVALUABLE:
        arm = arm_of(ident)
        rho_rows.append({"arm": arm, "identity": ident, "seed": seed_of(ident),
                         "raw_rho": None, "rho": data[ident]["rho"]})
        rho_by_arm[arm].append(data[ident]["rho"])

    # ---- write CSVs ----
    G2_OUT.mkdir(parents=True, exist_ok=True)

    def write_csv(name, fieldnames, rows):
        p = G2_OUT / name
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(rows)
        return p

    p_loc = write_csv("G2_LOCATION_PAIRWISE.csv",
                      ["arm", "identity_i", "identity_j", "seed_i", "seed_j", "location_l2_distance"],
                      loc_rows)
    p_cv = write_csv("G2_MARGINAL_SCALE_CV.csv",
                     ["arm", "latent_index", "semantic_block", "mean_marginal_sd",
                      "sd_marginal_sd", "cv_marginal_sd", "min_marginal_sd", "max_marginal_sd"],
                     cv_rows)
    p_ang = write_csv("G2_FACTOR_PRINCIPAL_ANGLES.csv",
                      ["arm", "identity_i", "identity_j", "seed_i", "seed_j",
                       "angle_index", "angle_radians", "angle_degrees"],
                      ang_rows)
    p_proj = write_csv("G2_PROJECTION_DISTANCE.csv",
                       ["arm", "identity_i", "identity_j", "seed_i", "seed_j",
                        "projection_frobenius_distance"],
                       proj_rows)
    p_proc = write_csv("G2_PROCRUSTES_COMPARISON.csv",
                       ["arm", "identity_i", "identity_j", "seed_i", "seed_j",
                        "raw_residual", "symmetric_normalized_residual"],
                       proc_rows)
    p_block = write_csv("G2_BLOCK_COVARIANCE_ALLOCATION.csv",
                        ["arm", "identity", "seed", "semantic_block",
                         "block_total_variance", "block_fraction_of_total_variance"],
                        block_rows)
    p_rho = write_csv("G2_RHO_VARIATION.csv",
                      ["arm", "identity", "seed", "raw_rho", "rho"],
                      rho_rows)

    # ---- arm summaries ----
    summary = {
        "P1": {
            "n": len(P1_IDS),
            "pair_count": len(loc_by_arm["P1"]),
            "location_l2_distance": desc_summary(loc_by_arm["P1"]),
            "marginal_scale_cv_across_coords": desc_summary(cv_summary["P1"]),
            "principal_angle_degrees": desc_summary(ang_by_arm["P1"]),
            "projection_frobenius_distance": desc_summary(proj_by_arm["P1"]),
            "procrustes_raw_residual": desc_summary(proc_by_arm["P1"]["raw"]),
            "procrustes_symmetric_normalized": desc_summary(proc_by_arm["P1"]["norm"]),
            "block_fraction_of_total_variance": {
                b: desc_summary(block_by_arm["P1"][b]) for b in block_by_arm["P1"]},
            "rho": desc_summary(rho_by_arm["P1"]),
        },
        "P4": {
            "n": len(P4_IDS),
            "pair_count": len(loc_by_arm["P4"]),
            "location_l2_distance": desc_summary(loc_by_arm["P4"]),
            "marginal_scale_cv_across_coords": desc_summary(cv_summary["P4"]),
            "principal_angle_degrees": desc_summary(ang_by_arm["P4"]),
            "projection_frobenius_distance": desc_summary(proj_by_arm["P4"]),
            "procrustes_raw_residual": desc_summary(proc_by_arm["P4"]["raw"]),
            "procrustes_symmetric_normalized": desc_summary(proc_by_arm["P4"]["norm"]),
            "block_fraction_of_total_variance": {
                b: desc_summary(block_by_arm["P4"][b]) for b in block_by_arm["P4"]},
            "rho": desc_summary(rho_by_arm["P4"]),
        },
    }
    p_sum_json = G2_OUT / "G2_ARM_SUMMARY.json"
    p_sum_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    md_lines = ["# G2 ARM SUMMARY (deterministic; descriptive only)", "",
                f"Generated: {utc_now()}", "",
                "No quantitative G2 threshold exists (42ZA/42ZD). "
                "Evidence is for human adjudication.", ""]
    for arm in ("P1", "P4"):
        s = summary[arm]
        md_lines += [f"## ARM {arm} (n={s['n']}, pairs={s['pair_count']})", ""]
        for metric in ("location_l2_distance", "marginal_scale_cv_across_coords",
                       "principal_angle_degrees", "projection_frobenius_distance",
                       "procrustes_raw_residual", "procrustes_symmetric_normalized"):
            d = s[metric]
            md_lines.append(f"- **{metric}**: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                            f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g} (n={d['n']})")
        md_lines.append("")
        md_lines.append("- **block_fraction_of_total_variance**:")
        for b, d in s["block_fraction_of_total_variance"].items():
            md_lines.append(f"  - {b}: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                            f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g} (n={d['n']})")
        r = s["rho"]
        md_lines.append(f"- **rho**: mean={r['mean']:.6g} sd={r['sd']:.6g} "
                        f"min={r['min']:.6g} max={r['max']:.6g} (n={r['n']})")
        md_lines.append("")
    p_sum_md = G2_OUT / "G2_ARM_SUMMARY.md"
    p_sum_md.write_text("\n".join(md_lines) + "\n", encoding="utf-8")

    # ---- post-execution read-only proof ----
    snap_after = {}
    unchanged = True
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_after[ident] = {"result": sha256(rd / "result.json"),
                             "npz": sha256(rd / "final_svi_params.npz")}
        if snap_after[ident] != snap_before[ident]:
            unchanged = False

    # ---- 42ZF evidence artifact ----
    out_files = {
        "G2_LOCATION_PAIRWISE.csv": str(p_loc),
        "G2_MARGINAL_SCALE_CV.csv": str(p_cv),
        "G2_FACTOR_PRINCIPAL_ANGLES.csv": str(p_ang),
        "G2_PROJECTION_DISTANCE.csv": str(p_proj),
        "G2_PROCRUSTES_COMPARISON.csv": str(p_proc),
        "G2_BLOCK_COVARIANCE_ALLOCATION.csv": str(p_block),
        "G2_RHO_VARIATION.csv": str(p_rho),
        "G2_ARM_SUMMARY.json": str(p_sum_json),
        "G2_ARM_SUMMARY.md": str(p_sum_md),
    }
    out_shas = {name: sha256(Path(p)) for name, p in out_files.items()}

    zf = {
        "artifact_id": "42ZF_V2_G2_DETERMINISTIC_STABILITY_EVIDENCE",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "classification": "G2_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION",
        "evaluable_total": 8,
        "P1_n": len(P1_IDS),
        "P4_n": len(P4_IDS),
        "P1_pair_count": len(loc_by_arm["P1"]),
        "P4_pair_count": len(loc_by_arm["P4"]),
        "engineering_attrition": 2,
        "G2_QUANTITATIVE_THRESHOLD_FROZEN": False,
        "threshold_policy": ("NO quantitative G2 threshold exists in any frozen source "
                             "(42ZA/42ZD); none invented. Evidence presented for human adjudication."),
        "arm_summary": summary,
        "output_files": out_shas,
        "run_artifacts_unchanged_after_execute": unchanged,
        "flags": {
            "G2_POSTERIOR_DRAWS_USED": False,
            "G2_NEW_INFERENCE_USED": False,
            "SVI_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "NUTS_HMC_MCMC_USED": False,
            "G3_AUTHORIZED": False,
        },
        "binds_sha256": {k: v[1] for k, v in FROZEN_CHAIN.items()},
        "elapsed_seconds": round(time.time() - t0, 3),
        "note": ("Deterministic G2 replicate-posterior-stability evidence computed "
                 "analytically from persisted fitted guide params (Sigma = B + U U^T). "
                 "No posterior draws, no new inference, no SVI, no sampling, no MCMC. "
                 "Read-only w.r.t. all 8 fitted run directories."),
    }
    atomic_write_json(zf_json, zf)
    zf_md = G2_OUT / "42ZF_V2_G2_DETERMINISTIC_STABILITY_EVIDENCE.md"
    mlines = ["# 42ZF — V2 G2 Deterministic Stability Evidence", "",
              f"Generated: {utc_now()}", "",
              "**Classification: G2_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION**", "",
              f"- Evaluable total = 8 | P1 n=3 | P4 n=5 | P1 pairs=3 | P4 pairs=10 | "
              f"engineering attrition=2", "",
              "- **No quantitative G2 threshold** is frozen (42ZA/42ZD); none is "
              "invented here. Evidence is for human adjudication.", ""]
    for arm in ("P1", "P4"):
        s = summary[arm]
        mlines += [f"## ARM {arm} (n={s['n']}, pairs={s['pair_count']})", ""]
        for metric in ("location_l2_distance", "marginal_scale_cv_across_coords",
                       "principal_angle_degrees", "projection_frobenius_distance",
                       "procrustes_raw_residual", "procrustes_symmetric_normalized"):
            d = s[metric]
            mlines.append(f"- **{metric}**: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                          f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g}")
        mlines.append("")
        mlines.append("- **block_fraction_of_total_variance**:")
        for b, d in s["block_fraction_of_total_variance"].items():
            mlines.append(f"  - {b}: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                          f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g}")
        r = s["rho"]
        mlines.append(f"- **rho**: mean={r['mean']:.6g} sd={r['sd']:.6g} "
                      f"min={r['min']:.6g} max={r['max']:.6g}")
        mlines.append("")
    mlines += ["## Output files (SHA256)", "", "| File | SHA256 |", "|---|---|"]
    for name, h in out_shas.items():
        mlines.append(f"| {name} | `{h}` |")
    mlines += ["", "## Flags", "",
               "- G2_POSTERIOR_DRAWS_USED = false", "- G2_NEW_INFERENCE_USED = false",
               "- SVI_USED = false", "- IMPORTANCE_SAMPLING_USED = false",
               "- NUTS_HMC_MCMC_USED = false", "- G3_AUTHORIZED = false", "",
               f"- run_artifacts_unchanged_after_execute = {unchanged}",
               f"- elapsed_seconds = {zf['elapsed_seconds']}"]
    zf_md.write_text("\n".join(mlines) + "\n", encoding="utf-8")

    print("G2 classification:", zf["classification"])
    print("42ZF JSON:", zf_json)
    print("42ZF JSON SHA:", sha256(zf_json))
    print("42ZF MD SHA:", sha256(zf_md))
    print("run_artifacts_unchanged:", unchanged)
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V2 G2 deterministic stability analysis")
    ap.add_argument("--mode", required=True, choices=["preflight", "execute"])
    args = ap.parse_args(argv)
    if args.mode == "preflight":
        return cmd_preflight()
    return cmd_execute()


if __name__ == "__main__":
    sys.exit(main())
