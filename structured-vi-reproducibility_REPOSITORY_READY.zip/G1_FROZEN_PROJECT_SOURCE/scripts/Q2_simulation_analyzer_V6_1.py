"""Q2 supplementary simulation — Evidence Analyzer V6.1 (read-only, governed).

Artifact: Q2_simulation_analyzer_V6_1.py
Frozen: 2026-08-23 (V6.1 analyzer/execution-governance repair). PRE-EXECUTION.
The analyzer ONLY reads persisted run artifacts (NPZ + JSON per run) produced by
the authorized Module B batch. It never refits and never regenerates runs.

V6.1 repairs vs V6 (V6 retained as historical artifact):
  (G1) RECONCILIATION FILE SCOPE: only official run artifacts are scanned —
       rglob("MB_*.json") / rglob("MB_*.npz"). Infrastructure files
       (module_b_manifest.json, module_b_batch_stopped.json,
       Q2_SIMULATION_RUN_MATRIX_RECONCILIATION.json, analysis outputs, …)
       NEVER enter the observed scientific identity set.
  (G2) ATTRITION ROBUSTNESS: CSV output uses a FIXED schema (no dependence on
       rows[0]); if successful = 0 (first identity failed) or successful = 1
       (second identity failed, pairwise = 0), the analyzer still completes:
       reconciliation JSON, human-adjudication handoff, empty-but-valid CSV
       (fixed header), and empty/partial summary JSON are all produced — no
       crash.

All V6 scientific logic unchanged (not a scientific redesign):
  Stage I / Stage II / known-target metrics, R5/R10/R20, target & seed matrix,
  P1/P4, guide (AR1 + rank4), optimizer (optax global-norm clip + Adam),
  early stopping, latent_dim=60, rank=4, trace shares, conditioning.
"""

from __future__ import annotations

import csv
import itertools
import json
from collections import Counter
from pathlib import Path

import numpy as np

from Q2_simulation_metrics_V4 import (
    location_l2, marginal_scale_cv, principal_angle_sin_norm,
    projection_frobenius, procrustes_raw_residual, covariance_relative_frobenius,
    correlation_rmse, normalized_spectrum_l2, component_relative_frobenius,
    low_rank_trace_share, mean_vector_l2_error_to_target,
    covariance_error_to_target, analytic_gaussian_kl,
)
from Q2_simulation_target_generator_V4 import TARGET_MAP

STAGE_I_KEYS = ["location_l2", "marginal_scale_cv", "principal_angle_sin_F",
                "projection_frobenius", "raw_procrustes"]
STAGE_I_PAIRWISE_KEYS = ["location_l2", "principal_angle_sin_F",
                         "projection_frobenius", "raw_procrustes"]
STAGE_II_PAIRWISE_KEYS = ["covariance_relative_frobenius", "correlation_rmse",
                          "normalized_spectrum_l2", "B_relative_frobenius",
                          "L_relative_frobenius"]
PAIRWISE_KEYS = STAGE_I_PAIRWISE_KEYS + STAGE_II_PAIRWISE_KEYS
KNOWN_TARGET_KEYS = ["mean_vector_l2_error_to_target", "covariance_error_to_target",
                     "analytic_gaussian_kl"]

# (G2) FIXED CSV schemas — never derived from rows[0]
PER_RUN_FIELDS = ["run_id", "target_id", "particles", "optimizer_seed",
                  "conditioning", "trace_share", "steps", "low_rank_trace_share",
                  "known_mean_vector_l2", "known_covariance_error", "known_analytic_kl"]
PAIRWISE_FIELDS = ["cell", "particles", "run_a", "run_b"] + PAIRWISE_KEYS

RECONCILIATION_FILE = "Q2_SIMULATION_RUN_MATRIX_RECONCILIATION.json"


# ---------------------------------------------------------------------------
# (G1) run-matrix reconciliation — official MB_* artifacts only
# ---------------------------------------------------------------------------
def _expected_identities(seed_matrix_csv: Path) -> dict[str, dict]:
    """Expected Module-B run identities from the frozen seed matrix (240)."""
    expected = {}
    with open(seed_matrix_csv, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row["module"] != "B":
                continue
            conditioning = row["conditioning"]
            share = float(row["trace_share"])
            particles = row["particles"]
            seed = int(row["seed"])
            target_id = next(k for k, v in TARGET_MAP.items() if v == (conditioning, share))
            rid = f"MB_{target_id}_{particles}_{seed:04d}"
            expected[rid] = {
                "target_id": target_id, "particles": particles,
                "conditioning": conditioning, "trace_share": share,
                "optimizer_seed": seed, "replicate_prefix": row["replicate_prefix"],
            }
    return expected


def reconcile_run_matrix(run_dir: Path, seed_matrix_csv: Path) -> dict:
    """Reconcile expected vs observed identities. Read-only.

    (G1) Only MB_*.json / MB_*.npz are considered scientific identities.
    Infrastructure files (manifest, batch-stopped, reconciliation, analysis
    outputs) are excluded by the MB_* prefix filter.
    """
    expected = _expected_identities(seed_matrix_csv)

    all_json = sorted(run_dir.rglob("MB_*.json"))
    all_npz = sorted(run_dir.rglob("MB_*.npz"))
    dup_rids = sorted({rid for rid, c in Counter(jf.stem for jf in all_json).items() if c > 1} |
                      {rid for rid, c in Counter(nz.stem for nz in all_npz).items() if c > 1})

    successful, failed = {}, {}
    json_only_anomaly, npz_only_anomaly = {}, {}
    for jf in all_json:
        rid = jf.stem
        meta = json.loads(jf.read_text(encoding="utf-8"))
        if meta.get("status") == "ENGINEERING_FAILED":
            failed[rid] = meta
        elif (jf.with_suffix(".npz")).exists():
            successful[rid] = meta
        else:
            json_only_anomaly[rid] = meta
    for nz in all_npz:
        rid = nz.stem
        if not (nz.with_suffix(".json")).exists():
            npz_only_anomaly[rid] = None

    overlap = sorted(set(successful) & set(failed))
    for rid in overlap:
        successful.pop(rid, None)

    observed_ids = (set(successful) | set(failed) |
                    set(json_only_anomaly) | set(npz_only_anomaly))
    missing = sorted(set(expected) - observed_ids)
    unexpected = sorted(observed_ids - set(expected))

    attrition = len(failed) + len(missing)
    anomaly = bool(json_only_anomaly or npz_only_anomaly)
    if dup_rids or unexpected or overlap or anomaly:
        verdict = "FAIL"
        reason = ("duplicate and/or unexpected identity detected; "
                  "scientific summary BLOCKED")
    elif attrition > 0:
        verdict = "PASS_WITH_ATTENTION"
        reason = ("engineering attrition present; original identities preserved, "
                  "no replacement; human adjudication decides evaluability")
    else:
        verdict = "PASS"
        reason = "all 240 identities observed successful; no attrition"

    return {
        "artifact": "Q2_SIMULATION_RUN_MATRIX_RECONCILIATION",
        "expected_identities": len(expected),
        "observed_successful": len(successful),
        "observed_failed": len(failed),
        "missing": missing,
        "missing_count": len(missing),
        "duplicate": dup_rids,
        "duplicate_count": len(dup_rids),
        "unexpected": unexpected,
        "unexpected_count": len(unexpected),
        "json_only_anomaly": sorted(json_only_anomaly),
        "npz_only_anomaly": sorted(npz_only_anomaly),
        "overlap_failed_successful": overlap,
        "attrition": attrition,
        "verdict": verdict,
        "reason": reason,
        "gate": "scientific summary ALLOWED" if verdict in ("PASS", "PASS_WITH_ATTENTION")
                else "scientific summary BLOCKED",
    }


def load_run(npz_path: Path, json_path: Path) -> dict:
    """Load one persisted successful run (NPZ arrays + JSON metadata)."""
    meta = json.loads(Path(json_path).read_text(encoding="utf-8"))
    npz = np.load(npz_path)
    return {
        **meta,
        "m_q": npz["m_q"], "U_q": npz["U_q"], "Sigma_q": npz["Sigma_q"],
        "B_q": npz["B_q"], "L_q": npz["L_q"],
    }


def cell_pairwise(runs: list[dict]) -> list[dict]:
    """Pairwise metrics within one cell (all pairs of distinct run_ids)."""
    pairs = []
    for (i, j) in itertools.combinations(range(len(runs)), 2):
        a, b = runs[i], runs[j]
        pair = {
            "cell": a["target_id"],
            "particles": a["particles"],
            "run_a": a["run_id"], "run_b": b["run_id"],
        }
        pair["location_l2"] = location_l2(a["m_q"], b["m_q"])
        pair["principal_angle_sin_F"] = principal_angle_sin_norm(a["U_q"], b["U_q"])
        pair["projection_frobenius"] = projection_frobenius(a["U_q"], b["U_q"])
        pair["raw_procrustes"] = procrustes_raw_residual(a["U_q"], b["U_q"])
        pair["covariance_relative_frobenius"] = covariance_relative_frobenius(a["Sigma_q"], b["Sigma_q"])
        pair["correlation_rmse"] = correlation_rmse(a["Sigma_q"], b["Sigma_q"])
        pair["normalized_spectrum_l2"] = normalized_spectrum_l2(a["Sigma_q"], b["Sigma_q"])
        pair["B_relative_frobenius"] = component_relative_frobenius(a["B_q"], b["B_q"])
        pair["L_relative_frobenius"] = component_relative_frobenius(a["L_q"], b["L_q"])
        pairs.append(pair)
    return pairs


def cell_marginal_cv(runs: list[dict], d: int = 60) -> float:
    """G2-parity marginal-scale CV: one call on (R, d) scale matrix; finite coords only."""
    scale_mat = np.array([np.sqrt(np.diag(r["Sigma_q"])) for r in runs], dtype=np.float64)
    _, _, cv = marginal_scale_cv(scale_mat)
    finite = cv[np.isfinite(cv)]
    return float(np.nanmean(finite)) if finite.size else float("nan")


def summarize_numeric(values: list[float]) -> dict:
    a = np.asarray(values, dtype=np.float64)
    if a.size == 0:
        return {"n": 0, "mean": float("nan"), "sd": float("nan"),
                "min": float("nan"), "max": float("nan")}
    return {"n": int(a.size), "mean": float(a.mean()), "sd": float(a.std(ddof=0)),
            "min": float(a.min()), "max": float(a.max())}


def _write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    """(G2) FIXED-schema CSV writer; valid header even when rows is empty."""
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        if rows:
            w.writerows(rows)


def analyze_run_dir(run_dir: Path, seed_matrix_csv: Path,
                    out_dir: Path | None = None) -> dict:
    """Reconcile, then (if allowed) analyze successful runs. Read-only on runs.

    (G2) Never crashes for successful=0 / successful=1: fixed CSV schemas and
    empty-array-safe summary JSON are produced.
    """
    run_dir = Path(run_dir)
    out_dir = Path(out_dir) if out_dir else run_dir / "analysis_v6_1"
    out_dir.mkdir(parents=True, exist_ok=True)

    recon = reconcile_run_matrix(run_dir, seed_matrix_csv)
    (out_dir / RECONCILIATION_FILE).write_text(
        json.dumps(recon, indent=2, ensure_ascii=False, default=float), encoding="utf-8")

    if recon["verdict"] == "FAIL":
        return {
            "n_runs_loaded": 0,
            "reconciliation": recon,
            "scientific_summary": "BLOCKED: duplicate/unexpected identity detected",
        }

    runs = []
    for jf in sorted(run_dir.glob("MB_*.json")):
        meta = json.loads(jf.read_text(encoding="utf-8"))
        if meta.get("status") == "ENGINEERING_FAILED":
            continue
        npz = jf.with_suffix(".npz")
        if npz.exists():
            runs.append(load_run(npz, jf))

    cells = {}
    for r in runs:
        cells.setdefault((r["target_id"], r["particles"]), []).append(r)
    for k in cells:
        cells[k].sort(key=lambda r: r["optimizer_seed"])

    prefix_map = {}
    with open(seed_matrix_csv, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row["module"] == "B":
                key = (row["conditioning"], float(row["trace_share"]), row["particles"])
                prefix_map.setdefault(key, []).append(int(row["seed"]))

    per_run_rows = []
    pairwise_rows = []
    cell_summaries = []
    r_prefix_summaries = []
    known_target_summaries = []
    adjudication = []

    for (target_id, particles), runs_cell in sorted(cells.items()):
        conditioning = runs_cell[0]["conditioning"]
        trace_share = runs_cell[0]["trace_share"]
        mcv = cell_marginal_cv(runs_cell)
        for r in runs_cell:
            per_run_rows.append({
                "run_id": r["run_id"], "target_id": target_id,
                "particles": particles, "optimizer_seed": r["optimizer_seed"],
                "conditioning": conditioning, "trace_share": trace_share,
                "steps": r.get("steps", ""),
                "low_rank_trace_share": r["low_rank_trace_share"],
                "known_mean_vector_l2": r["known_target"]["mean_vector_l2_error_to_target"],
                "known_covariance_error": r["known_target"]["covariance_error_to_target"],
                "known_analytic_kl": r["known_target"]["analytic_gaussian_kl"],
            })
        pw = cell_pairwise(runs_cell)
        for p in pw:
            pairwise_rows.append(p)
        share_cell = summarize_numeric([r["low_rank_trace_share"] for r in runs_cell])
        kt_cell = {k: summarize_numeric([r["known_target"][k] for r in runs_cell])
                   for k in KNOWN_TARGET_KEYS}
        cell_summaries.append({
            "target_id": target_id, "particles": particles,
            "conditioning": conditioning, "trace_share": trace_share,
            "n_runs": len(runs_cell), "n_pairs": len(pw),
            "marginal_scale_cv": mcv,
            "stage_I": {k: summarize_numeric([p[k] for p in pw]) for k in STAGE_I_PAIRWISE_KEYS},
            "stage_II": {k: summarize_numeric([p[k] for p in pw]) for k in STAGE_II_PAIRWISE_KEYS},
            "low_rank_trace_share": share_cell,
            "known_target": kt_cell,
        })
        known_target_summaries.append({
            "target_id": target_id, "particles": particles,
            "conditioning": conditioning, "trace_share": trace_share,
            "n_runs": len(runs_cell),
            **kt_cell,
        })
        seeds = prefix_map.get((conditioning, trace_share, particles), [])
        for R, n in (("R5", 5), ("R10", 10), ("R20", 20)):
            subset = [r for r in runs_cell if r["optimizer_seed"] in seeds[:n]]
            if len(subset) >= 2:
                spw = cell_pairwise(subset)
                smcv = cell_marginal_cv(subset)
                share_sub = summarize_numeric([r["low_rank_trace_share"] for r in subset])
                kt_sub = {k: summarize_numeric([r["known_target"][k] for r in subset])
                          for k in KNOWN_TARGET_KEYS}
                r_prefix_summaries.append({
                    "target_id": target_id, "particles": particles,
                    "conditioning": conditioning, "trace_share": trace_share,
                    "R": R, "n_runs": len(subset), "n_pairs": len(spw),
                    "marginal_scale_cv": smcv,
                    "stage_I": {k: summarize_numeric([p[k] for p in spw]) for k in STAGE_I_PAIRWISE_KEYS},
                    "stage_II": {k: summarize_numeric([p[k] for p in spw]) for k in STAGE_II_PAIRWISE_KEYS},
                    "low_rank_trace_share": share_sub,
                    "known_target": kt_sub,
                })
        adjudication.append({
            "target_id": target_id, "particles": particles,
            "note": "Descriptive within-cell summaries only; no significance testing; "
                    "no cross-cell pairs; pairwise distances not independent observations.",
            "marginal_scale_cv": mcv,
        })

    # (G2) fixed-schema CSV output; valid headers even when empty
    _write_csv(out_dir / "per_run_known_target.csv", PER_RUN_FIELDS, per_run_rows)
    _write_csv(out_dir / "pairwise_metrics.csv", PAIRWISE_FIELDS, pairwise_rows)
    (out_dir / "cell_summaries.json").write_text(
        json.dumps(cell_summaries, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    (out_dir / "r_prefix_summaries.json").write_text(
        json.dumps(r_prefix_summaries, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    (out_dir / "known_target_summaries.json").write_text(
        json.dumps(known_target_summaries, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    (out_dir / "human_adjudication_handoff.json").write_text(
        json.dumps(adjudication, indent=2, ensure_ascii=False, default=float), encoding="utf-8")

    return {
        "n_runs_loaded": len(runs),
        "n_cells": len(cells),
        "n_cell_summaries": len(cell_summaries),
        "n_known_target_summaries": len(known_target_summaries),
        "n_r_prefix_summaries": len(r_prefix_summaries),
        "reconciliation": recon,
        "outputs": {p.name: str(p) for p in out_dir.iterdir() if p.is_file()},
    }


if __name__ == "__main__":
    import sys
    run_dir = sys.argv[1] if len(sys.argv) > 1 else "results/q2_supplementary_simulation/module_b"
    seed_csv = "results/q2_supplementary_simulation/Q2_SIMULATION_SEED_MATRIX.csv"
    result = analyze_run_dir(run_dir, seed_csv)
    print(json.dumps(result, indent=2, ensure_ascii=False))
