"""Q2 supplementary simulation — Module A executor V4 (deterministic calibration).

Artifact: Q2_simulation_module_a_V4.py
Frozen: 2026-08-23 (V4 executor semantics repair). PRE-EXECUTION.
Imports reference ONLY V4 modules (no V2/V3 executor imports).
IMPORTANT: Running this script performs REAL Module A computation and requires a
separate execution authorization. It is implemented here for freeze/dry-import
only; the zero-compute preflight must NOT execute the real batch.

Module A is deterministic matrix algebra (no fitting, no sampling of posteriors,
no FAERS, no G1/G2/G3). It validates the metric behavior on constructed objects.

Exact frozen perturbation constructions (replaces "small tilt" wording):
  A0: U_rot = U_ref @ Q, Q = QR(Gaussian) — rotation only, span preserved.
  A1/A2 (genuine subspace tilt):
      - reference basis Q_ref from reference_construction_seed (well conditioning)
      - per-replicate tilt basis from Module A seed: E ~ N(0,I); project out
        span(Q_ref): E_perp = E - Q_ref Q_ref^T E; orthonormalize -> Q_perp
      - tilted basis: Q_tilt = orthonormalize( cos(theta)*Q_ref + sin(theta)*Q_perp )
      - theta = 0.3 rad exactly (frozen); identical family across shares
      - only the low-rank trace share changes (scale s from trace_share_scale)
  A3 (stable U, perturbed B):
      - U stable (fixed U_ref scaled to share 0.15)
      - B perturbed by exact rules:
          rho:      0.30 -> 0.30 + 0.10 = 0.40   (delta_rho = +0.10)
          diag floor: 1.00 -> 1.00 + 0.50 = 1.50 (delta_floor = +0.50)
      - B_pert = build_B_AR1(rho=0.40, floor=1.50)
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from Q2_simulation_target_generator_V4 import (  # noqa: E402
    LATENT_DIM, RANK, build_B_AR1, trace_share_scale,
)
from Q2_simulation_metrics_V4 import (  # noqa: E402
    principal_angle_sin_norm, projection_frobenius, procrustes_raw_residual,
    covariance_relative_frobenius, low_rank_trace_share,
)

# Frozen constants (must match config V2)
TILT_THETA_RAD = 0.3            # exact tilt angle for A1/A2
A3_RHO_DELTA = 0.10             # exact rho perturbation for A3
A3_FLOOR_DELTA = 0.50           # exact diagonal-floor perturbation for A3
A3_SHARE = 0.15                 # A3 fixed trace share
REFERENCE_CONSTRUCTION_SEED = 70000   # shared reference basis seed (outside optimizer & target ranges)


def orthonormalize(A: np.ndarray) -> np.ndarray:
    Q, _ = np.linalg.qr(np.asarray(A, dtype=np.float64))
    return Q[:, :A.shape[1]]


def reference_basis(seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return orthonormalize(rng.standard_normal((LATENT_DIM, RANK)))


def tilt_basis(Q_ref: np.ndarray, seed: int, theta: float = TILT_THETA_RAD) -> np.ndarray:
    """Exact genuine subspace tilt: principal angle theta between span(Q_ref) and result."""
    rng = np.random.default_rng(seed)
    E = rng.standard_normal((LATENT_DIM, RANK))
    E_perp = E - Q_ref @ (Q_ref.T @ E)
    Q_perp = orthonormalize(E_perp)
    return orthonormalize(np.cos(theta) * Q_ref + np.sin(theta) * Q_perp)


def module_a_scenario_a0(seed: int, share: float = 0.15) -> dict:
    """Rotation-equivalent representation (FIX3: full covariance consequence)."""
    Q_ref = reference_basis(REFERENCE_CONSTRUCTION_SEED)
    B = build_B_AR1("well_conditioned")
    s = trace_share_scale(share, np.trace(B), RANK)
    U_ref = s * Q_ref
    rng = np.random.default_rng(seed)
    Qrot = orthonormalize(rng.standard_normal((RANK, RANK)))
    U_rot = s * (Q_ref @ Qrot)  # same span as U_ref
    Sigma_ref = B + U_ref @ U_ref.T
    Sigma_rot = B + U_rot @ U_rot.T
    return {
        "scenario": "A0", "seed": seed, "share": share,
        "raw_factor_frobenius": float(np.linalg.norm(U_ref - U_rot, ord="fro")),
        "sin_F": principal_angle_sin_norm(U_ref, U_rot),
        "projection_F": projection_frobenius(U_ref, U_rot),
        "raw_procrustes": procrustes_raw_residual(U_ref, U_rot),
        "cov_rel_frob": covariance_relative_frobenius(Sigma_ref, Sigma_rot),
        "note": ("rotation only: raw factor difference > 0; rotation-invariant metrics "
                 "and cov_rel_frob expected at numerical equality floor (~1e-8, tol 1e-6)"),
    }


def module_a_scenario_a1a2(seed: int, share: float) -> dict:
    """Genuine subspace tilt, same family, only trace share varies."""
    Q_ref = reference_basis(REFERENCE_CONSTRUCTION_SEED)
    B = build_B_AR1("well_conditioned")
    s = trace_share_scale(share, np.trace(B), RANK)
    U_ref = s * Q_ref
    U_tilt = s * tilt_basis(Q_ref, seed, TILT_THETA_RAD)
    Sigma_ref = B + U_ref @ U_ref.T
    Sigma_tilt = B + U_tilt @ U_tilt.T
    return {
        "scenario": "A1" if share == 0.05 else "A2", "seed": seed, "share": share,
        "sin_F": principal_angle_sin_norm(U_ref, U_tilt),
        "projection_F": projection_frobenius(U_ref, U_tilt),
        "procrustes": procrustes_raw_residual(U_ref, U_tilt),
        "cov_rel_frob": covariance_relative_frobenius(Sigma_ref, Sigma_tilt),
        "low_rank_trace_share": low_rank_trace_share(U_tilt @ U_tilt.T, Sigma_tilt),
        "theta_rad": TILT_THETA_RAD,
    }


def module_a_scenario_a3(seed: int = 41) -> dict:
    """Stable U, perturbed structured residual B (FIX4: ONE deterministic record).

    A3 is a single deterministic calibration record, NOT 10 stochastic
    replicates. Seed 41 is the provenance construction seed; seeds 42-50 are
    UNUSED_RESERVED and are not re-assigned to any other scenario.
    """
    Q_ref = reference_basis(REFERENCE_CONSTRUCTION_SEED)
    B_ref = build_B_AR1("well_conditioned")
    s = trace_share_scale(A3_SHARE, np.trace(B_ref), RANK)
    U = s * Q_ref  # stable by construction (single deterministic record)
    Sigma_ref = B_ref + U @ U.T
    # exact perturbation rule (frozen)
    rho_pert = 0.30 + A3_RHO_DELTA
    floor_pert = 1.00 + A3_FLOOR_DELTA
    B_pert = build_B_AR1_rho_floor(rho_pert, floor_pert)
    Sigma_pert = B_pert + U @ U.T
    return {
        "scenario": "A3", "seed": seed, "share": A3_SHARE,
        "rho_delta": A3_RHO_DELTA, "floor_delta": A3_FLOOR_DELTA,
        "B_rel_frob": covariance_relative_frobenius(B_ref, B_pert),
        "cov_rel_frob": covariance_relative_frobenius(Sigma_ref, Sigma_pert),
        "deterministic_record": True,
        "unused_reserved_seeds": list(range(42, 51)),
        "note": "single deterministic calibration record; U stable; only B perturbed",
    }


def build_B_AR1_rho_floor(rho: float, floor: float) -> np.ndarray:
    """Frozen variant of build_B_AR1 with explicit rho and floor (for A3).

    Same stationary-AR1 block formula as the frozen target generator:
    B[i,j] = rho ** |i-j| within each block (PD for |rho| < 1), plus floor*I.
    """
    from Q2_simulation_target_generator_V4 import AR1_BLOCK_DIM, AR1_N_BLOCKS
    B = np.zeros((LATENT_DIM, LATENT_DIM), dtype=np.float64)
    for b in range(AR1_N_BLOCKS):
        s = b * AR1_BLOCK_DIM
        idx = np.arange(s, s + AR1_BLOCK_DIM)
        for i in range(AR1_BLOCK_DIM):
            for j in range(AR1_BLOCK_DIM):
                B[idx[i], idx[j]] += rho ** abs(i - j)
    B += floor * np.eye(LATENT_DIM)
    return B


def main() -> None:
    """Real Module A batch — REQUIRES execution authorization. Not run in preflight."""
    out = Path("results/q2_supplementary_simulation/module_a")
    records = []
    # A0: Module A seeds 1-10
    for seed in range(1, 11):
        records.append(module_a_scenario_a0(seed))
    # A1 (share 0.05): seeds 11-20 ; A2 (0.15): 21-30 ; A2 (0.30): 31-40
    for seed, share in zip(range(11, 21), [0.05] * 10):
        records.append(module_a_scenario_a1a2(seed, share))
    for seed, share in zip(range(21, 31), [0.15] * 10):
        records.append(module_a_scenario_a1a2(seed, share))
    for seed, share in zip(range(31, 41), [0.30] * 10):
        records.append(module_a_scenario_a1a2(seed, share))
    # A3 (stable U, perturbed B): ONE deterministic calibration record.
    # Seed 41 is the provenance construction seed; seeds 42-50 are UNUSED_RESERVED.
    records.append(module_a_scenario_a3(41))
    out.mkdir(parents=True, exist_ok=True)
    (out / "module_a_evidence.json").write_text(
        json.dumps({"artifact": "Q2_MODULE_A_EVIDENCE", "records": records}, indent=2), encoding="utf-8")
    print(f"module_a batch written: {len(records)} records -> {out}")


if __name__ == "__main__":
    main()
