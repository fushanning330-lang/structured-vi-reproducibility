from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

import jax
import numpy as np
import pandas as pd
from jax import random

from dhbcp_pv.evaluation.metrics import state_metrics
from dhbcp_pv.inference.posterior_integration import (
    integrate_posterior_outputs,
    posterior_parameter_summary,
)
from dhbcp_pv.inference.structured_svi import (
    SVIConfig,
    run_structured_svi,
    sample_structured_posterior,
    structured_covariance_diagnostics,
)
from dhbcp_pv.models.full_joint_model import reconstruct_x
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_a_replicate


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: dict[str, object]) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def parse_ids(specification: str) -> list[int]:
    values: list[int] = []
    for part in specification.split(","):
        if "-" in part:
            start, stop = (int(value) for value in part.split("-", 1))
            values.extend(range(start, stop + 1))
        else:
            values.append(int(part))
    return sorted(set(values))


def correlation(truth: np.ndarray, estimate: np.ndarray) -> float:
    if np.std(truth) == 0 or np.std(estimate) == 0:
        return 0.0
    return float(np.corrcoef(truth, estimate)[0, 1])


def run_one(replicate_id: int, seed: int, freeze: dict[str, object], optimizer: dict[str, object]) -> dict[str, object]:
    started = perf_counter()
    replicate = generate_tier_a_replicate(seed)
    steps = int(optimizer["primary"]["tier_a_full_sequence_steps"])
    svi = run_structured_svi(
        random.PRNGKey(seed),
        replicate.y,
        replicate.serious,
        replicate.expected,
        replicate.drug_index,
        replicate.event_index,
        18,
        9,
        hmax=12,
        config=SVIConfig(
            learning_rate=float(optimizer["primary"]["learning_rate"]),
            max_steps=steps,
            minimum_steps=1,
            early_stop_patience=10_000,
            gradient_clip_norm=float(optimizer["primary"]["gradient_clip_norm"]),
        ),
    )
    if not svi.finite:
        raise FloatingPointError("Tier A SVI returned non-finite or uncovered sites")
    samples = sample_structured_posterior(
        random.PRNGKey(seed + 1_000_000),
        svi.params,
        replicate.y,
        replicate.serious,
        replicate.expected,
        replicate.drug_index,
        replicate.event_index,
        18,
        9,
        num_samples=int(optimizer["primary"]["posterior_draws_primary"]),
        hmax=12,
    )
    integrated = integrate_posterior_outputs(
        samples,
        replicate.y,
        replicate.serious,
        replicate.drug_index,
        replicate.event_index,
        18,
        9,
        hmax=12,
    )
    paths = np.asarray(jax.vmap(reconstruct_x)(samples["x_initial"], samples["base_increment"]))
    x_mean = paths.mean(axis=0)
    x_q025 = np.quantile(paths, 0.025, axis=0)
    x_q975 = np.quantile(paths, 0.975, axis=0)
    x_rmse = float(np.sqrt(np.mean((x_mean - replicate.true_x) ** 2)))
    x_coverage = float(np.mean((replicate.true_x >= x_q025) & (replicate.true_x <= x_q975)))
    raw_drug = np.asarray(samples["raw_drug"])
    raw_event = np.asarray(samples["raw_event"])
    alpha = np.asarray(samples["sigma_drug"])[:, None] * (
        raw_drug - raw_drug.mean(axis=1, keepdims=True)
    )
    beta = np.asarray(samples["sigma_event"])[:, None] * (
        raw_event - raw_event.mean(axis=1, keepdims=True)
    )
    pair_effect = np.asarray(samples["sigma_pair"])[:, None] * np.asarray(samples["raw_pair"])
    serious_drug_raw = np.asarray(samples["raw_serious_drug"])
    serious_event_raw = np.asarray(samples["raw_serious_event"])
    serious_drug = np.asarray(samples["sigma_serious_drug"])[:, None] * (
        serious_drug_raw - serious_drug_raw.mean(axis=1, keepdims=True)
    )
    serious_event = np.asarray(samples["sigma_serious_event"])[:, None] * (
        serious_event_raw - serious_event_raw.mean(axis=1, keepdims=True)
    )
    effect_metrics = {
        "alpha_drug_correlation": correlation(np.asarray(replicate.truth["alpha_drug"]), alpha.mean(axis=0)),
        "beta_event_correlation": correlation(np.asarray(replicate.truth["beta_event"]), beta.mean(axis=0)),
        "b_pair_correlation": correlation(np.asarray(replicate.truth["b_pair"]), pair_effect.mean(axis=0)),
        "serious_drug_correlation": correlation(np.asarray(replicate.truth["serious_drug"]), serious_drug.mean(axis=0)),
        "serious_event_correlation": correlation(np.asarray(replicate.truth["serious_event"]), serious_event.mean(axis=0)),
    }
    pair_index = np.repeat(np.arange(162), 40)
    change = np.repeat(replicate.true_change_quarter, 40)
    state_values = state_metrics(
        replicate.true_state.reshape(-1),
        replicate.true_x.reshape(-1),
        integrated.state_probability.reshape(-1, 4),
        integrated.x_mean.reshape(-1),
        integrated.x_sd.reshape(-1),
        integrated.p_persist_h2.reshape(-1),
        integrated.p_change.reshape(-1),
        pair_index,
        change,
    )
    scalar_truth: dict[tuple[str, int], float] = {
        ("mu", 0): float(replicate.truth["mu"]),
        ("sigma_drug", 0): float(replicate.truth["sigma_drug"]),
        ("sigma_event", 0): float(replicate.truth["sigma_event"]),
        ("sigma_pair", 0): float(replicate.truth["sigma_pair"]),
        ("phi", 0): float(replicate.truth["phi"]),
        ("delta_emerging", 0): float(np.asarray(replicate.truth["drift"])[1]),
        ("delta_persistent", 0): float(np.asarray(replicate.truth["drift"])[2]),
        ("delta_waning_magnitude", 0): float(-np.asarray(replicate.truth["drift"])[3]),
        ("emerging_to_persistent_probability", 0): float(replicate.truth["emerging_to_persistent_probability"]),
        ("gamma0", 0): float(replicate.truth["gamma0"]),
        ("gamma_x", 0): float(replicate.truth["gamma_x"]),
        ("sigma_serious_drug", 0): float(replicate.truth["sigma_serious_drug"]),
        ("sigma_serious_event", 0): float(replicate.truth["sigma_serious_event"]),
    }
    for name in ("dynamic_sd", "duration_means", "duration_shapes"):
        for index, value in enumerate(np.asarray(replicate.truth[name])):
            scalar_truth[(name, index)] = float(value)
    for index, value in enumerate(np.asarray(replicate.truth["gamma_state"])[1:]):
        scalar_truth[("gamma_nonbackground", index)] = float(value)
    parameter_rows: list[dict[str, object]] = []
    for row in posterior_parameter_summary(samples):
        key = (str(row["parameter"]), int(row["index"]))
        if key not in scalar_truth:
            continue
        truth = scalar_truth[key]
        sd = max(float(row["sd"]), 1e-12)
        parameter_rows.append(
            {
                **row,
                "replicate_id": replicate_id,
                "seed": seed,
                "truth": truth,
                "error": float(row["mean"]) - truth,
                "absolute_standardized_error": abs(float(row["mean"]) - truth) / sd,
                "covered_95": bool(float(row["q025"]) <= truth <= float(row["q975"])),
            }
        )
    summary = {
        "replicate_id": replicate_id,
        "seed": seed,
        "status": "COMPLETE",
        "svi_initial_loss": svi.initial_loss,
        "svi_terminal_loss": svi.terminal_loss,
        "svi_loss_improved": bool(svi.terminal_loss < svi.initial_loss),
        "svi_steps": svi.steps,
        "svi_site_coverage": svi.site_coverage_passed,
        "x_rmse": x_rmse,
        "x_interval_coverage": x_coverage,
        **effect_metrics,
        **{f"state_{name}": value for name, value in state_values.items()},
        "wall_clock_seconds": perf_counter() - started,
        "svi_seconds": svi.wall_clock_seconds,
        "posterior_draws": int(optimizer["primary"]["posterior_draws_primary"]),
        "guide_covariance": structured_covariance_diagnostics(svi.params),
    }
    return {
        "version": "phase3b_tiera_checkpoint_v1",
        "freeze_sha256": freeze["formal_freeze_sha256"],
        "summary": summary,
        "parameter_rows": parameter_rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", default="1-100")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    result = root / "results" / "phase3b"
    freeze_path = result / "64_PHASE3B_FORMAL_FREEZE.json"
    freeze = json.loads(freeze_path.read_text())
    optimizer_path = root / "config" / "phase3b_optimizer_v1.yaml"
    if sha256(optimizer_path) != freeze["frozen_files"]["config/phase3b_optimizer_v1.yaml"]:
        raise SystemExit("optimizer config changed after formal freeze")
    optimizer = __import__("yaml").safe_load(optimizer_path.read_text())
    seeds = pd.read_csv(root / freeze["seed_manifests"]["tier_a"]["path"])
    checkpoint_dir = result / "checkpoints" / "tiera"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    for replicate_id in parse_ids(args.ids):
        path = checkpoint_dir / f"replicate_{replicate_id:03d}.json"
        if path.exists():
            print(f"Tier A {replicate_id:03d}: CHECKPOINT_EXISTS", flush=True)
            continue
        seed = int(seeds.loc[seeds.replicate_id == replicate_id, "seed"].iloc[0])
        try:
            payload = run_one(replicate_id, seed, freeze, optimizer)
        except Exception as error:
            payload = {
                "version": "phase3b_tiera_checkpoint_v1",
                "freeze_sha256": freeze["formal_freeze_sha256"],
                "summary": {
                    "replicate_id": replicate_id,
                    "seed": seed,
                    "status": "FAILED",
                    "exception": f"{type(error).__name__}: {error}",
                },
                "parameter_rows": [],
            }
        atomic_json(path, payload)
        print(f"Tier A {replicate_id:03d}: {payload['summary']['status']}", flush=True)


if __name__ == "__main__":
    main()
