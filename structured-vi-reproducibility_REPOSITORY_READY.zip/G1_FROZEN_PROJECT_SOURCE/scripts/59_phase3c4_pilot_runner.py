#!/usr/bin/env python
"""Phase 3C.4 frozen single-chain pilot runner.

Safety rule:
NUTS cannot run unless a separate pilot-authorization artifact exists
and explicitly binds this exact runner SHA256 to the already frozen
Phase 3C.4 protocol/config/implementation/preflight artifacts.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping

os.environ.setdefault("JAX_ENABLE_X64", "1")
os.environ.setdefault(
    "XLA_FLAGS",
    "--xla_force_host_platform_device_count=4",
)

import jax
import numpy as np
import yaml
from jax import random
from numpyro import handlers
from numpyro.infer import MCMC, NUTS

import importlib.util


CONFIG_REL = Path(
    "config/phase3c4_joint_scale_pilot_v1.yaml"
)

PROTOCOL_REL = Path(
    "results/phase3c4/07_PHASE3C4_PILOT_PROTOCOL_FREEZE.json"
)

PREFLIGHT_REL = Path(
    "results/phase3c4/08_PHASE3C4_MASS_MATRIX_PREFLIGHT.json"
)

IMPLEMENTATION_REL = Path(
    "scripts/58_phase3c4_joint_log_scale_radial.py"
)

AUTHORIZATION_REL = Path(
    "results/phase3c4/09_PHASE3C4_PILOT_AUTHORIZATION.json"
)

PILOT_DIR_REL = Path(
    "results/phase3c4/pilot"
)

RUN_MARKER_REL = Path(
    "results/phase3c4/pilot/"
    "JOINT_LOG_SCALE_RADIAL_t12_chain1.RUN_STARTED.json"
)


EXPECTED_CONFIG_SHA256 = (
    "38d97ae1fbeb99d527504e38df1428a270b154640708fc70777f4413b3daa17d"
)

EXPECTED_PROTOCOL_SHA256 = (
    "7965a1aec9ab7433e10cd5f090b5c5656b0d1653159bfd7ef163dfb3c8ab255f"
)

EXPECTED_PREFLIGHT_SHA256 = (
    "360e4f394879594869df113230ca3a4105797ca5c1a3c6cb38aa5e1563d853a8"
)

EXPECTED_IMPLEMENTATION_SHA256 = (
    "b98f15d4ef53ac34345e9a2e666e07024f583a15d1316ed9a85b3ed77de273be"
)

EXPECTED_LAMBDA_FREEZE_SHA256 = (
    "a9c46037e0543c097c473afffbeaf2e4cc685ae89d8d177139f0db814dfe9b01"
)

EXPECTED_TARGET_EQUIVALENCE_SHA256 = (
    "9ea5754bd68f66800e4702a90e2758ec30ca5483f27181f8f256bb3a2e19f14a"
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b"",
        ):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(
    path: Path,
    payload: Mapping[str, Any],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    tmp = path.with_suffix(
        path.suffix + ".tmp"
    )
    tmp.write_text(
        json.dumps(
            payload,
            indent=2,
            ensure_ascii=False,
        )
    )
    os.replace(
        tmp,
        path,
    )


def atomic_npz(
    path: Path,
    arrays: Mapping[str, np.ndarray],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    tmp = path.with_suffix(
        path.suffix + ".tmp"
    )
    with tmp.open("wb") as f:
        np.savez_compressed(
            f,
            **arrays,
        )
    os.replace(
        tmp,
        path,
    )


def load_module(
    path: Path,
    name: str,
):
    spec = importlib.util.spec_from_file_location(
        name,
        path,
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(
            f"Unable to load module: {path}"
        )

    module = importlib.util.module_from_spec(
        spec
    )
    spec.loader.exec_module(
        module
    )
    return module


def verify_file_sha(
    path: Path,
    expected: str,
    label: str,
) -> str:
    if not path.exists():
        raise RuntimeError(
            f"{label} missing: {path}"
        )

    actual = sha256(path)

    if actual != expected:
        raise RuntimeError(
            f"{label} SHA256 mismatch\n"
            f"expected={expected}\n"
            f"actual={actual}"
        )

    return actual


def locate_sha_artifact(
    directory: Path,
    expected_sha: str,
) -> Path:
    matches = []

    for path in directory.rglob("*"):
        if not path.is_file():
            continue

        try:
            if sha256(path) == expected_sha:
                matches.append(path)
        except OSError:
            continue

    if len(matches) != 1:
        raise RuntimeError(
            "Expected exactly one artifact matching "
            f"SHA256 {expected_sha}; "
            f"found {len(matches)}"
        )

    return matches[0]


def original_chain_rng_key(
    seed: int,
    cutoff: int,
    chain_id: int,
):
    """Frozen stress-chain identity used in Phase 3C.x pilots."""
    return random.split(
        random.PRNGKey(
            seed + 6000 + cutoff
        ),
        4,
    )[chain_id]


def ebfmi(energy) -> float:
    e = np.asarray(
        energy,
        dtype=float,
    ).reshape(-1)

    if len(e) < 2:
        return float("nan")

    variance = np.var(
        e,
        ddof=1,
    )

    if variance <= 0:
        return float("nan")

    return float(
        np.mean(
            np.diff(e) ** 2
        )
        / variance
    )


def load_frozen_state(root: Path):
    config_path = root / CONFIG_REL
    protocol_path = root / PROTOCOL_REL
    preflight_path = root / PREFLIGHT_REL
    implementation_path = (
        root / IMPLEMENTATION_REL
    )

    verify_file_sha(
        config_path,
        EXPECTED_CONFIG_SHA256,
        "Phase3C4 config",
    )

    verify_file_sha(
        protocol_path,
        EXPECTED_PROTOCOL_SHA256,
        "Phase3C4 protocol",
    )

    verify_file_sha(
        preflight_path,
        EXPECTED_PREFLIGHT_SHA256,
        "Phase3C4 mass-matrix preflight",
    )

    verify_file_sha(
        implementation_path,
        EXPECTED_IMPLEMENTATION_SHA256,
        "Phase3C4 implementation",
    )

    config = yaml.safe_load(
        config_path.read_text()
    )

    protocol = json.loads(
        protocol_path.read_text()
    )

    preflight = json.loads(
        preflight_path.read_text()
    )

    if protocol.get(
        "scientific_target_changed"
    ) is not False:
        raise RuntimeError(
            "Scientific target flag is not frozen FALSE."
        )

    if protocol.get(
        "nuts_authorized"
    ) is not False:
        raise RuntimeError(
            "Frozen protocol unexpectedly authorizes NUTS."
        )

    if protocol.get(
        "nuts_run"
    ) is not False:
        raise RuntimeError(
            "Frozen protocol says NUTS has already run."
        )

    if preflight.get(
        "passed"
    ) is not True:
        raise RuntimeError(
            "Mass-matrix preflight did not pass."
        )

    if preflight.get(
        "nuts_authorized"
    ) is not False:
        raise RuntimeError(
            "Preflight artifact unexpectedly authorizes NUTS."
        )

    if preflight.get(
        "nuts_run"
    ) is not False:
        raise RuntimeError(
            "Preflight artifact says NUTS has run."
        )

    if (
        protocol["config_sha256"]
        != EXPECTED_CONFIG_SHA256
    ):
        raise RuntimeError(
            "Protocol config SHA mismatch."
        )

    if (
        protocol["implementation_sha256"]
        != EXPECTED_IMPLEMENTATION_SHA256
    ):
        raise RuntimeError(
            "Protocol implementation SHA mismatch."
        )

    if (
        protocol["lambda_freeze_sha256"]
        != EXPECTED_LAMBDA_FREEZE_SHA256
    ):
        raise RuntimeError(
            "Protocol lambda-freeze SHA mismatch."
        )

    if (
        protocol["target_equivalence_sha256"]
        != EXPECTED_TARGET_EQUIVALENCE_SHA256
    ):
        raise RuntimeError(
            "Protocol target-equivalence SHA mismatch."
        )

    phase_dir = (
        root / "results/phase3c4"
    )

    lambda_artifact = locate_sha_artifact(
        phase_dir,
        EXPECTED_LAMBDA_FREEZE_SHA256,
    )

    target_eq_artifact = locate_sha_artifact(
        phase_dir,
        EXPECTED_TARGET_EQUIVALENCE_SHA256,
    )

    return {
        "config": config,
        "protocol": protocol,
        "preflight": preflight,
        "config_path": config_path,
        "protocol_path": protocol_path,
        "preflight_path": preflight_path,
        "implementation_path": implementation_path,
        "lambda_artifact": lambda_artifact,
        "target_eq_artifact": target_eq_artifact,
    }


def build_dense_mass(config):
    mm = config["mass_matrix"]

    dense_mass = [
        tuple(
            mm["count_plus_initial_block"]
        ),
        tuple(
            mm["dynamic_scale_block"]
        ),
        tuple(
            mm["seriousness_block"]
        ),
    ]

    diagonal = tuple(
        mm["diagonal_site"]
    )

    if diagonal != (
        "phase3c4_u",
    ):
        raise RuntimeError(
            "Frozen diagonal site is not phase3c4_u."
        )

    return dense_mass, diagonal


def trace_free_latents(
    model,
    key,
    args,
    kwargs,
):
    trace = handlers.trace(
        handlers.seed(
            model,
            key,
        )
    ).get_trace(
        *args,
        **kwargs,
    )

    return {
        name
        for name, site
        in trace.items()
        if site.get("type") == "sample"
        and not site.get(
            "is_observed",
            False,
        )
    }, trace


def validate_mass_matrix_sites(
    model,
    key,
    args,
    kwargs,
    config,
):
    free_sites, trace = (
        trace_free_latents(
            model,
            key,
            args,
            kwargs,
        )
    )

    dense_mass, diagonal = (
        build_dense_mass(
            config
        )
    )

    declared = []

    for block in dense_mass:
        declared.extend(block)

    declared.extend(diagonal)

    if len(declared) != len(set(declared)):
        raise RuntimeError(
            "Duplicate mass-matrix site detected."
        )

    declared_set = set(declared)

    missing = (
        free_sites
        - declared_set
    )

    extra = (
        declared_set
        - free_sites
    )

    if missing:
        raise RuntimeError(
            "Free latent sites missing from mass matrix: "
            + ", ".join(
                sorted(missing)
            )
        )

    if extra:
        raise RuntimeError(
            "Mass-matrix sites are not free latents: "
            + ", ".join(
                sorted(extra)
            )
        )

    for old_name in (
        "dynamic_sd",
        "base_increment",
    ):
        site = trace.get(
            old_name
        )

        if site is None:
            raise RuntimeError(
                f"Conditioned site missing: {old_name}"
            )

        if not site.get(
            "is_observed",
            False,
        ):
            raise RuntimeError(
                f"{old_name} is unexpectedly free."
            )

    for forbidden in (
        "phase3c3_dynamic_sd",
        "phase3c3_z",
    ):
        if forbidden in free_sites:
            raise RuntimeError(
                f"Forbidden Phase3C3 latent present: {forbidden}"
            )

    required_new = {
        "phase3c4_q0",
        "phase3c4_q1",
        "phase3c4_q2",
        "phase3c4_dynamic_sd3",
        "phase3c4_u",
    }

    if not required_new.issubset(
        free_sites
    ):
        raise RuntimeError(
            "Required Phase3C4 latent coordinates missing."
        )

    return (
        free_sites,
        dense_mass,
        diagonal,
    )


def runner_sha(root: Path) -> str:
    return sha256(
        Path(__file__).resolve()
    )


def verify_authorization(
    root: Path,
    state,
) -> dict:
    auth_path = (
        root / AUTHORIZATION_REL
    )

    if not auth_path.exists():
        raise RuntimeError(
            "PILOT NOT AUTHORIZED.\n"
            f"Missing authorization artifact: {AUTHORIZATION_REL}\n"
            "NUTS WILL NOT RUN."
        )

    auth = json.loads(
        auth_path.read_text()
    )

    current_runner_sha = (
        runner_sha(root)
    )

    required = {
        "status":
            "PILOT_AUTHORIZED",
        "nuts_authorized":
            True,
        "nuts_run":
            False,
        "runner_sha256":
            current_runner_sha,
        "config_sha256":
            EXPECTED_CONFIG_SHA256,
        "protocol_sha256":
            EXPECTED_PROTOCOL_SHA256,
        "preflight_sha256":
            EXPECTED_PREFLIGHT_SHA256,
        "implementation_sha256":
            EXPECTED_IMPLEMENTATION_SHA256,
        "chain_id":
            1,
        "cutoff":
            12,
        "warmup":
            500,
        "samples":
            500,
        "target_accept_prob":
            0.95,
        "max_tree_depth":
            12,
        "selected_lambda":
            0.25,
    }

    failures = []

    for key, expected in required.items():
        actual = auth.get(key)

        if actual != expected:
            failures.append(
                f"{key}: "
                f"expected={expected!r}, "
                f"actual={actual!r}"
            )

    if failures:
        raise RuntimeError(
            "PILOT AUTHORIZATION INVALID.\n"
            + "\n".join(failures)
            + "\nNUTS WILL NOT RUN."
        )

    return auth


def dry_run(root: Path) -> None:
    state = load_frozen_state(
        root
    )

    config = state["config"]
    protocol = state["protocol"]

    impl = load_module(
        state["implementation_path"],
        "phase3c4_impl_for_runner",
    )

    if not hasattr(
        impl,
        "phase3c4_transport_model",
    ):
        raise RuntimeError(
            "phase3c4_transport_model is missing."
        )

    if not hasattr(
        impl,
        "_PHASE3C3",
    ):
        raise RuntimeError(
            "_PHASE3C3 module is missing."
        )

    if not hasattr(
        impl._PHASE3C3,
        "reference_data",
    ):
        raise RuntimeError(
            "_PHASE3C3.reference_data is missing."
        )

    cutoff = int(
        config["reference"]["cutoff"]
    )

    seed, args, kwargs = (
        impl._PHASE3C3.reference_data(
            root,
            cutoff=cutoff,
        )
    )

    # Lightweight trace only. No NUTS.
    small_args = (
        args[0][:2, :4],
        args[1][:2, :4],
        args[2][:2, :4],
        args[3][:2],
        args[4][:2],
        2,
        2,
    )

    key = random.PRNGKey(
        seed + 94000
    )

    (
        free_sites,
        dense_mass,
        diagonal,
    ) = validate_mass_matrix_sites(
        impl.phase3c4_transport_model,
        key,
        small_args,
        kwargs,
        config,
    )

    pilot = config["pilot"]
    gate = config["pilot_gate"]

    frozen_checks = {
        "chain_id":
            int(pilot["chain_id"]) == 1,
        "cutoff":
            cutoff == 12,
        "warmup":
            int(pilot["warmup"]) == 500,
        "samples":
            int(pilot["samples"]) == 500,
        "target_accept_prob":
            float(
                pilot["target_accept_prob"]
            ) == 0.95,
        "max_tree_depth":
            int(
                pilot["max_tree_depth"]
            ) == 12,
        "x64":
            bool(
                pilot["x64"]
            ) is True,
        "chain_method":
            pilot["chain_method"]
            == "sequential",
        "regularize_mass_matrix":
            bool(
                pilot[
                    "regularize_mass_matrix"
                ]
            ) is True,
        "lambda":
            float(
                config["transport"]["lambda"]
            ) == 0.25,
        "gate_divergences":
            int(
                gate["divergences"]
            ) == 0,
        "gate_finite":
            bool(
                gate["finite_posterior"]
            ) is True,
        "gate_ebfmi":
            float(
                gate["ebfmi_min"]
            ) == 0.30,
        "gate_tree_sat":
            float(
                gate[
                    "tree_depth_saturation_rate_max"
                ]
            ) == 0.01,
    }

    failed = [
        name
        for name, passed
        in frozen_checks.items()
        if not passed
    ]

    if failed:
        raise RuntimeError(
            "Frozen pilot setting verification failed: "
            + ", ".join(failed)
        )

    chain_key = (
        original_chain_rng_key(
            seed,
            cutoff,
            1,
        )
    )

    auth_exists = (
        root / AUTHORIZATION_REL
    ).exists()

    run_marker = (
        root / RUN_MARKER_REL
    )

    pilot_npz = (
        root
        / PILOT_DIR_REL
        / "JOINT_LOG_SCALE_RADIAL_t12_chain1.npz"
    )

    pilot_json = (
        root
        / PILOT_DIR_REL
        / "JOINT_LOG_SCALE_RADIAL_t12_chain1.json"
    )

    consumed_artifacts = [
        path
        for path in (
            run_marker,
            pilot_npz,
            pilot_json,
        )
        if path.exists()
    ]

    if consumed_artifacts:
        raise RuntimeError(
            "Frozen Phase3C4 one-shot pilot has already "
            "been started or produced output:\n"
            + "\n".join(
                str(path.relative_to(root))
                for path in consumed_artifacts
            )
        )

    print(
        "=== PHASE3C4 PILOT RUNNER DRY-RUN ==="
    )

    print(
        "\nFROZEN ARTIFACT VERIFICATION: PASS"
    )
    print(
        "CONFIG SHA256:",
        EXPECTED_CONFIG_SHA256,
    )
    print(
        "PROTOCOL SHA256:",
        EXPECTED_PROTOCOL_SHA256,
    )
    print(
        "PREFLIGHT SHA256:",
        EXPECTED_PREFLIGHT_SHA256,
    )
    print(
        "IMPLEMENTATION SHA256:",
        EXPECTED_IMPLEMENTATION_SHA256,
    )

    print(
        "\nRESOLVED HASH-BOUND ARTIFACTS"
    )
    print(
        "lambda freeze:",
        state["lambda_artifact"].relative_to(
            root
        ),
    )
    print(
        "target equivalence:",
        state["target_eq_artifact"].relative_to(
            root
        ),
    )

    print(
        "\nPILOT SETTINGS"
    )
    print(
        "chain_id:",
        pilot["chain_id"],
    )
    print(
        "cutoff:",
        cutoff,
    )
    print(
        "warmup:",
        pilot["warmup"],
    )
    print(
        "samples:",
        pilot["samples"],
    )
    print(
        "target_accept_prob:",
        pilot["target_accept_prob"],
    )
    print(
        "max_tree_depth:",
        pilot["max_tree_depth"],
    )
    print(
        "lambda:",
        config["transport"]["lambda"],
    )

    print(
        "\nFREE LATENT SITE COUNT:",
        len(free_sites),
    )

    print(
        "FREE LATENTS:"
    )
    for name in sorted(
        free_sites
    ):
        print(
            " ",
            name,
        )

    print(
        "\nDENSE MASS BLOCKS:"
    )
    for block in dense_mass:
        print(
            block
        )

    print(
        "\nDIAGONAL SITES:"
    )
    print(
        diagonal
    )

    print(
        "\nMASS-MATRIX/SITE VERIFICATION: PASS"
    )

    print(
        "\nSTRESS CHAIN RNG"
    )
    print(
        "seed:",
        seed,
    )
    print(
        "chain_id:",
        1,
    )
    print(
        "key:",
        np.asarray(
            chain_key
        ).tolist(),
    )

    print(
        "\nRUNNER SHA256:",
        runner_sha(root),
    )

    print(
        "AUTHORIZATION FILE EXISTS:",
        auth_exists,
    )

    print(
        "ONE-SHOT RUN MARKER EXISTS:",
        run_marker.exists(),
    )

    print(
        "PILOT RESULT EXISTS:",
        (
            pilot_npz.exists()
            or pilot_json.exists()
        ),
    )

    print(
        "ONE-SHOT PILOT UNUSED: PASS"
    )

    print(
        "NUTS AUTHORIZED:",
        False,
    )

    print(
        "\nPHASE3C4 PILOT RUNNER DRY-RUN: PASS"
    )
    print(
        "NEXT: FREEZE_RUNNER_SHA_AND_CREATE_PILOT_AUTHORIZATION"
    )
    print(
        "NO NUTS WAS RUN"
    )


def run_pilot(root: Path) -> None:
    state = load_frozen_state(
        root
    )

    # This is the hard safety barrier.
    verify_authorization(
        root,
        state,
    )

    run_marker = (
        root / RUN_MARKER_REL
    )

    pilot_npz = (
        root
        / PILOT_DIR_REL
        / "JOINT_LOG_SCALE_RADIAL_t12_chain1.npz"
    )

    pilot_json = (
        root
        / PILOT_DIR_REL
        / "JOINT_LOG_SCALE_RADIAL_t12_chain1.json"
    )

    for path in (
        run_marker,
        pilot_npz,
        pilot_json,
    ):
        if path.exists():
            raise RuntimeError(
                "ONE-SHOT PILOT ALREADY CONSUMED. "
                "NUTS WILL NOT RUN. Existing artifact: "
                + str(path.relative_to(root))
            )

    config = state["config"]

    impl = load_module(
        state["implementation_path"],
        "phase3c4_impl_for_pilot",
    )

    cutoff = int(
        config["reference"]["cutoff"]
    )

    seed, args, kwargs = (
        impl._PHASE3C3.reference_data(
            root,
            cutoff=cutoff,
        )
    )

    free_sites, dense_mass, diagonal = (
        validate_mass_matrix_sites(
            impl.phase3c4_transport_model,
            random.PRNGKey(
                seed + 94001
            ),
            (
                args[0][:2, :4],
                args[1][:2, :4],
                args[2][:2, :4],
                args[3][:2],
                args[4][:2],
                2,
                2,
            ),
            kwargs,
            config,
        )
    )

    pilot = config["pilot"]

    kernel = NUTS(
        impl.phase3c4_transport_model,
        dense_mass=dense_mass,
        target_accept_prob=float(
            pilot["target_accept_prob"]
        ),
        max_tree_depth=int(
            pilot["max_tree_depth"]
        ),
        regularize_mass_matrix=bool(
            pilot[
                "regularize_mass_matrix"
            ]
        ),
    )

    mcmc = MCMC(
        kernel,
        num_warmup=int(
            pilot["warmup"]
        ),
        num_samples=int(
            pilot["samples"]
        ),
        num_chains=1,
        chain_method="sequential",
        progress_bar=True,
        progress_rate=25,
    )

    started = perf_counter()

    run_marker.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    marker_payload = {
        "phase":
            "Phase 3C.4",
        "status":
            "UNIQUE_PILOT_ATTEMPT_CONSUMED",
        "created_utc":
            utc_now(),
        "chain_id":
            1,
        "cutoff":
            12,
        "warmup":
            500,
        "samples":
            500,
        "target_accept_prob":
            0.95,
        "max_tree_depth":
            12,
        "selected_lambda":
            0.25,
        "runner_sha256":
            runner_sha(root),
        "config_sha256":
            EXPECTED_CONFIG_SHA256,
        "protocol_sha256":
            EXPECTED_PROTOCOL_SHA256,
        "preflight_sha256":
            EXPECTED_PREFLIGHT_SHA256,
        "implementation_sha256":
            EXPECTED_IMPLEMENTATION_SHA256,
        "note":
            (
                "Creation of this marker permanently consumes "
                "the single frozen Phase 3C.4 chain-1 pilot "
                "attempt, including in the event of interruption."
            ),
    }

    with run_marker.open(
        "x",
        encoding="utf-8",
    ) as f:
        json.dump(
            marker_payload,
            f,
            indent=2,
            ensure_ascii=False,
        )

    mcmc.run(
        original_chain_rng_key(
            seed,
            cutoff,
            1,
        ),
        *args,
        extra_fields=(
            "diverging",
            "num_steps",
            "accept_prob",
            "energy",
            "potential_energy",
        ),
        **kwargs,
    )

    raw = mcmc.get_samples(
        group_by_chain=True
    )

    extra = mcmc.get_extra_fields(
        group_by_chain=True
    )

    jax.block_until_ready(
        jax.tree.leaves(raw)[0]
    )

    arrays = {
        name: np.asarray(value)
        for name, value
        in raw.items()
    }

    arrays.update(
        {
            f"_extra_{name}":
                np.asarray(value)
            for name, value
            in extra.items()
        }
    )

    divergences = int(
        np.asarray(
            extra["diverging"],
            dtype=bool,
        ).sum()
    )

    finite = all(
        np.isfinite(value).all()
        for value
        in arrays.values()
    )

    energy = np.asarray(
        extra["energy"]
    )[0]

    bfmi_value = ebfmi(
        energy
    )

    max_tree_depth = int(
        pilot["max_tree_depth"]
    )

    saturation_threshold = (
        2 ** max_tree_depth
        - 1
    )

    num_steps = np.asarray(
        extra["num_steps"]
    )[0]

    tree_sat = float(
        np.mean(
            num_steps
            >= saturation_threshold
        )
    )

    accept_mean = float(
        np.mean(
            np.asarray(
                extra["accept_prob"]
            )[0]
        )
    )

    gate = config["pilot_gate"]

    passed = bool(
        divergences
        == int(
            gate["divergences"]
        )
        and finite
        == bool(
            gate["finite_posterior"]
        )
        and bfmi_value
        >= float(
            gate["ebfmi_min"]
        )
        and tree_sat
        <= float(
            gate[
                "tree_depth_saturation_rate_max"
            ]
        )
    )

    result_dir = (
        root / PILOT_DIR_REL
    )

    artifact = (
        result_dir
        / "JOINT_LOG_SCALE_RADIAL_t12_chain1.npz"
    )

    atomic_npz(
        artifact,
        arrays,
    )

    payload = {
        "version":
            "phase3c4_joint_log_scale_radial_pilot_result_v1",
        "created_utc":
            utc_now(),
        "status":
            "PASS_PROMISING"
            if passed
            else "FAIL_NOT_PROMISING",
        "scientific_target_changed":
            False,
        "chain_id":
            1,
        "cutoff":
            cutoff,
        "warmup":
            int(
                pilot["warmup"]
            ),
        "samples":
            int(
                pilot["samples"]
            ),
        "target_accept_prob":
            float(
                pilot["target_accept_prob"]
            ),
        "max_tree_depth":
            max_tree_depth,
        "selected_lambda":
            0.25,
        "dense_mass":
            [
                list(block)
                for block in dense_mass
            ],
        "diagonal_site":
            list(diagonal),
        "divergences":
            divergences,
        "finite_posterior":
            finite,
        "ebfmi":
            bfmi_value,
        "tree_depth_saturation_rate":
            tree_sat,
        "mean_accept_prob":
            accept_mean,
        "elapsed_seconds":
            perf_counter()
            - started,
        "runner_sha256":
            runner_sha(root),
        "config_sha256":
            EXPECTED_CONFIG_SHA256,
        "protocol_sha256":
            EXPECTED_PROTOCOL_SHA256,
        "preflight_sha256":
            EXPECTED_PREFLIGHT_SHA256,
        "implementation_sha256":
            EXPECTED_IMPLEMENTATION_SHA256,
        "artifact": {
            "path":
                artifact.relative_to(
                    root
                ).as_posix(),
            "bytes":
                artifact.stat().st_size,
            "sha256":
                sha256(
                    artifact
                ),
        },
        "pilot_gate":
            gate,
        "passed":
            passed,
    }

    atomic_json(
        artifact.with_suffix(
            ".json"
        ),
        payload,
    )

    print(
        json.dumps(
            payload,
            indent=2,
            ensure_ascii=False,
        )
    )

    print(
        "PHASE3C4 PILOT:",
        payload["status"],
    )


def main() -> None:
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--mode",
        choices=(
            "dry-run",
            "pilot",
        ),
        required=True,
    )

    ns = parser.parse_args()

    root = (
        Path(__file__)
        .resolve()
        .parents[1]
    )

    if ns.mode == "dry-run":
        dry_run(
            root
        )
        return

    run_pilot(
        root
    )


if __name__ == "__main__":
    main()
