"""Phase3C.4V V3 — G2 DETERMINISTIC STABILITY ANALYSIS EXECUTION RUNNER (scripts/90).

Derived from frozen scripts/89 (SHA 50a7cbcdc6f5c58e32515a00c55076ad8548e6f79917e3e35a8731576c943725,
which remains UNMODIFIED) with the following MINIMAL engineering repairs only:

  Repair A: execute CLI dispatch. main() now dispatches to cmd_execute()
            (`if mode == "execute": return cmd_execute()`); the unconditional
            STOP_NOT_AUTHORIZED hard-code in main() is REMOVED. Refusal now
            happens inside cmd_execute() Gate 1 (missing human authorization
            artifact), provable via the --execute negative-gate test (T18).
  Repair B: seed parser. seed_of() now strictly parses a `seedXXXX` token and
            raises ValueError for malformed identities (no silent -1 / None /
            coercion). Verified by T17.
  Repair C: Metric 3 sin_F vector-norm API fix. The buggy
            `np.linalg.norm(np.sin(theta), ord="fro")` (NumPy rejects 'fro'
            for the 1-D rank-4 principal-angle vector) is replaced by the exact
            frozen-definition implementation `np.linalg.norm(np.sin(theta), ord=2)`
            (vector L2 = ||sin(theta)||_2). Verified by T20 / T21. This is the
            ONLY scientific-path change; Metric 3 meaning is unchanged.

The V3 G2 scientific protocol implementation (Metric 1-7, covariance
Sigma_V3 = B_AR1 + U_local U_local.T, rank-4 prechecks, thresholds=NONE,
no new inference) is UNCHANGED from scripts88.

V3-specific adaptive G2 executor. Implements ONLY the frozen V3 G2 protocol
(43N + 43O + 43P + 43Q). NO scientific-model redesign.

Authoritative frozen sources (SHA-bound below):
  - 43N V3 G2 ADAPTIVE STABILITY PROTOCOL REFREEZE
        (V3_G2_ADAPTIVE_PROTOCOL_REFROZEN_PRE_EXECUTION)
  - 43O V3 G2 DETERMINISTIC SPECIFICATION CLARIFICATION FREEZE
        (raw-rho shape contract, arccos safety, rank-4 precheck,
         Metric 6 np.ix_ principal-submatrix indexing)
  - 43P V3 G2 PRE-IMPLEMENTATION PROTOCOL AMENDMENT FREEZE
        (Metric 2 = source-exact V2 marginal_scale_cv; 43N pairwise
         normalized-RMS formula SUPERSEDED; Metric 5 raw-only Procrustes,
         symmetric-normalized PROHIBITED)
  - 43Q V3 G2 FINAL ALGEBRAIC CLARIFICATION FREEZE
        (Metric 5 orientation: C = F_i.T @ F_j; R = Vt.T @ U.T;
         Metric 7 pairwise Delta-rho restored)
  - V3 guide (Sigma_V3 = B_AR1 + U_local U_local.T; rho = 0.99*tanh(raw))
  - serializer (NPZ + JSON manifest contract; recover_fitted_guide never samples)
  - scripts87 (V3_PARAM_SHAPES; canonical_raw_rho_scalar; persistence contract)

MODES:
  --mode preflight (alias --preflight)
      Implementation / static / synthetic validation ONLY. Runs the frozen
      synthetic unit tests T1..T23 (fabricated arrays ONLY - no fitted V3
      scientific values) plus a ZERO-SCIENTIFIC-COMPUTATION metadata preflight
      (file presence, manifests, parameter-file hashes, persistence PASS,
      final-on-disk PASS, protected source SHA). NO G2 metric is computed from
      real fitted parameters; NO pairwise scientific comparison of real runs.
      Writes results/phase3c4v_v3/preflight/V3_G2_EXECUTOR_PREFLIGHT_V3.{json,md}
      (independent new preflight; the scripts88 V3_G2_EXECUTOR_PREFLIGHT.json
      and scripts89 V3_G2_EXECUTOR_PREFLIGHT_V2.json artifacts are NOT overwritten).
      SAFETY: if the post-failure repaired-execution authorization
      (V3_G2_POST_FAILURE_REPAIRED_EXECUTION_AUTHORIZATION.json) already exists,
      --preflight is REFUSED (STOP_PREFLIGHT_AFTER_REPAIRED_AUTHORIZATION) so the
      negative execute tests cannot enter the real scientific path. Preflight
      must run BEFORE the new authorization is created.
  --mode execute (alias --execute)
      Real V3 G2 (post-failure repaired) scientific execution. FORBIDDEN unless
      BOTH (a) a PASSING V3 preflight artifact on disk AND (b) the DISTINCT
      post-failure repaired-execution authorization artifact
      results/phase3c4v_v3/authorizations/V3_G2_POST_FAILURE_REPAIRED_EXECUTION_AUTHORIZATION.json
      with {"V3_G2_REPAIRED_EXECUTION_AUTHORIZED": true}. The original scripts89
      authorization (V3_G2_REAL_EXECUTION_AUTHORIZATION.json, even if it still
      contains G2_REAL_EXECUTION_AUTHORIZED=true) is HISTORICAL_CONSUMED and NOT
      sufficient for scripts90. Absent -> STOP_NOT_AUTHORIZED.
      Runs exactly once (refuses if 43S evidence already exists).

Default invocation (no args): prints usage and runs NOTHING scientific.

NO SVI. NO Trace-ELBO objective. NO optimizer. NO posterior sampling. NO
importance sampling. NO PCA. NO NUTS/HMC/MCMC. No random draws. No
quantitative G2 threshold (quantitative G2 PASS threshold = NONE,
quantitative G2 FAIL threshold = NONE); allowed classification is only
G2_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION or G2_EXECUTION_INCOMPLETE.
"""

import argparse
import hashlib
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# Frozen V3 evaluable cohort (43N/43O/43P/43Q): exactly 9 identities.
# ---------------------------------------------------------------------------
EVALUABLE = [
    "V3_V3_ARM_P1_p1_seed1001_t12",
    "V3_V3_ARM_P1_p1_seed2002_t12",
    "V3_V3_ARM_P1_p1_seed3003_t12",
    "V3_V3_ARM_P1_p1_seed5005_t12",
    "V3_V3_ARM_P4_p4_seed1001_t12",
    "V3_V3_ARM_P4_p4_seed2002_t12",
    "V3_V3_ARM_P4_p4_seed3003_t12",
    "V3_V3_ARM_P4_p4_seed4004_t12",
    "V3_V3_ARM_P4_p4_seed5005_t12",
]
P1_IDS = [i for i in EVALUABLE if "_P1_" in i]     # exactly 4
P4_IDS = [i for i in EVALUABLE if "_P4_" in i]     # exactly 5
ENGINEERING_LOSS_P1 = ["V3_V3_ARM_P1_p1_seed4004_t12"]  # RUN_STARTED only; MUST_NOT_RERUN

RUNS_DIR = ROOT / "results/phase3c4v_v3/runs"
G2_OUT = ROOT / "results/phase3c4v_v3/g2"
PREFLIGHT_OUT = ROOT / "results/phase3c4v_v3/preflight"
AUTH_DIR = ROOT / "results/phase3c4v_v3/authorizations"
# scripts90 uses a DISTINCT post-failure repaired-execution authorization.
# The original scripts89 authorization (OLD_AUTH_FILE, key
# G2_REAL_EXECUTION_AUTHORIZED) is HISTORICAL_CONSUMED_NOT_VALID_FOR_SCRIPTS90
# and MUST NOT grant execution to scripts90 even if it still contains true.
OLD_AUTH_FILE = AUTH_DIR / "V3_G2_REAL_EXECUTION_AUTHORIZATION.json"
REPAIRED_AUTH_FILE = AUTH_DIR / "V3_G2_POST_FAILURE_REPAIRED_EXECUTION_AUTHORIZATION.json"
REPAIRED_AUTH_KEY = "V3_G2_REPAIRED_EXECUTION_AUTHORIZED"

# Frozen constants (43N/43O/43P/43Q)
LATENT_DIM = 708
FACTOR_DIM = 12            # V3: NO F_shared; three rank-4 local families
FAMILY_RANK = 4
TOTAL_ELEMENTS = 2049      # 708 + 708 + 480 + 64 + 88 + 1
LOG_SCALE_ABS_MAX = 300.0
RHO_MAX = 0.99

# Semantic blocks (frozen in 43N/43O; identical to V3 guide _BLOCK_SEGMENTS)
SEMANTIC_BLOCKS = [
    {"name": "count_plus_initial", "dim": 120, "indices": list(range(0, 70)) + list(range(108, 158))},
    {"name": "dynamic_scale", "dim": 16, "indices": list(range(70, 86))},
    {"name": "seriousness", "dim": 22, "indices": list(range(86, 108))},
    {"name": "temporal_path", "dim": 550, "indices": list(range(158, 708))},
]
BLOCK_OF_COORD = {}
for _b in SEMANTIC_BLOCKS:
    for _i in _b["indices"]:
        BLOCK_OF_COORD[_i] = _b["name"]

# Canonical local factor families (43N/43P/43Q): three and ONLY three.
FAMILIES = ["F_count_plus_initial", "F_dynamic_scale", "F_seriousness"]
FAMILY_PARAM_KEYS = {
    "F_count_plus_initial": "v3_F_count_plus_initial",
    "F_dynamic_scale": "v3_F_dynamic_scale",
    "F_seriousness": "v3_F_seriousness",
}

# Frozen V3 persisted parameter schema (43N/43O; scripts87 V3_PARAM_SHAPES)
PARAM_KEYS = ["v3_loc", "v3_diag_log_scale", "v3_F_count_plus_initial",
              "v3_F_dynamic_scale", "v3_F_seriousness", "v3_raw_temporal_rho"]
PARAM_SHAPES = {"v3_loc": (708,), "v3_diag_log_scale": (708,),
                "v3_F_count_plus_initial": (120, 4), "v3_F_dynamic_scale": (16, 4),
                "v3_F_seriousness": (22, 4), "v3_raw_temporal_rho": (1,)}

# Frozen SHA chain bound by this runner.
FROZEN_CHAIN = {
    "model": ("src/dhbcp_pv/models/full_joint_model.py",
              "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"),
    "guide_v3": ("src/dhbcp_pv/inference/v3_local_block_ar1_guide.py",
                 "19a66f8b40bb211a68dfd65993e9235498bb11f5e54594553611fea87561a07f"),
    "serializer": ("src/dhbcp_pv/inference/variational_param_persistence.py",
                   "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"),
    "scripts87": ("scripts/87_run_phase3c4v_v3_g1_remaining_matrix.py",
                  "24102da589e2c5992754d129c87f49c05f6eb3bbdf4b85af14e215d36cbda815"),
    "42ZA": ("results/phase3c4v_v2/protocol/42ZA_V2_G2_REPLICATE_POSTERIOR_STABILITY_PROTOCOL_FREEZE.json",
             "0b76b1a2fa7d56d7f328e1e9b929ceead194363199dcd537d26503866720f53e"),
    "42ZD": ("results/phase3c4v_v2/protocol/42ZD_V2_G2_DETERMINISTIC_EXECUTION_SPECIFICATION_FREEZE.json",
             "47fd48f39a39a73737946e976fa047f91e5a3d03fbf2f3c784021f0c229670e0"),
    "scripts78": ("scripts/78_phase3c4v_v2_g2_deterministic_stability_execute.py",
                  "516a6701aa8fa8f6b120dc58c6cc7f6fd741912d0f4a38624305f73c714e2d1a"),
    "43N": ("results/phase3c4v_v3/audit/43N_V3_G2_ADAPTIVE_STABILITY_PROTOCOL_REFREEZE.json",
            "a1dfe7a9d1b41c30443f9f71f16e805c41eae934ca3983cc99953ca6246cb1ba"),
    "43O": ("results/phase3c4v_v3/audit/43O_V3_G2_DETERMINISTIC_SPECIFICATION_CLARIFICATION_FREEZE.json",
            "4547b218ea765b950aa0ef3e4735bf0b41bc8bc92f4a790341a5821ea7733082"),
    "43P": ("results/phase3c4v_v3/audit/43P_V3_G2_PRE_IMPLEMENTATION_PROTOCOL_AMENDMENT_FREEZE.json",
            "c96adfdd773c686adba6360e4e1e85834c331cfc813e10215be1f0fe959e8e8a"),
    "43Q": ("results/phase3c4v_v3/audit/43Q_V3_G2_FINAL_ALGEBRAIC_CLARIFICATION_FREEZE.json",
            "f06c142b9aef404f45966f4fa6238ad246cc0aef6a4a86b292d2eded68dfd637"),
    "43S0": ("results/phase3c4v_v3/audit/43S0_V3_G2_FIRST_REAL_EXECUTION_ENGINEERING_EXCEPTION_FREEZE.json",
             "bd88fa8d72003a0d2c38439ac038e2d9dbaccc0baba6e33b4e7c7d2768e58dc9"),
    "43S0_MD": ("results/phase3c4v_v3/audit/43S0_V3_G2_FIRST_REAL_EXECUTION_ENGINEERING_EXCEPTION_FREEZE.md",
                "5a42438f33a2e339551876514d81f6b187289f110341d4f8d7b2d1eea410a1e1"),
    "43S1": ("results/phase3c4v_v3/audit/43S1_V3_G2_POST_FAILURE_EXECUTOR_REPAIR_PROTOCOL_FREEZE.json",
             "043f34b74e9069b5379650e2d46ae1ce660aae27cd76954ed020d5ad73829106"),
    "43S1_MD": ("results/phase3c4v_v3/audit/43S1_V3_G2_POST_FAILURE_EXECUTOR_REPAIR_PROTOCOL_FREEZE.md",
                "cf08e3143b0332edb2655fa774db731f164e85e299b8f02e14fcf97d7416c388"),
    "43S1A": ("results/phase3c4v_v3/audit/43S1A_V3_G2_REPAIR_C_EXACT_IMPLEMENTATION_CLARIFICATION.json",
              "3315874b810591a2a931c15d758e3854ecbeca593957087aad0185b9a7c4b853"),
    "43S1A_MD": ("results/phase3c4v_v3/audit/43S1A_V3_G2_REPAIR_C_EXACT_IMPLEMENTATION_CLARIFICATION.md",
                 "57e91fd5f183635e4d6d88b3836f3223dad9594ae719c315fdb117c27fecd228"),
}

# Prospective numerical tolerances (x64 machine-precision appropriate).
# These are IMPLEMENTATION tolerances only - NOT scientific stability thresholds.
# ANGLE_TOL basis: arccos of near-1 singular values rounds at ~sqrt(eps_float64)
# ~= 1.49e-8 rad for identical subspaces (observed <= 3.0e-8 across LAPACK paths);
# 1e-6 provides >=30x headroom and remains mathematically neutral.
ABS_TOL = 1e-10
REL_TOL = 1e-8
ANGLE_TOL = 1e-6

# Real-execution gate. During 43R/43R2 this MUST stay True and the
# authorization artifact MUST be absent, so --execute is refused.
EXECUTION_AUTHORIZATION_REQUIRED = True

# Zero-compute proof counters (43R2 T18). Incremented ONLY in the real
# scientific path (load_params / compute_all); printed at Gate-1 refusal so
# the --execute negative-gate test can deterministically prove 0 real
# scientific computation.
_FITTED_PARAM_LOADS = 0
_SCIENTIFIC_METRIC_CALLS = 0


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


# ---------------------------------------------------------------------------
# Parameter loading + analytic Sigma construction (frozen V3 definitions).
# ---------------------------------------------------------------------------
def canonical_raw_rho_scalar(x) -> np.ndarray:
    """Frozen 43O canonicalization: () or (1,) -> 0-d scalar via reshape.

    Raises ValueError for any other shape. NO [0] indexing after reshape.
    """
    a = np.asarray(x, dtype=np.float64)
    if a.shape not in ((), (1,)):
        raise ValueError(f"v3_raw_temporal_rho must be scalar () or one-element (1,); got shape {a.shape}")
    return np.reshape(a, ())


def load_params(ident: str) -> dict:
    """Load a persisted V3 parameter mapping (NPZ), validating the frozen schema.

    READ-ONLY w.r.t. the run directory. Never samples. Shape-checked.
    """
    global _FITTED_PARAM_LOADS
    _FITTED_PARAM_LOADS += 1
    rd = RUNS_DIR / ident
    npz = rd / "final_svi_params.npz"
    if not npz.exists():
        raise FileNotFoundError(f"final_svi_params.npz missing for {ident}")
    with np.load(npz, allow_pickle=False) as z:
        missing = [k for k in PARAM_KEYS if k not in z.files]
        if missing:
            raise ValueError(f"{ident}: missing keys {missing}")
        out = {k: np.asarray(z[k], dtype=np.float64) for k in PARAM_KEYS}
    for k in PARAM_KEYS:
        if out[k].shape != PARAM_SHAPES[k]:
            raise ValueError(f"{ident}: param {k} shape {out[k].shape} != {PARAM_SHAPES[k]}")
    if not all(np.all(np.isfinite(v)) for v in out.values()):
        raise ValueError(f"{ident}: non-finite parameter value present")
    return out


def build_u_local(params: dict) -> np.ndarray:
    """Embedded V3 factor matrix U_local (708, 12).

    cols [0:4] = F_count_plus_initial (120 rows)
    cols [4:8] = F_dynamic_scale       (16 rows)
    cols [8:12]= F_seriousness         (22 rows)
    NO F_shared. NO temporal low-rank factor.
    """
    U = np.zeros((LATENT_DIM, FACTOR_DIM), dtype=np.float64)
    idx = {}
    for b in SEMANTIC_BLOCKS:
        idx[b["name"]] = np.asarray(b["indices"], dtype=np.int64)
    U[idx["count_plus_initial"], 0:4] = params["v3_F_count_plus_initial"]
    U[idx["dynamic_scale"], 4:8] = params["v3_F_dynamic_scale"]
    U[idx["seriousness"], 8:12] = params["v3_F_seriousness"]
    return U


def build_sigma_components(params: dict) -> tuple[np.ndarray, np.ndarray, float, np.ndarray]:
    """Return (s, U_local, rho, diag_vec) for the frozen V3 covariance.

    s = exp(clip(v3_diag_log_scale, -300, 300))
    U_local = build_u_local(params)
    rho = 0.99 * tanh(canonical_raw_rho_scalar(v3_raw_temporal_rho))
    diag_vec[i] = s[i]**2 + ||U_local[i,:]||^2  == diag(B_AR1 + U U^T)
    (B_AR1[i,i] = s[i]^2 for all i: diag blocks s[0:158]^2 and, for each of the
     50 AR1 blocks, S_p R11 S_p has diagonal S_p^2 = s[block]^2.)
    """
    s = np.exp(np.clip(params["v3_diag_log_scale"], -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))
    U = build_u_local(params)
    raw = canonical_raw_rho_scalar(params["v3_raw_temporal_rho"])
    rho = RHO_MAX * float(np.tanh(raw))
    diag_vec = s ** 2 + np.sum(U * U, axis=1)
    return s, U, rho, diag_vec


def build_sigma_dense(params: dict) -> np.ndarray:
    """Dense 708x708 Sigma_V3 = B_AR1 + U_local U_local.T (for synthetic oracles)."""
    s, U, rho, _ = build_sigma_components(params)
    B = np.zeros((LATENT_DIM, LATENT_DIM), dtype=np.float64)
    B[np.arange(158), np.arange(158)] = s[:158] ** 2
    k = np.arange(11)
    R11 = rho ** np.abs(k[:, None] - k[None, :])
    for p in range(50):
        base = 158 + p * 11
        S = np.diag(s[base:base + 11])
        B[base:base + 11, base:base + 11] = S @ R11 @ S
    return B + U @ U.T


def family_matrix(params: dict, family: str) -> np.ndarray:
    return np.asarray(params[FAMILY_PARAM_KEYS[family]], dtype=np.float64)


def family_rank_ok(F: np.ndarray) -> tuple[bool, int, float]:
    """Frozen rank precheck (43O/43P/43Q): mathematical rank must equal 4.

    Tolerance: x64 equivalent of the NumPy matrix_rank default rule
    tol = S.max() * max(M, N) * eps_float64.
    """
    S = np.linalg.svd(F, compute_uv=False)
    tol = float(S.max()) * float(max(F.shape)) * np.finfo(np.float64).eps
    rank = int(np.sum(S > tol))
    return (rank == FAMILY_RANK), rank, tol


# ---------------------------------------------------------------------------
# Deterministic metric primitives (frozen V3 definitions).
# ---------------------------------------------------------------------------
def metric1_pairwise_l2(loc_a: np.ndarray, loc_b: np.ndarray) -> float:
    return float(np.linalg.norm(loc_a - loc_b, ord=2))


def metric2_cv_row(scale_mat: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Source-exact V2 marginal_scale_cv statistics (scripts78 L605-610).

    scale_mat: (n_runs, 708) of marginal SDs.
    mean_i = np.mean(scale_mat, axis=0)
    sd_i   = np.std(scale_mat, axis=0)   # ddof=0 (population)
    cv_i   = np.where(mean != 0, sd / mean, nan) with errstate guard
    """
    mean = np.mean(scale_mat, axis=0)
    sd = np.std(scale_mat, axis=0)  # default ddof=0
    with np.errstate(divide="ignore", invalid="ignore"):
        cv = np.where(mean != 0, sd / mean, np.nan)
    return mean, sd, cv


def principal_angles_family(F_a: np.ndarray, F_b: np.ndarray) -> np.ndarray:
    """Frozen 43O/43P: theta_k = arccos(clip(sigma_k, -1, 1)) via reduced QR."""
    Qa, _ = np.linalg.qr(F_a, mode="reduced")
    Qb, _ = np.linalg.qr(F_b, mode="reduced")
    _, sv, _ = np.linalg.svd(Qa.T @ Qb)
    return np.arccos(np.clip(sv, -1.0, 1.0))


def projection_matrix_family(F: np.ndarray) -> np.ndarray:
    """P = Q Q^T on the reduced-QR orthonormal basis of a canonical family."""
    Q, _ = np.linalg.qr(F, mode="reduced")
    return Q @ Q.T


def procrustes_raw_family(F_a: np.ndarray, F_b: np.ndarray) -> float:
    """Frozen 43Q orientation (raw-only).

    C = F_a.T @ F_b; U,S,Vt = svd(C); R = Vt.T @ U.T;
    d = ||F_a - F_b @ R||_F.  (min over orthogonal R of ||F_a - F_b R||_F)
    METRIC5_RAW_PROCRUSTES_ONLY. Symmetric-normalized variant PROHIBITED.
    """
    C = F_a.T @ F_b
    U, _, Vt = np.linalg.svd(C)
    R = Vt.T @ U.T
    return float(np.linalg.norm(F_a - F_b @ R, ord="fro"))


def block_allocations(diag_vec: np.ndarray, trace: float) -> dict:
    """Metric 6: allocation_B = trace(Sigma[np.ix_(idx_B, idx_B)]) / trace(Sigma).

    trace of the principal submatrix equals the sum of the covariance diagonal
    at idx_B (np.ix_ full submatrix semantics preserved: sum of diag entries).
    """
    out = {}
    for b in SEMANTIC_BLOCKS:
        idx = np.asarray(b["indices"], dtype=np.int64)
        out[b["name"]] = float(np.sum(diag_vec[idx]) / trace)
    return out


def within_arm_pairs(ids):
    pairs = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            pairs.append((ids[i], ids[j]))
    return pairs


def desc_summary(values) -> dict:
    """Frozen 42ZA-style summary over finite values (mean, SD ddof=0, CV, min, max, n)."""
    a = np.asarray(values, dtype=np.float64)
    a = a[np.isfinite(a)]
    n = int(a.size)
    if n == 0:
        return {"mean": float("nan"), "sd": float("nan"), "cv": float("nan"),
                "min": float("nan"), "max": float("nan"), "n": 0}
    mean = float(np.mean(a))
    sd = float(np.std(a, ddof=0))
    cv = sd / mean if mean != 0 and np.isfinite(mean) else float("nan")
    return {"mean": mean, "sd": sd, "cv": cv,
            "min": float(np.min(a)), "max": float(np.max(a)), "n": n}


def seed_of(ident: str) -> int:
    """Strict deterministic seed parser (Repair B).

    Parses a token of the form `seedXXXX` (4+ digits) and returns int(XXXX).
    Raises ValueError on ANY malformed identity - NO silent -1 / None /
    coercion / fallback. Verified by T17.
    """
    for tok in ident.split("_"):
        if tok.startswith("seed") and tok[4:].isdigit():
            return int(tok[4:])
    raise ValueError(f"malformed identity: no seedXXXX token in {ident!r}")


def arm_of(ident: str) -> str:
    return "P1" if "_P1_" in ident else "P4"


# ---------------------------------------------------------------------------
# Real scientific execution (cmd_execute) - FORBIDDEN during 43R.
# ---------------------------------------------------------------------------
def compute_all(ident: str) -> dict:
    global _SCIENTIFIC_METRIC_CALLS
    _SCIENTIFIC_METRIC_CALLS += 1
    params = load_params(ident)
    s, U, rho, diag_vec = build_sigma_components(params)
    trace = float(np.sum(diag_vec))  # == trace(Sigma_V3) = sum(s^2) + ||U||_F^2
    return {
        "loc": params["v3_loc"],
        "diag": diag_vec,
        "s": s,
        "U": U,
        "rho": rho,
        "trace": trace,
        "block": block_allocations(diag_vec, trace),
        "scale": np.sqrt(diag_vec),  # marginal SD = sqrt(diag(Sigma))
    }


def cmd_execute() -> int:
    global _FITTED_PARAM_LOADS, _SCIENTIFIC_METRIC_CALLS
    # Dispatch marker: proves --execute reached cmd_execute() (Repair A),
    # distinguishing cmd_execute-internal Gate-1 refusal from any main()
    # hard-coded refusal.
    print("G2_EXECUTE_DISPATCH_REACHED_CMD_EXECUTE")
    # ---- Gate 1: DISTINCT post-failure repaired-execution authorization (REQUIRED) ----
    # scripts90 ONLY honors REPAIRED_AUTH_FILE with REPAIRED_AUTH_KEY. The
    # original scripts89 authorization (OLD_AUTH_FILE, key
    # G2_REAL_EXECUTION_AUTHORIZED) is HISTORICAL_CONSUMED_NOT_VALID_FOR_SCRIPTS90
    # and is explicitly NOT accepted, even if it still contains true.
    if EXECUTION_AUTHORIZATION_REQUIRED:
        auth_ok = False
        if REPAIRED_AUTH_FILE.exists():
            try:
                auth = json.loads(REPAIRED_AUTH_FILE.read_text(encoding="utf-8"))
                auth_ok = auth.get(REPAIRED_AUTH_KEY) is True
            except Exception:  # noqa: BLE001
                auth_ok = False
        if not auth_ok:
            print("STOP_NOT_AUTHORIZED: real repaired G2 execution requires the DISTINCT "
                  "post-failure repaired-execution authorization artifact "
                  "(V3_G2_POST_FAILURE_REPAIRED_EXECUTION_AUTHORIZATION.json with "
                  "V3_G2_REPAIRED_EXECUTION_AUTHORIZED=true). The original scripts89 "
                  "authorization (V3_G2_REAL_EXECUTION_AUTHORIZATION.json, even if it "
                  "still contains G2_REAL_EXECUTION_AUTHORIZED=true) is "
                  "HISTORICAL_CONSUMED and NOT sufficient for scripts90.")
            print(f"ZERO_COMPUTE_PROOF fitted_param_loads={_FITTED_PARAM_LOADS} "
                  f"scientific_metric_calls={_SCIENTIFIC_METRIC_CALLS}")
            return 2
    # ---- Gate 2: passing NEW V3 preflight on disk (scripts90 binds V3) ----
    pf = PREFLIGHT_OUT / "V3_G2_EXECUTOR_PREFLIGHT_V3.json"
    if not pf.exists():
        print("STOP_NOT_AUTHORIZED: V2 preflight artifact missing; --execute requires a "
              "PASSING V2 preflight first.")
        return 2
    pf_data = json.loads(pf.read_text(encoding="utf-8"))
    if pf_data.get("classification") != "V3_G2_EXECUTOR_PREFLIGHT_PASS":
        print("STOP_NOT_AUTHORIZED: V2 preflight is not PASS; --execute refused.")
        return 2
    # ---- Gate 3: frozen chain exact ----
    chain = verify_frozen_chain()
    if not chain["ok"]:
        print("STOP_SHA_MISMATCH: frozen chain mismatch; --execute refused.")
        return 2
    # ---- Gate 4: exactly-once semantics ----
    zs = G2_OUT / "43S_V3_G2_DETERMINISTIC_STABILITY_EVIDENCE.json"
    if zs.exists():
        print("G2_ALREADY_EXECUTED: 43S evidence exists; refusing to overwrite. "
              "G2 execute is exactly-once.")
        return 3

    t0 = time.time()
    snap_before = {}
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_before[ident] = {"result": sha256(rd / "result.json"),
                              "npz": sha256(rd / "final_svi_params.npz")}

    data = {ident: compute_all(ident) for ident in EVALUABLE}

    # rank precheck (43O/43P/43Q): every required canonical family rank == 4
    rank_ok = True
    rank_detail = []
    for ident in EVALUABLE:
        params = load_params(ident)
        for fam in FAMILIES:
            F = family_matrix(params, fam)
            ok, r, tol = family_rank_ok(F)
            rank_ok = rank_ok and ok
            rank_detail.append({"identity": ident, "family": fam, "rank": r,
                                "tol": tol, "ok": ok})
    if not rank_ok:
        payload = {"classification": "G2_EXECUTION_INCOMPLETE",
                   "reason": "required canonical family rank != 4; no invented basis; "
                             "no silent rank reduction; no result-dependent fallback",
                   "rank_detail": rank_detail,
                   "created_utc": utc_now()}
        atomic_write_json(G2_OUT / "43S_V3_G2_DETERMINISTIC_STABILITY_EVIDENCE.json", payload)
        print("G2_EXECUTION_INCOMPLETE: rank precheck failed; evidence written; STOP.")
        return 0

    # ---- metric 1: guide location distance ----
    loc_rows = []
    loc_by_arm = {"P1": [], "P4": []}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in within_arm_pairs(ids):
            d = metric1_pairwise_l2(data[i]["loc"], data[j]["loc"])
            loc_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                             "seed_i": seed_of(i), "seed_j": seed_of(j),
                             "location_l2_distance": d})
            loc_by_arm[arm].append(d)

    # ---- metric 2: source-exact marginal_scale_cv (across-replicate CV) ----
    cv_rows = []
    cv_summary = {"P1": [], "P4": []}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        mat = np.vstack([data[ident]["scale"] for ident in ids])  # (n,708) marginal SDs
        mean, sd, cv = metric2_cv_row(mat)
        for coord in range(LATENT_DIM):
            cv_rows.append({"arm": arm, "latent_index": coord,
                            "semantic_block": BLOCK_OF_COORD[coord],
                            "mean_marginal_sd": float(mean[coord]),
                            "sd_marginal_sd": float(sd[coord]),
                            "cv_marginal_sd": float(cv[coord]),
                            "min_marginal_sd": float(np.min(mat[:, coord])),
                            "max_marginal_sd": float(np.max(mat[:, coord]))})
        cv_summary[arm] = [float(v) for v in cv if np.isfinite(v)]

    # ---- metric 3: family-specific principal angles ----
    ang_rows = []
    ang_by_arm = {"P1": {"F_count_plus_initial": [], "F_dynamic_scale": [], "F_seriousness": []},
                  "P4": {"F_count_plus_initial": [], "F_dynamic_scale": [], "F_seriousness": []}}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in within_arm_pairs(ids):
            pi, pj = load_params(i), load_params(j)
            for fam in FAMILIES:
                theta = principal_angles_family(family_matrix(pi, fam), family_matrix(pj, fam))
                row = {"arm": arm, "identity_i": i, "identity_j": j,
                       "family": fam, "theta": [float(v) for v in theta],
                       "theta_sum": float(np.sum(theta)),
                       "theta_max": float(np.max(theta)),
                       "sin_F": float(np.linalg.norm(np.sin(theta), ord=2))}
                ang_rows.append(row)
                ang_by_arm[arm][fam].append(row["sin_F"])

    # ---- metric 4: family-specific projection distance ----
    proj_rows = []
    proj_by_arm = {"P1": {f: [] for f in FAMILIES}, "P4": {f: [] for f in FAMILIES}}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in within_arm_pairs(ids):
            pi, pj = load_params(i), load_params(j)
            for fam in FAMILIES:
                Pa = projection_matrix_family(family_matrix(pi, fam))
                Pb = projection_matrix_family(family_matrix(pj, fam))
                d = float(np.linalg.norm(Pa - Pb, ord="fro"))
                proj_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                                  "family": fam, "projection_frobenius_distance": d})
                proj_by_arm[arm][fam].append(d)

    # ---- metric 5: raw-only orthogonal Procrustes (43Q orientation) ----
    proc_rows = []
    proc_by_arm = {"P1": {f: [] for f in FAMILIES}, "P4": {f: [] for f in FAMILIES}}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in within_arm_pairs(ids):
            pi, pj = load_params(i), load_params(j)
            for fam in FAMILIES:
                d = procrustes_raw_family(family_matrix(pi, fam), family_matrix(pj, fam))
                proc_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                                  "family": fam, "raw_procrustes_distance": d})
                proc_by_arm[arm][fam].append(d)

    # ---- metric 6: block covariance allocation + pairwise Delta ----
    block_rows = []
    delta_rows = []
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for ident in ids:
            for b in SEMANTIC_BLOCKS:
                block_rows.append({"arm": arm, "identity": ident, "seed": seed_of(ident),
                                   "semantic_block": b["name"],
                                   "block_fraction_of_total_variance": data[ident]["block"][b["name"]]})
        for (i, j) in within_arm_pairs(ids):
            for b in SEMANTIC_BLOCKS:
                delta = data[i]["block"][b["name"]] - data[j]["block"][b["name"]]
                delta_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                                   "semantic_block": b["name"], "delta_allocation": delta})

    # ---- metric 7: pairwise Delta-rho ----
    rho_rows = []
    delta_rho_rows = []
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for ident in ids:
            rho_rows.append({"arm": arm, "identity": ident, "seed": seed_of(ident),
                             "rho": data[ident]["rho"]})
        for (i, j) in within_arm_pairs(ids):
            delta_rho_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                                   "delta_rho": abs(data[i]["rho"] - data[j]["rho"])})

    # ---- arm summaries ----
    summary = {"P1": {"n": len(P1_IDS), "pair_count": len(loc_by_arm["P1"]),
                      "location_l2_distance": desc_summary(loc_by_arm["P1"]),
                      "marginal_scale_cv_across_coords": desc_summary(cv_summary["P1"]),
                      "principal_angle_sin_F": {f: desc_summary(ang_by_arm["P1"][f]) for f in FAMILIES},
                      "projection_frobenius_distance": {f: desc_summary(proj_by_arm["P1"][f]) for f in FAMILIES},
                      "procrustes_raw_residual": {f: desc_summary(proc_by_arm["P1"][f]) for f in FAMILIES},
                      "block_delta_allocation_mean_abs": {},
                      "rho": desc_summary([r["rho"] for r in rho_rows if r["arm"] == "P1"]),
                      "delta_rho": desc_summary([r["delta_rho"] for r in delta_rho_rows if r["arm"] == "P1"])},
               "P4": {"n": len(P4_IDS), "pair_count": len(loc_by_arm["P4"]),
                      "location_l2_distance": desc_summary(loc_by_arm["P4"]),
                      "marginal_scale_cv_across_coords": desc_summary(cv_summary["P4"]),
                      "principal_angle_sin_F": {f: desc_summary(ang_by_arm["P4"][f]) for f in FAMILIES},
                      "projection_frobenius_distance": {f: desc_summary(proj_by_arm["P4"][f]) for f in FAMILIES},
                      "procrustes_raw_residual": {f: desc_summary(proc_by_arm["P4"][f]) for f in FAMILIES},
                      "block_delta_allocation_mean_abs": {},
                      "rho": desc_summary([r["rho"] for r in rho_rows if r["arm"] == "P4"]),
                      "delta_rho": desc_summary([r["delta_rho"] for r in delta_rho_rows if r["arm"] == "P4"])}}
    for arm in ("P1", "P4"):
        for b in SEMANTIC_BLOCKS:
            vals = [r["delta_allocation"] for r in delta_rows
                    if r["arm"] == arm and r["semantic_block"] == b["name"]]
            summary[arm]["block_delta_allocation_mean_abs"][b["name"]] = \
                desc_summary([abs(v) for v in vals]) if vals else {"mean": float("nan")}

    snap_after = {}
    unchanged = True
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_after[ident] = {"result": sha256(rd / "result.json"),
                             "npz": sha256(rd / "final_svi_params.npz")}
        if snap_after[ident] != snap_before[ident]:
            unchanged = False

    # ---- 43S evidence artifact ----
    def write_csv(name, fieldnames, rows):
        import csv
        p = G2_OUT / name
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(rows)
        return p

    files = {
        "G2_LOCATION_PAIRWISE.csv": write_csv("G2_LOCATION_PAIRWISE.csv",
            ["arm", "identity_i", "identity_j", "seed_i", "seed_j", "location_l2_distance"], loc_rows),
        "G2_MARGINAL_SCALE_CV.csv": write_csv("G2_MARGINAL_SCALE_CV.csv",
            ["arm", "latent_index", "semantic_block", "mean_marginal_sd", "sd_marginal_sd",
             "cv_marginal_sd", "min_marginal_sd", "max_marginal_sd"], cv_rows),
        "G2_FACTOR_PRINCIPAL_ANGLES.csv": write_csv("G2_FACTOR_PRINCIPAL_ANGLES.csv",
            ["arm", "identity_i", "identity_j", "family", "theta_sum", "theta_max", "sin_F"],
            [{k: v for k, v in r.items() if k != "theta"} for r in ang_rows]),
        "G2_PROJECTION_DISTANCE.csv": write_csv("G2_PROJECTION_DISTANCE.csv",
            ["arm", "identity_i", "identity_j", "family", "projection_frobenius_distance"], proj_rows),
        "G2_PROCRUSTES_COMPARISON.csv": write_csv("G2_PROCRUSTES_COMPARISON.csv",
            ["arm", "identity_i", "identity_j", "family", "raw_procrustes_distance"], proc_rows),
        "G2_BLOCK_COVARIANCE_ALLOCATION.csv": write_csv("G2_BLOCK_COVARIANCE_ALLOCATION.csv",
            ["arm", "identity", "seed", "semantic_block", "block_fraction_of_total_variance"], block_rows),
        "G2_BLOCK_DELTA_ALLOCATION.csv": write_csv("G2_BLOCK_DELTA_ALLOCATION.csv",
            ["arm", "identity_i", "identity_j", "semantic_block", "delta_allocation"], delta_rows),
        "G2_RHO_VARIATION.csv": write_csv("G2_RHO_VARIATION.csv",
            ["arm", "identity", "seed", "rho"], rho_rows),
        "G2_DELTA_RHO_PAIRWISE.csv": write_csv("G2_DELTA_RHO_PAIRWISE.csv",
            ["arm", "identity_i", "identity_j", "delta_rho"], delta_rho_rows),
    }
    out_shas = {name: sha256(p) for name, p in files.items()}

    zs_data = {
        "artifact_id": "43S_V3_G2_DETERMINISTIC_STABILITY_EVIDENCE",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v_v3",
        "classification": "G2_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION",
        "evaluable_total": 9,
        "P1_n": len(P1_IDS),
        "P4_n": len(P4_IDS),
        "P1_pair_count": len(loc_by_arm["P1"]),
        "P4_pair_count": len(loc_by_arm["P4"]),
        "engineering_attrition": 1,
        "G2_QUANTITATIVE_THRESHOLD_FROZEN": False,
        "threshold_policy": "NO quantitative G2 threshold exists (43N/43O/43P/43Q); none invented. Evidence for human adjudication.",
        "arm_summary": summary,
        "rank_precheck": {"all_rank_4": rank_ok, "detail": rank_detail},
        "output_files": out_shas,
        "run_artifacts_unchanged_after_execute": unchanged,
        "flags": {"G2_POSTERIOR_DRAWS_USED": False, "G2_NEW_INFERENCE_USED": False,
                  "SVI_USED": False, "IMPORTANCE_SAMPLING_USED": False,
                  "NUTS_HMC_MCMC_USED": False, "G3_AUTHORIZED": False},
        "binds_sha256": {k: v[1] for k, v in FROZEN_CHAIN.items()},
        "elapsed_seconds": round(time.time() - t0, 3),
        "note": "Deterministic V3 G2 replicate-posterior-stability evidence computed analytically "
                "from persisted fitted V3 guide params (Sigma_V3 = B_AR1 + U_local U_local.T). "
                "No posterior draws, no new inference, no SVI, no sampling, no MCMC. "
                "Read-only w.r.t. all 9 evaluable run directories.",
    }
    atomic_write_json(zs, zs_data)
    print("G2 classification:", zs_data["classification"])
    print("43S JSON:", zs)
    print("43S JSON SHA:", sha256(zs))
    print("run_artifacts_unchanged:", unchanged)
    return 0


# ---------------------------------------------------------------------------
# Preflight: synthetic unit tests T1..T16 + zero-scientific-computation
# metadata checks. NO fitted-value arithmetic. NO pairwise scientific
# comparison of real runs.
# ---------------------------------------------------------------------------
def _toy_params(seed=20260821, rho=0.2) -> dict:
    rng = np.random.RandomState(seed)
    return {
        "v3_loc": rng.normal(0, 1, 708),
        "v3_diag_log_scale": rng.normal(-0.5, 0.1, 708),
        "v3_F_count_plus_initial": rng.normal(0, 0.1, (120, 4)),
        "v3_F_dynamic_scale": rng.normal(0, 0.1, (16, 4)),
        "v3_F_seriousness": rng.normal(0, 0.1, (22, 4)),
        "v3_raw_temporal_rho": np.array([rho]),
    }


def _toy_family(m, seed, rank=4) -> np.ndarray:
    rng = np.random.RandomState(seed)
    F = rng.normal(0, 1, (m, rank))
    if rank < 4:  # rank-deficient toy: repeat columns
        F = np.hstack([F[:, :rank], F[:, :(4 - rank)]]).copy()
        F = F[:, :4]
    return F


def run_synthetic_tests() -> dict:
    """Fabricated arrays ONLY. Never loads real fitted V3 values."""
    results = {}
    rec = lambda n, ok, d: results.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731

    # T1: parameter schema validation
    toy = _toy_params()
    ok1 = (sorted(toy.keys()) == sorted(PARAM_KEYS)
           and all(toy[k].shape == PARAM_SHAPES[k] for k in PARAM_KEYS)
           and sum(int(np.prod(PARAM_SHAPES[k])) for k in PARAM_KEYS) == TOTAL_ELEMENTS)
    rec("T1_parameter_schema_validation", ok1,
        {"n_params": len(PARAM_KEYS), "total_elements": TOTAL_ELEMENTS})

    # T2: raw-rho (1,) -> scalar canonicalization
    sc = canonical_raw_rho_scalar(np.array([0.2]))
    sc0 = canonical_raw_rho_scalar(np.array(0.2))
    ok2 = (sc.shape == () and sc0.shape == () and abs(float(sc) - 0.2) < ABS_TOL
           and abs(float(sc0) - 0.2) < ABS_TOL)
    try:
        canonical_raw_rho_scalar(np.array([0.2, 0.3]))
        bad = False
    except ValueError:
        bad = True
    rec("T2_raw_rho_canonicalization", ok2 and bad,
        {"scalar_ok": ok2, "rejects_non_scalar": bad})

    # T3: U_local embedding shape 708x12 and placement
    U = build_u_local(toy)
    idx = {b["name"]: np.asarray(b["indices"], dtype=np.int64) for b in SEMANTIC_BLOCKS}
    col_ok = (U.shape == (708, 12)
              and np.all(U[idx["count_plus_initial"], 0:4] == toy["v3_F_count_plus_initial"])
              and np.all(U[idx["dynamic_scale"], 4:8] == toy["v3_F_dynamic_scale"])
              and np.all(U[idx["seriousness"], 8:12] == toy["v3_F_seriousness"])
              and np.all(U[idx["temporal_path"], :] == 0))
    rec("T3_U_local_embedding", col_ok, {"shape": list(U.shape), "factor_dim": FACTOR_DIM})

    # T4: semantic block union = exactly 708, no overlap
    all_idx = np.concatenate([np.asarray(b["indices"], dtype=np.int64) for b in SEMANTIC_BLOCKS])
    ok4 = (all_idx.shape[0] == 708 and np.array_equal(np.sort(all_idx), np.arange(708))
           and np.unique(all_idx).size == 708)
    rec("T4_block_union_exact", ok4, {"n": int(all_idx.shape[0]), "dims": [b["dim"] for b in SEMANTIC_BLOCKS]})

    # T5: dense Sigma vs optimized marginal-variance diagonal
    Sigma = build_sigma_dense(toy)
    _, _, _, diag_vec = build_sigma_components(toy)
    ok5 = (np.max(np.abs(np.diag(Sigma) - diag_vec)) < ABS_TOL)
    rec("T5_dense_vs_optimized_marginal", ok5,
        {"max_diag_diff": float(np.max(np.abs(np.diag(Sigma) - diag_vec)))})

    # T6: Metric1 L2 against direct NumPy reference
    a, b = toy["v3_loc"], _toy_params(seed=20260822)["v3_loc"]
    d_f = metric1_pairwise_l2(a, b)
    d_ref = float(np.linalg.norm(a - b, ord=2))
    rec("T6_metric1_l2_reference", abs(d_f - d_ref) < ABS_TOL, {"d": d_f, "ref": d_ref})

    # T7: Metric2 CV against explicit NumPy reference (ddof=0)
    mat = np.vstack([np.sqrt(build_sigma_components(_toy_params(seed=s))[3]) for s in (1, 2, 3, 4)])
    mean, sd, cv = metric2_cv_row(mat)
    mean_ref = np.mean(mat, axis=0)
    sd_ref = np.std(mat, axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        cv_ref = np.where(mean_ref != 0, sd_ref / mean_ref, np.nan)
    ok7 = (np.max(np.abs(mean - mean_ref)) < ABS_TOL
           and np.max(np.abs(sd - sd_ref)) < ABS_TOL
           and np.allclose(cv, cv_ref, equal_nan=True, atol=ABS_TOL))
    rec("T7_metric2_cv_ddof0_reference", ok7,
        {"max_mean_diff": float(np.max(np.abs(mean - mean_ref))),
         "max_sd_diff": float(np.max(np.abs(sd - sd_ref)))})

    # T8: principal angles identical subspace -> ~0
    F = _toy_family(120, 7)
    theta = principal_angles_family(F, F)
    rec("T8_identical_subspace_zero_angles",
        bool(np.all(np.abs(theta) < ANGLE_TOL)), {"theta": [float(v) for v in theta]})

    # T9: principal-angle rotation/sign invariance
    F1 = _toy_family(120, 11)
    rng = np.random.RandomState(13)
    R0, _ = np.linalg.qr(rng.normal(0, 1, (4, 4)))
    F2 = F1 @ R0
    theta12 = principal_angles_family(F1, F2)
    rec("T9_principal_angle_rotation_invariance",
        bool(np.all(np.abs(theta12) < ANGLE_TOL)), {"theta": [float(v) for v in theta12]})

    # T10: projection distance invariant to within-family orthogonal rotation
    P1 = projection_matrix_family(F1)
    P2 = projection_matrix_family(F2)
    d_proj = float(np.linalg.norm(P1 - P2, ord="fro"))
    rec("T10_projection_rotation_invariance", d_proj < ABS_TOL, {"d_proj": d_proj})

    # T11: corrected Procrustes - F_j = F_i @ R0 must align to ~0 under frozen orientation
    d_proc = procrustes_raw_family(F1, F2)
    rec("T11_procrustes_corrected_orientation", d_proc < ANGLE_TOL, {"d": d_proc})

    # T12: normalized Procrustes variant absent/prohibited (source scan;
    #      tokens assembled dynamically so the scan cannot self-match)
    src = Path(__file__).read_text(encoding="utf-8")
    forbidden = ["symmetric_" + "normalized", "raw / " + "sqrt",
                 "norm_" + "scaling", "procrustes_" + "compare"]
    hits = [t for t in forbidden if t in src]
    rec("T12_normalized_procrustes_absent", not hits, {"hits": hits})

    # T13: Metric6 optimized block trace == explicit dense np.ix_ trace
    tr_dense = float(np.trace(Sigma))
    ok13 = True
    for b in SEMANTIC_BLOCKS:
        idx_b = np.asarray(b["indices"], dtype=np.int64)
        sub_tr = float(np.trace(Sigma[np.ix_(idx_b, idx_b)]))
        opt_tr = float(np.sum(diag_vec[idx_b]))
        if abs(sub_tr - opt_tr) > ABS_TOL or abs(sub_tr / tr_dense - float(np.sum(diag_vec[idx_b]) / np.sum(diag_vec))) > REL_TOL:
            ok13 = False
    rec("T13_metric6_optimized_equals_dense_ix", ok13,
        {"dense_trace": tr_dense, "optimized_trace": float(np.sum(diag_vec))})

    # T14: rho pairwise delta agrees with direct scalar calculation
    r1 = 0.99 * np.tanh(0.1)
    r2 = 0.99 * np.tanh(-0.05)
    p1 = _toy_params(seed=1, rho=0.1)
    p2 = _toy_params(seed=2, rho=-0.05)
    d_rho = abs(float(0.99 * np.tanh(canonical_raw_rho_scalar(p1["v3_raw_temporal_rho"])))
                - float(0.99 * np.tanh(canonical_raw_rho_scalar(p2["v3_raw_temporal_rho"]))))
    d_ref = abs(r1 - r2)
    rec("T14_rho_pairwise_delta", abs(d_rho - d_ref) < ABS_TOL, {"d": d_rho, "ref": d_ref})

    # T15: pair generation P1=6, P4=10, no cross-arm
    p1_pairs = within_arm_pairs(P1_IDS)
    p4_pairs = within_arm_pairs(P4_IDS)
    cross = [p for p in p1_pairs + p4_pairs if arm_of(p[0]) != arm_of(p[1])]
    rec("T15_pair_generation",
        len(p1_pairs) == 6 and len(p4_pairs) == 10 and not cross,
        {"P1": len(p1_pairs), "P4": len(p4_pairs), "cross_arm": len(cross)})

    # T16: rank-deficient synthetic family triggers G2_EXECUTION_INCOMPLETE logic
    F_rank3 = _toy_family(120, 19, rank=3)
    ok16, r16, tol16 = family_rank_ok(F_rank3)
    rec("T16_rank_deficiency_incomplete",
        (not ok16) and r16 == 3,
        {"ok": ok16, "rank": r16, "tol": tol16, "expected_rank": FAMILY_RANK})

    # ---- T17: seed parser (Repair B) ----
    legal = {
        "V3_V3_ARM_P1_p1_seed1001_t12": 1001,
        "V3_V3_ARM_P1_p1_seed2002_t12": 2002,
        "V3_V3_ARM_P1_p1_seed3003_t12": 3003,
        "V3_V3_ARM_P4_p4_seed4004_t12": 4004,
        "V3_V3_ARM_P4_p4_seed5005_t12": 5005,
    }
    legal_ok = all(seed_of(i) == s for i, s in legal.items())
    malformed = ["V3_V3_ARM_P1_p1_t12", "V3_V3_ARM_P1_p1_seedX_t12",
                 "V3_V3_ARM_P1_p1_1001_t12", "", "seed", "V3_ARM_P1_seed"]
    rejected = 0
    for m in malformed:
        try:
            seed_of(m)
        except ValueError:
            rejected += 1
    rec("T17_seed_parser",
        legal_ok and rejected == len(malformed) and all(seed_of(i) == s for i, s in legal.items()),
        {"legal": {i: seed_of(i) for i in legal},
         "malformed_rejected": rejected, "malformed_total": len(malformed)})

    # ---- T18: --execute dispatch reaches cmd_execute() Gate 1 ----
    # Proves: main() -> cmd_execute() -> Gate 1 -> STOP_NOT_AUTHORIZED (no
    # human authorization artifact), with 0 fitted loads / 0 metric calls /
    # 0 outputs / 0 43S / 0 authorization artifacts. Distinguishes Gate-1
    # refusal from any main()-level unconditional refusal via the dispatch
    # marker emitted by cmd_execute() itself.
    import subprocess
    g2_entries_before = sorted(p.name for p in G2_OUT.iterdir()) if G2_OUT.exists() else []
    auth_before = REPAIRED_AUTH_FILE.exists()
    proc = subprocess.run([sys.executable, str(Path(__file__).resolve()),
                           "--mode", "execute"],
                          capture_output=True, text=True, cwd=str(ROOT), timeout=180)
    out = (proc.stdout or "") + (proc.stderr or "")
    dispatch_marker = "G2_EXECUTE_DISPATCH_REACHED_CMD_EXECUTE" in out
    gate1_refusal = "STOP_NOT_AUTHORIZED" in out and "repaired-execution authorization" in out
    zero_proof = "ZERO_COMPUTE_PROOF fitted_param_loads=0 scientific_metric_calls=0" in out
    no_main_refusal = ("unconditional" not in out)
    g2_entries_after = sorted(p.name for p in G2_OUT.iterdir()) if G2_OUT.exists() else []
    auth_after = REPAIRED_AUTH_FILE.exists()
    zs_absent = not (G2_OUT / "43S_V3_G2_DETERMINISTIC_STABILITY_EVIDENCE.json").exists()
    rec("T18_execute_dispatch_reaches_internal_gate",
        (proc.returncode == 2 and dispatch_marker and gate1_refusal and zero_proof
         and g2_entries_before == g2_entries_after == []
         and not auth_before and not auth_after and zs_absent),
        {"returncode": proc.returncode, "dispatch_marker": dispatch_marker,
         "gate1_refusal": gate1_refusal, "zero_proof": zero_proof,
         "g2_entries_before": g2_entries_before, "g2_entries_after": g2_entries_after,
         "auth_artifact_before": auth_before, "auth_artifact_after": auth_after,
         "43S_absent": zs_absent,
         "note": "refusal emitted by cmd_execute() Gate 1 (dispatch marker present); "
                 "main() has no unconditional refusal"})

    # ---- T19: default invocation is safe ----
    proc_def = subprocess.run([sys.executable, str(Path(__file__).resolve())],
                              capture_output=True, text=True, cwd=str(ROOT), timeout=180)
    def_out = (proc_def.stdout or "") + (proc_def.stderr or "")
    def_safe = ("NOTHING scientific" in def_out)
    g2_entries_after_def = sorted(p.name for p in G2_OUT.iterdir()) if G2_OUT.exists() else []
    auth_after_def = REPAIRED_AUTH_FILE.exists()
    rec("T19_default_invocation_safe",
        (proc_def.returncode == 0 and def_safe
         and g2_entries_after_def == [] and not auth_after_def
         and not (G2_OUT / "43S_V3_G2_DETERMINISTIC_STABILITY_EVIDENCE.json").exists()),
        {"returncode": proc_def.returncode, "safe_message": def_safe,
         "g2_entries_after": g2_entries_after_def, "auth_artifact_after": auth_after_def,
         "43S_absent": not (G2_OUT / "43S_V3_G2_DETERMINISTIC_STABILITY_EVIDENCE.json").exists()})

    # ---- T20: Metric3 sin_F vector-L2 norm (Repair C exact expression) ----
    # Verifies the frozen implementation float(np.linalg.norm(np.sin(theta),
    # ord=2)) against the explicit mathematical reference sqrt(sum sin^2), and
    # that the EXECUTABLE sin_F implementation uses ord=2 (not ord="fro"). The
    # buggy form is allowed only as documentation (backtick-wrapped) in the
    # Repair-C docstring, so we inspect the actual "sin_F": ... implementation
    # token rather than scanning for a literal string.
    theta = np.array([0.15, 0.30, 0.45, 0.60], dtype=np.float64)
    observed = float(np.linalg.norm(np.sin(theta), ord=2))
    expected = float(np.sqrt(np.sum(np.sin(theta) ** 2)))
    src_t20 = Path(__file__).read_text(encoding="utf-8")
    _m = re.search(r'"sin_F":\s*float\(np\.linalg\.norm\(np\.sin\(theta\),\s*ord=([^)]+)\)\)',
                   src_t20)
    _sinF_ord = _m.group(1).strip() if _m else None
    correct_sinF_impl = (_sinF_ord is not None and _sinF_ord == "2")
    ok20 = (theta.shape == (4,) and np.isfinite(observed) and observed >= 0.0
            and abs(observed - expected) < ABS_TOL and correct_sinF_impl)
    rec("T20_metric3_sinF_vector_norm", ok20,
        {"theta_shape": list(theta.shape), "observed": observed, "expected": expected,
         "agreement": abs(observed - expected), "finite": bool(np.isfinite(observed)),
         "nonnegative": bool(observed >= 0), "sin_F_ord": _sinF_ord,
         "correct_sinF_impl": correct_sinF_impl})

    # ---- T21: full Metric3 row-aggregation synthetic path ----
    # Walks the COMPLETE synthetic Metric3 row: reduced QR -> SVD -> theta ->
    # theta_sum -> theta_max -> repaired sin_F. Prevents the historical gap
    # where primitive tests passed but the real row-building expression was
    # never executed. No fitted parameters loaded.
    Fi = _toy_family(120, 23)
    Fj = _toy_family(120, 29)
    Qi, _ = np.linalg.qr(Fi)
    Qj, _ = np.linalg.qr(Fj)
    C21 = Qi.T @ Qj
    svals21 = np.linalg.svd(C21, compute_uv=False)
    theta21 = np.arccos(np.clip(svals21, -1.0, 1.0))
    theta_sum = float(np.sum(theta21))
    theta_max = float(np.max(theta21))
    sin_F = float(np.linalg.norm(np.sin(theta21), ord=2))
    ref_sin = float(np.sqrt(np.sum(np.sin(theta21) ** 2)))
    ok21 = (theta21.shape == (4,) and np.isfinite(sin_F) and abs(sin_F - ref_sin) < ABS_TOL)
    rec("T21_metric3_full_row_aggregation_path", ok21,
        {"theta_shape": list(theta21.shape), "theta_sum": theta_sum,
         "theta_max": theta_max, "sin_F": sin_F, "ref_sin": ref_sin,
         "finite": bool(np.isfinite(sin_F)),
         "row_construction_ok": True, "fitted_param_loads": 0})

    # ---- T22: consumed OLD authorization is NOT sufficient for scripts90 ----
    # Runs scripts90 --execute; the OLD consumed scripts89 authorization EXISTS
    # on disk (G2_REAL_EXECUTION_AUTHORIZED=true) but scripts90 MUST refuse it.
    # Does NOT create any repaired authorization.
    proc22 = subprocess.run([sys.executable, str(Path(__file__).resolve()),
                             "--mode", "execute"],
                            capture_output=True, text=True, cwd=str(ROOT), timeout=180)
    out22 = (proc22.stdout or "") + (proc22.stderr or "")
    refused22 = proc22.returncode == 2
    old_not_honored = ("HISTORICAL_CONSUMED" in out22
                       or "repaired-execution authorization" in out22)
    new_auth_absent22 = not REPAIRED_AUTH_FILE.exists()
    rec("T22_consumed_old_authorization_not_sufficient",
        refused22 and old_not_honored and new_auth_absent22,
        {"returncode": proc22.returncode, "old_auth_not_honored": old_not_honored,
         "new_auth_absent": new_auth_absent22,
         "note": "scripts90 Gate 1 ignores the old scripts89 authorization even if it "
                 "contains G2_REAL_EXECUTION_AUTHORIZED=true"})

    # ---- T23: preflight-after-new-authorization is forbidden (isolated) ----
    # Uses an isolated temp copy of scripts90 with REPAIRED_AUTH_FILE redirected
    # to a temp authorization file. Does NOT create any authorization in the
    # real authorization directory. Proves that once repaired-auth condition is
    # true, --preflight immediately refuses (exit 4) without fitted computation.
    import tempfile as _tempfile  # noqa: E402
    import os as _os  # noqa: E402
    _td = _tempfile.mkdtemp(prefix="s90_t23_")
    _tmp_auth = Path(_td) / "V3_G2_POST_FAILURE_REPAIRED_EXECUTION_AUTHORIZATION.json"
    _tmp_auth.write_text(json.dumps({"V3_G2_REPAIRED_EXECUTION_AUTHORIZED": True}),
                         encoding="utf-8")
    _src90 = Path(__file__).read_text(encoding="utf-8")
    # Line-based replacement: redirect ONLY the REPAIRED_AUTH_FILE definition
    # line. A whole-source str.replace would also clobber the search literal
    # embedded inside this very test (T23), which breaks the temp module's
    # syntax. We match the exact stripped definition line (no surrounding quotes)
    # so the quoted literal in T23's code is left untouched.
    _DEF_LINE = 'REPAIRED_AUTH_FILE = AUTH_DIR / "V3_G2_POST_FAILURE_REPAIRED_EXECUTION_AUTHORIZATION.json"'
    _patched_lines = []
    for _line in _src90.split("\n"):
        if _line.strip() == _DEF_LINE:
            _patched_lines.append(f'REPAIRED_AUTH_FILE = Path({str(_tmp_auth)!r})')
        else:
            _patched_lines.append(_line)
    _patched = "\n".join(_patched_lines)
    _tmp_mod = Path(_td) / "tmp_s90.py"
    _tmp_mod.write_text(_patched, encoding="utf-8")
    proc23 = subprocess.run([sys.executable, str(_tmp_mod), "--mode", "preflight"],
                            capture_output=True, text=True, cwd=str(ROOT), timeout=180)
    out23 = (proc23.stdout or "") + (proc23.stderr or "")
    refused23 = proc23.returncode == 4
    msg23 = "STOP_PREFLIGHT_AFTER_REPAIRED_AUTHORIZATION" in out23
    no_fitted23 = ("fitted_param_loads" not in out23) or ("fitted_param_loads=0" in out23)
    try:
        _tmp_mod.unlink(); _tmp_auth.unlink(); _os.rmdir(_td)
    except OSError:
        pass
    rec("T23_preflight_after_new_authorization_forbidden",
        refused23 and msg23 and no_fitted23,
        {"returncode": proc23.returncode, "refusal_message": msg23,
         "isolated_temp": True, "no_real_auth_created": True})

    return results


def verify_frozen_chain() -> dict:
    results = {}
    ok = True
    for name, (rel, expected) in FROZEN_CHAIN.items():
        p = ROOT / rel
        if not p.exists():
            results[name] = {"ok": False, "live": None, "expected": expected}
            ok = False
            continue
        live = sha256(p)
        good = (live == expected) if len(expected) == 64 else (live.startswith(expected))
        ok = ok and good
        results[name] = {"ok": good, "live": live, "expected": expected}
    return {"ok": ok, "results": results}


def run_zero_compute_preflight() -> dict:
    """Metadata-only preflight. NO fitted-value arithmetic, NO scientific metrics.

    Reads: file existence, identity names, RUN_STARTED / terminal metadata,
    manifests, parameter-file hashes, declared shapes, persistence PASS,
    final-on-disk PASS, protected source SHA.
    """
    checks = {}
    rec = lambda n, ok, d: checks.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731

    # Z1: 9 evaluable run dirs exist
    dirs_ok = all((RUNS_DIR / i).is_dir() for i in EVALUABLE)
    rec("Z1_evaluable_dirs_exist", dirs_ok, {"n": len(EVALUABLE), "ids": EVALUABLE})

    # Z2: each has RUN_STARTED
    rec("Z2_run_started_present",
        all((RUNS_DIR / i / "RUN_STARTED").exists() for i in EVALUABLE),
        {"n": len(EVALUABLE)})

    # Z3: each has result.json
    rec("Z3_result_json_present",
        all((RUNS_DIR / i / "result.json").exists() for i in EVALUABLE),
        {"n": len(EVALUABLE)})

    # Z4: each has npz + manifest
    rec("Z4_npz_manifest_present",
        all((RUNS_DIR / i / "final_svi_params.npz").exists()
            and (RUNS_DIR / i / "final_svi_params_manifest.json").exists()
            for i in EVALUABLE),
        {"n": len(EVALUABLE)})

    # Z5: manifest declares the 6 V3 params with exact shapes (JSON only)
    man_ok = True
    man_problems = []
    for ident in EVALUABLE:
        mp = RUNS_DIR / ident / "final_svi_params_manifest.json"
        try:
            man = json.loads(mp.read_text(encoding="utf-8"))
            params = man.get("parameters", {})
            if set(params.keys()) != set(PARAM_KEYS):
                man_ok = False
                man_problems.append(f"{ident}: keys mismatch")
                continue
            for k in PARAM_KEYS:
                if list(params[k]["shape"]) != list(PARAM_SHAPES[k]):
                    man_ok = False
                    man_problems.append(f"{ident}: {k} shape {params[k]['shape']} != {PARAM_SHAPES[k]}")
        except Exception as exc:  # noqa: BLE001
            man_ok = False
            man_problems.append(f"{ident}: {exc!r}")
    rec("Z5_manifest_shapes_exact", man_ok, {"problems": man_problems or "all OK"})

    # Z6: parameter file hashes match manifest npz_sha256 (file hash only)
    hash_ok = True
    hash_problems = []
    for ident in EVALUABLE:
        npz = RUNS_DIR / ident / "final_svi_params.npz"
        mp = RUNS_DIR / ident / "final_svi_params_manifest.json"
        try:
            man = json.loads(mp.read_text(encoding="utf-8"))
            if sha256(npz) != man.get("npz_sha256"):
                hash_ok = False
                hash_problems.append(f"{ident}: npz hash mismatch")
        except Exception as exc:  # noqa: BLE001
            hash_ok = False
            hash_problems.append(f"{ident}: {exc!r}")
    rec("Z6_npz_hashes_match_manifest", hash_ok, {"problems": hash_problems or "all OK"})

    # Z7: persistence validation PASS (roundtrip_pass == true)
    pers_ok = True
    pers_problems = []
    for ident in EVALUABLE:
        pp = RUNS_DIR / ident / "PARAMETER_PERSISTENCE_VALIDATION.json"
        try:
            d = json.loads(pp.read_text(encoding="utf-8"))
            if d.get("roundtrip_pass") is not True:
                pers_ok = False
                pers_problems.append(f"{ident}: roundtrip_pass != true")
            if list(d.get("PERSISTED_RAW_RHO_SHAPE", [])) != [1]:
                pers_ok = False
                pers_problems.append(f"{ident}: PERSISTED_RAW_RHO_SHAPE != [1]")
        except Exception as exc:  # noqa: BLE001
            pers_ok = False
            pers_problems.append(f"{ident}: {exc!r}")
    rec("Z7_persistence_validation_pass", pers_ok, {"problems": pers_problems or "all OK"})

    # Z8: final-on-disk validation PASS
    fod_ok = True
    fod_problems = []
    for ident in EVALUABLE:
        fp = RUNS_DIR / ident / "FINAL_ON_DISK_VALIDATION.json"
        try:
            d = json.loads(fp.read_text(encoding="utf-8"))
            if d.get("PASS") is not True:
                fod_ok = False
                fod_problems.append(f"{ident}: PASS != true")
        except Exception as exc:  # noqa: BLE001
            fod_ok = False
            fod_problems.append(f"{ident}: {exc!r}")
    rec("Z8_final_on_disk_validation_pass", fod_ok, {"problems": fod_problems or "all OK"})

    # Z9: P1 seed4004 engineering loss - RUN_STARTED only, not evaluable, not deleted
    el = RUNS_DIR / "V3_V3_ARM_P1_p1_seed4004_t12"
    el_ok = (el.is_dir()
             and (el / "RUN_STARTED").exists()
             and not (el / "result.json").exists()
             and not (el / "final_svi_params.npz").exists()
             and "V3_V3_ARM_P1_p1_seed4004_t12" not in EVALUABLE)
    rec("Z9_engineering_loss_seed4004", el_ok,
        {"run_started": (el / "RUN_STARTED").exists() if el.is_dir() else False,
         "no_result": not (el / "result.json").exists() if el.is_dir() else None,
         "no_npz": not (el / "final_svi_params.npz").exists() if el.is_dir() else None,
         "in_evaluable": "V3_V3_ARM_P1_p1_seed4004_t12" in EVALUABLE})

    # Z10: protected source SHA chain exact
    chain = verify_frozen_chain()
    rec("Z10_protected_sha_chain", chain["ok"],
        {"mismatches": [k for k, v in chain["results"].items() if not v["ok"]]})

    # Z11: pair counts exact (static constants)
    rec("Z11_pair_counts",
        len(within_arm_pairs(P1_IDS)) == 6 and len(within_arm_pairs(P4_IDS)) == 10,
        {"P1": len(within_arm_pairs(P1_IDS)), "P4": len(within_arm_pairs(P4_IDS))})

    # Z12: g2 output namespace clean (no scientific evidence yet)
    rec("Z12_g2_namespace_clean",
        (not G2_OUT.exists()) or (not any(G2_OUT.iterdir())),
        {"g2_dir_exists": G2_OUT.exists(),
         "existing": sorted(p.name for p in G2_OUT.iterdir()) if G2_OUT.exists() else []})

    # Z13: no forbidden inference patterns in this source
    src = Path(__file__).read_text(encoding="utf-8")
    pat_svi = "SVI" + "("
    pat_trace_elbo = "Trace" + "_ELBO"
    pat_optim = "optimizer" + "("
    pat_sample = "numpyro." + "sample("
    pat_importance = "importance" + "("
    pat_nuts = "NUT" + "S("
    pat_hmc = "HM" + "C("
    pat_mcmc = "MCM" + "C("
    pat_pca = "PCA" + "("
    hits = [p for p in (pat_svi, pat_trace_elbo, pat_optim, pat_sample, pat_importance,
                        pat_nuts, pat_hmc, pat_mcmc, pat_pca) if p in src]
    rec("Z13_no_forbidden_inference", not hits, {"hits": hits})

    # Z14: no quantitative G2 threshold in source (tokens assembled
    #      dynamically so the scan cannot self-match)
    t_hits = [p for p in ("G2_" + "PASS_THRESHOLD", "G2_" + "FAIL_THRESHOLD",
                          "st" + "able", "unst" + "able", "win" + "ner") if p in src]
    rec("Z14_no_g2_threshold", not t_hits, {"hits": t_hits})

    # Z15: no real fitted-value arithmetic in preflight path (slice-based scan:
    #      between 'def run_zero_compute_preflight' and 'def cmd_preflight',
    #      no calls to load_params / compute_all / metric primitives on real ids)
    pf_src = src.split("def run_zero_compute_preflight", 1)[1].split("def cmd_preflight", 1)[0]
    forbidden_calls = ["load_params(", "compute_all(", "build_sigma_components(",
                       "build_sigma_dense(", "metric1_pairwise_l2(", "metric2_cv_row(",
                       "principal_angles_family(", "projection_matrix_family(",
                       "procrustes_raw_family(", "block_allocations("]
    z15_hits = [c for c in forbidden_calls if c in pf_src]
    rec("Z15_no_fitted_arithmetic_in_preflight", not z15_hits,
        {"hits": z15_hits, "note": "preflight reads metadata only; no arithmetic on fitted values"})

    return checks


def cmd_preflight() -> int:
    # Preflight-after-authorization safety (Section H): once the DISTINCT
    # repaired-execution authorization exists, --preflight must REFUSE so the
    # preflight's negative execute tests cannot accidentally enter the real
    # scientific execution path. Preflight must run BEFORE the new authorization
    # is created. This returns immediately without running synthetic tests or
    # any fitted computation.
    if REPAIRED_AUTH_FILE.exists():
        print("STOP_PREFLIGHT_AFTER_REPAIRED_AUTHORIZATION: a post-failure repaired "
              "execution authorization already exists; --preflight is forbidden after "
              "authorization to protect the real scientific path. Preflight must run "
              "BEFORE the new authorization is created.")
        return 4
    t0 = time.time()
    syn = run_synthetic_tests()
    zc = run_zero_compute_preflight()
    chain = verify_frozen_chain()

    syn_ok = all(v["ok"] for v in syn.values())
    zc_ok = all(v["ok"] for v in zc.values())
    chain_ok = chain["ok"]
    ok = syn_ok and zc_ok and chain_ok
    classification = ("V3_G2_EXECUTOR_PREFLIGHT_PASS" if ok
                      else "V3_G2_EXECUTOR_PREFLIGHT_FAIL")

    payload = {
        "artifact_id": "V3_G2_EXECUTOR_PREFLIGHT_V3",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v_v3",
        # Executor identity bound into the V3 preflight. scripts90 self-hash
        # cannot be embedded literally (self-referential hash), so it is recorded
        # here as metadata rather than included in the self-verifying chain.
        "executor": str(Path(__file__).resolve().name),
        "executor_sha256": sha256(Path(__file__).resolve()),
        "mode": ("V3 G2 DETERMINISTIC EXECUTOR PREFLIGHT V3 (scripts90, post-failure repaired) "
                 "- synthetic T1..T23 + ZERO-SCIENTIFIC-COMPUTATION metadata checks; "
                 "NO G2 metrics computed from real fitted parameters"),
        "classification": classification,
        "synthetic_tests": {k: v["ok"] for k, v in syn.items()},
        "synthetic_test_details": syn,
        "zero_compute_checks": {k: v["ok"] for k, v in zc.items()},
        "zero_compute_details": zc,
        "sha_chain": chain["results"],
        "flags": {
            "REAL_G2_EXECUTION": False,
            "REAL_EXECUTION_FORBIDDEN_DURING_43R": True,
            "G2_EXECUTED": False,
            "G2_POSTERIOR_DRAWS_USED": False,
            "G2_NEW_INFERENCE_USED": False,
            "SVI_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "NUTS_HMC_MCMC_USED": False,
            "G3_AUTHORIZED": False,
        },
        "final_state": classification,
        "elapsed_seconds": round(time.time() - t0, 3),
    }
    out_path = PREFLIGHT_OUT / "V3_G2_EXECUTOR_PREFLIGHT_V3.json"
    atomic_write_json(out_path, payload)
    md = ["# V3 G2 Executor Preflight V3 (scripts90, post-failure repaired)", "",
          f"Generated: {utc_now()}", "",
          f"**Classification: {classification}**", "",
          "## Synthetic tests (fabricated arrays only)", "", "| Test | Result |", "|---|---|"]
    for k, v in syn.items():
        md.append(f"| {k} | {'PASS' if v['ok'] else 'FAIL'} |")
    md += ["", "## Zero-compute metadata checks", "", "| Check | Result |", "|---|---|"]
    for k, v in zc.items():
        md.append(f"| {k} | {'PASS' if v['ok'] else 'FAIL'} |")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in chain["results"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", f"## Final state: **{classification}**",
           "",
           "REAL repaired G2 EXECUTION REMAINS FORBIDDEN until a DISTINCT repaired-execution "
           "authorization (V3_G2_POST_FAILURE_REPAIRED_EXECUTION_AUTHORIZATION.json) is "
           "created after this preflight. Preflight is forbidden once that authorization exists."]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")

    print("classification:", classification)
    n_syn = sum(1 for v in syn.values() if v["ok"])
    print(f"synthetic tests passed {n_syn}/{len(syn)}")
    failed = [k for k, v in syn.items() if not v["ok"]]
    if failed:
        print("failed synthetic tests:", failed)
    print("OVERALL:", "PASS" if ok else "FAIL")
    return 0 if ok else 2


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V3 G2 deterministic stability executor (frozen protocol)")
    ap.add_argument("--mode", choices=["preflight", "execute"],
                    help="preflight: synthetic+metadata validation ONLY; execute: real G2 (FORBIDDEN during 43R)")
    ap.add_argument("--preflight", action="store_true", help="alias for --mode preflight")
    ap.add_argument("--execute", action="store_true", help="alias for --mode execute (refused during 43R)")
    args = ap.parse_args(argv)

    mode = args.mode
    if mode is None:
        if args.preflight:
            mode = "preflight"
        elif args.execute:
            mode = "execute"
        else:
            print("V3 G2 deterministic executor (frozen 43N/43O/43P/43Q protocol).")
            print("Default invocation runs NOTHING scientific.")
            print("Use --mode preflight (or --preflight) for synthetic + metadata validation.")
            print("Use --mode execute (or --execute) ONLY after explicit human authorization;")
            print("REAL G2 EXECUTION IS FORBIDDEN DURING 43R.")
            return 0

    if mode == "preflight":
        return cmd_preflight()

    if mode == "execute":
        # Repair A: real dispatch to cmd_execute(). Refusal (if any) happens
        # INSIDE cmd_execute() Gate 1 (missing human authorization artifact),
        # NOT via a hard-coded refusal in main().
        return cmd_execute()

    return 2  # unreachable


if __name__ == "__main__":
    sys.exit(main())
