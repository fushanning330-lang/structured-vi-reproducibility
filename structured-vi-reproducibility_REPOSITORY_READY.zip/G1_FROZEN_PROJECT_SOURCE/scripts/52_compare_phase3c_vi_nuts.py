from __future__ import annotations

import os

os.environ.setdefault("JAX_ENABLE_X64", "1")

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import jax.numpy as jnp
import numpy as np
import pandas as pd
import yaml
from jax import random
from scipy.stats import spearmanr

from dhbcp_pv.inference.phase3c_stabilized import GLOBAL_DIAGNOSTIC_SITES, assert_x64_reference_mode
from dhbcp_pv.inference.posterior_integration import integrate_posterior_outputs
from dhbcp_pv.inference.structured_svi import sample_structured_posterior
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_a_replicate


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, allow_nan=False, sort_keys=True) + "\n")
    os.replace(temporary, path)


def reference_data(root: Path, cutoff: int):
    seeds = pd.read_csv(root / "config/phase3b_tiera_seeds_v1.csv")
    seed = int(seeds.loc[seeds.replicate_id == 1, "seed"].iloc[0])
    replicate = generate_tier_a_replicate(seed, n_quarters=40)
    mask = (replicate.drug_index < 10) & (replicate.event_index < 5)
    return seed, (
        jnp.asarray(replicate.y[mask, :cutoff]),
        jnp.asarray(replicate.serious[mask, :cutoff]),
        jnp.asarray(replicate.expected[mask, :cutoff], dtype=jnp.float64),
        jnp.asarray(replicate.drug_index[mask]),
        jnp.asarray(replicate.event_index[mask]),
        10,
        5,
    )


def flatten_and_subset(samples: dict[str, np.ndarray], draws: int = 64) -> dict[str, jnp.ndarray]:
    flattened = {
        name: value.reshape((-1,) + value.shape[2:])
        for name, value in samples.items()
    }
    count = next(iter(flattened.values())).shape[0]
    indices = np.linspace(0, count - 1, draws, dtype=int)
    return {name: jnp.asarray(value[indices]) for name, value in flattened.items()}


def metric_gate(metric: str, value: float, thresholds: dict[str, float]) -> bool:
    if metric.endswith("spearman") or metric.endswith("jaccard"):
        return value >= thresholds[f"{metric}_min"]
    return value <= thresholds[f"{metric}_max"]


def aggregate(root: Path) -> None:
    result = root / "results/phase3c"
    gates = yaml.safe_load((root / "config/phase3c_acceptance_gates_v1.yaml").read_text())["vi_vs_nuts"]
    rows = []
    for cutoff in gates["evaluate_at_cutoffs"]:
        checkpoint = result / f"checkpoints/vi_vs_nuts/t{cutoff:02d}.json"
        if not checkpoint.exists():
            return
        payload = json.loads(checkpoint.read_text())
        for metric, value in payload["metrics"].items():
            key = f"{metric}_min" if metric.endswith(("spearman", "jaccard")) else f"{metric}_max"
            rows.append({
                "cutoff": cutoff,
                "accepted_nuts_rung": payload["accepted_nuts_rung"],
                "metric": metric,
                "value": value,
                "threshold": gates["metrics"][key],
                "direction": "min" if key.endswith("_min") else "max",
                "passed": payload["pass_flags"][metric],
                "marginal_fail_within_10pct": payload["marginal_fail_within_10pct"].get(metric, False),
            })
    output = result / "89_PHASE3C_VI_VS_NUTS.csv"
    temporary = output.with_suffix(output.suffix + ".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rung", choices=("N1", "N2", "N3_NEUTRA"), required=True)
    parser.add_argument("--cutoff", choices=(12, 24, 40), type=int, required=True)
    parsed = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    result = root / "results/phase3c"
    assert_x64_reference_mode()
    nuts_metadata_path = result / f"checkpoints/nuts/{parsed.rung}_t{parsed.cutoff:02d}.json"
    chain_path = result / f"checkpoints/nuts/{parsed.rung}_t{parsed.cutoff:02d}_chains.npz"
    nuts_metadata = json.loads(nuts_metadata_path.read_text())
    if not nuts_metadata["minimum_reference_pass"]:
        raise SystemExit("VI comparison is forbidden for a failed NUTS chain")

    seed, args = reference_data(root, parsed.cutoff)
    loaded = np.load(chain_path)
    chain_samples = {
        name: loaded[name]
        for name in loaded.files
        if not name.startswith("_extra_")
    }
    nuts_subset = flatten_and_subset(chain_samples, 64)
    params_loaded = np.load(result / f"checkpoints/nuts_init/structured_svi_t{parsed.cutoff:02d}.npz")
    params = {name: jnp.asarray(params_loaded[name]) for name in params_loaded.files}
    vi_samples = sample_structured_posterior(
        random.PRNGKey(seed + 8000 + parsed.cutoff),
        params,
        *args,
        num_samples=64,
        hmax=12,
    )
    nuts_integrated = integrate_posterior_outputs(
        nuts_subset,
        args[0],
        args[1],
        args[3],
        args[4],
        10,
        5,
        hmax=12,
    )
    vi_integrated = integrate_posterior_outputs(
        vi_samples,
        args[0],
        args[1],
        args[3],
        args[4],
        10,
        5,
        hmax=12,
    )

    standardized = []
    flattened_nuts = {
        name: value.reshape((-1,) + value.shape[2:]) for name, value in chain_samples.items()
    }
    for site in GLOBAL_DIAGNOSTIC_SITES:
        nuts = np.asarray(flattened_nuts[site]).reshape(flattened_nuts[site].shape[0], -1)
        vi = np.asarray(vi_samples[site]).reshape(64, -1)
        standardized.extend(
            np.abs(vi.mean(axis=0) - nuts.mean(axis=0))
            / np.maximum(nuts.std(axis=0, ddof=1), 1e-12)
        )
    nuts_delta = nuts_integrated.delta_expected_loss[:, -1]
    vi_delta = vi_integrated.delta_expected_loss[:, -1]
    top_nuts = set(np.argsort(-nuts_delta)[:10].tolist())
    top_vi = set(np.argsort(-vi_delta)[:10].tolist())
    metrics = {
        "terminal_x_mean_rmse": float(np.sqrt(np.mean(
            (vi_integrated.x_mean[:, -1] - nuts_integrated.x_mean[:, -1]) ** 2
        ))),
        "terminal_x_sd_mae": float(np.mean(np.abs(
            vi_integrated.x_sd[:, -1] - nuts_integrated.x_sd[:, -1]
        ))),
        "global_parameter_standardized_mean_error_median": float(np.median(standardized)),
        "global_parameter_standardized_mean_error_p90": float(np.quantile(standardized, 0.9)),
        "filtered_state_probability_l1": float(np.mean(np.abs(
            vi_integrated.state_probability - nuts_integrated.state_probability
        ))),
        "change_probability_mae": float(np.mean(np.abs(
            vi_integrated.p_change - nuts_integrated.p_change
        ))),
        "persistence_probability_mae": float(np.mean(np.abs(
            vi_integrated.p_persist_h2 - nuts_integrated.p_persist_h2
        ))),
        "seriousness_probability_mae": float(np.mean(np.abs(
            vi_integrated.p_serious - nuts_integrated.p_serious
        ))),
        "Delta_spearman": float(spearmanr(nuts_delta, vi_delta).statistic),
        "Delta_top10_jaccard": len(top_nuts & top_vi) / len(top_nuts | top_vi),
    }
    thresholds = yaml.safe_load((root / "config/phase3c_acceptance_gates_v1.yaml").read_text())["vi_vs_nuts"]["metrics"]
    normalized_metrics = {
        "terminal_x_mean_rmse": "terminal_x_mean_rmse",
        "terminal_x_sd_mae": "terminal_x_sd_mae",
        "global_parameter_standardized_mean_error_median": "global_parameter_standardized_mean_error_median",
        "global_parameter_standardized_mean_error_p90": "global_parameter_standardized_mean_error_p90",
        "filtered_state_probability_l1": "filtered_state_probability_l1",
        "change_probability_mae": "change_probability_mae",
        "persistence_probability_mae": "persistence_probability_mae",
        "seriousness_probability_mae": "seriousness_probability_mae",
        "Delta_spearman": "Delta_spearman",
        "Delta_top10_jaccard": "Delta_top10_jaccard",
    }
    flags = {}
    marginal = {}
    ranking = {"Delta_spearman", "Delta_top10_jaccard"}
    for metric, threshold_name in normalized_metrics.items():
        if metric in ranking:
            threshold = float(thresholds[f"{threshold_name}_min"])
            flags[metric] = metrics[metric] >= threshold
            marginal[metric] = False
        else:
            threshold = float(thresholds[f"{threshold_name}_max"])
            flags[metric] = metrics[metric] <= threshold
            marginal[metric] = (not flags[metric]) and metrics[metric] <= threshold * 1.10
    payload = {
        "version": "phase3c_vi_vs_nuts_checkpoint_v1",
        "cutoff": parsed.cutoff,
        "accepted_nuts_rung": parsed.rung,
        "nuts_diagnostic_pass_verified": True,
        "posterior_draws": 64,
        "metrics": metrics,
        "pass_flags": flags,
        "marginal_fail_within_10pct": marginal,
        "truth_fields_accessed": False,
    }
    output = result / f"checkpoints/vi_vs_nuts/t{parsed.cutoff:02d}.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    atomic_json(output, payload)
    aggregate(root)
    print(json.dumps(payload), flush=True)


if __name__ == "__main__":
    main()
