from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path

import duckdb


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    database = root / "data/interim/phase2_etl.duckdb"
    connection = duckdb.connect(str(database), read_only=True)
    connection.execute("SET threads=1")
    connection.execute("SET preserve_insertion_order=false")
    artifacts = {
        root / "data/interim/faers_incident_cases.parquet": """SELECT i.*, s.serious, s.distinct_outcome_codes
            FROM incident_selected i JOIN case_serious s
            USING (quarter, quarter_index, split, primaryid, caseid)
            ORDER BY quarter_index, caseid""",
        root / "data/interim/faers_incident_case_exceptions.parquet":
            "SELECT * FROM incident_exceptions ORDER BY coalesce(initial_quarter_index, -999), caseid",
        root / "data/interim/faers_case_drugs.parquet":
            "SELECT * FROM case_drugs ORDER BY quarter_index, caseid, drug_entity",
        root / "data/interim/faers_case_events.parquet":
            "SELECT * FROM case_events ORDER BY quarter_index, caseid, event_pt",
        root / "data/interim/faers_case_outcomes.parquet":
            "SELECT * FROM case_outcomes ORDER BY quarter_index, caseid, outc_cod",
        root / "data/processed/drug_mapping_dev_v1.parquet":
            "SELECT * FROM drug_mapping_dev ORDER BY drugname_norm",
        root / "data/processed/faers_quarter_marginals.parquet":
            "SELECT * FROM quarter_marginals ORDER BY role_scope, quarter_index, margin_type, entity",
        root / "data/processed/faers_pair_quarter_sparse.parquet":
            "SELECT * FROM pair_panel_ps_ss ORDER BY drug_entity, event_pt, quarter_index",
        root / "data/processed/faers_pair_quarter_ps_only_sparse.parquet":
            "SELECT * FROM pair_panel_ps_only ORDER BY drug_entity, event_pt, quarter_index",
    }
    comparisons = []
    with tempfile.TemporaryDirectory(prefix="dhbcp_phase2_repro_") as temporary:
        temporary_path = Path(temporary)
        for index, (original, query) in enumerate(artifacts.items(), 1):
            canonical = original.with_suffix(original.suffix + ".canonical_tmp")
            if canonical.exists():
                canonical.unlink()
            canonical_escaped = str(canonical).replace("'", "''")
            connection.execute(
                f"COPY ({query}) TO '{canonical_escaped}' (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 100000)"
            )
            os.replace(canonical, original)
            duplicate = temporary_path / original.name
            escaped = str(duplicate).replace("'", "''")
            connection.execute(
                f"COPY ({query}) TO '{escaped}' (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 100000)"
            )
            original_hash = sha256(original)
            duplicate_hash = sha256(duplicate)
            comparisons.append(
                {
                    "artifact": original.name,
                    "original_sha256": original_hash,
                    "second_export_sha256": duplicate_hash,
                    "match": original_hash == duplicate_hash,
                }
            )
            print(f"[phase2-repro] {index}/{len(artifacts)} {original.name} {original_hash == duplicate_hash}", flush=True)
    connection.close()
    report = {
        "status": "PASS" if all(item["match"] for item in comparisons) else "FAIL",
        "method": "Second deterministic Parquet export from the same persisted raw-derived DuckDB relations, unchanged Phase 2 config and environment",
        "config_sha256": sha256(root / "config/phase2_etl_v1.yaml"),
        "environment_sha256": "4a8d2985b1b3696b1de40911609de94fa9e2f88998f6e2bdb708e978cef23b6e",
        "artifacts": comparisons,
    }
    output = root / "results/phase2/phase2_reproducibility_check.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    no_leakage_path = root / "results/phase2/34_PHASE2_NO_LEAKAGE_TESTS.json"
    no_leakage = json.loads(no_leakage_path.read_text(encoding="utf-8"))
    no_leakage["checks"]["deterministic_second_export_all_artifacts"] = report["status"] == "PASS"
    no_leakage["passed"] = all(no_leakage["checks"].values())
    no_leakage_path.write_text(json.dumps(no_leakage, indent=2) + "\n", encoding="utf-8")

    manifest_path = root / "data/manifests/phase2_processed_artifacts.csv"
    with manifest_path.open(newline="", encoding="utf-8-sig") as handle:
        manifest_rows = list(csv.DictReader(handle))
    by_name = {path.name: path for path in artifacts}
    for row in manifest_rows:
        path = by_name[row["artifact"]]
        row["bytes"] = str(path.stat().st_size)
        row["sha256"] = sha256(path)
    with manifest_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(manifest_rows[0]))
        writer.writeheader()
        writer.writerows(manifest_rows)
    shutil.copy2(manifest_path, root / "results/phase2/35_PHASE2_PROCESSED_ARTIFACT_MANIFEST.csv")
    print(json.dumps({"status": report["status"], "artifacts": len(comparisons)}, indent=2))
    if report["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
