from __future__ import annotations
import hashlib, json, platform, subprocess, sys
from pathlib import Path
from importlib.metadata import distributions

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "environment"

packages = sorted(
    (d.metadata["Name"] or "", d.version)
    for d in distributions()
    if d.metadata["Name"]
)
payload = {
    "python": sys.version,
    "executable": sys.executable,
    "platform": platform.platform(),
    "machine": platform.machine(),
    "packages": packages,
}
canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode()
payload["environment_sha256"] = hashlib.sha256(canonical).hexdigest()
(OUT / "installed_environment.json").write_text(
    json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
)
subprocess.run([sys.executable, "-m", "pip", "freeze"], check=True,
               stdout=(OUT / "pip_freeze.txt").open("w", encoding="utf-8"))
print(payload["environment_sha256"])
