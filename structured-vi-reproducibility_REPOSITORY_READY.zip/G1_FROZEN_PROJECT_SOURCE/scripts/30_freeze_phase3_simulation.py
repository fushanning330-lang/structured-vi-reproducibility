from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from dhbcp_pv.baselines.registry import baseline_registry_rows


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def code_tree_hash(root: Path) -> tuple[str, list[dict[str, object]]]:
    selected: list[Path] = []
    for directory in ("src", "scripts", "tests"):
        selected.extend(
            path for path in (root / directory).rglob("*.py") if "__pycache__" not in path.parts
        )
    rows = []
    digest = hashlib.sha256()
    for path in sorted(selected):
        relative = path.relative_to(root).as_posix()
        file_digest = sha256(path)
        digest.update(f"{relative}\0{file_digest}\n".encode())
        rows.append({"path": relative, "bytes": path.stat().st_size, "sha256": file_digest})
    return digest.hexdigest(), rows


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    result_dir = root / "results/phase3"
    checkpoint_dir = result_dir / "checkpoints"
    freeze_dir = result_dir / "formal_freeze"
    if checkpoint_dir.exists() and any(checkpoint_dir.glob("replicate_*.json")):
        raise SystemExit("Refusing to rewrite freeze after formal checkpoint creation")
    result_dir.mkdir(parents=True, exist_ok=True)
    freeze_dir.mkdir(parents=True, exist_ok=True)
    config_paths = [
        root / "config/phase3_formal_sim_v1.yaml",
        root / "config/phase3_baselines_v1.yaml",
        root / "config/phase3_inference_v1.yaml",
        root / "config/phase3_priors_v1.yaml",
    ]
    config_hashes = {path.relative_to(root).as_posix(): sha256(path) for path in config_paths}
    formal_config_sha = config_hashes["config/phase3_formal_sim_v1.yaml"]
    seed_path = freeze_dir / "phase3_seed_manifest.csv"
    with seed_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["replicate_id", "seed", "derivation"])
        writer.writeheader()
        for replicate in range(1, 201):
            source = f"DHBCP-PV-V2|phase3|replicate={replicate}"
            seed = int(hashlib.sha256(source.encode()).hexdigest()[:8], 16)
            writer.writerow({"replicate_id": replicate, "seed": seed, "derivation": source})
    code_sha, code_files = code_tree_hash(root)
    phase2_manifest_path = root / "results/phase2/35_PHASE2_PROCESSED_ARTIFACT_MANIFEST.csv"
    artifact_rows = []
    phase2_ok = True
    with phase2_manifest_path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            path = Path(row["path"])
            actual = sha256(path) if path.exists() else None
            match = actual == row["sha256"]
            phase2_ok &= match
            artifact_rows.append({"artifact": row["artifact"], "expected_sha256": row["sha256"], "actual_sha256": actual, "match": match})
    phase2_provenance = json.loads((root / "results/phase2/41_PHASE2_PROVENANCE.json").read_text())
    payload = {
        "version": "phase3_formal_freeze_v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "freeze_before_first_comparative_result": True,
        "formal_config_sha256": formal_config_sha,
        "config_sha256": config_hashes,
        "seed_manifest": {"path": seed_path.relative_to(root).as_posix(), "rows": 200, "sha256": sha256(seed_path)},
        "code_tree_sha256": code_sha,
        "code_files": code_files,
        "environment_sha256": phase2_provenance["environment"]["environment_sha256"],
        "phase2_artifacts_unchanged": phase2_ok,
        "phase2_artifacts": artifact_rows,
        "formal_results_opened_before_freeze": False,
        "model_retuning_after_results_allowed": False,
    }
    if not phase2_ok:
        raise SystemExit("Phase 2 artifact hash mismatch; Phase 3 formal freeze aborted")
    freeze_path = result_dir / "46_PHASE3_FORMAL_SIMULATION_FREEZE.json"
    freeze_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    pd.DataFrame(baseline_registry_rows()).to_csv(result_dir / "47_PHASE3_BASELINE_REGISTRY.csv", index=False)
    print(json.dumps({"status": "FROZEN", "config_sha256": formal_config_sha, "seed_manifest_sha256": sha256(seed_path), "code_tree_sha256": code_sha}, indent=2))


if __name__ == "__main__":
    main()

