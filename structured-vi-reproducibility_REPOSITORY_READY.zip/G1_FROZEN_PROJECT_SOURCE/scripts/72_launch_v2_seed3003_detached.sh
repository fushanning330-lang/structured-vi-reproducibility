#!/usr/bin/env bash
# scripts/72_launch_v2_seed3003_detached.sh — EXECUTION-ENVIRONMENT ONLY.
#
# Launches the V2 third canary (V2_V2_ARM_P1_p1_seed3003_t12) DETACHED from
# any foreground/WorkBuddy command lifecycle, using macOS caffeinate + nohup,
# so the training process survives terminal / session teardown.
#
# This script NEVER modifies inference, the model, the guide, the runner, or
# any frozen source. It only validates preconditions and launches.
#
# Execute (from the repository root or anywhere):
#   bash scripts/72_launch_v2_seed3003_detached.sh
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

IDENTITY="V2_V2_ARM_P1_p1_seed3003_t12"
AUTH="results/phase3c4v_v2/authorizations/V2_G1_THIRD_CANARY_AUTHORIZATION.json"
RUN_DIR="results/phase3c4v_v2/runs/$IDENTITY"
LOG_DIR="results/phase3c4v_v2/runtime_logs"

# 1. verify .venv python exists
if [ ! -x ".venv/bin/python" ]; then
  echo "FATAL: .venv/bin/python missing (run from the repository root)." >&2
  exit 1
fi

# 2. verify scripts71 exists
if [ ! -f "scripts/71_run_phase3c4v_v2_g1_third_canary.py" ]; then
  echo "FATAL: scripts/71_run_phase3c4v_v2_g1_third_canary.py missing." >&2
  exit 1
fi

# 3. verify third-canary authorization exists
if [ ! -f "$AUTH" ]; then
  echo "FATAL: third canary authorization missing: $AUTH" >&2
  exit 1
fi

# 4. refuse if seed3003 RUN_STARTED already exists (identity permanently consumed)
if [ -f "$RUN_DIR/RUN_STARTED" ]; then
  echo "FATAL: seed3003 already consumed (RUN_STARTED exists); NEVER rerun." >&2
  exit 1
fi

# 5. create the runtime log directory
mkdir -p "$LOG_DIR"

# 6. detached launch: caffeinate keeps the host awake; nohup detaches the
#    process from this shell; /usr/bin/time -l records max RSS at exit.
LAUNCH_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
nohup caffeinate -dimsu /usr/bin/time -l \
  .venv/bin/python \
  scripts/71_run_phase3c4v_v2_g1_third_canary.py \
  --mode third-canary \
  > "$LOG_DIR/seed3003_console.log" \
  2> "$LOG_DIR/seed3003_runtime.log" &
LAUNCHER_PID=$!
echo "$LAUNCHER_PID" > "$LOG_DIR/seed3003_launcher.pid"
echo "$LAUNCH_UTC" > "$LOG_DIR/seed3003_launch_timestamp.txt"

echo "Launched third canary seed3003 (detached)."
echo "launcher_pid=$LAUNCHER_PID launch_utc=$LAUNCH_UTC"
echo "console_log=$LOG_DIR/seed3003_console.log"
echo "runtime_log=$LOG_DIR/seed3003_runtime.log"
echo "monitor: tail -f $LOG_DIR/seed3003_runtime.log"
