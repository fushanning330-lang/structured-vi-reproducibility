"""Phase3C.4V V2 — CORRECTIVE DETERMINISTIC G0 PREFLIGHT (scripts/66).

Corrective implementation preflight per artifact 42H (human source audit).
The corrected canonical V2 source is
``src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py``
(historical 42G prototype source is NOT imported for V2 implementation tests
and remains immutable).

NO SVI execution path exists in this script. NO SVI.init / SVI.update /
SVI.stable_update / optimization / posterior sampling / importance sampling /
NUTS / HMC / MCMC / NeuTra. NO inference authorization artifact is created.

Tests G0C.1..G0C.19 (see _run_g0 below).
Output: results/phase3c4v/preflight/42I_V2_AR1_CORRECTIVE_IMPLEMENTATION_G0_PREFLIGHT.{json,md}
"""
from __future__ import annotations

import ast
import hashlib
import json
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)  # MUST be set before numpyro import

import jax.numpy as jnp
import numpy as np
import numpyro
from numpyro import handlers
from numpyro.distributions.transforms import biject_to

ROOT = Path(__file__).resolve().parents[1]

EXPECTED_MODEL_SHA = "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"
EXPECTED_V1_GUIDE_SHA = "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878"
EXPECTED_SERIALIZER_SHA = "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"
EXPECTED_SCRIPTS64_SHA = "6879309eaf50505da8b923fe4705a48581d21f4c91bf4dfddaaffb98019a0ade"
EXPECTED_18_SHA = "02670ddfe22a1d86d3cb707f21a24fa34a5d5eae346b55ec34bd106b7f4dae70"
EXPECTED_42E_SHA = "c50a2bac39d0c5a5c257a0c62f1b94189b4275e08f91621ff6153959fcf33bc5"
EXPECTED_42F_SHA = "e60c654259ef7763bc00c9315ef6cdb214b35fc5270e725aa7a5b90e87df3066"

GUIDE_FIX_REL = "src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py"
GUIDE_42G_REL = "src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide.py"
PREFLIGHT_OUT_REL = "results/phase3c4v/preflight/42I_V2_AR1_CORRECTIVE_IMPLEMENTATION_G0_PREFLIGHT.json"
AUDIT_42H_REL = "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.json"

sys.path.insert(0, str(ROOT / "src"))

# V2 implementation under test: ONLY the corrected source.
from dhbcp_pv.inference.v2_shared_ar1_temporal_guide_g0fix import (  # noqa: E402
    V2SharedAR1TemporalAutoGuide,
    V2AR1TemporalDistribution,
    LOG_SCALE_ABS_MAX,
    _r11,
    _rho_from_raw,
    _apply_r_inv,
    _tridiag_t,
    _effective_log_scale,
    _BLOCK_SEGMENTS,
    _FACTOR_SUBKEY_ORDER,
    _LATENT_DIM,
    _RHO_MAX,
    _N_PAIRS,
    _T_LEN,
    _T_NON_TEMPORAL,
)
# Frozen references (NOT V2 implementation): V1 guide for factor-RNG alignment,
# the frozen model target, and the frozen serializer.
from dhbcp_pv.inference.v1_structured_lowrank_guide import (  # noqa: E402
    StructuredLowRankAutoGuide,
    _FACTOR_SUBKEY_ORDER as V1_FACTOR_SUBKEY_ORDER,
)
from dhbcp_pv.models.full_joint_model import full_joint_model as TARGET  # noqa: E402
from dhbcp_pv.inference.variational_param_persistence import (  # noqa: E402
    validate_params_roundtrip,
)
# numpyro internal packing helpers used to build a genuine repack function
# (UnpackTransform.inv is unusable in numpyro 0.21 because its pack_fn is
# stored without the bound shape_dict; we bind it ourselves below).
from numpyro.infer.autoguide import _ravel_dict, _ravel_dict_with_shape_dict  # noqa: E402


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def frozen_reference_data(root: Path, cutoff: int):
    import importlib.util
    path = root / "scripts/51_run_phase3c_nuts.py"
    spec = importlib.util.spec_from_file_location("frozen_51_g0", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.reference_data(root, cutoff)


def derive_keys(seed: int) -> dict:
    master = jax.random.PRNGKey(seed)
    prototype_key, factor_init_key, svi_init_key, svi_runtime_key = jax.random.split(master, 4)
    return {
        "master_key": np.asarray(master).tolist(),
        "prototype_key": np.asarray(prototype_key).tolist(),
        "factor_init_key": np.asarray(factor_init_key).tolist(),
        "svi_init_key": np.asarray(svi_init_key).tolist(),
        "svi_runtime_key": np.asarray(svi_runtime_key).tolist(),
    }


def _build_dense_oracle(loc, diag_log_scale, U, raw_rho):
    """Independent dense 708x708 oracle (G0 only). Uses effective (clipped)
    log scale s = exp(clip(diag_log_scale, -300, 300)) exactly as production."""
    rho = _rho_from_raw(raw_rho)
    s = jnp.exp(_effective_log_scale(diag_log_scale))
    R11 = _r11(rho)
    B = jnp.zeros((708, 708))
    B = B.at[:158, :158].set(jnp.diag(s[0:158] ** 2))
    for p in range(50):
        s_p = s[158 + 11 * p:158 + 11 * (p + 1)]
        Bp = jnp.diag(s_p) @ R11 @ jnp.diag(s_p)
        B = B.at[158 + 11 * p:158 + 11 * (p + 1), 158 + 11 * p:158 + 11 * (p + 1)].set(Bp)
    Sigma = B + U @ U.T
    return Sigma


def _dense_mvn_log_prob(loc, Sigma, value):
    L = jnp.linalg.cholesky(Sigma)
    delta = value - loc
    x = jax.scipy.linalg.solve_triangular(L, delta, lower=True)
    lp = -0.5 * (708 * jnp.log(2 * jnp.pi) + 2 * jnp.sum(jnp.log(jnp.diag(L))) + jnp.dot(x, x))
    return lp


def _callable_name(node) -> str | None:
    """Extract the invoked-callable name for an AST Call func node.

    Only dotted paths rooted at a variable Name are reported (e.g.
    ``svi.update`` -> "svi.update"); call funcs whose base is itself a Call
    (e.g. ``np.asarray(x).tolist()``) are reduced to their leaf attribute
    (``tolist``) because the invoked function is the leaf method. Arguments
    are never part of the callable path, so a frozen protocol variable such
    as ``svi_init_key`` passed as an ARGUMENT is correctly not flagged.
    """
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        if isinstance(node.value, ast.Name):
            return ast.unparse(node)  # dotted path rooted at a variable
        if isinstance(node.value, ast.Call):
            return node.attr  # method call on an expression result
        return None
    return None


def _ast_forbidden_audit(path: Path) -> list:
    """Static AST audit: return list of forbidden executable call/import paths.

    Only executable CALLABLE paths and import paths are considered: the
    invoked function name of every Call node and every Import / ImportFrom
    module / alias. Comments and docstrings (string constants) are NOT
    audited. Variable names used only as arguments (e.g. the frozen protocol
    key ``svi_init_key``) are NOT call/import paths and are NOT flagged.
    """
    forbidden = ["svi", "nuts", "hmc", "mcmc", "neura", "sample_posterior", "importance"]
    src = Path(path).read_text(encoding="utf-8")
    tree = ast.parse(src)
    hits = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = _callable_name(node.func)
            if name:
                low = name.lower()
                for f in forbidden:
                    if f in low:
                        hits.append("call:" + name)
        elif isinstance(node, ast.Import):
            for a in node.names:
                for f in forbidden:
                    if f in (a.name or "").lower():
                        hits.append("import:" + (a.name or ""))
        elif isinstance(node, ast.ImportFrom):
            mod = (node.module or "")
            for a in node.names:
                for f in forbidden:
                    if f in mod.lower() or f in (a.name or "").lower():
                        hits.append("importfrom:" + mod + "." + (a.name or ""))
    return sorted(set(hits))


def run_g0(root: Path) -> dict:
    checks = {}
    results = {}

    # ------------------------------------------------------------------
    # G0C.1 FROZEN SHA CHAIN
    # ------------------------------------------------------------------
    sha_map = {
        "model": (root / "src/dhbcp_pv/models/full_joint_model.py", EXPECTED_MODEL_SHA),
        "v1_guide": (root / "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py", EXPECTED_V1_GUIDE_SHA),
        "scripts64": (root / "scripts/64_run_phase3c4v_parameter_persistent_validation.py", EXPECTED_SCRIPTS64_SHA),
        "serializer": (root / "src/dhbcp_pv/inference/variational_param_persistence.py", EXPECTED_SERIALIZER_SHA),
        "artifact18": (root / "results/phase3c4/18_NEUTRA_EXACT_PACKED_LATENT_MAP.json", EXPECTED_18_SHA),
        "42E": (root / "results/phase3c4v/audit/42E_V2_AR1_TEMPORAL_MATHEMATICAL_SPECIFICATION_FREEZE.json", EXPECTED_42E_SHA),
        "42F": (root / "results/phase3c4v/audit/42F_V2_AR1_NUMERICAL_SAFETY_AMENDMENT.json", EXPECTED_42F_SHA),
    }
    sha_ok = True
    for name, (p, exp) in sha_map.items():
        live = sha256(p)
        results["sha_" + name] = {"expected": exp, "live": live, "ok": live == exp}
        sha_ok = sha_ok and (live == exp)

    # 42G machine result + immutability: compare against the SHAs recorded in 42H.
    h42 = json.loads((root / AUDIT_42H_REL).read_text(encoding="utf-8"))
    results["42H_classification"] = h42.get("classification")
    results["42H_machine_result_remains_PASS"] = h42.get("1_machine_result", {}).get("machine_result_remains_PASS")
    g42_files = h42.get("1_machine_result", {}).get("42G_files_sha", {})
    for name, p in [
        ("42G_json", root / "results/phase3c4v/preflight/42G_V2_AR1_IMPLEMENTATION_DETERMINISTIC_G0_PREFLIGHT.json"),
        ("42G_md", root / "results/phase3c4v/preflight/42G_V2_AR1_IMPLEMENTATION_DETERMINISTIC_G0_PREFLIGHT.md"),
        ("v2_guide_42g", root / GUIDE_42G_REL),
        ("scripts65", root / "scripts/65_phase3c4v_v2_deterministic_implementation_preflight.py"),
    ]:
        live = sha256(p)
        exp = g42_files.get(name)
        ok = bool(exp and live == exp)
        results["42G_immutable_" + name] = {"recorded_in_42H": exp, "live": live, "ok": ok}
        sha_ok = sha_ok and ok
    checks["G0C.1_frozen_sha_chain"] = bool(sha_ok)

    # ------------------------------------------------------------------
    # frozen RNG keys (seed 1001; determinism only)
    # ------------------------------------------------------------------
    keys = derive_keys(1001)
    factor_init_key = jnp.asarray(keys["factor_init_key"], dtype=jnp.uint32)
    prototype_key = jnp.asarray(keys["prototype_key"], dtype=jnp.uint32)
    rng_key = jax.random.PRNGKey(20260819)

    _, args, kwargs = frozen_reference_data(root, 12)
    results["cutoff_from_reference_data"] = 12

    guide = V2SharedAR1TemporalAutoGuide(
        TARGET, prefix="v2", init_loc_fn=numpyro.infer.init_to_median,
        factor_init_key=factor_init_key,
    )
    with handlers.seed(rng_seed=prototype_key):
        guide._setup_prototype(*args, **kwargs)

    # ------------------------------------------------------------------
    # G0C.2 LATENT STRUCTURE
    # ------------------------------------------------------------------
    n_latent = len(getattr(guide, "_init_locs", {}))
    results["G0C.2_latent_dim"] = int(guide.latent_dim)
    results["G0C.2_latent_sites"] = n_latent
    packed18 = json.loads((root / "results/phase3c4/18_NEUTRA_EXACT_PACKED_LATENT_MAP.json").read_text())
    coords = packed18["coordinate_map"]
    base_inc_entries = [c for c in coords if c.get("site") == "base_increment"]
    offsets_ok = True
    for c in base_inc_entries:
        pair, time = c.get("local_index", [None, None])
        if c["packed_index"] != 158 + pair * 11 + time:
            offsets_ok = False
            break
    results["G0C.2_base_increment_entries"] = len(base_inc_entries)
    checks["G0C.2_latent_structure"] = bool(
        guide.latent_dim == 708 and n_latent == 24
        and len(base_inc_entries) == 550 and offsets_ok
        and _N_PAIRS * _T_LEN == 550
    )

    # ------------------------------------------------------------------
    # G0C.3 ACTUAL PARAMETER TRACE (no hard-coding of the pass)
    # ------------------------------------------------------------------
    try:
        with handlers.trace() as tr:
            with handlers.seed(rng_seed=jax.random.PRNGKey(12345)):
                guide._get_posterior()
        param_sites = {n: s for n, s in tr.items() if s["type"] == "param"}
    except Exception as exc:  # noqa: BLE001
        checks["G0C.3_actual_parameter_trace"] = False
        results["G0C.3_error"] = repr(exc)
        param_sites = {}
    expected_schema = {
        "v2_loc": (708,),
        "v2_diag_log_scale": (708,),
        "v2_F_shared": (708, 16),
        "v2_F_count_plus_initial": (120, 4),
        "v2_F_dynamic_scale": (16, 4),
        "v2_F_seriousness": (22, 4),
        "v2_raw_temporal_rho": (),
    }
    schema_ok = bool(len(param_sites) == 7 and set(param_sites) == set(expected_schema))
    shapes_ok = True
    for n, shp in expected_schema.items():
        if n not in param_sites:
            shapes_ok = False
            continue
        live_shp = tuple(jnp.shape(param_sites[n]["value"]))
        if live_shp != shp:
            shapes_ok = False
    total_elts = sum(int(jnp.size(param_sites[n]["value"])) for n in param_sites)
    results["G0C.3_actual_param_names"] = sorted(param_sites)
    results["G0C.3_actual_shapes"] = {n: tuple(jnp.shape(param_sites[n]["value"])) for n in sorted(param_sites)}
    results["G0C.3_total_elements"] = total_elts
    no_temporal = "v2_F_temporal_path" not in param_sites
    checks["G0C.3_actual_parameter_trace"] = bool(schema_ok and shapes_ok and total_elts == 13377 and no_temporal)

    # ------------------------------------------------------------------
    # G0C.4 U (708,28) built through ACTUAL guide code with exact embeddings
    # ------------------------------------------------------------------
    F_shared = 0.01 * jax.random.normal(jax.random.PRNGKey(11), (708, 16))
    F_count = 0.01 * jax.random.normal(jax.random.PRNGKey(12), (120, 4))
    F_dynamic = 0.01 * jax.random.normal(jax.random.PRNGKey(13), (16, 4))
    F_serious = 0.01 * jax.random.normal(jax.random.PRNGKey(14), (22, 4))
    U_test = V2SharedAR1TemporalAutoGuide._build_u(F_shared, F_count, F_dynamic, F_serious)
    from dhbcp_pv.inference.v2_shared_ar1_temporal_guide_g0fix import _block_index_arrays
    bidx = _block_index_arrays(708)
    emb_ok = (
        jnp.array_equal(U_test[:, :16], F_shared)
        and jnp.array_equal(U_test[bidx["count_plus_initial"], 16:20], F_count)
        and jnp.array_equal(U_test[bidx["dynamic_scale"], 20:24], F_dynamic)
        and jnp.array_equal(U_test[bidx["seriousness"], 24:28], F_serious)
    )
    # semantic embeddings exact: zero outside the intended block rows/cols
    zero_ok = True
    Uz = jnp.zeros_like(U_test)
    Uz = Uz.at[:, :16].set(F_shared)
    Uz = Uz.at[bidx["count_plus_initial"], 16:20].set(F_count)
    Uz = Uz.at[bidx["dynamic_scale"], 20:24].set(F_dynamic)
    Uz = Uz.at[bidx["seriousness"], 24:28].set(F_serious)
    zero_ok = bool(jnp.array_equal(U_test, Uz))
    checks["G0C.4_U_shape_embeddings"] = bool(
        jnp.shape(U_test) == (708, 28) and emb_ok and zero_ok
    )
    results["G0C.4_U_shape"] = list(jnp.shape(U_test))

    # ------------------------------------------------------------------
    # G0C.5 SUPPORT ROUNDTRIP per latent site (genuine forward/inverse)
    # ------------------------------------------------------------------
    all_rt = True
    rt_detail = {}
    for name, init_val in guide._init_locs.items():
        site = guide.prototype_trace[name]
        transform = biject_to(site["fn"].support)
        shp = tuple(jnp.shape(init_val))
        tests = []
        if shp == ():
            for v in [-2.5, 0.3, 1.7]:
                u = jnp.array(v)
                val = transform(u)
                u_back = transform.inv(val)
                tests.append(bool(jnp.allclose(u_back, u, atol=1e-10, rtol=1e-10)))
        else:
            # more than one deterministic vector where shape allows
            u1 = jnp.zeros(shp)
            u2 = jnp.linspace(-1.0, 1.0, int(np.prod(shp))).reshape(shp)
            u3 = init_val  # deterministic frozen init
            for u in [u1, u2, u3]:
                val = transform(u)
                u_back = transform.inv(val)
                tests.append(bool(jnp.allclose(u_back, u, atol=1e-10, rtol=1e-10)))
        ok = all(tests)
        rt_detail[name] = {"support": str(site["fn"].support), "shape": shp, "roundtrip_ok": ok}
        all_rt = all_rt and ok
    checks["G0C.5_support_roundtrip"] = bool(all_rt and len(rt_detail) == 24)
    results["G0C.5_detail"] = rt_detail

    # ------------------------------------------------------------------
    # G0C.6 PACKING ROUNDTRIP: packed -> unpack -> repack == packed
    # ------------------------------------------------------------------
    unpack_transform = guide._unpack_latent
    # numpyro 0.21's UnpackTransform.inv is unusable (its pack_fn is stored
    # without the bound shape_dict), so we bind the frozen shape_dict and use
    # the exact same _ravel_dict_with_shape_dict helper AutoContinuous uses.
    _, frozen_shape_dict = _ravel_dict(guide._init_locs)

    def repack(unpacked):
        return _ravel_dict_with_shape_dict(unpacked, frozen_shape_dict)

    pack_ok = True
    pack_detail = {}
    pack_vectors = {
        "zeros": jnp.zeros(708),
        "linear": (0.01 * jnp.arange(708) - 3.5),
        "seeded_random": jax.random.normal(jax.random.PRNGKey(99), (708,)),
    }
    for pname, z in pack_vectors.items():
        try:
            unpacked = unpack_transform(z)
            repacked = repack(unpacked)
            eq = bool(jnp.allclose(repacked, z, atol=1e-12, rtol=1e-12))
            pack_detail[pname] = {"equal": eq, "max_abs_diff": float(jnp.max(jnp.abs(repacked - z)))}
            pack_ok = pack_ok and eq
        except Exception as exc:  # noqa: BLE001
            pack_detail[pname] = {"error": repr(exc)}
            pack_ok = False
    checks["G0C.6_packing_roundtrip"] = bool(pack_ok and len(pack_detail) == 3)
    results["G0C.6_detail"] = pack_detail

    # ------------------------------------------------------------------
    # G0C.7 AR1 SAFETY
    # ------------------------------------------------------------------
    raw_list = [-100.0, -20.0, -10.0, -5.0, 0.0, 5.0, 10.0, 20.0, 100.0]
    ar1_ok = True
    ar1_detail = {}
    min_eig_099 = True
    for rv in raw_list:
        rho = _rho_from_raw(jnp.array(rv))
        R = _r11(rho)
        ev = jnp.linalg.eigvalsh(R)
        ok = (
            bool(jnp.isfinite(rho))
            and bool(abs(rho) <= _RHO_MAX)
            and bool((1.0 - rho ** 2) > 0)
            and bool(jnp.allclose(R, R.T))
            and bool(jnp.allclose(jnp.diag(R), jnp.ones(_T_LEN)))
            and bool(ev.min() > 0)
        )
        ar1_detail[str(rv)] = {
            "rho": float(rho),
            "finite": bool(jnp.isfinite(rho)),
            "abs_rho_leq_0.99": bool(abs(rho) <= _RHO_MAX),
            "1_minus_rho2_gt_0": bool((1.0 - rho ** 2) > 0),
            "sym": bool(jnp.allclose(R, R.T)),
            "diag1": bool(jnp.allclose(jnp.diag(R), jnp.ones(_T_LEN))),
            "pd": bool(ev.min() > 0),
        }
        ar1_ok = ar1_ok and ok
    for sgn in (1.0, -1.0):
        ev = jnp.linalg.eigvalsh(_r11(sgn * _RHO_MAX))
        min_eig_099 = min_eig_099 and bool(ev.min() > 0)
    results["G0C.7_min_eig_at_0.99"] = float(jnp.linalg.eigvalsh(_r11(_RHO_MAX)).min())
    checks["G0C.7_ar1_safety"] = bool(ar1_ok and min_eig_099)
    results["G0C.7_detail"] = ar1_detail

    # ------------------------------------------------------------------
    # G0C.8 AR1 ANALYTIC IDENTITIES
    # ------------------------------------------------------------------
    max_inv_diff = 0.0
    max_logdet_diff = 0.0
    for rv in raw_list:
        rho = _rho_from_raw(jnp.array(rv))
        R = _r11(rho)
        P_a = _tridiag_t(rho) / (1.0 - rho ** 2)
        P_d = jnp.linalg.inv(R)
        max_inv_diff = max(max_inv_diff, float(jnp.max(jnp.abs(P_a - P_d))))
        logdet_a = (_T_LEN - 1) * jnp.log1p(-rho ** 2)
        logdet_d = jnp.linalg.slogdet(R)[1]
        max_logdet_diff = max(max_logdet_diff, float(abs(logdet_a - logdet_d)))
    rho_a = _rho_from_raw(jnp.array(0.6))
    c = jnp.sqrt(jnp.maximum(1.0 - rho_a ** 2, 0.0))
    t_idx = jnp.arange(11)[:, None]
    k_idx = jnp.arange(11)[None, :]
    L_ar = jnp.where(k_idx <= t_idx, rho_a ** (t_idx - k_idx), 0.0)
    L_ar = L_ar.at[:, 0].set(rho_a ** t_idx[:, 0])
    for t in range(1, 11):
        L_ar = L_ar.at[t, 1:t + 1].set(rho_a ** (t - jnp.arange(1, t + 1)) * c)
    L_ar = L_ar.at[0, 0].set(1.0)
    lar_err = float(jnp.max(jnp.abs(L_ar @ L_ar.T - _r11(rho_a))))
    results["G0C.8_max_inv_diff"] = max_inv_diff
    results["G0C.8_max_logdet_diff"] = max_logdet_diff
    results["G0C.8_LAR_LAR_T_err"] = lar_err
    checks["G0C.8_ar1_analytic_identities"] = bool(
        max_inv_diff < 1e-8 and max_logdet_diff < 1e-8 and lar_err < 1e-10
    )

    # ------------------------------------------------------------------
    # G0C.9 SCALE FLOAT64 SAFETY (LOG_SCALE_ABS_MAX = 300.0)
    # ------------------------------------------------------------------
    scale_vals = [-1000.0, -400.0, -300.0, -100.0, float(jnp.log(0.1)), 0.0, 100.0, 300.0, 400.0, 1000.0]
    scale_ok = True
    scale_detail = {}
    test_loc = jnp.zeros(708)
    test_U = 0.01 * jax.random.normal(jax.random.PRNGKey(7), (708, 28))
    zz0 = 0.3 * jnp.ones(708)
    for sv in scale_vals:
        dls = jnp.full(708, sv)
        eff = _effective_log_scale(dls)
        s = jnp.exp(eff)
        dd = V2AR1TemporalDistribution(test_loc, dls, test_U, jnp.array(0.7))
        lp = dd.log_prob(zz0)
        ok = (
            bool(jnp.isfinite(eff).all())
            and bool(jnp.all(eff >= -LOG_SCALE_ABS_MAX)) and bool(jnp.all(eff <= LOG_SCALE_ABS_MAX))
            and bool(jnp.isfinite(s).all()) and bool((s > 0).all())
            and bool(jnp.isfinite(s ** 2).all()) and bool((s ** 2 > 0).all())
            and bool(jnp.isfinite(1.0 / (s ** 2)).all())
            and bool(jnp.isfinite(lp))
        )
        scale_detail[str(sv)] = {
            "effective": float(eff[0]), "s": float(s[0]), "log_prob": float(lp),
            "finite_output": bool(jnp.isfinite(lp)), "ok": ok,
        }
        scale_ok = scale_ok and ok
    checks["G0C.9_scale_float64_safety"] = bool(scale_ok and LOG_SCALE_ABS_MAX == 300.0)
    results["G0C.9_detail"] = scale_detail

    # ------------------------------------------------------------------
    # G0C.10 B AND SIGMA SPD under multiple deterministic settings
    # ------------------------------------------------------------------
    spd_ok = True
    spd_detail = {}
    settings = [
        ("s_log01_raw07", jnp.full(708, jnp.log(0.1)), 0.7, 0.01 * jax.random.normal(jax.random.PRNGKey(7), (708, 28))),
        ("s0_raw_neg09", jnp.zeros(708), -0.9, 0.05 * jax.random.normal(jax.random.PRNGKey(8), (708, 28))),
        ("s_log05_raw03_zeroU", jnp.full(708, jnp.log(0.5)), 0.3, jnp.zeros((708, 28))),
    ]
    for sname, dls, raw, U in settings:
        Sigma = _build_dense_oracle(test_loc, dls, U, jnp.array(raw))
        B = Sigma - U @ U.T
        evB = jnp.linalg.eigvalsh(B)
        evS = jnp.linalg.eigvalsh(Sigma)
        ok = bool(evB.min() > 0) and bool(evS.min() > 0)
        spd_detail[sname] = {"min_eig_B": float(evB.min()), "min_eig_Sigma": float(evS.min()), "ok": ok}
        spd_ok = spd_ok and ok
    checks["G0C.10_B_Sigma_spd"] = bool(spd_ok)
    results["G0C.10_detail"] = spd_detail

    # ------------------------------------------------------------------
    # G0C.11 EXACT LOG_PROB ORACLE vs dense 708 MVN
    # ------------------------------------------------------------------
    max_abs_err = 0.0
    max_rel_err = 0.0
    oracle_detail = []
    for raw_v in [-100.0, -10.0, 0.0, 0.5, 10.0, 100.0]:
        for dls_v in [float(jnp.log(0.1)), -100.0, 0.0, 100.0]:
            dls = jnp.full(708, dls_v)
            dd = V2AR1TemporalDistribution(test_loc, dls, test_U, jnp.array(raw_v))
            S = _build_dense_oracle(test_loc, dls, test_U, jnp.array(raw_v))
            pts = {
                "p_neg3": test_loc - 3.0 * jnp.ones(708),
                "p0": test_loc,
                "p2_5": test_loc + 2.5 * jnp.ones(708),
                "linear": 0.01 * jnp.arange(708) - 3.5,
            }
            for pname, zz in pts.items():
                lp_c = dd.log_prob(zz)
                lp_d = _dense_mvn_log_prob(test_loc, S, zz)
                aerr = float(abs(lp_c - lp_d))
                rel = aerr / max(1.0, abs(float(lp_d)))
                max_abs_err = max(max_abs_err, aerr)
                max_rel_err = max(max_rel_err, rel)
                oracle_detail.append({
                    "raw": raw_v, "scale": dls_v, "point": pname,
                    "lp_prod": float(lp_c), "lp_dense": float(lp_d),
                    "abs_err": aerr, "rel_err": rel,
                })
    # benign-scale subset (log(0.1), 0): require small absolute error too
    benign_abs = max(
        d["abs_err"] for d in oracle_detail if d["scale"] in (float(jnp.log(0.1)), 0.0)
    )
    results["G0C.11_max_abs_error"] = max_abs_err
    results["G0C.11_max_relative_error"] = max_rel_err
    results["G0C.11_benign_scale_max_abs_error"] = benign_abs
    results["G0C.11_n_comparisons"] = len(oracle_detail)
    checks["G0C.11_log_prob_oracle"] = bool(max_rel_err < 1e-6 and benign_abs < 1e-4)

    # ------------------------------------------------------------------
    # G0C.12 ACTUAL FACTOR GRADIENTS (separate pathways through _build_u)
    # ------------------------------------------------------------------
    def lp_fn(loc, dls, F_sh, F_ct, F_dy, F_se, raw, zz):
        Uu = V2SharedAR1TemporalAutoGuide._build_u(F_sh, F_ct, F_dy, F_se)
        return V2AR1TemporalDistribution(loc, dls, Uu, raw).log_prob(zz)

    grad_fn = jax.jit(jax.grad(lp_fn, argnums=(0, 1, 2, 3, 4, 5, 6)))
    grad_ok = True
    grad_detail = {}
    F_sh = 0.01 * jax.random.normal(jax.random.PRNGKey(21), (708, 16))
    F_ct = 0.01 * jax.random.normal(jax.random.PRNGKey(22), (120, 4))
    F_dy = 0.01 * jax.random.normal(jax.random.PRNGKey(23), (16, 4))
    F_se = 0.01 * jax.random.normal(jax.random.PRNGKey(24), (22, 4))
    zz_g = 0.3 * jnp.ones(708)
    for raw_v in [0.0, 20.0, -20.0, 100.0, -100.0]:
        for dls_v in [-300.0, -100.0, float(jnp.log(0.1)), 0.0, 100.0, 300.0]:
            dls = jnp.full(708, dls_v)
            grads = grad_fn(test_loc, dls, F_sh, F_ct, F_dy, F_se, jnp.array(raw_v), zz_g)
            finite = all(bool(jnp.isfinite(g).all()) for g in grads)
            key = "raw_{}_scale_{}".format(raw_v, dls_v)
            grad_detail[key] = {
                "loc_finite": bool(jnp.isfinite(grads[0]).all()),
                "dls_finite": bool(jnp.isfinite(grads[1]).all()),
                "F_shared_finite": bool(jnp.isfinite(grads[2]).all()),
                "F_count_finite": bool(jnp.isfinite(grads[3]).all()),
                "F_dynamic_finite": bool(jnp.isfinite(grads[4]).all()),
                "F_seriousness_finite": bool(jnp.isfinite(grads[5]).all()),
                "raw_rho_finite": bool(jnp.isfinite(grads[6]).all()),
            }
            grad_ok = grad_ok and finite
    checks["G0C.12_actual_factor_gradients"] = bool(grad_ok and len(grad_detail) == 30)
    results["G0C.12_detail"] = grad_detail

    # ------------------------------------------------------------------
    # G0C.13 SAMPLING
    # ------------------------------------------------------------------
    dd_s = V2AR1TemporalDistribution(test_loc, jnp.full(708, jnp.log(0.1)), test_U, jnp.array(0.5))
    z_a = dd_s.sample(rng_key)
    z_b = dd_s.sample(rng_key)
    z_c = dd_s.sample(jax.random.PRNGKey(4242))
    # reparameterized formula consistency: z == loc + structured + U @ eps_u
    key_n, key_e, key_u = jax.random.split(rng_key, 3)
    eps_non = jax.random.normal(key_n, (158,))
    eta = jax.random.normal(key_e, (50, 11))
    rho_s = _rho_from_raw(jnp.array(0.5))
    sqrt_1mr2 = jnp.sqrt(jnp.maximum(1.0 - rho_s ** 2, 0.0))
    y = eta[:, 0]
    ys = [y]
    for t in range(1, 11):
        y = rho_s * y + sqrt_1mr2 * eta[:, t]
        ys.append(y)
    y = jnp.stack(ys, axis=-1)
    s_full = jnp.exp(jnp.full(708, jnp.log(0.1)))
    s_temp = jnp.reshape(s_full[158:708], (50, 11))
    r_temp_flat = jnp.reshape(s_temp * y, (550,))
    r_non = s_full[0:158] * eps_non
    structured = jnp.concatenate([r_non, r_temp_flat], axis=-1)
    eps_u = jax.random.normal(key_u, (28,))
    z_recon = test_loc + structured + jnp.einsum("ij,j->i", test_U, eps_u)
    formula_ok = bool(jnp.array_equal(z_a, z_recon))
    checks["G0C.13_sampling"] = bool(
        jnp.shape(z_a) == (708,) and bool(jnp.isfinite(z_a).all())
        and bool(jnp.array_equal(z_a, z_b)) and bool(not jnp.array_equal(z_a, z_c))
        and formula_ok
    )
    results["G0C.13_sample_shape"] = list(jnp.shape(z_a))
    results["G0C.13_same_key_reproducible"] = bool(jnp.array_equal(z_a, z_b))
    results["G0C.13_diff_key_changes"] = bool(not jnp.array_equal(z_a, z_c))
    results["G0C.13_formula_consistent"] = formula_ok

    # ------------------------------------------------------------------
    # G0C.14 FOUR-FACTOR RNG ALIGNMENT (V1 vs corrected V2)
    # ------------------------------------------------------------------
    v1_guide = StructuredLowRankAutoGuide(
        TARGET, prefix="auto", init_loc_fn=numpyro.infer.init_to_median,
        factor_init_key=factor_init_key,
    )
    with handlers.seed(rng_seed=prototype_key):
        v1_guide._setup_prototype(*args, **kwargs)
    with handlers.trace() as tr1:
        with handlers.seed(rng_seed=jax.random.PRNGKey(12345)):
            v1_guide._get_posterior()
    v1_params = {n: s["value"] for n, s in tr1.items() if s["type"] == "param"}
    with handlers.trace() as tr2:
        with handlers.seed(rng_seed=jax.random.PRNGKey(12345)):
            guide._get_posterior()
    v2_params = {n: s["value"] for n, s in tr2.items() if s["type"] == "param"}
    align_ok = bool(V1_FACTOR_SUBKEY_ORDER[:4] == _FACTOR_SUBKEY_ORDER[:4])
    align_detail = {}
    for fname in ["shared", "count_plus_initial", "dynamic_scale", "seriousness"]:
        k1 = "auto_F_{}".format(fname)
        k2 = "v2_F_{}".format(fname)
        eq = bool(k1 in v1_params and k2 in v2_params
                  and jnp.array_equal(v1_params[k1], v2_params[k2]))
        align_detail[fname] = {
            "v1_shape": tuple(jnp.shape(v1_params[k1])) if k1 in v1_params else None,
            "v2_shape": tuple(jnp.shape(v2_params[k2])) if k2 in v2_params else None,
            "exact_equal": eq,
        }
        align_ok = align_ok and eq
    align_ok = align_ok and bool(_FACTOR_SUBKEY_ORDER[4] == "temporal_reserved")
    checks["G0C.14_four_factor_rng_alignment"] = bool(align_ok)
    results["G0C.14_v1_subkey_order"] = V1_FACTOR_SUBKEY_ORDER
    results["G0C.14_v2_subkey_order"] = _FACTOR_SUBKEY_ORDER
    results["G0C.14_detail"] = align_detail

    # ------------------------------------------------------------------
    # G0C.15 SERIALIZER (frozen, unchanged; temporary directory only)
    # ------------------------------------------------------------------
    params = {
        "v2_loc": np.asarray(test_loc),
        "v2_diag_log_scale": np.asarray(jnp.full(708, jnp.log(0.1))),
        "v2_F_shared": np.asarray(F_sh),
        "v2_F_count_plus_initial": np.asarray(F_ct),
        "v2_F_dynamic_scale": np.asarray(F_dy),
        "v2_F_seriousness": np.asarray(F_se),
        # scalar rho persisted through the frozen serializer as a one-element
        # array (numpy ascontiguousarray promotes 0-d -> (1,)); semantics scalar.
        "v2_raw_temporal_rho": np.asarray([0.0]),
    }
    ser_ok = False
    with tempfile.TemporaryDirectory() as td:
        npz = Path(td) / "v2_params.npz"
        man = Path(td) / "v2_manifest.json"
        rt = validate_params_roundtrip(params, npz, man)
        ser_ok = bool(rt.get("PASS"))
        results["G0C.15_roundtrip"] = rt.get("PASS")
        results["G0C.15_manifest_n_parameters"] = rt.get("manifest", {}).get("n_parameters")
    checks["G0C.15_serializer"] = bool(ser_ok)
    results["G0C.15_in_memory_semantics"] = "scalar"
    results["G0C.15_persisted_representation"] = "one-element array (shape (1,))"

    # ------------------------------------------------------------------
    # G0C.16 FORBIDDEN-CALL STATIC AUDIT (AST; NOT hard-coded)
    # ------------------------------------------------------------------
    hits_guide = _ast_forbidden_audit(root / GUIDE_FIX_REL)
    hits_66 = _ast_forbidden_audit(Path(__file__).resolve())
    checks["G0C.16_forbidden_call_static_audit"] = bool(
        not hits_guide and not hits_66
    )
    results["G0C.16_guide_hits"] = hits_guide
    results["G0C.16_scripts66_hits"] = hits_66

    # ------------------------------------------------------------------
    # G0C.17 X64
    # ------------------------------------------------------------------
    checks["G0C.17_x64"] = bool(jax.config.read("jax_enable_x64") is True)

    # ------------------------------------------------------------------
    # G0C.18 SCIENTIFIC INVARIANCE
    # ------------------------------------------------------------------
    src_guide_fix = (root / GUIDE_FIX_REL).read_text(encoding="utf-8")
    no_pca = ("pca" not in src_guide_fix.lower() and "loadings" not in src_guide_fix.lower())
    checks["G0C.18_scientific_invariance"] = bool(
        results["sha_model"]["ok"]
        and results["sha_v1_guide"]["ok"]
        and results["sha_scripts64"]["ok"]
        and packed18.get("latent_dim") == 708
        and no_pca
        and results["cutoff_from_reference_data"] == 12
    )
    results["G0C.18_model_sha_unchanged"] = results["sha_model"]["ok"]
    results["G0C.18_latent_dim"] = int(guide.latent_dim)
    results["G0C.18_cutoff"] = 12

    # ------------------------------------------------------------------
    # G0C.19 CREATED / MODIFIED AUDIT
    # ------------------------------------------------------------------
    # Files created BEFORE this run (42I json/md are created by this very
    # script and are verified post-write in main()).
    expected_created = [
        "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.json",
        "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.md",
        GUIDE_FIX_REL,
        "scripts/66_phase3c4v_v2_corrective_deterministic_g0_preflight.py",
    ]
    created_ok = all((root / p).exists() for p in expected_created)
    results["G0C.19_42H_sha_json"] = sha256(root / "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.json")
    results["G0C.19_42H_sha_md"] = sha256(root / "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.md")
    results["G0C.19_guide_fix_sha"] = sha256(root / GUIDE_FIX_REL)
    results["G0C.19_scripts66_sha"] = sha256(Path(__file__).resolve())
    # Historical 42G files remain unchanged (G0C.1 cross-check against 42H).
    checks["G0C.19_created_modified_audit"] = bool(
        created_ok and results["42G_immutable_42G_json"]["ok"]
        and results["42G_immutable_42G_md"]["ok"]
        and results["42G_immutable_v2_guide_42g"]["ok"]
        and results["42G_immutable_scripts65"]["ok"]
    )

    # ------------------------------------------------------------------
    # aggregate
    # ------------------------------------------------------------------
    gate_names = [k for k in checks if k.startswith("G0C.")]
    failed = [g for g in gate_names if not checks[g]]
    checks["critical_failed"] = failed
    checks["OVERALL"] = "PASS" if not failed else "FAIL"
    return {"checks": checks, "results": results}


def main() -> None:
    root = ROOT
    out = run_g0(root)
    checks = out["checks"]
    # run history: if a previous 42I exists, record it (transparency for
    # FAIL -> diagnose -> fix -> rerun cycles; no silent overwrite).
    prev = None
    prev_path = root / PREFLIGHT_OUT_REL
    if prev_path.exists():
        try:
            pj = json.loads(prev_path.read_text(encoding="utf-8"))
            prev = {
                "created_utc": pj.get("created_utc"),
                "classification": pj.get("classification"),
                "critical_failed": pj.get("checks", {}).get("critical_failed"),
            }
        except Exception:  # noqa: BLE001
            prev = {"unreadable": True}
    classification = (
        "V2_CORRECTIVE_G0_PREFLIGHT_PASS" if checks["OVERALL"] == "PASS"
        else "V2_CORRECTIVE_G0_PREFLIGHT_FAIL"
    )
    payload = {
        "artifact_id": "42I_V2_AR1_CORRECTIVE_IMPLEMENTATION_G0_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "mode": "CORRECTIVE DETERMINISTIC G0 PREFLIGHT (no SVI, no optimization, no inference)",
        "classification": classification,
        "checks": checks,
        "results": out["results"],
        "previous_run": prev,
        "run_history": prev,
        "g0_scope": {
            "corrected_guide": GUIDE_FIX_REL,
            "42G_prototype_guide": GUIDE_42G_REL,
            "42G_prototype_immutable": True,
            "42H": AUDIT_42H_REL,
            "corrections_bound": [
                "DEFECT_1 -> G0C.3 actual parameter trace",
                "DEFECT_2 -> G0C.5 per-site support roundtrip",
                "DEFECT_3 -> G0C.6 pack/unpack/repack equality",
                "DEFECT_4 -> G0C.12 separate factor gradients through _build_u",
                "DEFECT_5 -> G0C.14 all four factor arrays aligned",
                "DEFECT_6 -> G0C.16 AST forbidden-call audit",
                "DEFECT_7 -> Cholesky triangular Woodbury solve (no K inversion)",
                "DEFECT_8 -> constraints.real_matrix for U",
                "LOG_SCALE_ABS_MAX=300.0 -> G0C.9 scale float64 safety",
                "G0C.12 backward-pass fix -> B^-1 applied via exp(-eff)/exp(-2*eff) "
                "multiplications (reverse-mode 1/exp(2k*eff) underflow removed)",
            ],
            "constraint_used_for_U": "constraints.real_matrix (event_dim=2; verified present in installed NumPyro 0.21.0)",
            "woodbury_solve": "cholesky(K) + two triangular solves (jax.lax.linalg.triangular_solve); explicit K inversion absent",
        },
        "created_files": [
            "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.json",
            "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.md",
            GUIDE_FIX_REL,
            "scripts/66_phase3c4v_v2_corrective_deterministic_g0_preflight.py",
            PREFLIGHT_OUT_REL,
            PREFLIGHT_OUT_REL.replace(".json", ".md"),
        ],
        "modified_files": [],
        "authorization": {
            "V2_CORRECTIVE_SOURCE_IMPLEMENTATION": True,
            "V2_OPTIMIZATION_AUTHORIZED": False,
            "V2_G1_AUTHORIZED": False,
            "V2_CANARY_AUTHORIZED": False,
            "V2_VALIDATION_AUTHORIZED": False,
            "G3_AUTHORIZED": False,
            "NEW_INFERENCE_RUN": False,
            "NEW_OPTIMIZATION_RUN": False,
            "POSTERIOR_DRAWS_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "SCIENTIFIC_TARGET_MODIFIED": False,
            "V1_MODIFIED": False,
            "FAILED_PHASE3C4_PCA_USED": False,
        },
        "final_state": ("V2_CORRECTIVE_G0_PREFLIGHT_PASS"
                        if classification == "V2_CORRECTIVE_G0_PREFLIGHT_PASS"
                        else "V2_CORRECTIVE_G0_PREFLIGHT_FAIL"),
        "waiting_for": ("STOP_WAITING_FOR_V2_G1_PROTOCOL_FREEZE"
                        if classification == "V2_CORRECTIVE_G0_PREFLIGHT_PASS"
                        else "V2_CORRECTIVE_G0_PREFLIGHT_FAIL (do not silently patch and rerun)"),
        "source_sha256": {
            "corrected_v2_guide": sha256(root / GUIDE_FIX_REL),
            "scripts66": sha256(Path(__file__).resolve()),
            "42H_json": sha256(root / AUDIT_42H_REL),
            "42G_v2_guide": sha256(root / GUIDE_42G_REL),
            "42G_json": sha256(root / "results/phase3c4v/preflight/42G_V2_AR1_IMPLEMENTATION_DETERMINISTIC_G0_PREFLIGHT.json"),
            "scripts65": sha256(root / "scripts/65_phase3c4v_v2_deterministic_implementation_preflight.py"),
            "42E": sha256(root / "results/phase3c4v/audit/42E_V2_AR1_TEMPORAL_MATHEMATICAL_SPECIFICATION_FREEZE.json"),
            "42F": sha256(root / "results/phase3c4v/audit/42F_V2_AR1_NUMERICAL_SAFETY_AMENDMENT.json"),
            "model": sha256(root / "src/dhbcp_pv/models/full_joint_model.py"),
            "v1_guide": sha256(root / "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py"),
            "scripts64": sha256(root / "scripts/64_run_phase3c4v_parameter_persistent_validation.py"),
            "serializer": sha256(root / "src/dhbcp_pv/inference/variational_param_persistence.py"),
            "artifact18": sha256(root / "results/phase3c4/18_NEUTRA_EXACT_PACKED_LATENT_MAP.json"),
        },
    }
    out_path = root / PREFLIGHT_OUT_REL
    atomic_write_json(out_path, payload)
    # post-write existence verification for this run's own outputs (G0C.19).
    postwrite_ok = bool(out_path.exists() and out_path.with_suffix(".md").exists())
    payload["postwrite_42I_exists"] = postwrite_ok
    # rewrite json with the postwrite flag so the artifact is self-consistent
    atomic_write_json(out_path, payload)

    md = ["# 42I — V2 AR(1) CORRECTIVE IMPLEMENTATION G0 PREFLIGHT", "",
          f"Generated: {utc_now()}  |  Mode: CORRECTIVE DETERMINISTIC G0 PREFLIGHT "
          f"(no SVI, no optimization, no inference)", "",
          f"**Classification: {classification}**", "",
          "| Gate | Result |", "|---|---|"]
    for k in sorted(checks):
        if k.startswith("G0C."):
            md.append(f"| {k} | {'PASS' if checks[k] else 'FAIL'} |")
    if prev:
        md += ["", "## Run history", ""]
        md.append(f"- Previous run: classification=`{prev.get('classification')}`, "
                  f"created_utc=`{prev.get('created_utc')}`, "
                  f"critical_failed={prev.get('critical_failed')}")
    md += ["", "| Flag | Value |", "|---|---|"]
    for k, v in payload["authorization"].items():
        md.append(f"| {k} | {v} |")
    md += ["", "## Corrections bound", ""]
    for c in payload["g0_scope"]["corrections_bound"]:
        md.append(f"- {c}")
    md += ["", "## Source SHAs", ""]
    for k, v in payload["source_sha256"].items():
        md.append(f"- {k}: `{v}`")
    md += ["", f"## Final state: **{payload['final_state']}**",
           f"- {payload['waiting_for']}"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", checks["OVERALL"], "| failed:", checks.get("critical_failed"))
    print("postwrite_42I_exists:", postwrite_ok)
    return 0 if checks["OVERALL"] == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())
