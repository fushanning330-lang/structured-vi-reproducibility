from __future__ import annotations

import json
import platform
import time
from pathlib import Path

import jax
import numpy as np
from jax import numpy as jnp
from numpyro.diagnostics import summary
from numpyro.infer import MCMC, NUTS

from dhbcp_pv.models.reference_numpyro import static_hierarchical_nb_model


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    results = root / "results/phase2"
    results.mkdir(parents=True, exist_ok=True)
    seed = 104729
    rng = np.random.default_rng(seed)
    n_drugs, n_events, n_pairs, observations_per_pair = 3, 4, 8, 6
    pair_index = np.repeat(np.arange(n_pairs), observations_per_pair)
    drug_for_pair = np.arange(n_pairs) % n_drugs
    event_for_pair = (np.arange(n_pairs) * 2 + 1) % n_events
    drug_index = np.repeat(drug_for_pair, observations_per_pair)
    event_index = np.repeat(event_for_pair, observations_per_pair)
    m_expected = rng.lognormal(np.log(2.5), 0.45, len(pair_index))
    true_mu = 0.15
    true_phi = 9.0
    drug_effect = np.array([-0.18, 0.05, 0.13])
    event_effect = np.array([-0.12, 0.08, 0.18, -0.14])
    pair_effect = rng.normal(0, 0.18, n_pairs)
    eta = true_mu + drug_effect[drug_index] + event_effect[event_index] + pair_effect[pair_index]
    mean = m_expected * np.exp(eta)
    y = rng.negative_binomial(true_phi, true_phi / (true_phi + mean))

    mean_test_rng = np.random.default_rng(130363)
    test_mean, test_phi = 3.75, 7.0
    draws = mean_test_rng.negative_binomial(test_phi, test_phi / (test_phi + test_mean), 200_000)
    empirical_mean = float(draws.mean())
    mean_parameterization_relative_error = abs(empirical_mean - test_mean) / test_mean

    max_tree_depth = 7
    kernel = NUTS(static_hierarchical_nb_model, target_accept_prob=0.85, max_tree_depth=max_tree_depth)
    mcmc = MCMC(
        kernel,
        num_warmup=200,
        num_samples=250,
        num_chains=2,
        chain_method="sequential",
        progress_bar=False,
    )
    started = time.perf_counter()
    mcmc.run(
        jax.random.PRNGKey(seed),
        y=jnp.asarray(y),
        m_expected=jnp.asarray(m_expected),
        drug_index=jnp.asarray(drug_index),
        event_index=jnp.asarray(event_index),
        pair_index=jnp.asarray(pair_index),
        n_drugs=n_drugs,
        n_events=n_events,
        n_pairs=n_pairs,
        extra_fields=("diverging", "num_steps"),
    )
    runtime = time.perf_counter() - started
    samples_chain = mcmc.get_samples(group_by_chain=True)
    samples_flat = mcmc.get_samples(group_by_chain=False)
    diagnostics = summary(samples_chain, group_by_chain=True)
    finite = {name: bool(np.isfinite(np.asarray(value)).all()) for name, value in samples_flat.items()}
    scalar_diagnostics = [value for name, value in diagnostics.items() if name != "mean_reports"]
    max_rhat = max(float(np.nanmax(np.asarray(value["r_hat"]))) for value in scalar_diagnostics)
    min_bulk_ess = min(float(np.nanmin(np.asarray(value["n_eff"]))) for value in scalar_diagnostics)
    extra = mcmc.get_extra_fields(group_by_chain=True)
    divergences = int(np.asarray(extra["diverging"]).sum())
    num_steps = np.asarray(extra["num_steps"])
    max_tree_depth_events = int((num_steps >= (2**max_tree_depth - 1)).sum())

    def interval(name: str, truth: float) -> dict[str, float | bool]:
        values = np.asarray(samples_flat[name]).reshape(-1)
        low, median, high = np.quantile(values, [0.05, 0.5, 0.95])
        return {
            "truth": truth,
            "q05": float(low),
            "median": float(median),
            "q95": float(high),
            "truth_in_90pct_interval": bool(low <= truth <= high),
        }

    recovery = {"mu": interval("mu", true_mu), "phi": interval("phi", true_phi)}
    checks = {
        "posterior_finite": all(finite.values()),
        "zero_divergences": divergences == 0,
        "rhat_below_1_20": max_rhat < 1.20,
        "bulk_ess_above_20": min_bulk_ess > 20,
        "nb2_mean_parameterization_relative_error_below_2pct": mean_parameterization_relative_error < 0.02,
        "mu_recovered_in_90pct_interval": recovery["mu"]["truth_in_90pct_interval"],
        "phi_recovered_in_90pct_interval": recovery["phi"]["truth_in_90pct_interval"],
    }
    report = {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "result_scope": "ENGINEERING_PILOT_NOT_FORMAL",
        "formal_results": False,
        "model": "static hierarchical NB2 reference; no HSMM",
        "parameterization": "Y~NegativeBinomial2(mean=M*exp(mu+alpha_drug+beta_event+b_pair), concentration=phi)",
        "seed": seed,
        "observations": int(len(y)),
        "chains": 2,
        "warmup_per_chain": 200,
        "samples_per_chain": 250,
        "runtime_seconds": runtime,
        "jax_backend": jax.default_backend(),
        "jax_devices": [str(device) for device in jax.devices()],
        "platform": platform.platform(),
        "divergences": divergences,
        "max_tree_depth_events": max_tree_depth_events,
        "max_rhat": max_rhat,
        "min_bulk_ess": min_bulk_ess,
        "posterior_finite_by_site": finite,
        "selected_parameter_recovery": recovery,
        "nb2_mean_parameterization_test": {
            "target_mean": test_mean,
            "empirical_mean": empirical_mean,
            "relative_error": mean_parameterization_relative_error,
            "draws": 200_000,
        },
        "checks": checks,
        "phase3_boundary": {
            "explicit_duration_hsmm": "NOT_IMPLEMENTED",
            "posterior_state_inference": "NOT_RUN",
            "formal_simulation": "NOT_RUN",
            "temporal_validation": "NOT_RUN",
        },
    }
    (results / "38_PHASE2_REFERENCE_MODEL_SMOKE.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"status": report["status"], "runtime_seconds": runtime, "checks": checks}, indent=2))


if __name__ == "__main__":
    main()
