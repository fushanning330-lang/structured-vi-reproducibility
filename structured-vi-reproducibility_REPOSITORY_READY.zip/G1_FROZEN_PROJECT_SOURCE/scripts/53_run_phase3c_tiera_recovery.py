from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter
from typing import Any

import jax
import numpy as np
import pandas as pd
import yaml
from jax import random

from dhbcp_pv.evaluation.metrics import state_metrics
from dhbcp_pv.inference.posterior_integration import (
    integrate_posterior_outputs,
    posterior_parameter_summary,
)
from dhbcp_pv.inference.structured_svi import (
    SVIConfig,
    run_structured_svi,
    sample_structured_posterior,
    structured_covariance_diagnostics,
)
from dhbcp_pv.models.full_joint_model import reconstruct_x
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_a_replicate


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, allow_nan=False, sort_keys=True) + "\n")
    os.replace(temporary, path)


def write_csv(path: Path, rows: list[dict[str, Any]], columns: list[str] | None = None) -> None:
    frame = pd.DataFrame(rows)
    if columns is not None:
        frame = frame.reindex(columns=columns)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    os.replace(temporary, path)


def tree_hash(root: Path) -> str:
    digest = hashlib.sha256()
    rows = []
    for directory in ("src", "scripts", "tests"):
        for path in sorted((root / directory).rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            rows.append((path.relative_to(root).as_posix(), sha256(path)))
    for name, value in sorted(rows):
        digest.update(f"{name}\0{value}\n".encode())
    return digest.hexdigest()


def source_hash_is_authorized(root: Path, freeze: dict[str, Any], actual: str) -> bool:
    if actual == freeze["source_tree_sha256"]:
        return True
    resume_path = root / "results/phase3c/PHASE3C_RESUME_VERIFICATION.json"
    if not resume_path.exists():
        return False
    resume = json.loads(resume_path.read_text())
    return bool(
        resume.get("passed")
        and resume.get("pre_amendment_source_tree_sha256") == freeze["source_tree_sha256"]
        and resume.get("post_amendment_source_tree_sha256") == actual
        and resume.get("compute_amendment_only")
        and not resume.get("scientific_target_changed")
        and not resume.get("thresholds_changed")
    )


def parse_ids(specification: str) -> list[int]:
    values = []
    for item in specification.split(","):
        if "-" in item:
            start, stop = map(int, item.split("-", 1))
            values.extend(range(start, stop + 1))
        else:
            values.append(int(item))
    values = sorted(set(values))
    if not values or min(values) < 1 or max(values) > 100:
        raise ValueError("Tier A replicate IDs must be in 1..100")
    return values


def correlation(truth: np.ndarray, estimate: np.ndarray) -> float:
    if np.std(truth) == 0 or np.std(estimate) == 0:
        return 0.0
    return float(np.corrcoef(truth, estimate)[0, 1])


def vi_gate_passed(root: Path) -> bool:
    path = root / "results/phase3c/89_PHASE3C_VI_VS_NUTS.csv"
    if not path.exists():
        return False
    frame = pd.read_csv(path)
    if set(frame.cutoff.astype(int)) != {12, 24, 40}:
        return False
    later = frame[frame.cutoff.isin([24, 40])]
    if not bool(later.passed.all()):
        return False
    early = frame[frame.cutoff == 12]
    failed = early[~early.passed]
    if failed.empty:
        return True
    ranking = {"Delta_spearman", "Delta_top10_jaccard"}
    return (
        len(failed) == 1
        and failed.iloc[0].metric not in ranking
        and bool(failed.iloc[0].marginal_fail_within_10pct)
    )


def selected_config(root: Path) -> tuple[SVIConfig, int]:
    payload = yaml.safe_load((root / "results/phase3c/84_PHASE3C_SELECTED_SVI_CONFIG.yaml").read_text())
    row = payload["selected_schedule"]
    return SVIConfig(
        learning_rate=float(row["learning_rate"]),
        max_steps=int(row["max_steps"]),
        minimum_steps=int(row["minimum_steps"]),
        early_stop_patience=int(row["early_stop_patience"]),
        relative_tolerance=float(row["relative_tolerance"]),
        gradient_clip_norm=float(row["gradient_clip_norm"]),
        num_elbo_particles=int(row["elbo_particles"]),
    ), int(payload["posterior_draws_primary"])


def run_one(replicate_id: int, seed: int, root: Path) -> dict[str, Any]:
    started = perf_counter()
    replicate = generate_tier_a_replicate(seed, n_quarters=40)
    config, posterior_draws = selected_config(root)
    svi = run_structured_svi(
        random.PRNGKey(seed),
        replicate.y,
        replicate.serious,
        replicate.expected,
        replicate.drug_index,
        replicate.event_index,
        18,
        9,
        hmax=12,
        config=config,
    )
    if not svi.finite or svi.nonfinite_gradient_or_loss_steps:
        raise FloatingPointError("Phase3C Tier A SVI failed its numerical contract")
    samples = sample_structured_posterior(
        random.PRNGKey(seed + 1_000_000),
        svi.params,
        replicate.y,
        replicate.serious,
        replicate.expected,
        replicate.drug_index,
        replicate.event_index,
        18,
        9,
        num_samples=posterior_draws,
        hmax=12,
    )
    integrated = integrate_posterior_outputs(
        samples,
        replicate.y,
        replicate.serious,
        replicate.drug_index,
        replicate.event_index,
        18,
        9,
        hmax=12,
    )
    paths = np.asarray(jax.vmap(reconstruct_x)(samples["x_initial"], samples["base_increment"]))
    x_mean = paths.mean(axis=0)
    x_q025 = np.quantile(paths, 0.025, axis=0)
    x_q975 = np.quantile(paths, 0.975, axis=0)
    raw_drug = np.asarray(samples["raw_drug"])
    raw_event = np.asarray(samples["raw_event"])
    alpha = np.asarray(samples["sigma_drug"])[:, None] * (
        raw_drug - raw_drug.mean(axis=1, keepdims=True)
    )
    beta = np.asarray(samples["sigma_event"])[:, None] * (
        raw_event - raw_event.mean(axis=1, keepdims=True)
    )
    pair_effect = np.asarray(samples["sigma_pair"])[:, None] * np.asarray(samples["raw_pair"])
    raw_serious_drug = np.asarray(samples["raw_serious_drug"])
    raw_serious_event = np.asarray(samples["raw_serious_event"])
    serious_drug = np.asarray(samples["sigma_serious_drug"])[:, None] * (
        raw_serious_drug - raw_serious_drug.mean(axis=1, keepdims=True)
    )
    serious_event = np.asarray(samples["sigma_serious_event"])[:, None] * (
        raw_serious_event - raw_serious_event.mean(axis=1, keepdims=True)
    )
    pair_index = np.repeat(np.arange(162), 40)
    change = np.repeat(replicate.true_change_quarter, 40)
    state_values = state_metrics(
        replicate.true_state.reshape(-1),
        replicate.true_x.reshape(-1),
        integrated.state_probability.reshape(-1, 4),
        integrated.x_mean.reshape(-1),
        integrated.x_sd.reshape(-1),
        integrated.p_persist_h2.reshape(-1),
        integrated.p_change.reshape(-1),
        pair_index,
        change,
    )
    scalar_truth: dict[tuple[str, int], float] = {
        ("mu", 0): float(replicate.truth["mu"]),
        ("sigma_drug", 0): float(replicate.truth["sigma_drug"]),
        ("sigma_event", 0): float(replicate.truth["sigma_event"]),
        ("sigma_pair", 0): float(replicate.truth["sigma_pair"]),
        ("phi", 0): float(replicate.truth["phi"]),
        ("delta_emerging", 0): float(np.asarray(replicate.truth["drift"])[1]),
        ("delta_persistent", 0): float(np.asarray(replicate.truth["drift"])[2]),
        ("delta_waning_magnitude", 0): float(-np.asarray(replicate.truth["drift"])[3]),
        ("emerging_to_persistent_probability", 0): float(replicate.truth["emerging_to_persistent_probability"]),
        ("gamma0", 0): float(replicate.truth["gamma0"]),
        ("gamma_x", 0): float(replicate.truth["gamma_x"]),
        ("sigma_serious_drug", 0): float(replicate.truth["sigma_serious_drug"]),
        ("sigma_serious_event", 0): float(replicate.truth["sigma_serious_event"]),
    }
    for name in ("dynamic_sd", "duration_means", "duration_shapes"):
        for index, value in enumerate(np.asarray(replicate.truth[name])):
            scalar_truth[(name, index)] = float(value)
    for index, value in enumerate(np.asarray(replicate.truth["gamma_state"])[1:]):
        scalar_truth[("gamma_nonbackground", index)] = float(value)
    parameter_rows = []
    for row in posterior_parameter_summary(samples):
        key = (str(row["parameter"]), int(row["index"]))
        if key not in scalar_truth:
            continue
        truth = scalar_truth[key]
        sd = max(float(row["sd"]), 1e-12)
        parameter_rows.append({
            **row,
            "replicate_id": replicate_id,
            "seed": seed,
            "truth": truth,
            "error": float(row["mean"]) - truth,
            "absolute_standardized_error": abs(float(row["mean"]) - truth) / sd,
            "covered_95": bool(float(row["q025"]) <= truth <= float(row["q975"])),
        })
    summary = {
        "replicate_id": replicate_id,
        "seed": seed,
        "status": "COMPLETE",
        "svi_initial_loss": svi.initial_loss,
        "svi_terminal_loss": svi.terminal_loss,
        "svi_steps": svi.steps,
        "svi_convergence_code": svi.convergence_code,
        "svi_site_coverage": svi.site_coverage_passed,
        "x_rmse": float(np.sqrt(np.mean((x_mean - replicate.true_x) ** 2))),
        "x_interval_coverage": float(np.mean(
            (replicate.true_x >= x_q025) & (replicate.true_x <= x_q975)
        )),
        "alpha_drug_correlation": correlation(np.asarray(replicate.truth["alpha_drug"]), alpha.mean(axis=0)),
        "beta_event_correlation": correlation(np.asarray(replicate.truth["beta_event"]), beta.mean(axis=0)),
        "b_pair_correlation": correlation(np.asarray(replicate.truth["b_pair"]), pair_effect.mean(axis=0)),
        "serious_drug_correlation": correlation(np.asarray(replicate.truth["serious_drug"]), serious_drug.mean(axis=0)),
        "serious_event_correlation": correlation(np.asarray(replicate.truth["serious_event"]), serious_event.mean(axis=0)),
        **{f"state_{name}": value for name, value in state_values.items()},
        "wall_clock_seconds": perf_counter() - started,
        "svi_seconds": svi.wall_clock_seconds,
        "posterior_draws": posterior_draws,
        "guide_covariance": structured_covariance_diagnostics(svi.params),
    }
    return {
        "version": "phase3c_tiera_checkpoint_v1",
        "summary": summary,
        "parameter_rows": parameter_rows,
    }


def parameter_label(parameter: str, index: int) -> str:
    return parameter if index == 0 and parameter not in {"dynamic_sd", "duration_means"} else f"{parameter}[{index}]"


def aggregate(root: Path) -> None:
    result = root / "results/phase3c"
    paths = sorted((result / "checkpoints/tiera").glob("replicate_[0-9][0-9][0-9].json"))
    checkpoints = [json.loads(path.read_text()) for path in paths]
    if len(checkpoints) != 100:
        raise SystemExit(f"expected 100 accounted checkpoints, found {len(checkpoints)}")
    ids = sorted(int(item["summary"]["replicate_id"]) for item in checkpoints)
    if ids != list(range(1, 101)):
        raise SystemExit("Phase3C Tier A replicate IDs are not exactly 1..100")
    summaries = [item["summary"] for item in checkpoints]
    summary_rows = []
    for row in summaries:
        row = dict(row)
        covariance = row.pop("guide_covariance", None)
        row["guide_covariance_min_eigenvalue"] = (
            covariance["minimum_covariance_eigenvalue"] if covariance else None
        )
        summary_rows.append(row)
    write_csv(result / "90_PHASE3C_TIERA_RECOVERY_SUMMARY.csv", summary_rows)

    parameter_rows = [row for item in checkpoints for row in item["parameter_rows"]]
    parameter_frame = pd.DataFrame(parameter_rows)
    aggregate_parameters = []
    for (parameter, index), group in parameter_frame.groupby(["parameter", "index"], sort=True):
        aggregate_parameters.append({
            "parameter": parameter,
            "index": int(index),
            "parameter_label": parameter_label(str(parameter), int(index)),
            "truth": float(group.truth.iloc[0]),
            "posterior_mean_mean": float(group["mean"].mean()),
            "bias": float(group.error.mean()),
            "rmse": float(np.sqrt(np.mean(np.square(group.error)))),
            "median_absolute_standardized_error": float(group.absolute_standardized_error.median()),
            "coverage_95": float(group.covered_95.sum() / 100.0),
            "complete_replicates": int(group.replicate_id.nunique()),
            "accounted_replicates_denominator": 100,
        })
    write_csv(result / "91_PHASE3C_TIERA_PARAMETER_RECOVERY.csv", aggregate_parameters)

    gate_path = root / "config/phase3c_acceptance_gates_v1.yaml"
    gate_config = yaml.safe_load(gate_path.read_text())["tiera_recovery"]
    thresholds = gate_config["gates"]
    critical = set(gate_config["critical_scalar_parameters"])
    critical_rows = [row for row in aggregate_parameters if row["parameter_label"] in critical]
    if len(critical_rows) != len(critical):
        missing = sorted(critical.difference(row["parameter_label"] for row in critical_rows))
        raise RuntimeError(f"critical recovery rows missing: {missing}")
    complete = [row for row in summaries if row["status"] == "COMPLETE"]
    coverage = [float(row["coverage_95"]) for row in critical_rows]
    standardized = [float(row["median_absolute_standardized_error"]) for row in critical_rows]
    def med(column: str) -> float:
        return float(np.median([float(row[column]) for row in complete])) if complete else float("nan")
    values = {
        "replicates_accounted_for": len(summaries),
        "replicates_complete": len(complete),
        "median_95pct_coverage_across_critical_scalars": float(np.median(coverage)),
        "any_critical_scalar_95pct_coverage": float(np.min(coverage)),
        "median_absolute_standardized_error_across_critical_scalars": float(np.median(standardized)),
        "any_critical_scalar_median_absolute_standardized_error": float(np.max(standardized)),
        "median_x_interval_coverage": med("x_interval_coverage"),
        "median_x_rmse": med("x_rmse"),
        "median_alpha_drug_truth_posterior_correlation": med("alpha_drug_correlation"),
        "median_beta_event_truth_posterior_correlation": med("beta_event_correlation"),
        "median_b_pair_truth_posterior_correlation": med("b_pair_correlation"),
        "median_serious_drug_truth_posterior_correlation": med("serious_drug_correlation"),
        "median_serious_event_truth_posterior_correlation": med("serious_event_correlation"),
    }
    flags = {
        "replicates_accounted_for": values["replicates_accounted_for"] == int(thresholds["replicates_accounted_for"]),
        "replicates_complete": values["replicates_complete"] == 100,
        "median_95pct_coverage_across_critical_scalars": values["median_95pct_coverage_across_critical_scalars"] >= float(thresholds["median_95pct_coverage_across_critical_scalars_min"]),
        "any_critical_scalar_95pct_coverage": values["any_critical_scalar_95pct_coverage"] >= float(thresholds["any_critical_scalar_95pct_coverage_min"]),
        "median_absolute_standardized_error_across_critical_scalars": values["median_absolute_standardized_error_across_critical_scalars"] <= float(thresholds["median_absolute_standardized_error_across_critical_scalars_max"]),
        "any_critical_scalar_median_absolute_standardized_error": values["any_critical_scalar_median_absolute_standardized_error"] <= float(thresholds["any_critical_scalar_median_absolute_standardized_error_max"]),
        "median_x_interval_coverage": values["median_x_interval_coverage"] >= float(thresholds["median_x_interval_coverage_min"]),
        "median_x_rmse": values["median_x_rmse"] <= float(thresholds["median_x_rmse_max"]),
        "median_alpha_drug_truth_posterior_correlation": values["median_alpha_drug_truth_posterior_correlation"] >= float(thresholds["median_alpha_drug_truth_posterior_correlation_min"]),
        "median_beta_event_truth_posterior_correlation": values["median_beta_event_truth_posterior_correlation"] >= float(thresholds["median_beta_event_truth_posterior_correlation_min"]),
        "median_b_pair_truth_posterior_correlation": values["median_b_pair_truth_posterior_correlation"] >= float(thresholds["median_b_pair_truth_posterior_correlation_min"]),
        "median_serious_drug_truth_posterior_correlation": values["median_serious_drug_truth_posterior_correlation"] >= float(thresholds["median_serious_drug_truth_posterior_correlation_min"]),
        "median_serious_event_truth_posterior_correlation": values["median_serious_event_truth_posterior_correlation"] >= float(thresholds["median_serious_event_truth_posterior_correlation_min"]),
    }
    atomic_json(result / "92_PHASE3C_RECOVERY_GATE.json", {
        "version": "phase3c_recovery_gate_v1",
        "threshold_source": {
            "path": gate_path.relative_to(root).as_posix(),
            "sha256": sha256(gate_path),
            "frozen_before_recovery": True,
        },
        "values": values,
        "pass_flags": flags,
        "passed": all(flags.values()),
        "failed_replicate_ids": [row["replicate_id"] for row in summaries if row["status"] != "COMPLETE"],
    })


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", default="1-100")
    parser.add_argument("--aggregate-only", action="store_true")
    parsed = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    result = root / "results/phase3c"
    freeze = json.loads((result / "82_PHASE3C_PROTOCOL_FREEZE.json").read_text())
    source_hash_now = tree_hash(root)
    if not source_hash_is_authorized(root, freeze, source_hash_now):
        raise SystemExit("Phase3C source is neither frozen nor an authorized resume amendment")
    if not vi_gate_passed(root):
        raise SystemExit("Tier A recovery is forbidden until the VI-vs-NUTS gate passes")
    if parsed.aggregate_only:
        aggregate(root)
        return
    seeds = pd.read_csv(root / "config/phase3c_tiera_seeds_v1.csv")
    checkpoint_dir = result / "checkpoints/tiera"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    for replicate_id in parse_ids(parsed.ids):
        output = checkpoint_dir / f"replicate_{replicate_id:03d}.json"
        if output.exists():
            print(f"Phase3C Tier A {replicate_id:03d}: CHECKPOINT_EXISTS", flush=True)
            continue
        seed = int(seeds.loc[seeds.replicate_id == replicate_id, "seed"].iloc[0])
        last_error = None
        payload = None
        for attempt in (1, 2):
            try:
                payload = run_one(replicate_id, seed, root)
                payload["summary"]["attempts"] = attempt
                break
            except Exception as error:  # deterministic retry and accounting
                last_error = f"{type(error).__name__}: {error}"
        if payload is None:
            payload = {
                "version": "phase3c_tiera_checkpoint_v1",
                "summary": {
                    "replicate_id": replicate_id,
                    "seed": seed,
                    "status": "FAILED",
                    "attempts": 2,
                    "exception": last_error,
                },
                "parameter_rows": [],
            }
        atomic_json(output, payload)
        print(f"Phase3C Tier A {replicate_id:03d}: {payload['summary']['status']}", flush=True)
    accounted = list(checkpoint_dir.glob("replicate_[0-9][0-9][0-9].json"))
    if len(accounted) == 100:
        aggregate(root)


if __name__ == "__main__":
    main()
