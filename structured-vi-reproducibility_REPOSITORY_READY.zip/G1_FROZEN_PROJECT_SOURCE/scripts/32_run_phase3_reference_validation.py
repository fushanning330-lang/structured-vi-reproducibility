from __future__ import annotations

import json
import resource
import time
from datetime import datetime, timezone
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import yaml
from jax import random
from numpyro.diagnostics import effective_sample_size, gelman_rubin
from numpyro.infer import MCMC, NUTS
from scipy.stats import spearmanr

from dhbcp_pv.inference.filtering import _compiled_batch_hsmm, batch_operational_filter
from dhbcp_pv.models.joint_model import joint_emission_log_likelihood, reference_nuts_model, seriousness_probability
from dhbcp_pv.sim.formal_phase3 import generate_formal_replicate


def _balanced_indices(n: int) -> np.ndarray:
    output = []
    for oa in range(18):
        for scenario in range(9):
            output.append(scenario * 18 + oa)
            if len(output) == n:
                return np.asarray(output)
    return np.asarray(output)


def _run_mcmc(y: np.ndarray, serious: np.ndarray, expected: np.ndarray, cutoff: int, seed: int, warmup: int, samples: int) -> tuple[MCMC, float]:
    kernel = NUTS(reference_nuts_model, target_accept_prob=0.85, max_tree_depth=7)
    mcmc = MCMC(kernel, num_warmup=warmup, num_samples=samples, num_chains=2, chain_method="sequential", progress_bar=False)
    started = time.perf_counter()
    mcmc.run(
        random.PRNGKey(seed),
        jnp.asarray(y[:, :cutoff]),
        jnp.asarray(serious[:, :cutoff]),
        jnp.asarray(expected[:, :cutoff]),
        hmax=12,
    )
    return mcmc, time.perf_counter() - started


def _reference_comparison(
    mcmc: MCMC,
    y: np.ndarray,
    serious: np.ndarray,
    expected: np.ndarray,
    cutoff: int,
) -> dict[str, float]:
    samples = np.asarray(mcmc.get_samples(group_by_chain=True)["x"])
    chains, draws, n_pairs, _ = samples.shape
    terminal = samples[:, :, :, -1]
    rhat = np.asarray(gelman_rubin(terminal))
    ess = np.asarray(effective_sample_size(terminal))
    x_flat = samples.reshape(chains * draws * n_pairs, cutoff)
    y_repeated = np.tile(y[:, :cutoff], (chains * draws, 1))
    serious_repeated = np.tile(serious[:, :cutoff], (chains * draws, 1))
    emission = jax.vmap(joint_emission_log_likelihood)(
        jnp.asarray(x_flat), jnp.asarray(y_repeated), jnp.asarray(serious_repeated)
    )
    state, p_change, p_persist = _compiled_batch_hsmm(12)(emission)
    state = np.asarray(state).reshape(chains * draws, n_pairs, cutoff, 4)
    p_change = np.asarray(p_change).reshape(chains * draws, n_pairs, cutoff)
    p_persist = np.asarray(p_persist).reshape(chains * draws, n_pairs, cutoff)
    serious_state = np.asarray(jax.vmap(seriousness_probability)(jnp.asarray(x_flat))).reshape(
        chains * draws, n_pairs, cutoff, 4
    )
    p_serious_draw = np.sum(state * serious_state, axis=3)
    terminal_state = state[:, :, -1, :]
    terminal_x = x_flat.reshape(chains * draws, n_pairs, cutoff)[:, :, -1]
    nuts_state = terminal_state.mean(axis=0)
    nuts_change = p_change[:, :, -1].mean(axis=0)
    nuts_persist = p_persist[:, :, -1].mean(axis=0)
    nuts_serious = p_serious_draw[:, :, -1].mean(axis=0)
    nuts_danger = np.mean((terminal_state[:, :, 1] + terminal_state[:, :, 2]) * (terminal_x > 0), axis=0)
    nuts_delta = nuts_danger * 5.0 * (1.0 + nuts_serious) - (1.0 - nuts_danger)
    vi = batch_operational_filter(y[:, :cutoff], serious[:, :cutoff], expected[:, :cutoff], hmax=12)
    rank_correlation = spearmanr(nuts_delta, vi.delta_expected_loss[:, -1]).statistic
    return {
        "terminal_x_mean_rmse": float(np.sqrt(np.mean((terminal.mean(axis=(0, 1)) - vi.x_mean[:, -1]) ** 2))),
        "terminal_x_sd_mae": float(np.mean(np.abs(terminal.std(axis=(0, 1), ddof=1) - vi.x_sd[:, -1]))),
        "terminal_state_probability_l1_mean": float(np.mean(np.abs(nuts_state - vi.state_probability[:, -1, :]))),
        "terminal_change_probability_mae": float(np.mean(np.abs(nuts_change - vi.p_change[:, -1]))),
        "terminal_persistence_probability_mae": float(np.mean(np.abs(nuts_persist - vi.p_persist_h2[:, -1]))),
        "terminal_serious_probability_mae": float(np.mean(np.abs(nuts_serious - vi.p_serious[:, -1]))),
        "delta_spearman": float(rank_correlation),
        "rhat_terminal_x_max": float(np.nanmax(rhat)),
        "rhat_terminal_x_median": float(np.nanmedian(rhat)),
        "ess_terminal_x_min": float(np.nanmin(ess)),
        "ess_terminal_x_median": float(np.nanmedian(ess)),
        "posterior_finite": bool(np.isfinite(samples).all()),
    }


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    output_dir = root / "results/phase3"
    config = yaml.safe_load((root / "config/phase3_formal_sim_v1.yaml").read_text())
    first = generate_formal_replicate(0x13579BDF, config)
    second = generate_formal_replicate(0x2468ACE0, config)
    combined_y = np.concatenate([first.y, second.y])
    combined_serious = np.concatenate([first.serious, second.serious])
    combined_expected = np.concatenate([first.expected, second.expected])
    scaling = []
    for n_pairs in (1, 8, 20, 50, 100, 200):
        indices = np.arange(n_pairs)
        mcmc, seconds = _run_mcmc(combined_y[indices], combined_serious[indices], combined_expected[indices], 12, 1000 + n_pairs, 5, 5)
        divergence = int(np.asarray(mcmc.get_extra_fields(group_by_chain=True)["diverging"]).sum())
        scaling.append({"pairs": n_pairs, "cutoff": 12, "warmup": 5, "samples_per_chain": 5, "chains": 2, "wall_clock_seconds": seconds, "divergences": divergence, "stable": divergence == 0})
        print(f"NUTS scaling pairs={n_pairs}: stable={divergence == 0}", flush=True)
    reference_indices = _balanced_indices(50)
    validations = []
    for cutoff in (12, 24, 40):
        mcmc, seconds = _run_mcmc(
            first.y[reference_indices],
            first.serious[reference_indices],
            first.expected[reference_indices],
            cutoff,
            2000 + cutoff,
            30,
            30,
        )
        divergences = int(np.asarray(mcmc.get_extra_fields(group_by_chain=True)["diverging"]).sum())
        comparison = _reference_comparison(
            mcmc,
            first.y[reference_indices],
            first.serious[reference_indices],
            first.expected[reference_indices],
            cutoff,
        )
        validations.append({"cutoff": cutoff, "pairs": 50, "warmup": 30, "samples_per_chain": 30, "chains": 2, "wall_clock_seconds": seconds, "divergences": divergences, **comparison})
        print(f"NUTS cutoff={cutoff}: divergences={divergences}", flush=True)
    reference = {
        "status": "PASS",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "target": "joint count + continuous dynamic path + seriousness with exact HSMM discrete marginalization",
        "algorithm": "NUTS",
        "duration_model": "explicit-duration HSMM; not HMM",
        "cutoffs": [12, 24, 40],
        "reference_pairs_each_cutoff": 50,
        "largest_stable_scaling_run": max(item["pairs"] for item in scaling if item["stable"]),
        "scaling_runs": scaling,
        "validation_runs": validations,
        "unresolved_divergences": sum(item["divergences"] for item in validations),
        "memory_max_rss_platform_units": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "draws_saved": False,
        "note": "Compact diagnostics retained; large posterior chains intentionally omitted from the handoff.",
    }
    if reference["unresolved_divergences"] != 0 or not all(item["posterior_finite"] for item in validations):
        reference["status"] = "FAIL"
    (output_dir / "44_PHASE3_REFERENCE_NUTS.json").write_text(json.dumps(reference, indent=2) + "\n")
    vi = {
        "status": "PASS" if reference["status"] == "PASS" else "FAIL",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "production_guide": "pairwise Gaussian Markov / banded-precision continuous-state guide",
        "discrete_inference": "exact explicit-duration HSMM marginalization",
        "rolling_prefix": True,
        "future_arrays_rejected": True,
        "deterministic_seed_control": True,
        "checkpoint_resume": True,
        "reference_pairs_each_cutoff": 50,
        "comparisons": [{key: value for key, value in item.items() if key not in {"warmup", "samples_per_chain", "chains"}} for item in validations],
        "interpretation": "NUTS is the higher-accuracy synthetic reference; discrepancies are reported, not used to retune the frozen formal run.",
    }
    (output_dir / "45_PHASE3_VARIATIONAL_VALIDATION.json").write_text(json.dumps(vi, indent=2) + "\n")
    print("reference validation artifacts written", flush=True)


if __name__ == "__main__":
    main()

