"""Q2 supplementary simulation — Module B executor V6.1 (synthetic Gaussian VI, Route A).

Artifact: Q2_simulation_module_b_V6_1.py
Frozen: 2026-08-23 (V6.1 analyzer/execution-governance repair). PRE-EXECUTION.
REAL execution REQUIRES a separate execution authorization and is NOT performed
here or in preflight.

V6.1 repairs vs V6 (V6 retained as historical artifact):
  (G3) OFFICIAL-OUTPUT FRESHNESS GUARD: before ANY fit_one, the executor checks
       results/q2_supplementary_simulation/module_b/; if ANY MB_*.json /
       MB_*.npz / module_b_manifest.json / module_b_batch_stopped.json already
       exists, it REFUSES TO START with
         OFFICIAL_OUTPUT_NOT_FRESH_ABORT
       No auto-resume, no overwrite, no rerun.
  (G4) PERSISTENCE NO-OVERWRITE: persist_run() raises
       EngineeringFailure("persistence_preexisting_identity", ...) if the
       identity's MB_*.json OR MB_*.npz already exists; persist_failure() raises
       if the MB_*.json already exists. Plain write_text/savez must never
       overwrite a prior identity.

V6 repairs retained (R1/R3/R6/R8):
  (R1) NumPyro SVI state-explicit API: `svi.step()` does NOT exist in NumPyro 0.21.0
       (verified by introspection: hasattr(SVI, 'step') == False). The loop now uses
         state, loss = svi.update(state)
       and `svi.get_params(state)` reads from the UPDATED state. Early-stopping
       checkpoint KL is computed from the UPDATED state params.
  (R3) Optimizer semantics corrected: NumPyro ClippedAdam performs ELEMENTWISE
       clipping (each |g_i| <= clip_norm), which is NOT the frozen V5 scientific
       spec of GLOBAL gradient-norm clip = 10. V6 uses
         tx = optax.chain(optax.clip_by_global_norm(10.0), optax.adam(0.003))
         OPTIMIZER = numpyro.optim.optax_to_numpyro(tx)
       The EXACT object passed to SVI is this chain. No numpyro.optim.ClippedAdam
       anywhere in the scientific path. (Environment: optax 0.2.8 compatible with
       jax 0.11.0 / numpyro 0.21.0 — verified by import + numerical hand-test:
       global norm 14.1421 -> 10.0000.)
  (R6) JAX x64 explicitly enabled BEFORE any JAX numerical construction:
         from jax import config; config.update("jax_enable_x64", True)
       Preflight asserts jax.config.x64_enabled and checks actual float64 dtype
       of m / U / B_q / Sigma_q / Sigma_star.
  (R8) Failure governance: ONE seed-matrix identity = at most ONE authorized
       attempt. If fit_one raises, an ENGINEERING_FAILED record is persisted
       (run_id/particles/optimizer_seed/target_id/target_seed/conditioning/
       trace_share/stage/exception_type/exception_message/status) and the batch
       STOPS (no replacement seed, no silent rerun, no auto-continue to 240).
       Human/ChatGPT adjudication decides whether evidence is still evaluable.

All V4/V5/V6 scientific design unchanged: guide q(z)=N(m, Sigma_q),
Sigma_q = B_q_AR1(rho_q, floor_q) + U_q U_q^T (AR1 + rank-4, well-specified);
P1 -> Trace_ELBO(num_particles=1), P4 -> num_particles=4; 12 cells x 20 seeds =
240 runs; R5/R10/R20 prefixes; MC Trace_ELBO drives gradients; analytic Gaussian
KL is checkpoint monitoring ONLY.

Environment: project .venv (jax 0.11.0, numpyro 0.21.0, optax 0.2.8).
"""

from __future__ import annotations

import json
from pathlib import Path

# ---------------------------------------------------------------------------
# (R6) JAX x64 MUST be enabled before any JAX numerical construction
# ---------------------------------------------------------------------------
from jax import config as jax_config
jax_config.update("jax_enable_x64", True)

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
import numpyro.distributions as dist
import optax
from numpyro.infer import SVI, Trace_ELBO
from numpyro.optim import optax_to_numpyro

from Q2_simulation_target_generator_V4 import (
    LATENT_DIM, RANK, AR1_BLOCK_DIM, AR1_N_BLOCKS, make_target, TARGET_MAP,
)
from Q2_simulation_metrics_V4 import (
    mean_vector_l2_error_to_target, covariance_error_to_target,
    analytic_gaussian_kl, low_rank_trace_share, component_relative_frobenius,
)

# ---------------------------------------------------------------------------
# frozen hyperparameters (must match Protocol Freeze V6 / Config V6)
# ---------------------------------------------------------------------------
OPT = {
    "lr": 0.003,
    "clip_norm": 10.0,          # GLOBAL gradient-norm clip (V5 scientific spec, frozen)
    "max_steps": 2000,
    "checkpoint_interval": 100,
    "min_early_stop_step": 500,  # no early stop before step 500
    "relative_tolerance": 1e-4,
    "patience": 5,               # counted by checkpoint
    "minimum_loss_reduction": 0.15,
}

# (R3) EXACT optimizer object passed into SVI: global-norm clip + Adam.
OPT_TX = optax.chain(
    optax.clip_by_global_norm(OPT["clip_norm"]),   # GLOBAL gradient-norm clipping
    optax.adam(OPT["lr"]),                          # Adam
)
OPTIMIZER = optax_to_numpyro(OPT_TX)

TARGET_SEEDS = {  # frozen in Q2_SIMULATION_TARGET_MATRIX.csv
    "T01": 70001, "T02": 70002, "T03": 70003,
    "T04": 70004, "T05": 70005, "T06": 70006,
}
PARTICLE_MAP = {"P1": 1, "P4": 4}


# ---------------------------------------------------------------------------
# (R8) failure governance
# ---------------------------------------------------------------------------
class EngineeringFailure(Exception):
    """Exception carrying the failure stage for the ENGINEERING_FAILED record."""

    def __init__(self, stage: str, message: str):
        super().__init__(message)
        self.stage = stage


def engineering_failure_record(row: dict, stage: str, exc: Exception) -> dict:
    """Build the frozen ENGINEERING_FAILED record for one identity.

    ONE identity = at most ONE authorized attempt; no replacement seed; no
    silent rerun. target_id resolution failure is itself an engineering
    failure (stage 'target_resolution').
    """
    conditioning = row["conditioning"]
    share = float(row["trace_share"])
    particles = row["particles"]
    optimizer_seed = int(row["seed"])
    try:
        target_id = next(k for k, v in TARGET_MAP.items() if v == (conditioning, share))
    except StopIteration:
        target_id = "UNRESOLVED"
    return {
        "run_id": f"MB_{target_id}_{particles}_{optimizer_seed:04d}",
        "particles": particles,
        "num_particles": PARTICLE_MAP.get(particles),
        "optimizer_seed": optimizer_seed,
        "target_id": target_id,
        "target_seed": TARGET_SEEDS.get(target_id),
        "conditioning": conditioning,
        "trace_share": share,
        "replicate_prefix": row.get("replicate_prefix", ""),
        "scenario": row.get("scenario", "synthetic_gaussian_vi"),
        "stage": stage,
        "exception_type": type(exc).__name__,
        "exception_message": str(exc),
        "status": "ENGINEERING_FAILED",
        "steps": 0,
    }


# ---------------------------------------------------------------------------
# well-specified guide / model (NumPyro), built per run via closures
# ---------------------------------------------------------------------------
def build_B_q_jnp(rho: jax.Array, floor: jax.Array, d: int = LATENT_DIM,
                  block_dim: int = AR1_BLOCK_DIM) -> jax.Array:
    """B_q AR1 block as JAX (differentiable): rho**|i-j| within blocks + floor*I."""
    n_blocks = d // block_dim
    rows, cols = [], []
    for b in range(n_blocks):
        s = b * block_dim
        for i in range(block_dim):
            for j in range(block_dim):
                rows.append(s + i); cols.append(s + j)
    i_idx = jnp.asarray(rows, dtype=jnp.int32)
    j_idx = jnp.asarray(cols, dtype=jnp.int32)
    vals = jnp.power(rho, jnp.abs(i_idx - j_idx).astype(jnp.float32))
    B = jnp.zeros((d, d))
    B = B.at[i_idx, j_idx].set(vals)
    B = B + floor * jnp.eye(d)
    return B


def make_model(Sigma_star: np.ndarray):
    """Per-run target p(z) = N(0, Sigma*) closure."""
    S = jnp.asarray(Sigma_star, dtype=jnp.float64)
    d = S.shape[0]

    def _model():
        numpyro.sample("z", dist.MultivariateNormal(jnp.zeros(d), covariance_matrix=S))
    return _model


def make_guide(U_init: np.ndarray, m_init: np.ndarray):
    """Per-run well-specified guide q(z)=N(m, Sigma_q), Sigma_q = B_q_AR1 + U U^T."""
    U0 = jnp.asarray(U_init, dtype=jnp.float64)
    m0 = jnp.asarray(m_init, dtype=jnp.float64)
    d = m0.shape[0]

    def _guide():
        m = numpyro.param("m", m0)
        raw_rho = numpyro.param("raw_rho", jnp.array(0.0))
        log_floor = numpyro.param("log_floor", jnp.array(0.0))
        U = numpyro.param("U", U0)
        rho = jnp.tanh(raw_rho)             # in (-1, 1)
        floor = jnp.exp(log_floor)          # > 0
        B = build_B_q_jnp(rho, floor, d)
        Sigma_q = B + U @ U.T
        Sigma_q = 0.5 * (Sigma_q + Sigma_q.T)  # enforce symmetry
        numpyro.sample("z", dist.MultivariateNormal(m, covariance_matrix=Sigma_q))
    return _guide


def _guide_to_covariance(params: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Reconstruct (m_q, B_q, U_q, Sigma_q) from NumPyro params (float64)."""
    m_q = np.asarray(params["m"], dtype=np.float64)
    rho = float(np.tanh(params["raw_rho"]))
    floor = float(np.exp(params["log_floor"]))
    U_q = np.asarray(params["U"], dtype=np.float64)
    B_q = np.asarray(build_B_q_jnp(jnp.tanh(params["raw_rho"]),
                                   jnp.exp(params["log_floor"])), dtype=np.float64)
    Sigma_q = B_q + U_q @ U_q.T
    return m_q, B_q, U_q, Sigma_q


# ---------------------------------------------------------------------------
# per-run fit (REAL execution path — not run in preflight)
# ---------------------------------------------------------------------------
def fit_one(row: dict) -> dict:
    """Fit exactly one seed-matrix row. Returns a per-run record.

    row keys: particles ('P1'/'P4'), conditioning, trace_share, seed (optimizer),
    replicate_prefix, scenario.

    (R1) NumPyro 0.21.0 state-explicit loop: state, loss = svi.update(state);
    checkpoint params always read from the UPDATED state.
    (R8) Any raised exception is wrapped in EngineeringFailure(stage, msg);
    the batch records ENGINEERING_FAILED and STOPS.
    """
    particles = PARTICLE_MAP[row["particles"]]
    conditioning = row["conditioning"]
    share = float(row["trace_share"])
    optimizer_seed = int(row["seed"])
    try:
        target_id = next(k for k, v in TARGET_MAP.items() if v == (conditioning, share))
    except StopIteration as e:
        raise EngineeringFailure("target_resolution", f"no frozen target for {conditioning}/{share}") from e
    try:
        target = make_target(conditioning, share, TARGET_SEEDS[target_id])
        Sigma_star = np.asarray(target["Sigma_star"], dtype=np.float64)
    except Exception as e:
        raise EngineeringFailure("target_construction", str(e)) from e

    rng = np.random.default_rng(optimizer_seed)
    U_init = rng.standard_normal((LATENT_DIM, RANK)) * 0.05
    m_init = rng.standard_normal(LATENT_DIM) * 0.05

    try:
        rng_key = jax.random.PRNGKey(optimizer_seed)
        svi = SVI(make_model(Sigma_star), make_guide(U_init, m_init),
                  OPTIMIZER,                 # (R3) exact optax global-clip+Adam chain
                  Trace_ELBO(num_particles=particles))
        state = svi.init(rng_key)
        loss_history = []
        best_loss = None
        patience_count = 0
        steps = 0
        for step in range(1, OPT["max_steps"] + 1):
            # (R1) state-explicit update; MC Trace_ELBO drives gradients
            state, loss = svi.update(state)
            steps = step
            # checkpoint-based monitoring ONLY, from UPDATED state
            if step >= OPT["min_early_stop_step"] and step % OPT["checkpoint_interval"] == 0:
                params = svi.get_params(state)
                m_q, B_q, U_q, Sigma_q = _guide_to_covariance(params)
                kl = analytic_gaussian_kl(m_q, Sigma_q, np.zeros(LATENT_DIM), Sigma_star)
                loss_history.append({"step": step, "mc_elbo_loss": float(loss), "analytic_kl": kl})
                if best_loss is None:
                    best_loss = kl; patience_count = 0
                else:
                    improvement = best_loss - kl
                    threshold = max(OPT["minimum_loss_reduction"],
                                    OPT["relative_tolerance"] * abs(best_loss))
                    if improvement >= threshold:
                        best_loss = kl; patience_count = 0
                    else:
                        patience_count += 1
                if patience_count >= OPT["patience"]:
                    break
    except Exception as e:
        raise EngineeringFailure("svi_run", str(e)) from e

    # final params from UPDATED state -> persisted artifacts + metrics
    params = svi.get_params(state)
    m_q, B_q, U_q, Sigma_q = _guide_to_covariance(params)
    L_q = U_q @ U_q.T
    rho = float(np.tanh(params["raw_rho"]))
    floor = float(np.exp(params["log_floor"]))

    record = {
        "run_id": f"MB_{target_id}_{row['particles']}_{optimizer_seed:04d}",
        "particles": row["particles"],
        "num_particles": particles,
        "optimizer_seed": optimizer_seed,
        "target_id": target_id,
        "target_seed": TARGET_SEEDS[target_id],
        "conditioning": conditioning,
        "trace_share": share,
        "replicate_prefix": row.get("replicate_prefix", ""),
        "scenario": row.get("scenario", "synthetic_gaussian_vi"),
        "status": "COMPLETED",
        "steps": steps,
        "rho": rho,
        "diagonal_floor": floor,
        "m_q": m_q,
        "U_q": U_q,
        "Sigma_q": Sigma_q,
        "B_q": B_q,
        "L_q": L_q,
        "known_target": {
            "mean_vector_l2_error_to_target": mean_vector_l2_error_to_target(m_q, np.zeros(LATENT_DIM)),
            "covariance_error_to_target": covariance_error_to_target(Sigma_q, Sigma_star),
            "analytic_gaussian_kl": analytic_gaussian_kl(m_q, Sigma_q, np.zeros(LATENT_DIM), Sigma_star),
        },
        "low_rank_trace_share": low_rank_trace_share(L_q, Sigma_q),
        "B_relative_frobenius_to_target": component_relative_frobenius(B_q, target["B_star"]),
        "L_relative_frobenius_to_target": component_relative_frobenius(L_q, target["U_star"] @ target["U_star"].T),
        "loss_history": loss_history,
        "dtype": str(Sigma_q.dtype),
        "shapes": {"m_q": list(m_q.shape), "U_q": list(U_q.shape),
                   "Sigma_q": list(Sigma_q.shape)},
    }
    return record


# ---------------------------------------------------------------------------
# persistence (G): one NPZ + one JSON per successful run; JSON-only for failures
# ---------------------------------------------------------------------------
def persist_run(record: dict, out_dir: Path) -> dict:
    """Persist ONE successful run (NPZ + JSON). (G4) NO OVERWRITE.

    Raises EngineeringFailure("persistence_preexisting_identity") if the
    identity's MB_*.json or MB_*.npz already exists.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    run_id = record["run_id"]
    npz_path = out_dir / f"{run_id}.npz"
    json_path = out_dir / f"{run_id}.json"
    if npz_path.exists() or json_path.exists():
        raise EngineeringFailure(
            "persistence_preexisting_identity",
            f"{run_id} already persisted: npz={npz_path.exists()} json={json_path.exists()} (no overwrite)")
    np.savez(npz_path,
             m_q=record["m_q"], U_q=record["U_q"], Sigma_q=record["Sigma_q"],
             B_q=record["B_q"], L_q=record["L_q"])
    meta = {k: v for k, v in record.items() if not isinstance(v, np.ndarray)}
    meta["m_q_shape"] = list(record["m_q"].shape)
    meta["U_q_shape"] = list(record["U_q"].shape)
    json_path.write_text(
        json.dumps(meta, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    return {"npz": str(npz_path), "json": str(json_path)}


def persist_failure(record: dict, out_dir: Path) -> dict:
    """Persist an ENGINEERING_FAILED record (JSON only; no NPZ). (G4) NO OVERWRITE.

    Raises EngineeringFailure("persistence_preexisting_identity") if the
    identity's MB_*.json already exists.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{record['run_id']}.json"
    if json_path.exists():
        raise EngineeringFailure(
            "persistence_preexisting_identity",
            f"{record['run_id']}.json already exists (no overwrite)")
    json_path.write_text(
        json.dumps(record, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    return {"json": str(json_path)}


# ---------------------------------------------------------------------------
# (G3) official-output freshness guard
# ---------------------------------------------------------------------------
def check_official_output_fresh(out_dir: Path) -> None:
    """Refuse to start if any official Module-B artifact already exists.

    Any MB_*.json / MB_*.npz / module_b_manifest.json /
    module_b_batch_stopped.json in the official module_b output directory ->
    OFFICIAL_OUTPUT_NOT_FRESH_ABORT. No auto-resume, no overwrite, no rerun.
    """
    out_dir = Path(out_dir)
    existing = []
    if out_dir.exists():
        for pat in ("MB_*.json", "MB_*.npz",
                    "module_b_manifest.json", "module_b_batch_stopped.json"):
            existing.extend(sorted(out_dir.glob(pat)))
    if existing:
        names = [p.name for p in existing[:10]]
        more = f" (+{len(existing) - 10} more)" if len(existing) > 10 else ""
        raise RuntimeError(
            f"OFFICIAL_OUTPUT_NOT_FRESH_ABORT: {len(existing)} pre-existing artifact(s) "
            f"in {out_dir}: {names}{more}")


# ---------------------------------------------------------------------------
# dry scheduler (B): proves 240 = 240, never 480
# ---------------------------------------------------------------------------
def build_dry_schedule(seed_matrix_csv: str | Path) -> dict:
    import csv
    rows = []
    with open(seed_matrix_csv, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r["module"] != "B":
                continue
            rows.append({
                "particles": r["particles"],
                "conditioning": r["conditioning"],
                "trace_share": r["trace_share"],
                "seed": int(r["seed"]),
                "replicate_prefix": r["replicate_prefix"],
                "scenario": r["scenario"],
            })
    unique = len({(r["particles"], r["conditioning"], r["trace_share"], r["seed"]) for r in rows})
    return {
        "planned_identities": len(rows),
        "unique_identities": unique,
        "executed_if_authorized": len(rows),
        "rows": rows,
    }


def main() -> None:
    """REAL Module B batch — REQUIRES execution authorization. NOT run in preflight.

    (G3) Official-output freshness guard runs FIRST: any pre-existing MB_* /
    manifest / batch-stopped artifact -> OFFICIAL_OUTPUT_NOT_FRESH_ABORT before
    any fit (no auto-resume, no overwrite, no rerun).
    (R8) Batch policy: iterate the dry schedule in frozen order; each identity is
    attempted at most once; on the first engineering failure persist the
    ENGINEERING_FAILED record and STOP the batch (no replacement seed, no silent
    rerun, no auto-continue) — await human/ChatGPT adjudication.
    """
    out = Path("results/q2_supplementary_simulation/module_b")
    check_official_output_fresh(out)   # (G3) refuse if official output not fresh
    schedule = build_dry_schedule("results/q2_supplementary_simulation/Q2_SIMULATION_SEED_MATRIX.csv")
    assert schedule["planned_identities"] == 240
    assert schedule["unique_identities"] == 240
    manifest = []
    for row in schedule["rows"]:
        try:
            rec = fit_one(row)
            persist_run(rec, out)
            manifest.append(rec["run_id"])
        except EngineeringFailure as e:
            fail = engineering_failure_record(row, e.stage, e)
            persist_failure(fail, out)
            (out / "module_b_batch_stopped.json").write_text(
                json.dumps({"artifact": "Q2_MODULE_B_BATCH_STOPPED_V6",
                            "reason": "engineering failure; batch stopped; await adjudication",
                            "failed_identity": fail}, indent=2, ensure_ascii=False, default=float),
                encoding="utf-8")
            print(f"BATCH STOPPED at identity {fail['run_id']} (stage={e.stage}); "
                  f"completed_before_stop={len(manifest)}")
            break
        except Exception as e:  # unexpected exception outside fit_one contract
            fail = engineering_failure_record(row, "fit_one_unknown", e)
            persist_failure(fail, out)
            (out / "module_b_batch_stopped.json").write_text(
                json.dumps({"artifact": "Q2_MODULE_B_BATCH_STOPPED_V6",
                            "reason": "unexpected exception; batch stopped; await adjudication",
                            "failed_identity": fail}, indent=2, ensure_ascii=False, default=float),
                encoding="utf-8")
            print(f"BATCH STOPPED at identity {fail['run_id']} (stage=fit_one_unknown); "
                  f"completed_before_stop={len(manifest)}")
            break
    (out / "module_b_manifest.json").write_text(
        json.dumps({"artifact": "Q2_MODULE_B_MANIFEST_V6",
                    "runs": manifest, "count": len(manifest)}, indent=2), encoding="utf-8")
    print(f"module_b batch manifest: {len(manifest)} completed runs -> {out}")


if __name__ == "__main__":
    main()
