"""Q2 supplementary simulation — Module B executor V4 (synthetic Gaussian VI, Route A).

Artifact: Q2_simulation_module_b_V4.py
Frozen: 2026-08-23 (V4 executor semantics repair). PRE-EXECUTION.
REAL execution REQUIRES a separate execution authorization and is NOT performed
here or in preflight.

V4 repairs vs V3 (V3 retained as historical artifact):
  (B) One seed-matrix row = one scientific run. Module B = 240 rows (12 cells x 20
      optimizer seeds). Each row supplies particles / conditioning / trace_share /
      optimizer_seed / replicate_prefix / scenario. particles P1 -> 1, P4 -> 4.
      conditioning+trace_share -> frozen target_id. Fit exactly once per row.
      Dry scheduler proves planned=240, unique=240, executed-if-authorized=240
      (never 480).
  (C) WELL-SPECIFIED guide: q(z) = N(m, Sigma_q) with
      Sigma_q = B_q_AR1 + U_q U_q^T  (same family as the target Sigma*), so the
      guide family CAN represent Sigma*. Parameters: m; raw_rho (tanh-transformed
      rho); log diagonal floor (exp-transformed); U rank-4. No deliberate
      misspecification to manufacture a reproducibility-vs-accuracy gap.
  (D) Autodiff gradients of the complete ELBO via NumPyro/JAX (no custom analytic
      gradients). A gradient sanity test compares autodiff vs central finite
      difference at engineering tolerance.
  (B2) Particle count truly enters the Monte Carlo gradient estimator:
      numpyro.infer.Trace_ELBO(num_particles=P) with P=1 (P1) or 4 (P4).
  (E) ClippedAdam with GLOBAL gradient-norm clipping (norm > 10 -> scale all
      gradients by 10/norm). Elementwise np.clip is removed.
  (F) Exact early stopping: evaluation ONLY at checkpoint multiples of 100; no
      early stop before step 500; meaningful improvement iff
        best_loss - current_loss >= max(minimum_loss_reduction,
                                        relative_tolerance * abs(best_loss))
      with minimum_loss_reduction=0.15, relative_tolerance=1e-4, patience=5
      (counted by checkpoint), max_steps=2000.
      DISTINCTION FROZEN: Monte-Carlo Trace_ELBO drives optimization gradients;
      analytic Gaussian KL is allowed ONLY as deterministic checkpoint monitoring,
      never as the optimization gradient.
  (G) Per-run persistence: one NPZ (arrays) + one JSON (metadata/metrics) per run.

Environment: project .venv (jax 0.11.0, numpyro 0.21.0) — frozen project stack.

Model/guide are built per-run via closures (no module-level global state) so each
run's target Sigma* and guide U init are independent and correct.
"""

from __future__ import annotations

import json
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
import numpyro.distributions as dist
from numpyro.infer import SVI, Trace_ELBO
from numpyro.optim import ClippedAdam

from Q2_simulation_target_generator_V4 import (
    LATENT_DIM, RANK, AR1_BLOCK_DIM, AR1_N_BLOCKS, make_target, TARGET_MAP,
)
from Q2_simulation_metrics_V4 import (
    mean_vector_l2_error_to_target, covariance_error_to_target,
    analytic_gaussian_kl, low_rank_trace_share, component_relative_frobenius,
)

# ---------------------------------------------------------------------------
# frozen hyperparameters (must match Protocol Freeze V4 / Config V4)
# ---------------------------------------------------------------------------
OPT = {
    "lr": 0.003,
    "clip_norm": 10.0,          # GLOBAL gradient norm clip (ClippedAdam)
    "max_steps": 2000,
    "checkpoint_interval": 100,
    "min_early_stop_step": 500,  # no early stop before step 500
    "relative_tolerance": 1e-4,
    "patience": 5,               # counted by checkpoint
    "minimum_loss_reduction": 0.15,
}

TARGET_SEEDS = {  # frozen in Q2_SIMULATION_TARGET_MATRIX.csv
    "T01": 70001, "T02": 70002, "T03": 70003,
    "T04": 70004, "T05": 70005, "T06": 70006,
}
PARTICLE_MAP = {"P1": 1, "P4": 4}


# ---------------------------------------------------------------------------
# well-specified guide / model (NumPyro), built per run via closures
# ---------------------------------------------------------------------------
def build_B_q_jnp(rho: jax.Array, floor: jax.Array, d: int = LATENT_DIM,
                  block_dim: int = AR1_BLOCK_DIM) -> jax.Array:
    """B_q AR1 block as JAX (differentiable): rho**|i-j| within blocks + floor*I."""
    n_blocks = d // block_dim
    rows, cols = [], []
    for b in range(n_blocks):
        s = b * block_dim
        for i in range(block_dim):
            for j in range(block_dim):
                rows.append(s + i); cols.append(s + j)
    i_idx = jnp.asarray(rows, dtype=jnp.int32)
    j_idx = jnp.asarray(cols, dtype=jnp.int32)
    vals = jnp.power(rho, jnp.abs(i_idx - j_idx).astype(jnp.float32))
    B = jnp.zeros((d, d))
    B = B.at[i_idx, j_idx].set(vals)
    B = B + floor * jnp.eye(d)
    return B


def make_model(Sigma_star: np.ndarray):
    """Per-run target p(z) = N(0, Sigma*) closure."""
    S = jnp.asarray(Sigma_star, dtype=jnp.float64)
    d = S.shape[0]

    def _model():
        numpyro.sample("z", dist.MultivariateNormal(jnp.zeros(d), covariance_matrix=S))
    return _model


def make_guide(U_init: np.ndarray, m_init: np.ndarray):
    """Per-run well-specified guide q(z)=N(m, Sigma_q), Sigma_q = B_q_AR1 + U U^T."""
    U0 = jnp.asarray(U_init, dtype=jnp.float64)
    m0 = jnp.asarray(m_init, dtype=jnp.float64)
    d = m0.shape[0]

    def _guide():
        m = numpyro.param("m", m0)
        raw_rho = numpyro.param("raw_rho", jnp.array(0.0))
        log_floor = numpyro.param("log_floor", jnp.array(0.0))
        U = numpyro.param("U", U0)
        rho = jnp.tanh(raw_rho)             # in (-1, 1)
        floor = jnp.exp(log_floor)          # > 0
        B = build_B_q_jnp(rho, floor, d)
        Sigma_q = B + U @ U.T
        Sigma_q = 0.5 * (Sigma_q + Sigma_q.T)  # enforce symmetry
        numpyro.sample("z", dist.MultivariateNormal(m, covariance_matrix=Sigma_q))
    return _guide


def _guide_to_covariance(params: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Reconstruct (m_q, B_q, U_q, Sigma_q) from NumPyro params (float64)."""
    m_q = np.asarray(params["m"], dtype=np.float64)
    rho = float(np.tanh(params["raw_rho"]))
    floor = float(np.exp(params["log_floor"]))
    U_q = np.asarray(params["U"], dtype=np.float64)
    B_q = np.asarray(build_B_q_jnp(jnp.tanh(params["raw_rho"]),
                                   jnp.exp(params["log_floor"])), dtype=np.float64)
    Sigma_q = B_q + U_q @ U_q.T
    return m_q, B_q, U_q, Sigma_q


# ---------------------------------------------------------------------------
# per-run fit (REAL execution path — not run in preflight)
# ---------------------------------------------------------------------------
def fit_one(row: dict) -> dict:
    """Fit exactly one seed-matrix row. Returns a per-run record.

    row keys: particles ('P1'/'P4'), conditioning, trace_share, seed (optimizer),
    replicate_prefix, scenario.
    """
    particles = PARTICLE_MAP[row["particles"]]
    conditioning = row["conditioning"]
    share = float(row["trace_share"])
    optimizer_seed = int(row["seed"])
    target_id = next(k for k, v in TARGET_MAP.items()
                     if v == (conditioning, share))
    target = make_target(conditioning, share, TARGET_SEEDS[target_id])
    Sigma_star = np.asarray(target["Sigma_star"], dtype=np.float64)

    rng = np.random.default_rng(optimizer_seed)
    U_init = rng.standard_normal((LATENT_DIM, RANK)) * 0.05
    m_init = rng.standard_normal(LATENT_DIM) * 0.05

    rng_key = jax.random.PRNGKey(optimizer_seed)
    svi = SVI(make_model(Sigma_star), make_guide(U_init, m_init),
              ClippedAdam(step_size=OPT["lr"], clip_norm=OPT["clip_norm"]),
              Trace_ELBO(num_particles=particles))
    state = svi.init(rng_key)
    loss_history = []
    best_loss = None
    patience_count = 0
    steps = 0
    for step in range(1, OPT["max_steps"] + 1):
        rng_key, step_key = jax.random.split(rng_key)
        loss = svi.step(step_key)  # MC Trace_ELBO (negative ELBO) drives gradients
        steps = step
        # checkpoint-based monitoring ONLY
        if step >= OPT["min_early_stop_step"] and step % OPT["checkpoint_interval"] == 0:
            params = svi.get_params(state)
            m_q, B_q, U_q, Sigma_q = _guide_to_covariance(params)
            kl = analytic_gaussian_kl(m_q, Sigma_q, np.zeros(LATENT_DIM), Sigma_star)
            loss_history.append({"step": step, "mc_elbo_loss": float(loss), "analytic_kl": kl})
            if best_loss is None:
                best_loss = kl; patience_count = 0
            else:
                improvement = best_loss - kl
                threshold = max(OPT["minimum_loss_reduction"],
                                OPT["relative_tolerance"] * abs(best_loss))
                if improvement >= threshold:
                    best_loss = kl; patience_count = 0
                else:
                    patience_count += 1
            if patience_count >= OPT["patience"]:
                break

    # final params -> persisted artifacts + metrics
    params = svi.get_params(state)
    m_q, B_q, U_q, Sigma_q = _guide_to_covariance(params)
    L_q = U_q @ U_q.T
    rho = float(np.tanh(params["raw_rho"]))
    floor = float(np.exp(params["log_floor"]))

    record = {
        "run_id": f"MB_{target_id}_{row['particles']}_{optimizer_seed:04d}",
        "particles": row["particles"],
        "num_particles": particles,
        "optimizer_seed": optimizer_seed,
        "target_id": target_id,
        "target_seed": TARGET_SEEDS[target_id],
        "conditioning": conditioning,
        "trace_share": share,
        "replicate_prefix": row.get("replicate_prefix", ""),
        "scenario": row.get("scenario", "synthetic_gaussian_vi"),
        "status": "COMPLETED",
        "steps": steps,
        "rho": rho,
        "diagonal_floor": floor,
        "m_q": m_q,
        "U_q": U_q,
        "Sigma_q": Sigma_q,
        "B_q": B_q,
        "L_q": L_q,
        "known_target": {
            "mean_vector_l2_error_to_target": mean_vector_l2_error_to_target(m_q, np.zeros(LATENT_DIM)),
            "covariance_error_to_target": covariance_error_to_target(Sigma_q, Sigma_star),
            "analytic_gaussian_kl": analytic_gaussian_kl(m_q, Sigma_q, np.zeros(LATENT_DIM), Sigma_star),
        },
        "low_rank_trace_share": low_rank_trace_share(L_q, Sigma_q),
        "B_relative_frobenius_to_target": component_relative_frobenius(B_q, target["B_star"]),
        "L_relative_frobenius_to_target": component_relative_frobenius(L_q, target["U_star"] @ target["U_star"].T),
        "loss_history": loss_history,
        "dtype": str(Sigma_q.dtype),
        "shapes": {"m_q": list(m_q.shape), "U_q": list(U_q.shape),
                   "Sigma_q": list(Sigma_q.shape)},
    }
    return record


# ---------------------------------------------------------------------------
# persistence (G): one NPZ + one JSON per run
# ---------------------------------------------------------------------------
def persist_run(record: dict, out_dir: Path) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    run_id = record["run_id"]
    np.savez(out_dir / f"{run_id}.npz",
             m_q=record["m_q"], U_q=record["U_q"], Sigma_q=record["Sigma_q"],
             B_q=record["B_q"], L_q=record["L_q"])
    meta = {k: v for k, v in record.items() if not isinstance(v, np.ndarray)}
    meta["m_q_shape"] = list(record["m_q"].shape)
    meta["U_q_shape"] = list(record["U_q"].shape)
    (out_dir / f"{run_id}.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    return {"npz": str(out_dir / f"{run_id}.npz"), "json": str(out_dir / f"{run_id}.json")}


# ---------------------------------------------------------------------------
# dry scheduler (B): proves 240 = 240, never 480
# ---------------------------------------------------------------------------
def build_dry_schedule(seed_matrix_csv: str | Path) -> dict:
    import csv
    rows = []
    with open(seed_matrix_csv, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r["module"] != "B":
                continue
            rows.append({
                "particles": r["particles"],
                "conditioning": r["conditioning"],
                "trace_share": r["trace_share"],
                "seed": int(r["seed"]),
                "replicate_prefix": r["replicate_prefix"],
                "scenario": r["scenario"],
            })
    unique = len({(r["particles"], r["conditioning"], r["trace_share"], r["seed"]) for r in rows})
    return {
        "planned_identities": len(rows),
        "unique_identities": unique,
        "executed_if_authorized": len(rows),
        "rows": rows,
    }


def main() -> None:
    """REAL Module B batch — REQUIRES execution authorization. NOT run in preflight."""
    from pathlib import Path
    out = Path("results/q2_supplementary_simulation/module_b")
    schedule = build_dry_schedule("results/q2_supplementary_simulation/Q2_SIMULATION_SEED_MATRIX.csv")
    assert schedule["planned_identities"] == 240
    assert schedule["unique_identities"] == 240
    manifest = []
    for row in schedule["rows"]:
        rec = fit_one(row)
        persist_run(rec, out)
        manifest.append(rec["run_id"])
    (out / "module_b_manifest.json").write_text(
        json.dumps({"artifact": "Q2_MODULE_B_MANIFEST_V4",
                    "runs": manifest, "count": len(manifest)}, indent=2), encoding="utf-8")
    print(f"module_b batch manifest: {len(manifest)} runs -> {out}")


if __name__ == "__main__":
    main()
