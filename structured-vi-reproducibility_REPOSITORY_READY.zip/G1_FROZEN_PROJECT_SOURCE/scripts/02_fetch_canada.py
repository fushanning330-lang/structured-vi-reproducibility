from __future__ import annotations
import csv, hashlib, urllib.request, zipfile
from datetime import datetime, timezone
from pathlib import Path

URL = "https://www.canada.ca/content/dam/hc-sc/migration/hc-sc/dhp-mps/alt_formats/zip/medeff/databasdon/extract_extrait.zip"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()

def main():
    root = Path(__file__).resolve().parents[1]
    raw = root / "data/raw/canada"
    raw.mkdir(parents=True, exist_ok=True)
    dest = raw / "extract_extrait.zip"
    if not dest.exists():
        part = dest.with_suffix(".zip.part")
        req = urllib.request.Request(URL, headers={"User-Agent": "DHBCP-PV-V2/0.1"})
        with urllib.request.urlopen(req, timeout=300) as r, part.open("wb") as f:
            while True:
                chunk = r.read(1024*1024)
                if not chunk:
                    break
                f.write(chunk)
        part.replace(dest)

    extract_dir = raw / "extract"
    if not extract_dir.exists():
        extract_dir.mkdir()
        with zipfile.ZipFile(dest) as z:
            z.extractall(extract_dir)

    manifest = root / "data/manifests/canada_download_manifest.csv"
    with manifest.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["url","retrieved_utc","bytes","sha256"])
        w.writeheader()
        w.writerow({
            "url": URL,
            "retrieved_utc": datetime.now(timezone.utc).isoformat(),
            "bytes": dest.stat().st_size,
            "sha256": sha256(dest),
        })
    print(dest)

if __name__ == "__main__":
    main()
