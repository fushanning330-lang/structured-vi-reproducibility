args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 4) stop("usage: run_pvebayes.R INPUT.csv OUTPUT.csv FAILURES.csv SEED")
.libPaths(c(Sys.getenv("R_LIBS_USER"), .libPaths()))
suppressPackageStartupMessages(library(pvEBayes))
input_path <- args[[1]]
output_path <- args[[2]]
failure_path <- args[[3]]
seed <- as.integer(args[[4]])
y <- as.matrix(read.csv(input_path, check.names = FALSE))
if (nrow(y) != 162) stop("expected 162 pair rows")
n_quarters <- ncol(y)
drug_index <- rep(0:17, each = 9)
event_index <- rep(0:8, times = 18)
cumulative <- matrix(0, nrow = 9, ncol = 18)
rows <- list()
failures <- list()
for (quarter in seq_len(n_quarters)) {
  for (pair in seq_len(162)) {
    cumulative[event_index[[pair]] + 1, drug_index[[pair]] + 1] <-
      cumulative[event_index[[pair]] + 1, drug_index[[pair]] + 1] + y[pair, quarter]
  }
  result <- tryCatch({
    set.seed(seed + quarter)
    fit <- pvEBayes(
      cumulative,
      model = "GPS",
      n_posterior_draws = 64,
      message = FALSE
    )
    probability <- as.matrix(get_posterior_prob(fit, cutoff_signal = 1.001))
    data.frame(
      pair_index = seq_len(162) - 1,
      quarter = quarter,
      score = probability[cbind(event_index + 1, drug_index + 1)],
      alert = probability[cbind(event_index + 1, drug_index + 1)] >= 0.95
    )
  }, error = function(e) {
    failures[[length(failures) + 1]] <<- data.frame(
      quarter = quarter,
      code = "PVEBAYES_PREFIX_FAILURE",
      detail = conditionMessage(e)
    )
    data.frame(
      pair_index = seq_len(162) - 1,
      quarter = quarter,
      score = NA_real_,
      alert = FALSE
    )
  })
  rows[[quarter]] <- result
}
write.csv(do.call(rbind, rows), output_path, row.names = FALSE)
if (length(failures)) {
  write.csv(do.call(rbind, failures), failure_path, row.names = FALSE)
} else {
  write.csv(data.frame(quarter=integer(), code=character(), detail=character()), failure_path, row.names = FALSE)
}
