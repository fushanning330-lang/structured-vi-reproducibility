#!/usr/bin/env python3
"""Isolated official MDDC 1.1.0 prefix runner.

Input is a NumPy ``.npz`` with ``y[pair,quarter]``, ``drug_index`` and
``event_index``.  Output contains pair-major scores/alerts for every prefix.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
from joblib import parallel_config

os.environ.setdefault("MPLCONFIGDIR", "/private/tmp/phase3b_mddc_mpl")
from MDDC.MDDC import mddc  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    data = np.load(args.input)
    y = np.asarray(data["y"], dtype=int)
    drug = np.asarray(data["drug_index"], dtype=int)
    event = np.asarray(data["event_index"], dtype=int)
    n_pairs, n_quarters = y.shape
    score = np.full((n_pairs, n_quarters), np.nan)
    alert = np.zeros((n_pairs, n_quarters), dtype=bool)
    failures: list[dict[str, object]] = []
    cumulative = np.zeros((9, 18), dtype=int)
    for quarter in range(n_quarters):
        cumulative[event, drug] += y[:, quarter]
        try:
            with parallel_config(backend="threading", n_jobs=1):
                result = mddc(
                    cumulative,
                    method="boxplot",
                    col_specific_cutoff=True,
                    separate=True,
                    if_col_corr=False,
                    corr_lim=0.8,
                    coef=1.5,
                    n_jobs=1,
                    seed=args.seed + quarter,
                )
            adjusted = np.asarray(result.corr_signal_adj_pval, dtype=float)
            adjusted = np.nan_to_num(adjusted, nan=1.0, posinf=1.0, neginf=1.0)
            signal = np.asarray(result.signal, dtype=bool)
            score[:, quarter] = -np.log10(np.clip(adjusted[event, drug], 1e-300, 1.0))
            alert[:, quarter] = signal[event, drug]
        except Exception as exc:  # one bad prefix must not block later prefixes
            failures.append(
                {"quarter": quarter + 1, "code": "MDDC_PREFIX_FAILURE", "detail": repr(exc)}
            )
    metadata = {
        "package": "MDDC",
        "version": "1.1.0",
        "function": "MDDC.MDDC.mddc",
        "method": "boxplot",
        "coef": 1.5,
        "table_orientation": "9 adverse-event rows x 18 drug columns",
        "prefix_accumulation": True,
        "failures": failures,
    }
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.output, score=score, alert=alert, metadata=json.dumps(metadata))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
