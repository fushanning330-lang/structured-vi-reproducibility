from __future__ import annotations

import csv
import hashlib
import json
import os
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from dhbcp_pv.data import canada


URL = "https://www.canada.ca/content/dam/hc-sc/migration/hc-sc/dhp-mps/alt_formats/zip/medeff/databasdon/extract_extrait.zip"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    raw = root / "data/raw/canada"
    raw.mkdir(parents=True, exist_ok=True)
    destination = raw / "extract_extrait.zip"
    part = raw / "extract_extrait.zip.phase2.part"
    if part.exists():
        quarantine = raw / f"quarantine_pre_phase2_{int(part.stat().st_mtime)}.part"
        os.replace(part, quarantine)

    command = [
        "curl", "--http1.1", "--fail", "--location", "--silent", "--show-error",
        "--connect-timeout", "15", "--max-time", "120", "--speed-time", "30",
        "--speed-limit", "1024", "--user-agent", "DHBCP-PV-V2/0.1",
        "--output", str(part), URL,
    ]
    started = datetime.now(timezone.utc)
    completed = subprocess.run(command, capture_output=True, text=True, timeout=130, check=False)
    status = "FAILED_DOWNLOAD"
    error = completed.stderr.strip() or f"curl exit {completed.returncode}"
    archive_bytes = part.stat().st_size if part.exists() else 0
    archive_sha256 = sha256(part) if part.exists() and archive_bytes else ""
    schema_audit = None
    if completed.returncode == 0 and part.exists():
        try:
            with zipfile.ZipFile(part) as archive:
                bad_member = archive.testzip()
                if bad_member is not None:
                    raise RuntimeError(f"ZIP integrity failed at {bad_member}")
            os.replace(part, destination)
            archive_bytes = destination.stat().st_size
            archive_sha256 = sha256(destination)
            extract = raw / "extract"
            extract.mkdir(exist_ok=True)
            with zipfile.ZipFile(destination) as archive:
                archive.extractall(extract)
            schema_audit = canada.audit_headers(extract)
            status = "VERIFIED"
            error = ""
        except Exception as exception:
            error = f"post-download validation failed: {exception}"
    if status == "FAILED_DOWNLOAD" and part.exists():
        quarantine = raw / "quarantine_phase2_failed_download.part"
        os.replace(part, quarantine)

    finished = datetime.now(timezone.utc)
    report = {
        "status": status,
        "url": URL,
        "attempts_this_phase": 1,
        "bounded": True,
        "connect_timeout_seconds": 15,
        "max_time_seconds": 120,
        "low_speed_abort": {"seconds": 30, "bytes_per_second": 1024},
        "started_utc": started.isoformat(),
        "finished_utc": finished.isoformat(),
        "runtime_seconds": (finished - started).total_seconds(),
        "curl_exit_code": completed.returncode,
        "bytes": archive_bytes,
        "sha256": archive_sha256 or None,
        "zip_integrity": "PASS" if status == "VERIFIED" else "NOT_AVAILABLE",
        "schema_audit": schema_audit,
        "error": error,
        "blocks_phase2": False,
    }
    results = root / "results/phase2"
    results.mkdir(parents=True, exist_ok=True)
    (results / "canada_phase2_retry_status.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    manifest = root / "data/manifests/canada_phase2_retry_manifest.csv"
    with manifest.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["url", "status", "attempts", "retrieved_utc", "bytes", "sha256", "error"],
        )
        writer.writeheader()
        writer.writerow(
            {
                "url": URL,
                "status": status,
                "attempts": 1,
                "retrieved_utc": finished.isoformat(),
                "bytes": archive_bytes,
                "sha256": archive_sha256,
                "error": error,
            }
        )
    print(json.dumps({"status": status, "runtime_seconds": report["runtime_seconds"], "error": error}, indent=2))


if __name__ == "__main__":
    main()
