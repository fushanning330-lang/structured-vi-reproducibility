"""Phase3C.4 variational automation controller (scripts/62).

ORCHESTRATION / SUPERVISION ONLY. This file NEVER executes inference:
no SVI, no NUTS/HMC/MCMC, no pilot run, no optimization. It only:
  - monitors the pilot process (read-only),
  - validates frozen SHAs / authorization (29) bindings,
  - aggregates pilot result.json outputs,
  - classifies errors (non-scientific vs scientific gate),
  - advances the AUTOMATION_STATE.json state machine (append-only audit log).

State machine (25A / automation protocol):
  CURRENT_PILOT_RUNNING
      -> PILOT_COMPLETE
      -> G1_AUDIT
      -> G1_PASS | G1_FAIL
  G1_PASS -> G2_READY -> (G2 no-draws audit) ->
      G2_PASS_NO_DRAWS                  -> G3_PROTOCOL_READY -> (G3 design freeze)
                                          -> STOP_WAITING_FOR_G3_SAMPLING_AUTHORIZATION
      G2_PARTIAL_PASS_DRAWS_REQUIRED    -> STOP_G2_POSTERIOR_DRAW_AUTHORIZATION_REQUIRED
      G2_FAIL_REPLICATE_INSTABILITY     -> STOP_G2_REPLICATE_INSTABILITY
  G1_FAIL -> STOP_G1_FAILED                         (scientific gate, human review)
  any scientific failure -> SCIENTIFIC_GATE_FAILED_REQUIRES_REVIEW

Modes:
  --mode init      create AUTOMATION_STATE.json + audit log if missing
  --mode status    print current state + task registry
  --mode validate  verify 29 bindings + frozen SHAs against live files
  --mode advance   recompute state from filesystem conditions and transition
  --mode g1-audit  frozen G1 audit over pilot result.json (writes 30 if absent)
  --mode g2-audit  no-draws G2 replicate-stability analysis (writes 31)
  --mode g3-design freeze the G3 importance protocol design (writes 32; NO sampling)

G2/G3 NEVER generate posterior draws, never run sampling, never run inference.
All G2 metrics are computed exclusively from the saved 15-run artifacts
(result.json, checkpoint_history, factor_spectrum_history, block_budget_history).

This controller never modifies the scientific model, runner, guide, frozen
artifacts, or any pilot_runs output. It only writes inside
results/phase3c4/automation/.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUTOMATION_DIR = ROOT / "results" / "phase3c4" / "automation"
STATE_PATH = AUTOMATION_DIR / "AUTOMATION_STATE.json"
AUDIT_PATH = AUTOMATION_DIR / "AUTOMATION_AUDIT_LOG.jsonl"
PILOT_RUNS_DIR = ROOT / "results" / "phase3c4" / "pilot_runs"
RUNNER_PATH = ROOT / "scripts" / "61_run_phase3c_variational_v1_pilot.py"
GUIDE_PATH = ROOT / "src" / "dhbcp_pv" / "inference" / "v1_structured_lowrank_guide.py"
ART29_PATH = ROOT / "results" / "phase3c4" / "29_EXPLICIT_VARIATIONAL_PILOT_RUN_AUTHORIZATION.json"

G1_JSON = AUTOMATION_DIR / "30_VARIATIONAL_PILOT_G1_AUDIT.json"
G1_MD = AUTOMATION_DIR / "30_VARIATIONAL_PILOT_G1_AUDIT.md"
G2_JSON = AUTOMATION_DIR / "31_G2_REPLICATE_STABILITY.json"
G2_MD = AUTOMATION_DIR / "31_G2_REPLICATE_STABILITY.md"
G3_JSON = AUTOMATION_DIR / "32_G3_EXACT_TARGET_IMPORTANCE_PROTOCOL.json"
G3_MD = AUTOMATION_DIR / "32_G3_EXACT_TARGET_IMPORTANCE_PROTOCOL.md"

# Frozen identities (25A / 25B / 28D / 29).
FROZEN = {
    "runner_sha256": "db2ba5a31ccf79cc2b323950d093c987d5b3d0bf816b2a5045ffd30a9b795dcb",
    "guide_sha256": "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878",
    "art29_sha256": "072cdd1aedd48d3ff48064c6f3344317f816bca0935a2f45583a9cef3cdfa610",
    "run_matrix_identity_hash": "084a24559846a80d9f138dd3a968ef1bdb573f33a3951bffb6ff216fe0a56bed",
    "seeds": [1001, 2002, 3003, 4004, 5005],
    "total_runs": 15,
    "arms": {
        "ARM_A": {"role": "HISTORICAL FAMILY CONTROL", "num_particles": 1},
        "ARM_B": {"role": "ARCHITECTURE COMPARISON vs V0 at identical num_particles=1", "num_particles": 1},
        "ARM_C": {"role": "PARTICLE COMPARISON (V1 p=1 vs p=4)", "num_particles": 4},
    },
}

G1_THRESHOLD = {"min_loss_reduction_fraction": 0.15, "max_nonfinite_steps": 0, "required_seeds_per_arm": 5}

STATE_SEQUENCE = [
    "CURRENT_PILOT_RUNNING",
    "PILOT_COMPLETE",
    "G1_AUDIT",
    "G1_PASS",
    "G1_FAIL",
    "G2_READY",
    "G3_PROTOCOL_READY",
    "G3_READY",
    "G4_READY",
    "G5_READY",
    "SCIENTIFIC_USE_READY",
    "STOP_G1_FAILED",
    "SCIENTIFIC_GATE_FAILED_REQUIRES_REVIEW",
    "STOP_CONSUMED_RUN_REQUIRES_HUMAN_DECISION",
    "STOP_G2_REPLICATE_INSTABILITY",
    "STOP_G2_POSTERIOR_DRAW_AUTHORIZATION_REQUIRED",
    "STOP_WAITING_FOR_G3_SAMPLING_AUTHORIZATION",
]

TASK_REGISTRY = {
    "TASK1_CURRENT_PILOT_SUPERVISOR": {"artifact": "01_CURRENT_PILOT_SUPERVISOR.json", "status": "DONE"},
    "TASK2_EXECUTION_SPEED_AUDIT": {"artifact": "03_EXECUTION_SPEED_AUDIT.json/.md", "status": "DONE"},
    "TASK3_AUTOMATION_CONTROLLER": {"artifact": "scripts/62_phase3c_variational_automation_controller.py + AUTOMATION_STATE.json", "status": "IN_PROGRESS"},
    "TASK4_G1_AUDIT": {"artifact": "30_VARIATIONAL_PILOT_G1_AUDIT.json/.md", "status": "WAITING_PILOT_COMPLETE"},
    "TASK5_G2_REPLICATE_STABILITY": {"artifact": "31_G2_REPLICATE_STABILITY.json/.md", "status": "WAITING_G1_PASS"},
    "TASK6_G3_EXACT_TARGET_IMPORTANCE_PROTOCOL": {"artifact": "32_G3_EXACT_TARGET_IMPORTANCE_PROTOCOL.json", "status": "WAITING_G2_READY"},
    "TASK7_G4_SYNTHETIC_CALIBRATION_DESIGN": {"artifact": "33_G4_SYNTHETIC_CALIBRATION_DESIGN.json", "status": "WAITING_G3_READY"},
    "TASK8_G5_SMALL_REFERENCE_POSTERIOR_DESIGN": {"artifact": "34_G5_SMALL_REFERENCE_POSTERIOR_DESIGN.json", "status": "WAITING_G4_READY"},
}


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic_write(path: Path, obj) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


# ---------------------------------------------------------------- audit log
def audit(entry: dict) -> None:
    AUTOMATION_DIR.mkdir(parents=True, exist_ok=True)
    entry = {"ts": utc_now(), **entry}
    with open(AUDIT_PATH, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry, ensure_ascii=False) + "\n")


def load_state() -> dict:
    if STATE_PATH.exists():
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    return {
        "schema_version": "1.0",
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4",
        "current_state": "INIT",
        "last_updated_utc": utc_now(),
        "tasks": json.loads(json.dumps(TASK_REGISTRY)),
        "recent_transitions": [],
    }


def save_state(state: dict) -> None:
    state["last_updated_utc"] = utc_now()
    atomic_write(STATE_PATH, state)


def transition(state: dict, to_state: str, trigger: str, detail: str) -> None:
    from_state = state["current_state"]
    if to_state == from_state:
        return
    state["current_state"] = to_state
    entry = {
        "from_state": from_state,
        "to_state": to_state,
        "trigger": trigger,
        "detail": detail,
    }
    state["recent_transitions"].append(entry)
    state["recent_transitions"] = state["recent_transitions"][-20:]
    save_state(state)
    audit({"event": "STATE_TRANSITION", **entry})


# ---------------------------------------------------------------- helpers
def _run_matrix_entries() -> list:
    """Reconstruct the 15 frozen run identities (mirror of 25A, read-only)."""
    entries = []
    ids = {
        "ARM_A": "V0_INSTRUMENTED_GLOBAL_LR32_CONTROL",
        "ARM_B": "V1_SHARED_PLUS_BLOCK_LOW_RANK",
        "ARM_C": "V1_SHARED_PLUS_BLOCK_LOW_RANK",
    }
    for arm in ["ARM_A", "ARM_B", "ARM_C"]:
        for seed in FROZEN["seeds"]:
            entries.append(
                {
                    "arm": arm,
                    "arm_id": ids[arm],
                    "num_particles": FROZEN["arms"][arm]["num_particles"],
                    "role": FROZEN["arms"][arm]["role"],
                    "seed": seed,
                    "identity": f"{ids[arm]}_p{FROZEN['arms'][arm]['num_particles']}_seed{seed}_t12",
                    "output_rel": f"results/phase3c4/pilot_runs/{ids[arm]}_p{FROZEN['arms'][arm]['num_particles']}_seed{seed}_t12",
                }
            )
    return entries


def _result_files() -> list:
    files = []
    for e in _run_matrix_entries():
        p = ROOT / e["output_rel"] / "result.json"
        if p.exists():
            files.append(p)
    return files


def _run_started_count() -> int:
    return sum(1 for e in _run_matrix_entries() if (ROOT / e["output_rel"] / "RUN_STARTED.json").exists())


def _pilot_process_alive() -> bool:
    """Best-effort liveness check via pgrep (read-only). Never signals the process."""
    try:
        out = subprocess.run(
            ["pgrep", "-f", "61_run_phase3c_variational_v1_pilot.py --mode pilot"],
            capture_output=True, text=True, timeout=10,
        )
        return out.returncode == 0 and bool(out.stdout.strip())
    except Exception:
        return False


def validate_identities() -> dict:
    results = {}
    live = {
        "runner_sha256": sha256(RUNNER_PATH),
        "guide_sha256": sha256(GUIDE_PATH),
        "art29_sha256": sha256(ART29_PATH) if ART29_PATH.exists() else None,
    }
    for k, exp in FROZEN.items():
        if k in live and live[k] is not None:
            results[k] = {"expected": exp, "live": live[k], "pass": live[k] == exp}
        elif k in ("runner_sha256", "guide_sha256", "art29_sha256"):
            results[k] = {"expected": exp, "live": live[k], "pass": live[k] == exp}
    # 29 internal binding checks
    if ART29_PATH.exists():
        d29 = json.loads(ART29_PATH.read_text(encoding="utf-8"))
        bindings = {
            "28D": d29.get("prerequisite_sha256", {}).get("28D", {}).get("sha256"),
            "runner": d29.get("prerequisite_sha256", {}).get("runner", {}).get("sha256"),
            "guide": d29.get("prerequisite_sha256", {}).get("guide", {}).get("sha256"),
            "run_matrix_identity_hash": d29.get("run_matrix_identity_hash"),
        }
        results["29_authorized"] = d29.get("VARIATIONAL_PILOT_AUTHORIZED") is True
        results["29_bindings_live"] = {
            "28D": {
                "expected": bindings["28D"],
                "live_28D_file": sha256(ROOT / "results/phase3c4/28D_READY_FOR_EXPLICIT_VARIATIONAL_PILOT_RUN_AUTHORIZATION.json"),
            },
            "runner": {
                "expected": bindings["runner"],
                "live": sha256(RUNNER_PATH),
                "pass": bindings["runner"] == sha256(RUNNER_PATH),
            },
            "guide": {
                "expected": bindings["guide"],
                "live": sha256(GUIDE_PATH),
                "pass": bindings["guide"] == sha256(GUIDE_PATH),
            },
            "run_matrix_identity_hash": {"expected": bindings["run_matrix_identity_hash"]},
        }
    return results


def classify_result(r: dict) -> dict:
    """Frozen per-run G1 gate (25): all must hold."""
    finite = bool(r.get("all_params_finite") is True and r.get("nonfinite_gradient_or_loss_steps", 1) == 0)
    loss_ok = float(r.get("loss_reduction_fraction", -1.0)) >= G1_THRESHOLD["min_loss_reduction_fraction"]
    histories = bool(r.get("required_histories_present") is True)
    g1 = bool(finite and loss_ok and histories)
    return {
        "identity": r.get("identity") or r.get("rng_identity", {}).get("identity"),
        "seed": r.get("seed"),
        "arm": r.get("arm"),
        "steps_completed": r.get("steps_completed"),
        "loss_reduction_fraction": r.get("loss_reduction_fraction"),
        "nonfinite_steps": r.get("nonfinite_gradient_or_loss_steps"),
        "all_params_finite": r.get("all_params_finite"),
        "required_histories_present": r.get("required_histories_present"),
        "terminal_status": r.get("terminal_status"),
        "G1_run_pass": bool(r.get("G1_run_pass")),
        "G1_gate_pass": g1,
    }


def g1_audit() -> dict:
    files = _result_files()
    if len(files) < FROZEN["total_runs"]:
        return {"ready": False, "result_files_found": len(files), "required": FROZEN["total_runs"]}
    rows = []
    for p in files:
        try:
            rows.append(classify_result(json.loads(p.read_text(encoding="utf-8"))))
        except Exception as exc:  # noqa: BLE001
            rows.append({"path": str(p), "error": repr(exc), "G1_gate_pass": False})
    by_arm = {"ARM_A": [], "ARM_B": [], "ARM_C": []}
    for r in rows:
        by_arm.setdefault(r.get("arm"), []).append(r)
    arm_result = {}
    all_pass = True
    for arm in ["ARM_A", "ARM_B", "ARM_C"]:
        rs = by_arm.get(arm, [])
        g1_flags = [r.get("G1_gate_pass", False) for r in rs]
        arm_result[arm] = {
            "n_results": len(rs),
            "G1_pass_count": int(sum(bool(f) for f in g1_flags)),
            "G1_required_count": len(FROZEN["seeds"]),
            "G1_arm_pass": bool(len(rs) == 5 and all(g1_flags)),
        }
        if not (len(rs) == 5 and all(g1_flags)):
            all_pass = False
    return {
        "ready": True,
        "result_files_found": len(files),
        "required": FROZEN["total_runs"],
        "per_run": rows,
        "arms": arm_result,
        "G1_OVERALL_PASS": all_pass,
    }


def derive_state() -> dict:
    alive = _pilot_process_alive()
    started = _run_started_count()
    n_results = len(_result_files())
    return {
        "pilot_process_alive": alive,
        "run_started_count": started,
        "result_count": n_results,
        "state": "CURRENT_PILOT_RUNNING" if (alive or started < FROZEN["total_runs"]) else (
            "PILOT_COMPLETE" if n_results >= FROZEN["total_runs"] else "CURRENT_PILOT_RUNNING"
        ),
    }


# ---------------------------------------------------------------- G2 (no-draws)
BLOCK_NAMES = ["count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]
G2_STABILITY = {"terminal_loss_cv_max": 0.30, "loss_reduction_std_max": 0.10}


def _cv(values) -> float:
    vals = [float(v) for v in values if v is not None]
    if len(vals) < 2:
        return 0.0
    mean = statistics.fmean(vals)
    if mean == 0:
        return 0.0
    return statistics.pstdev(vals) / abs(mean)


def _norm_spectrum(sv):
    s = float(sum(sv))
    return [v / s for v in sv] if s > 0 else list(sv)


def _spectrum_pairwise_distance(rows) -> float:
    norms = [_norm_spectrum(r["singular_values"]) for r in rows if r.get("singular_values")]
    if len(norms) < 2:
        return None
    dists = []
    for i in range(len(norms)):
        for j in range(i + 1, len(norms)):
            dists.append(math.sqrt(sum((a - b) ** 2 for a, b in zip(norms[i], norms[j]))))
    return float(statistics.fmean(dists)) if dists else None


def _load_per_run_metrics() -> list:
    """Read the 15 saved run artifacts (JSON only). No inference, no draws."""
    rows = []
    for e in _run_matrix_entries():
        rp = ROOT / e["output_rel"] / "result.json"
        if not rp.exists():
            continue
        r = json.loads(rp.read_text(encoding="utf-8"))
        row = {
            "identity": e["identity"], "arm": e["arm"], "seed": e["seed"],
            "num_particles": e["num_particles"], "role": e["role"],
            "terminal_loss": r.get("terminal_loss"),
            "loss_reduction_fraction": r.get("loss_reduction_fraction"),
            "steps_completed": r.get("steps_completed"),
            "early_stop_reason": r.get("early_stop_reason"),
            "nonfinite_steps": r.get("nonfinite_gradient_or_loss_steps"),
            "all_params_finite": r.get("all_params_finite"),
            "required_histories_present": r.get("required_histories_present"),
        }
        ck = r.get("checkpoint_history") or []
        if ck:
            c = ck[-1]
            row["effective_rank"] = c.get("effective_rank")
            row["numerical_rank"] = c.get("numerical_rank")
            row["global_lr_fraction"] = c.get("global_lr_fraction")
        sp = ROOT / e["output_rel"] / "factor_spectrum_history.json"
        if sp.exists():
            hist = json.loads(sp.read_text(encoding="utf-8")).get("history") or []
            if hist and isinstance(hist[-1], list):
                row["singular_values"] = [float(x) for x in hist[-1]]
        bb = ROOT / e["output_rel"] / "block_budget_history.json"
        if bb.exists():
            bh = json.loads(bb.read_text(encoding="utf-8")).get("history") or []
            if bh and isinstance(bh[-1], dict):
                row["block_allocation"] = {
                    name: {
                        "low_rank_variance_total": b.get("low_rank_variance_total"),
                        "low_rank_variance_share": b.get("low_rank_variance_share"),
                        "within_block_low_rank_fraction": b.get("within_block_low_rank_fraction"),
                    }
                    for name, b in bh[-1].items()
                }
        rows.append(row)
    return rows


def compute_g2() -> dict:
    """No-draws G2 replicate-stability analysis from the 15 saved artifacts."""
    rows = _load_per_run_metrics()
    by_arm = {"ARM_A": [], "ARM_B": [], "ARM_C": []}
    for r in rows:
        by_arm.setdefault(r["arm"], []).append(r)

    def arm_stats(rs):
        def col(key):
            return [r[key] for r in rs if r.get(key) is not None]

        def summary(key, digits=4):
            vals = col(key)
            if not vals:
                return None
            return {"mean": round(statistics.fmean(vals), digits),
                    "std": round(statistics.pstdev(vals), digits) if len(vals) > 1 else 0.0,
                    "cv": round(_cv(vals), digits)}

        block = {}
        for name in BLOCK_NAMES:
            shares = []
            within = []
            for r in rs:
                ba = r.get("block_allocation") or {}
                b = ba.get(name) or {}
                if b.get("low_rank_variance_share") is not None:
                    shares.append(b["low_rank_variance_share"])
                if b.get("within_block_low_rank_fraction") is not None:
                    within.append(b["within_block_low_rank_fraction"])
            block[name] = {
                "mean_share": round(statistics.fmean(shares), 4) if shares else None,
                "std_share": round(statistics.pstdev(shares), 4) if len(shares) > 1 else 0.0,
                "cv_share": round(_cv(shares), 4) if shares else None,
                "mean_within_block_fraction": round(statistics.fmean(within), 4) if within else None,
                "std_within_block_fraction": round(statistics.pstdev(within), 4) if len(within) > 1 else 0.0,
            }
        return {
            "n": len(rs),
            "terminal_loss": summary("terminal_loss"),
            "loss_reduction_fraction": summary("loss_reduction_fraction"),
            "effective_rank": summary("effective_rank"),
            "global_lr_fraction": summary("global_lr_fraction"),
            "steps_completed": sorted({r["steps_completed"] for r in rs if r.get("steps_completed") is not None}),
            "early_stop_reasons": sorted({r["early_stop_reason"] for r in rs if r.get("early_stop_reason")}),
            "spectrum_stability": {
                "mean_pairwise_l2_normalized": _spectrum_pairwise_distance(rs),
                "n_spectra": sum(1 for r in rs if r.get("singular_values")),
            },
            "block_allocation_stability": block,
        }

    arms = {arm: arm_stats(by_arm[arm]) for arm in ["ARM_A", "ARM_B", "ARM_C"]}

    def cmp_metric(a, b, key):
        va, vb = arms[a][key], arms[b][key]
        if not va or not vb:
            return None
        return {"A": va, "B": vb,
                "delta_B_minus_A_mean": round((vb["mean"] - va["mean"]), 4),
                "delta_B_minus_A_cv": round((vb["cv"] - va["cv"]), 4)}

    a_vs_b = {
        "comparison": "ARM_A (V0-p1) vs ARM_B (V1-p1) - ARCHITECTURE comparison at identical num_particles=1",
        "terminal_loss": cmp_metric("ARM_A", "ARM_B", "terminal_loss"),
        "loss_reduction_fraction": cmp_metric("ARM_A", "ARM_B", "loss_reduction_fraction"),
        "effective_rank": cmp_metric("ARM_A", "ARM_B", "effective_rank"),
        "global_lr_fraction": cmp_metric("ARM_A", "ARM_B", "global_lr_fraction"),
        "spectrum_stability": {"ARM_A": arms["ARM_A"]["spectrum_stability"],
                               "ARM_B": arms["ARM_B"]["spectrum_stability"]},
        "block_allocation_stability": {"ARM_A": arms["ARM_A"]["block_allocation_stability"],
                                       "ARM_B": arms["ARM_B"]["block_allocation_stability"]},
        "note": "Lower CV / std indicates better replicate stability; do NOT use terminal-loss minimum alone as winner.",
    }
    b_vs_c = {
        "comparison": "ARM_B (V1-p1) vs ARM_C (V1-p4) - PARTICLE comparison (num_particles 1 vs 4)",
        "terminal_loss": cmp_metric("ARM_B", "ARM_C", "terminal_loss"),
        "loss_reduction_fraction": cmp_metric("ARM_B", "ARM_C", "loss_reduction_fraction"),
        "effective_rank": cmp_metric("ARM_B", "ARM_C", "effective_rank"),
        "global_lr_fraction": cmp_metric("ARM_B", "ARM_C", "global_lr_fraction"),
        "spectrum_stability": {"ARM_B": arms["ARM_B"]["spectrum_stability"],
                               "ARM_C": arms["ARM_C"]["spectrum_stability"]},
        "block_allocation_stability": {"ARM_B": arms["ARM_B"]["block_allocation_stability"],
                                       "ARM_C": arms["ARM_C"]["block_allocation_stability"]},
        "note": "No architecture x particle interaction claim: there is no V0-p4 arm.",
    }

    unevaluable = [
        "posterior guide LOCATION stability (guide loc vectors are NOT persisted in saved artifacts)",
        "marginal / diagonal scale stability (diag scale is NOT persisted in saved artifacts)",
        "factor SUBSPACE vector alignment (only singular-value spectra are persisted, not factor vectors)",
    ]

    instability_flags = []
    for arm in ["ARM_A", "ARM_B", "ARM_C"]:
        rs = by_arm[arm]
        if len(rs) != 5:
            instability_flags.append(f"{arm}: expected 5 results, found {len(rs)}")
        if any(r.get("nonfinite_steps", 0) or not r.get("all_params_finite", True)
               or not r.get("required_histories_present", False) for r in rs):
            instability_flags.append(f"{arm}: nonfinite params/steps or missing required histories")
        tl = arms[arm]["terminal_loss"]
        if tl and tl["cv"] > G2_STABILITY["terminal_loss_cv_max"]:
            instability_flags.append(f"{arm}: terminal-loss CV {tl['cv']:.3f} > {G2_STABILITY['terminal_loss_cv_max']}")
        lr = arms[arm]["loss_reduction_fraction"]
        if lr and lr["std"] > G2_STABILITY["loss_reduction_std_max"]:
            instability_flags.append(f"{arm}: loss-reduction std {lr['std']:.3f} > {G2_STABILITY['loss_reduction_std_max']}")

    if instability_flags:
        classification = "G2_FAIL_REPLICATE_INSTABILITY"
    elif unevaluable:
        classification = "G2_PARTIAL_PASS_DRAWS_REQUIRED"
    else:
        classification = "G2_PASS_NO_DRAWS"

    return {
        "generated_utc": utc_now(),
        "posterior_draws_used": False,
        "new_optimization_run": False,
        "n_runs_analyzed": len(rows),
        "per_arm": arms,
        "per_seed_table": [{k: r[k] for k in ("identity", "arm", "seed", "terminal_loss",
                                              "loss_reduction_fraction", "steps_completed",
                                              "early_stop_reason", "effective_rank",
                                              "global_lr_fraction")} for r in rows],
        "A_vs_B_architecture_comparison": a_vs_b,
        "B_vs_C_particle_comparison": b_vs_c,
        "limitations": unevaluable,
        "instability_flags": instability_flags,
        "classification": classification,
        "classification_rules": {
            "G2_FAIL_REPLICATE_INSTABILITY": "any arm: <5 results, nonfinite, terminal-loss CV > "
                                             f"{G2_STABILITY['terminal_loss_cv_max']}, or loss-reduction std > "
                                             f"{G2_STABILITY['loss_reduction_std_max']}",
            "G2_PARTIAL_PASS_DRAWS_REQUIRED": "no replicate instability, but some dimensions are "
                                              "NOT_EVALUABLE_WITHOUT_POSTERIOR_DRAWS",
            "G2_PASS_NO_DRAWS": "no replicate instability AND all dimensions evaluable without draws",
        },
        "no_phase3c4_failed_pca_used": True,
    }


def write_g2(g2: dict) -> None:
    atomic_write(G2_JSON, g2)
    md = [
        "# 31 — G2 REPLICATE STABILITY (no-draws, auto)",
        "",
        f"Generated: {utc_now()}  |  Generator: scripts/62 --mode g2-audit",
        "",
        f"**Classification: {g2['classification']}**",
        f"posterior_draws_used: {g2['posterior_draws_used']}  |  new_optimization_run: {g2['new_optimization_run']}",
        "",
        "## Per-arm summary",
        "",
        "| arm | terminal loss mean/std/cv | reduction mean/std/cv | effective rank mean/std | global LR frac mean/std |",
        "|---|---|---|---|---|",
    ]
    for arm in ["ARM_A", "ARM_B", "ARM_C"]:
        a = g2["per_arm"][arm]
        tl = a["terminal_loss"] or {}
        lr = a["loss_reduction_fraction"] or {}
        er = a["effective_rank"] or {}
        gl = a["global_lr_fraction"] or {}
        md.append(
            f"| {arm} | {tl.get('mean')}/{tl.get('std')}/{tl.get('cv')} | "
            f"{lr.get('mean')}/{lr.get('std')}/{lr.get('cv')} | "
            f"{er.get('mean')}/{er.get('std')} | {gl.get('mean')}/{gl.get('std')} |"
        )
    md.append("")
    md.append("## Comparisons")
    for c in [g2["A_vs_B_architecture_comparison"], g2["B_vs_C_particle_comparison"]]:
        md.append(f"- {c['comparison']}")
        for k in ["terminal_loss", "loss_reduction_fraction", "effective_rank", "global_lr_fraction"]:
            v = c.get(k)
            if v:
                md.append(f"  - {k}: A={v['A'].get('mean')}/{v['A'].get('cv')}  "
                          f"B={v['B'].get('mean')}/{v['B'].get('cv')}  delta_mean={v['delta_B_minus_A_mean']}  "
                          f"delta_cv={v['delta_B_minus_A_cv']}")
    md.append("")
    md.append("## Limitations (NOT_EVALUABLE_WITHOUT_POSTERIOR_DRAWS)")
    for x in g2["limitations"]:
        md.append(f"- {x}")
    if g2["instability_flags"]:
        md.append("")
        md.append("## Instability flags")
        for f in g2["instability_flags"]:
            md.append(f"- {f}")
    G2_MD.write_text("\n".join(md) + "\n", encoding="utf-8")


# ---------------------------------------------------------------- G3 (design freeze only)
def write_g3() -> None:
    design = {
        "artifact_id": "32_G3_EXACT_TARGET_IMPORTANCE_PROTOCOL",
        "generated_utc": utc_now(),
        "generator": "scripts/62 --mode g3-design",
        "status": "DESIGNED_AND_FROZEN_NOT_SAMPLED",
        "sampling_performed": False,
        "pre_registered": {
            "1_candidate_guide_selection_rule": "Use the V1 StructuredLowRankAutoGuide (guide SHA "
                                                "0116cdea...) trained by the frozen pilot; winner is NOT "
                                                "selected by terminal loss alone - selection requires G2 "
                                                "stability evidence and is locked BEFORE sampling.",
            "2_number_of_guide_draws": 4000,
            "3_rng_seeds": [9001, 9002, 9003, 9004, 9005],
            "4_exact_target_log_density": "log p(y,z) evaluated by the frozen scientific model "
                                          "(full_joint_model.py SHA 163c86e5...) at guide-sampled z",
            "5_log_q_evaluation": "log q(z) from the fitted V1 guide posterior (LowRankMultivariateNormal)",
            "6_log_weight_computation": "log w = log p(y,z) - log q(z)",
            "7_finite_weight_checks": "all log-weights must be finite; count of non-finite -> gate fail",
            "8_normalized_importance_ESS": "ESS = (sum w)^2 / sum w^2 after log-sum-exp normalization",
            "9_pareto_k_psis": "Pareto-k / PSIS diagnostics used IF supported by installed tooling; "
                               "k thresholds frozen (k < 0.5 usable, 0.5-0.7 moderate, >0.7 flagged)",
            "10_numerical_overflow_handling": "log-space evaluation with log-sum-exp; per-batch rescaling",
            "11_failure_thresholds": "any non-finite log weight, ESS < 0.1*N, or Pareto-k > 0.7 => G3 FAIL",
            "12_storage_format": "npz + JSON summary (log_weights, ESS, Pareto-k, per-candidate metrics)",
            "13_anti_post_hoc_rules": "sample count, seeds, candidate guide, thresholds, and PSIS rule are "
                                      "FROZEN and MUST NOT be changed based on observed G3 results",
        },
        "no_sampling_run": True,
        "anti_post_hoc": True,
    }
    atomic_write(G3_JSON, design)
    md = ["# 32 — G3 EXACT TARGET / IMPORTANCE PROTOCOL (design + freeze ONLY)", "",
          f"Generated: {utc_now()}  |  Generator: scripts/62 --mode g3-design", "",
          "**Status: DESIGNED_AND_FROZEN_NOT_SAMPLED** — no sampling performed.", ""]
    for k, v in design["pre_registered"].items():
        md.append(f"- **{k}**: {v}")
    G3_MD.write_text("\n".join(md) + "\n", encoding="utf-8")


# ---------------------------------------------------------------- modes
def cmd_init(state: dict) -> None:
    AUTOMATION_DIR.mkdir(parents=True, exist_ok=True)
    if not STATE_PATH.exists():
        state["current_state"] = "CURRENT_PILOT_RUNNING"
        save_state(state)
        audit({"event": "AUTOMATION_INIT", "detail": "AUTOMATION_STATE.json created"})
        print("AUTOMATION_STATE.json initialized -> CURRENT_PILOT_RUNNING")
    else:
        print("AUTOMATION_STATE.json already exists; state =", state["current_state"])


def cmd_status(state: dict) -> None:
    v = derive_state()
    print("current_state:", state["current_state"])
    print("derived:", json.dumps(v, ensure_ascii=False))
    for k, t in state.get("tasks", {}).items():
        print(f"  {k}: {t['status']} ({t['artifact']})")


def cmd_validate(state: dict) -> None:
    res = validate_identities()
    ok = all(
        (v.get("pass") if isinstance(v, dict) and "pass" in v else True)
        for v in res.values()
    ) and res.get("29_authorized") is True
    print(json.dumps(res, indent=2, ensure_ascii=False))
    print("OVERALL_IDENTITY_VALIDATION:", "PASS" if ok else "FAIL")
    audit({"event": "IDENTITY_VALIDATION", "overall": "PASS" if ok else "FAIL", "detail": res})


def cmd_advance(state: dict) -> None:
    """Automated state progression: PILOT -> G1 -> G2(no-draws) -> G3(design) -> HUMAN GATE."""
    v = derive_state()
    cur = state["current_state"]

    if cur == "CURRENT_PILOT_RUNNING":
        if v["result_count"] >= FROZEN["total_runs"]:
            transition(state, "PILOT_COMPLETE", "15 result.json present", f"result_count={v['result_count']}")
            transition(state, "G1_AUDIT", "PILOT_COMPLETE", "starting frozen G1 audit")
            g = g1_audit()
            if g.get("ready") and g.get("G1_OVERALL_PASS"):
                transition(state, "G1_PASS", "G1 audit passed", "all 15 runs pass frozen G1 gate")
                transition(state, "G2_READY", "G1_PASS", "G2 design authorized (no new posterior draws)")
            else:
                transition(state, "STOP_G1_FAILED", "G1 audit failed", json.dumps(g.get("arms", {}), ensure_ascii=False))
        else:
            print("still running:", v["result_count"], "of", FROZEN["total_runs"], "results; state stays CURRENT_PILOT_RUNNING")

    # G2 no-draws audit (auto-chained when G2_READY)
    if state["current_state"] == "G2_READY":
        g2 = compute_g2()
        write_g2(g2)
        audit({"event": "G2_AUDIT_COMPLETE", "detail": {
            "classification": g2["classification"],
            "n_runs_analyzed": g2["n_runs_analyzed"],
            "posterior_draws_used": g2["posterior_draws_used"]}})
        state["tasks"]["TASK5_G2_REPLICATE_STABILITY"]["status"] = "DONE"
        state["tasks"]["TASK5_G2_REPLICATE_STABILITY"]["classification"] = g2["classification"]
        save_state(state)
        if g2["classification"] == "G2_FAIL_REPLICATE_INSTABILITY":
            transition(state, "STOP_G2_REPLICATE_INSTABILITY", "G2 replicate instability",
                       json.dumps(g2["instability_flags"], ensure_ascii=False))
        elif g2["classification"] == "G2_PARTIAL_PASS_DRAWS_REQUIRED":
            transition(state, "STOP_G2_POSTERIOR_DRAW_AUTHORIZATION_REQUIRED",
                       "G2 no-draws complete; posterior draws required",
                       json.dumps(g2["limitations"], ensure_ascii=False))
        else:  # G2_PASS_NO_DRAWS
            transition(state, "G3_PROTOCOL_READY", "G2_PASS_NO_DRAWS",
                       "no-draws replicate stability passed; G3 design authorized")

    # G3 design freeze (auto-chained only after G2_PASS_NO_DRAWS -> G3_PROTOCOL_READY)
    if state["current_state"] == "G3_PROTOCOL_READY":
        write_g3()
        audit({"event": "G3_PROTOCOL_FROZEN_NO_SAMPLING", "detail": {"sampling_performed": False}})
        state["tasks"]["TASK6_G3_EXACT_TARGET_IMPORTANCE_PROTOCOL"]["status"] = "DONE"
        save_state(state)
        transition(state, "STOP_WAITING_FOR_G3_SAMPLING_AUTHORIZATION",
                   "G3 protocol designed and frozen", "sampling NOT authorized")

    print("state after advance:", state["current_state"])


def cmd_g1_audit(state: dict) -> None:
    g = g1_audit()
    if g.get("ready"):
        # Write 30 only if absent; never overwrite an existing 30 artifact.
        if not G1_JSON.exists():
            atomic_write(G1_JSON, {
                "artifact_id": "30_VARIATIONAL_PILOT_G1_AUDIT",
                "generated_utc": utc_now(),
                "generator": "scripts/62 --mode g1-audit (auto)",
                "G1_OVERALL_PASS": g["G1_OVERALL_PASS"],
                "arms": g["arms"],
                "per_run": [{k: r.get(k) for k in ("identity", "arm", "seed", "loss_reduction_fraction",
                                                   "terminal_status", "G1_gate_pass")} for r in g["per_run"]],
            })
            md = ["# 30 — VARIATIONAL PILOT G1 AUDIT (auto)", "",
                  f"Generated: {utc_now()}  |  Generator: scripts/62 --mode g1-audit", "",
                  f"**G1_OVERALL_PASS: {g['G1_OVERALL_PASS']}**", ""]
            for arm in ["ARM_A", "ARM_B", "ARM_C"]:
                a = g["arms"][arm]
                md.append(f"- {arm}: {a['G1_pass_count']}/{a['G1_required_count']} G1_arm_pass={a['G1_arm_pass']}")
            G1_MD.write_text("\n".join(md) + "\n", encoding="utf-8")
            audit({"event": "G1_AUDIT_ARTIFACT_CREATED", "detail": {"sha": sha256(G1_JSON)}})
        else:
            audit({"event": "G1_AUDIT_ARTIFACT_PRESERVED", "detail": {"sha": sha256(G1_JSON)}})
        print("30 G1 artifact SHA:", sha256(G1_JSON) if G1_JSON.exists() else "MISSING")
        state["tasks"]["TASK4_G1_AUDIT"]["status"] = "DONE"
        save_state(state)
    print("G1 OVERALL PASS:", g.get("G1_OVERALL_PASS") if g.get("ready") else "NOT READY",
          "| result files:", g.get("result_files_found", 0), "/", FROZEN["total_runs"])
    audit({"event": "G1_AUDIT_SNAPSHOT", "detail": {k: g.get(k) for k in ("ready", "result_files_found", "G1_OVERALL_PASS")}})


def cmd_g2_audit(state: dict) -> None:
    g2 = compute_g2()
    write_g2(g2)
    audit({"event": "G2_AUDIT_COMPLETE", "detail": {
        "classification": g2["classification"],
        "n_runs_analyzed": g2["n_runs_analyzed"],
        "posterior_draws_used": g2["posterior_draws_used"]}})
    state["tasks"]["TASK5_G2_REPLICATE_STABILITY"]["status"] = "DONE"
    state["tasks"]["TASK5_G2_REPLICATE_STABILITY"]["classification"] = g2["classification"]
    save_state(state)
    if g2["classification"] == "G2_FAIL_REPLICATE_INSTABILITY":
        transition(state, "STOP_G2_REPLICATE_INSTABILITY", "G2 replicate instability",
                   json.dumps(g2["instability_flags"], ensure_ascii=False))
    elif g2["classification"] == "G2_PARTIAL_PASS_DRAWS_REQUIRED":
        transition(state, "STOP_G2_POSTERIOR_DRAW_AUTHORIZATION_REQUIRED",
                   "G2 no-draws complete; posterior draws required",
                   json.dumps(g2["limitations"], ensure_ascii=False))
    else:
        transition(state, "G3_PROTOCOL_READY", "G2_PASS_NO_DRAWS",
                   "no-draws replicate stability passed; G3 design authorized")
    print("G2 classification:", g2["classification"])
    print("31 G2 artifact SHA:", sha256(G2_JSON))


def cmd_g3_design(state: dict) -> None:
    if state["current_state"] != "G3_PROTOCOL_READY":
        print("G3 design only allowed after G2_PASS_NO_DRAWS (state must be G3_PROTOCOL_READY); "
              f"current state = {state['current_state']}")
        return
    write_g3()
    audit({"event": "G3_PROTOCOL_FROZEN_NO_SAMPLING", "detail": {"sampling_performed": False}})
    state["tasks"]["TASK6_G3_EXACT_TARGET_IMPORTANCE_PROTOCOL"]["status"] = "DONE"
    save_state(state)
    transition(state, "STOP_WAITING_FOR_G3_SAMPLING_AUTHORIZATION",
               "G3 protocol designed and frozen", "sampling NOT authorized")
    print("32 G3 protocol SHA:", sha256(G3_JSON))


def main() -> None:
    ap = argparse.ArgumentParser(description="Phase3C.4 variational automation controller (supervision only)")
    ap.add_argument("--mode", choices=["init", "status", "validate", "advance", "g1-audit", "g2-audit", "g3-design"], default="status")
    args = ap.parse_args()
    state = load_state()
    handlers = {
        "init": cmd_init,
        "status": cmd_status,
        "validate": cmd_validate,
        "advance": cmd_advance,
        "g1-audit": cmd_g1_audit,
        "g2-audit": cmd_g2_audit,
        "g3-design": cmd_g3_design,
    }
    handlers[args.mode](state)


if __name__ == "__main__":
    main()
