from __future__ import annotations

import csv
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import jax
import numpy as np
import pandas as pd
import yaml
from jax import random
from scipy.stats import spearmanr

from dhbcp_pv.inference.phase3c_stabilized import (
    posterior_scale_diagnostics,
    validate_dense_mass_contract,
)
from dhbcp_pv.inference.posterior_integration import integrate_posterior_outputs
from dhbcp_pv.inference.structured_svi import (
    SVIConfig,
    run_structured_svi,
    sample_structured_posterior,
)
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_a_replicate


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    atomic_text(path, json.dumps(payload, indent=2, allow_nan=False, sort_keys=True) + "\n")


def atomic_npz(path: Path, arrays: dict[str, np.ndarray]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    os.replace(temporary, path)


def deterministic_seed(namespace: str, replicate_id: int) -> int:
    value = hashlib.sha256(f"{namespace}|{replicate_id:03d}".encode()).digest()
    return int.from_bytes(value[:8], "big") % 2_000_000_000 + 1


def write_seed_manifest(path: Path, namespace: str, count: int) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["replicate_id", "seed", "namespace"])
        writer.writeheader()
        for replicate_id in range(1, count + 1):
            writer.writerow({
                "replicate_id": replicate_id,
                "seed": deterministic_seed(namespace, replicate_id),
                "namespace": namespace,
            })
    os.replace(temporary, path)


def tree_records(root: Path, directories: tuple[str, ...]) -> tuple[str, list[dict[str, Any]]]:
    records = []
    for directory in directories:
        for path in sorted((root / directory).rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            records.append({
                "path": path.relative_to(root).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            })
    records.sort(key=lambda row: row["path"])
    digest = hashlib.sha256()
    for row in records:
        digest.update(f"{row['path']}\0{row['sha256']}\n".encode())
    return digest.hexdigest(), records


def config_from_row(row: dict[str, Any]) -> SVIConfig:
    return SVIConfig(
        learning_rate=float(row["learning_rate"]),
        max_steps=int(row["max_steps"]),
        minimum_steps=int(row["minimum_steps"]),
        early_stop_patience=int(row["early_stop_patience"]),
        relative_tolerance=float(row["relative_tolerance"]),
        gradient_clip_norm=float(row["gradient_clip_norm"]),
        num_elbo_particles=int(row["elbo_particles"]),
    )


def load_params(path: Path) -> dict[str, jax.Array]:
    loaded = np.load(path)
    return {name: jax.numpy.asarray(loaded[name]) for name in loaded.files if not name.startswith("_")}


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    result = root / "results/phase3c"
    freeze_path = result / "82_PHASE3C_PROTOCOL_FREEZE.json"
    if freeze_path.exists():
        raise SystemExit("Phase3C protocol is already frozen")
    prechange_path = result / "phase3c_prechange_freeze.json"
    if not prechange_path.exists():
        raise SystemExit("missing Phase3C prechange freeze")
    prechange = json.loads(prechange_path.read_text())
    if not prechange["phase3a_immutability"]["unchanged"]:
        raise SystemExit("Phase3A immutable inputs did not pass prechange verification")

    svi_protocol = yaml.safe_load((root / "config/phase3c_svi_stabilization_v1.yaml").read_text())
    checkpoint_dir = result / "checkpoints/svi_preflight"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    all_rows: list[dict[str, Any]] = []
    selected: dict[str, Any] | None = None
    schedule_summaries: list[dict[str, Any]] = []
    namespace = str(svi_protocol["preflight_seed_namespace"])

    for schedule in svi_protocol["candidate_schedules"]:
        schedule_id = str(schedule["id"])
        config = config_from_row(schedule)
        rows: list[dict[str, Any]] = []
        for replicate_id in range(1, int(svi_protocol["preflight_replicates"]) + 1):
            metadata_path = checkpoint_dir / f"{schedule_id}_replicate_{replicate_id:02d}.json"
            params_path = checkpoint_dir / f"{schedule_id}_replicate_{replicate_id:02d}.npz"
            if metadata_path.exists() and params_path.exists():
                metadata = json.loads(metadata_path.read_text())
            else:
                seed = deterministic_seed(namespace, replicate_id)
                observed = generate_tier_a_replicate(seed, n_quarters=40)
                fitted = run_structured_svi(
                    random.PRNGKey(seed),
                    observed.y,
                    observed.serious,
                    observed.expected,
                    observed.drug_index,
                    observed.event_index,
                    18,
                    9,
                    hmax=12,
                    config=config,
                )
                params = {name: np.asarray(value) for name, value in fitted.params.items()}
                scale = posterior_scale_diagnostics(fitted.params)
                reduction = (
                    (fitted.initial_loss - fitted.terminal_loss)
                    / max(abs(fitted.initial_loss), 1.0)
                )
                metadata = {
                    "schedule_id": schedule_id,
                    "replicate_id": replicate_id,
                    "seed": seed,
                    "namespace": namespace,
                    "pairs": 162,
                    "quarters": 40,
                    "initial_loss": fitted.initial_loss,
                    "terminal_loss": fitted.terminal_loss,
                    "loss_reduction_fraction": reduction,
                    "steps": fitted.steps,
                    "convergence_code": fitted.convergence_code,
                    "seconds": fitted.wall_clock_seconds,
                    "finite": fitted.finite,
                    "latent_site_coverage": fitted.site_coverage_passed,
                    "nonfinite_gradient_or_loss_steps": fitted.nonfinite_gradient_or_loss_steps,
                    "posterior_scale": scale,
                    "truth_fields_accessed": False,
                    "performance_metrics_computed": False,
                }
                atomic_npz(params_path, {**params, "_loss_trace": fitted.loss_trace})
                metadata["params_artifact"] = {
                    "path": params_path.relative_to(root).as_posix(),
                    "bytes": params_path.stat().st_size,
                    "sha256": sha256(params_path),
                }
                atomic_json(metadata_path, metadata)
            row = {
                "schedule_id": schedule_id,
                "replicate_id": replicate_id,
                "seed": metadata["seed"],
                "finite": metadata["finite"],
                "latent_site_coverage": metadata["latent_site_coverage"],
                "positive_definite_time_guide": metadata["posterior_scale"]["positive_definite"],
                "loss_reduction_fraction": metadata["loss_reduction_fraction"],
                "loss_reduction_ge_15pct": metadata["loss_reduction_fraction"] >= 0.15,
                "nonfinite_gradient_or_loss_steps": metadata["nonfinite_gradient_or_loss_steps"],
                "scale_below_1e6_count": len(metadata["posterior_scale"]["below_1e_6"]),
                "steps": metadata["steps"],
                "convergence_code": metadata["convergence_code"],
                "seconds": metadata["seconds"],
                "mc_64_vs_128_delta_spearman": None,
            }
            rows.append(row)
            print(
                f"SVI {schedule_id} replicate {replicate_id:02d}/10: "
                f"finite={row['finite']} reduction={100 * float(row['loss_reduction_fraction']):.1f}%",
                flush=True,
            )

        mc_values = []
        for replicate_id in (1, 2, 3):
            seed = deterministic_seed(namespace, replicate_id)
            observed = generate_tier_a_replicate(seed, n_quarters=40)
            params_path = checkpoint_dir / f"{schedule_id}_replicate_{replicate_id:02d}.npz"
            posterior = sample_structured_posterior(
                random.PRNGKey(seed + 1),
                load_params(params_path),
                observed.y,
                observed.serious,
                observed.expected,
                observed.drug_index,
                observed.event_index,
                18,
                9,
                num_samples=128,
                hmax=12,
            )
            posterior = {name: jax.device_get(value) for name, value in posterior.items()}
            integrated_128 = integrate_posterior_outputs(
                posterior,
                observed.y,
                observed.serious,
                observed.drug_index,
                observed.event_index,
                18,
                9,
                hmax=12,
            )
            integrated_64 = integrate_posterior_outputs(
                {name: value[:64] for name, value in posterior.items()},
                observed.y,
                observed.serious,
                observed.drug_index,
                observed.event_index,
                18,
                9,
                hmax=12,
            )
            coefficient = float(spearmanr(
                integrated_64.delta_expected_loss[:, -1],
                integrated_128.delta_expected_loss[:, -1],
            ).statistic)
            mc_values.append(coefficient)
            rows[replicate_id - 1]["mc_64_vs_128_delta_spearman"] = coefficient

        gate_flags = {
            "finite_runs": sum(bool(row["finite"]) for row in rows) == 10,
            "latent_site_coverage": sum(bool(row["latent_site_coverage"]) for row in rows) == 10,
            "positive_definite_time_guide": sum(bool(row["positive_definite_time_guide"]) for row in rows) == 10,
            "loss_reduction": sum(bool(row["loss_reduction_ge_15pct"]) for row in rows) >= 9,
            "nonfinite_gradients_or_losses": sum(int(row["nonfinite_gradient_or_loss_steps"]) for row in rows) == 0,
            "posterior_scales": sum(int(row["scale_below_1e6_count"]) for row in rows) == 0,
            "mc_delta_stability": all(np.isfinite(mc_values)) and min(mc_values) >= 0.99,
        }
        summary = {
            "schedule_id": schedule_id,
            "gate_flags": gate_flags,
            "passed": all(gate_flags.values()),
            "mc_64_vs_128_delta_spearman": mc_values,
            "truth_fields_accessed": False,
            "performance_metrics_computed": False,
        }
        schedule_summaries.append(summary)
        all_rows.extend(rows)
        if summary["passed"]:
            selected = {**schedule, "gate_summary": summary}
            break

    csv_path = result / "83_PHASE3C_SVI_PREFLIGHT.csv"
    fieldnames = list(all_rows[0])
    temporary_csv = csv_path.with_suffix(csv_path.suffix + ".tmp")
    with temporary_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_rows)
    os.replace(temporary_csv, csv_path)
    if selected is None:
        atomic_json(result / "83_PHASE3C_SVI_PREFLIGHT_FAILURE.json", {
            "version": "phase3c_svi_preflight_failure_v1",
            "schedules": schedule_summaries,
            "gate": "FAIL_BLOCKED",
        })
        raise SystemExit("No SVI schedule passed the frozen numerical gate")

    selected_path = result / "84_PHASE3C_SELECTED_SVI_CONFIG.yaml"
    selected_payload = {
        "version": "phase3c_selected_svi_config_v1",
        "selected_schedule": {key: value for key, value in selected.items() if key != "gate_summary"},
        "selection": selected["gate_summary"],
        "rolling_prefix": {
            "initial_prefix_steps": int(selected["minimum_steps"]),
            "updates_per_added_quarter": max(10, int(selected["minimum_steps"]) // 10),
            "early_stop_enabled_each_prefix": True,
            "warm_start": True,
        },
        "posterior_draws_primary": 64,
        "truth_or_performance_metrics_used_for_selection": False,
    }
    atomic_text(selected_path, yaml.safe_dump(selected_payload, sort_keys=False))

    seed_path = root / "config/phase3c_tiera_seeds_v1.csv"
    write_seed_manifest(seed_path, "DHBCP-PV-V2|phase3c|tiera-recovery", 100)
    phase3b_seeds = pd.read_csv(root / "config/phase3b_tiera_seeds_v1.csv")
    phase3c_seeds = pd.read_csv(seed_path)
    if set(phase3b_seeds["seed"]).intersection(set(phase3c_seeds["seed"])):
        raise SystemExit("Phase3C recovery seeds overlap Phase3B")

    completed = subprocess.run(
        [sys.executable, "-m", "pytest", "tests", "-q"],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    test_output = completed.stdout + completed.stderr
    if completed.returncode != 0:
        raise SystemExit("tests failed before Phase3C protocol freeze\n" + test_output)

    source_hash, source_records = tree_records(root, ("src", "scripts", "tests"))
    config_paths = [
        root / "config/phase3c_nuts_stabilization_v1.yaml",
        root / "config/phase3c_svi_stabilization_v1.yaml",
        root / "config/phase3c_acceptance_gates_v1.yaml",
        seed_path,
        selected_path,
    ]
    freeze = {
        "version": "phase3c_protocol_freeze_v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scientific_target": "src/dhbcp_pv/models/full_joint_model.py (unchanged Phase3B callable)",
        "scientific_target_changed": False,
        "source_tree_sha256": source_hash,
        "source_files": source_records,
        "frozen_files": {
            path.relative_to(root).as_posix(): {"bytes": path.stat().st_size, "sha256": sha256(path)}
            for path in config_paths
        },
        "prechange_freeze": {
            "path": prechange_path.relative_to(root).as_posix(),
            "sha256": sha256(prechange_path),
        },
        "selected_svi": selected_payload,
        "svi_schedule_summaries": schedule_summaries,
        "dense_mass_contract": validate_dense_mass_contract(),
        "tests": {
            "command": "python -m pytest tests -q",
            "returncode": completed.returncode,
            "output": test_output.strip(),
        },
        "selection_used_truth_or_performance_metrics": False,
        "phase3a_unchanged": True,
        "phase3b_unchanged": True,
        "phase3d_started": False,
        "phase4_started": False,
        "tierb_started": False,
        "canada_started": False,
        "faers_2023_2025_started": False,
    }
    atomic_json(freeze_path, freeze)
    print(json.dumps({
        "selected_schedule": selected["id"],
        "preflight_rows": len(all_rows),
        "tests": test_output.strip().splitlines()[-1],
        "freeze": str(freeze_path),
    }), flush=True)


if __name__ == "__main__":
    main()
