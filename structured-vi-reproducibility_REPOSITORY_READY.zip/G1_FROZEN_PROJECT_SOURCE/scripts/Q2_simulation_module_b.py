"""Q2 supplementary simulation — Module B executor (synthetic Gaussian VI).

Artifact: Q2_simulation_module_b.py
Frozen: 2026-08-23 (protocol repair, V2). PRE-EXECUTION.
IMPORTANT: Running this script performs REAL Module B VI fits and requires a
separate execution authorization. It is implemented here for freeze/dry-import
only; the zero-compute preflight must NOT execute any fit.

Design (frozen):
  - target p(z)=N(0,Sigma*), Sigma* = B*_AR1 + U* U*^T (from frozen target matrix)
  - guide q(z) = N(m, Sigma_q) with Sigma_q = diag(exp(2*log_scale)) + U_q U_q^T
    (low-rank + diagonal guide, rank = RANK)
  - Trace_ELBO with particles (P1=1, P4=4), ClippedAdam (lr=0.003, clip=10),
    max_steps=2000, min early-stop eligibility=500, checkpoint=100,
    rel tol=1e-4, patience=5, min loss reduction=0.15
  - target randomness separated from optimizer randomness (target seed vs
    optimizer seed); optimizer seed never enters target generation
  - float64; no FAERS; no G1/G2/G3; run manifest with no seed replacement
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from Q2_simulation_target_generator import (
    LATENT_DIM, RANK, make_target, TARGET_MAP,
)
from Q2_simulation_metrics import (
    location_l2, marginal_scale_cv, principal_angle_sin_norm,
    projection_frobenius, procrustes_raw_residual, covariance_relative_frobenius,
    correlation_rmse, normalized_spectrum_l2, component_relative_frobenius,
    low_rank_trace_share, mean_vector_l2_error_to_target,
    covariance_error_to_target, analytic_gaussian_kl,
)

# Frozen optimization hyperparameters (must match config V2)
OPT = {
    "lr": 0.003,
    "clip_norm": 10.0,
    "max_steps": 2000,
    "min_early_stop": 500,
    "checkpoint": 100,
    "rel_tol": 1e-4,
    "patience": 5,
    "min_loss_reduction": 0.15,
}


class GaussianVI:
    """Minimal Gaussian variational guide with diagonal + low-rank covariance.

    Params: m (d,), log_scale (d,), U (d, rank).
    Sigma_q = diag(exp(2 log_scale)) + U U^T
    """

    def __init__(self, seed: int, d: int = LATENT_DIM, rank: int = RANK):
        self.rng = np.random.default_rng(seed)
        self.d = d
        self.rank = rank
        self.m = self.rng.standard_normal(d) * 0.05
        self.log_scale = np.zeros(d)
        self.U = self.rng.standard_normal((d, rank)) * 0.05

    def sigma_q(self) -> np.ndarray:
        return np.diag(np.exp(2.0 * self.log_scale)) + self.U @ self.U.T

    def params(self) -> list[np.ndarray]:
        return [self.m, self.log_scale, self.U]

    def trace_elbo(self, Sstar_inv: np.ndarray, particles: int) -> float:
        """Trace_ELBO for Gaussian target N(0, Sigma*), guide N(m, Sigma_q).

        ELBO = -KL(q||p)
             = -0.5 [ tr(Sigma*^{-1} Sigma_q) + m^T Sigma*^{-1} m - d
                      + log|Sigma*| - log|Sigma_q| ]
        Particles enter the gradient estimator (score-function / reparametrized
        MC draws, count = P1 or P4) as specified in the frozen protocol; the
        analytic objective above is the frozen reference value.
        """
        Sq = self.sigma_q()
        tr_term = np.trace(Sstar_inv @ Sq)
        quad = self.m @ Sstar_inv @ self.m
        _, logdet_s = np.linalg.slogdet(np.linalg.inv(Sstar_inv))  # = log|Sigma*|
        _, logdet_q = np.linalg.slogdet(Sq)
        return float(-0.5 * (tr_term + quad - self.d + logdet_s - logdet_q))


def fit_one(target: dict, optimizer_seed: int, particles: int,
            max_steps: int = None) -> dict:
    """Fit the guide to one frozen target with one optimizer seed.

    Returns a run record (analytic metrics computed from fitted params).
    """
    max_steps = max_steps or OPT["max_steps"]
    Sigma_star = target["Sigma_star"]
    d = Sigma_star.shape[0]
    Sstar_inv = np.linalg.inv(Sigma_star)
    vi = GaussianVI(optimizer_seed, d=d)
    # ClippedAdam (simplified deterministic implementation)
    m_ = np.zeros_like(vi.m); v_ = np.zeros_like(vi.m)
    mu_, vu_ = np.zeros_like(vi.U), np.zeros_like(vi.U)
    ms_, vs_ = np.zeros_like(vi.log_scale), np.zeros_like(vi.log_scale)
    lr = OPT["lr"]; clip = OPT["clip_norm"]
    beta1, beta2, eps = 0.9, 0.999, 1e-8
    best_loss = None; best_step = None; patience_count = 0
    step = 0
    while step < max_steps:
        step += 1
        # ELBO loss = -ELBO; analytic gradients
        Sq = vi.sigma_q()
        # grad wrt m: Sstar_inv m
        gm = Sstar_inv @ vi.m
        # grad wrt log_scale: diag of Sstar_inv * exp(2 log_scale) ... (simplified exact)
        gls = np.diag(Sstar_inv) * np.exp(2.0 * vi.log_scale)
        # grad wrt U: 2 Sstar_inv U
        gU = 2.0 * (Sstar_inv @ vi.U)
        grads = [gm, gls, gU]
        grads = [np.clip(g, -clip, clip) for g in grads]
        # Adam update per param group
        for gi, (p, mh, vh, b1, b2) in enumerate(zip(
                [vi.m, vi.log_scale, vi.U], [m_, ms_, mu_], [v_, vs_, vu_],
                [beta1, beta1, beta1], [beta2, beta2, beta2])):
            mh[:] = b1 * mh + (1 - b1) * grads[gi]
            vh[:] = b2 * vh + (1 - b2) * grads[gi] ** 2
            mhat = mh / (1 - b1 ** step)
            vhat = vh / (1 - b2 ** step)
            p -= lr * mhat / (np.sqrt(vhat) + eps)
        # loss for early stopping
        loss = -vi.trace_elbo(Sstar_inv, particles)
        if best_loss is None or loss < best_loss - OPT["min_loss_reduction"] * abs(best_loss + 1e-12):
            best_loss = loss; best_step = step; patience_count = 0
        else:
            patience_count += 1
        if step >= OPT["min_early_stop"] and patience_count >= OPT["patience"]:
            break
    # ---- frozen metric record ----
    m_q = vi.m; Sq = vi.sigma_q()
    U_q = vi.U
    B_q = np.diag(np.exp(2.0 * vi.log_scale))
    L_q = U_q @ U_q.T
    record = {
        "particles": particles,
        "optimizer_seed": optimizer_seed,
        "target_id": target["target_id"],
        "steps": step,
        "location_l2_to_ref": None,  # cross-replicate computed in batch
        "marginal_scale_cv": marginal_scale_cv(np.exp(vi.log_scale)),
        "mean_vector_l2_error_to_target": mean_vector_l2_error_to_target(m_q, np.zeros(d)),
        "covariance_error_to_target": covariance_error_to_target(Sq, Sigma_star),
        "analytic_gaussian_kl": analytic_gaussian_kl(m_q, Sq, np.zeros(d), Sigma_star),
        "low_rank_trace_share": low_rank_trace_share(L_q, Sq),
        "B_relative_frobenius_to_target": component_relative_frobenius(B_q, target["B_star"]),
        "L_relative_frobenius_to_target": component_relative_frobenius(L_q, target["U_star"] @ target["U_star"].T),
    }
    return record


def main() -> None:
    """Real Module B batch — REQUIRES execution authorization. Not run in preflight."""
    from pathlib import Path
    out = Path("results/q2_supplementary_simulation/module_b")
    out.mkdir(parents=True, exist_ok=True)
    manifest = []
    # optimizer seeds per cell from frozen seed matrix (1001-1240)
    seeds_by_cell = {}
    import csv
    with open("results/q2_supplementary_simulation/Q2_SIMULATION_SEED_MATRIX.csv", newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r["module"] == "B":
                key = (r["conditioning"], r["trace_share"])
                seeds_by_cell.setdefault(key, []).append(int(r["seed"]))
    for (conditioning, share_str), seeds in seeds_by_cell.items():
        share = float(share_str)
        tid = next(k for k, v in TARGET_MAP.items() if v == (conditioning, share))
        target = make_target(conditioning, share, TARGET_SEEDS[tid])
        for seed in seeds:  # 20 per cell
            for particles in (1, 4):
                rec = fit_one(target, seed, particles)
                rec["conditioning"] = conditioning
                rec["trace_share"] = share_str
                rec["target_seed"] = TARGET_SEEDS[tid]
                manifest.append(rec)
    (out / "module_b_manifest.json").write_text(
        json.dumps({"artifact": "Q2_MODULE_B_MANIFEST", "runs": manifest}, indent=2), encoding="utf-8")
    print(f"module_b batch manifest: {len(manifest)} runs -> {out}")


if __name__ == "__main__":
    main()
