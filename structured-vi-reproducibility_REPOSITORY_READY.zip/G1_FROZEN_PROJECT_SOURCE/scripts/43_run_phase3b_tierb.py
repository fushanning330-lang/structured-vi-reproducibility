from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd
import yaml

from dhbcp_pv.baselines.phase3b_sidecars import run_mddc_sidecar, run_pvebayes_sidecar
from dhbcp_pv.baselines.registry import PRIMARY_METHODS, run_all_baselines
from dhbcp_pv.evaluation.metrics import (
    discrimination_metrics,
    ranking_metrics,
    state_metrics,
    temporal_metrics,
)
from dhbcp_pv.inference.phase3b_operational import OperationalPanelResult, run_checkpointed_rolling_model
from dhbcp_pv.sim.formal_phase3 import SCENARIOS
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_b_replicate


REFIT_MODELS = ("FULL", "A_NO_HIERARCHY", "A_STICKY_HMM", "A_NO_SERIOUSNESS")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: dict[str, object]) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def parse_ids(specification: str) -> list[int]:
    values: list[int] = []
    for part in specification.split(","):
        if "-" in part:
            start, stop = (int(value) for value in part.split("-", 1))
            values.extend(range(start, stop + 1))
        else:
            values.append(int(part))
    return sorted(set(values))


def metric_rows(
    replicate_id: int,
    scenario: str,
    method: str,
    family: str,
    values: dict[str, float],
) -> list[dict[str, object]]:
    return [
        {
            "replicate_id": replicate_id,
            "scenario": scenario,
            "method": method,
            "metric_family": family,
            "metric": name,
            "value": value,
            "operational_filtering": True,
        }
        for name, value in values.items()
    ]


def finite_discrimination(truth: np.ndarray, score: np.ndarray) -> dict[str, float]:
    mask = np.isfinite(score)
    if not np.any(mask):
        return {"auprc": 0.0, "auroc": 0.5}
    return discrimination_metrics(truth[mask], score[mask])


def run_replicate(
    root: Path,
    replicate_id: int,
    seed: int,
    freeze: dict[str, object],
    optimizer: dict[str, object],
    phase3_config: dict[str, object],
) -> dict[str, object]:
    started = perf_counter()
    replicate = generate_tier_b_replicate(seed, phase3_config)
    result_root = root / "results" / "phase3b"
    rolling_root = result_root / "checkpoints" / "tierb_rolling" / f"replicate_{replicate_id:03d}"
    source_hash = str(freeze["code_tree_sha256"])
    config_hash = str(freeze["formal_freeze_sha256"])
    outputs: dict[str, OperationalPanelResult] = {}
    failure_rows: list[dict[str, object]] = []
    resource_rows: list[dict[str, object]] = []
    for offset, ablation in enumerate(REFIT_MODELS):
        checkpoint = rolling_root / f"{ablation}.pkl.gz"
        model_started = perf_counter()
        try:
            output = run_checkpointed_rolling_model(
                replicate.y,
                replicate.serious,
                replicate.expected,
                replicate.drug_index,
                replicate.event_index,
                seed=seed + 10_000 * offset,
                ablation=ablation,
                checkpoint_path=checkpoint,
                config_hash=config_hash,
                source_hash=source_hash,
                hmax=int(optimizer["primary_hmax"]),
                initial_steps=int(optimizer["primary"]["tier_b_initial_prefix_steps"]),
                updates_per_quarter=int(optimizer["primary"]["tier_b_updates_per_quarter"]),
                learning_rate=float(optimizer["primary"]["learning_rate"]),
                posterior_samples=int(optimizer["primary"]["posterior_draws_primary"]),
            )
        except (FloatingPointError, ArithmeticError) as first_error:
            failed_checkpoint = checkpoint.with_suffix(checkpoint.suffix + ".attempt1_failed")
            if checkpoint.exists():
                os.replace(checkpoint, failed_checkpoint)
            output = run_checkpointed_rolling_model(
                replicate.y,
                replicate.serious,
                replicate.expected,
                replicate.drug_index,
                replicate.event_index,
                seed=seed + 10_000 * offset,
                ablation=ablation,
                checkpoint_path=checkpoint,
                config_hash=config_hash,
                source_hash=source_hash,
                hmax=int(optimizer["primary_hmax"]),
                initial_steps=int(optimizer["primary"]["tier_b_initial_prefix_steps"]),
                updates_per_quarter=int(optimizer["primary"]["tier_b_updates_per_quarter"]),
                learning_rate=float(optimizer["retry_policy"]["retry_learning_rate"]),
                posterior_samples=int(optimizer["primary"]["posterior_draws_primary"]),
            )
            failure_rows.append(
                {
                    "replicate_id": replicate_id,
                    "method": ablation,
                    "quarter": 0,
                    "code": "NUMERICAL_RETRY_RESOLVED",
                    "detail": f"{type(first_error).__name__}: {first_error}",
                    "status": "RESOLVED_ON_FROZEN_RETRY",
                }
            )
        outputs[ablation] = output
        resource_rows.append(
            {
                "replicate_id": replicate_id,
                "method": ablation,
                "optimization_seconds": output.optimization_seconds,
                "posterior_integration_seconds": output.posterior_integration_seconds,
                "total_seconds": perf_counter() - model_started,
                "resumed_from_prefix": output.resumed_from_prefix,
                "posterior_samples": output.posterior_samples,
            }
        )
    method_scores: dict[str, np.ndarray] = {
        "DHBCP_PV_V2": outputs["FULL"].score,
        "A_NO_HIERARCHY": outputs["A_NO_HIERARCHY"].score,
        "A_STICKY_HMM": outputs["A_STICKY_HMM"].score,
        "A_NO_SERIOUSNESS": outputs["A_NO_SERIOUSNESS"].score,
        "A_NO_DECISION_LOSS": outputs["FULL"].p_dangerous,
    }
    method_alerts: dict[str, np.ndarray] = {
        "DHBCP_PV_V2": outputs["FULL"].alert,
        "A_NO_HIERARCHY": outputs["A_NO_HIERARCHY"].alert,
        "A_STICKY_HMM": outputs["A_STICKY_HMM"].alert,
        "A_NO_SERIOUSNESS": outputs["A_NO_SERIOUSNESS"].alert,
        "A_NO_DECISION_LOSS": outputs["FULL"].p_dangerous >= 0.5,
    }
    for method in PRIMARY_METHODS:
        method_scores[method] = np.zeros_like(replicate.expected)
        method_alerts[method] = np.zeros_like(replicate.y, dtype=bool)
    for pair in range(162):
        pair_output = run_all_baselines(replicate.y[pair], replicate.expected[pair])
        for method, baseline in pair_output.items():
            method_scores[method][pair] = baseline.score
            method_alerts[method][pair] = baseline.alert
    method_scores["A_STATIC_BAYESIAN"] = method_scores["STATIC_HIERARCHICAL_NB"]
    method_alerts["A_STATIC_BAYESIAN"] = method_alerts["STATIC_HIERARCHICAL_NB"]

    sidecar_root = root.parents[1] / "phase3b_sidecars"
    scratch = root.parents[1] / "phase3b_scratch"
    mddc_started = perf_counter()
    mddc = run_mddc_sidecar(
        replicate.y,
        replicate.drug_index,
        replicate.event_index,
        seed=seed,
        python_executable=sidecar_root / "mddc_venv2" / "bin" / "python",
        runner=root / "scripts" / "phase3b_sidecars" / "run_mddc.py",
        scratch_root=scratch,
    )
    method_scores["MDDC"] = mddc.score
    method_alerts["MDDC"] = mddc.alert
    resource_rows.append(
        {"replicate_id": replicate_id, "method": "MDDC", "total_seconds": perf_counter() - mddc_started}
    )
    for failure in mddc.failures:
        failure_rows.append(
            {"replicate_id": replicate_id, "method": "MDDC", **failure, "status": "FAILED_PREFIX_CONTINUED"}
        )
    pve_started = perf_counter()
    pve = run_pvebayes_sidecar(
        replicate.y,
        seed=seed,
        r_executable=Path("/usr/local/bin/R"),
        runner=root / "scripts" / "phase3b_sidecars" / "run_pvebayes.R",
        r_library=sidecar_root / "R_libs",
        scratch_root=scratch,
    )
    method_scores["PVEBAYES_GPS"] = pve.score
    method_alerts["PVEBAYES_GPS"] = pve.alert
    resource_rows.append(
        {"replicate_id": replicate_id, "method": "PVEBAYES_GPS", "total_seconds": perf_counter() - pve_started}
    )
    for failure in pve.failures:
        failure_rows.append(
            {"replicate_id": replicate_id, "method": "PVEBAYES_GPS", **failure, "status": "FAILED_PREFIX_CONTINUED"}
        )

    performance_rows: list[dict[str, object]] = []
    state_rows: list[dict[str, object]] = []
    temporal_rows: list[dict[str, object]] = []
    ranking_rows: list[dict[str, object]] = []
    sensitivity_rows: list[dict[str, object]] = []
    primary = outputs["FULL"]
    methods = tuple(method_scores)
    for scenario in SCENARIOS:
        pair_mask = replicate.scenario == scenario
        n_scenario_pairs = int(pair_mask.sum())
        pair_index = np.repeat(np.arange(n_scenario_pairs), 40)
        quarter = np.tile(np.arange(1, 41), n_scenario_pairs)
        truth = replicate.is_true_signal[pair_mask].reshape(-1)
        true_change = np.repeat(replicate.true_change_quarter[pair_mask], 40)
        for method in methods:
            score = method_scores[method][pair_mask].reshape(-1)
            alert = method_alerts[method][pair_mask].reshape(-1)
            performance_rows.extend(
                metric_rows(
                    replicate_id,
                    scenario,
                    method,
                    "discrimination",
                    finite_discrimination(truth, score),
                )
            )
            temporal_rows.extend(
                metric_rows(
                    replicate_id,
                    scenario,
                    method,
                    "temporal",
                    temporal_metrics(alert, pair_index, quarter, true_change),
                )
            )
            ranking_score = np.nan_to_num(score, nan=-np.inf)
            ranking_rows.extend(
                metric_rows(
                    replicate_id,
                    scenario,
                    method,
                    "ranking",
                    ranking_metrics(truth, ranking_score, alert, pair_index, quarter),
                )
            )
        state_values = state_metrics(
            replicate.true_state[pair_mask].reshape(-1),
            replicate.true_x[pair_mask].reshape(-1),
            primary.state_probability[pair_mask].reshape(-1, 4),
            primary.x_mean[pair_mask].reshape(-1),
            primary.x_sd[pair_mask].reshape(-1),
            primary.p_persist_h2[pair_mask].reshape(-1),
            primary.p_change[pair_mask].reshape(-1),
            pair_index,
            true_change,
        )
        state_rows.extend(metric_rows(replicate_id, scenario, "DHBCP_PV_V2", "state", state_values))
        p_dangerous = primary.p_dangerous[pair_mask]
        p_cross = primary.p_dangerous_serious[pair_mask]
        for fn_cost in optimizer["decision"]["fn_fp_ratios"]:
            for severity in optimizer["decision"]["lambda_severity"]:
                delta = (
                    float(fn_cost) * p_dangerous
                    + float(fn_cost) * float(severity) * p_cross
                    - (1.0 - p_dangerous)
                )
                values = temporal_metrics(
                    (delta > 0).reshape(-1), pair_index, quarter, true_change
                )
                for metric, value in values.items():
                    sensitivity_rows.append(
                        {
                            "replicate_id": replicate_id,
                            "scenario": scenario,
                            "sensitivity_type": "decision",
                            "parameter_value": f"FNFP={fn_cost};lambda={severity}",
                            "metric": metric,
                            "value": value,
                            "operational_filtering": True,
                        }
                    )
    return {
        "version": "phase3b_tierb_checkpoint_v1",
        "freeze_sha256": freeze["formal_freeze_sha256"],
        "replicate_id": replicate_id,
        "seed": seed,
        "status": "COMPLETE",
        "wall_clock_seconds": perf_counter() - started,
        "performance_rows": performance_rows,
        "state_rows": state_rows,
        "temporal_rows": temporal_rows,
        "ranking_rows": ranking_rows,
        "sensitivity_rows": sensitivity_rows,
        "resource_rows": resource_rows,
        "failure_rows": failure_rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", default="1-200")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    result = root / "results" / "phase3b"
    freeze = json.loads((result / "64_PHASE3B_FORMAL_FREEZE.json").read_text())
    optimizer_path = root / "config" / "phase3b_optimizer_v1.yaml"
    if sha256(optimizer_path) != freeze["frozen_files"]["config/phase3b_optimizer_v1.yaml"]:
        raise SystemExit("optimizer config changed after formal freeze")
    optimizer = yaml.safe_load(optimizer_path.read_text())
    phase3_config = yaml.safe_load((root / "config" / "phase3_formal_sim_v1.yaml").read_text())
    seeds = pd.read_csv(root / freeze["seed_manifests"]["tier_b"]["path"])
    checkpoint_dir = result / "checkpoints" / "tierb"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    for replicate_id in parse_ids(args.ids):
        path = checkpoint_dir / f"replicate_{replicate_id:03d}.json"
        if path.exists():
            print(f"Tier B {replicate_id:03d}: CHECKPOINT_EXISTS", flush=True)
            continue
        seed = int(seeds.loc[seeds.replicate_id == replicate_id, "seed"].iloc[0])
        try:
            payload = run_replicate(root, replicate_id, seed, freeze, optimizer, phase3_config)
        except Exception as error:
            payload = {
                "version": "phase3b_tierb_checkpoint_v1",
                "freeze_sha256": freeze["formal_freeze_sha256"],
                "replicate_id": replicate_id,
                "seed": seed,
                "status": "FAILED",
                "exception": f"{type(error).__name__}: {error}",
                "performance_rows": [],
                "state_rows": [],
                "temporal_rows": [],
                "ranking_rows": [],
                "sensitivity_rows": [],
                "resource_rows": [],
                "failure_rows": [
                    {
                        "replicate_id": replicate_id,
                        "method": "REPLICATE",
                        "quarter": 0,
                        "code": "UNRESOLVED_REPLICATE_FAILURE",
                        "detail": f"{type(error).__name__}: {error}",
                        "status": "UNRESOLVED",
                    }
                ],
            }
        atomic_json(path, payload)
        print(f"Tier B {replicate_id:03d}: {payload['status']}", flush=True)


if __name__ == "__main__":
    main()
