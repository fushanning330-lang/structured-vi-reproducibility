from pathlib import Path
import subprocess, sys, os

root = Path(__file__).resolve().parents[1]
env = os.environ.copy()
env["PYTHONPATH"] = str(root/"src")
raise SystemExit(subprocess.call(
    [sys.executable, "-m", "unittest", "discover", "-s", str(root/"tests"), "-v"],
    env=env
))
