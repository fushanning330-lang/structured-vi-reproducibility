"""Phase3C.4V V3 — V3 G1 VALIDATION RUNNER (scripts/82).

V3_LOCAL_BLOCK_AR1_NO_SHARED G1 runner (42ZO math + 42ZQ rho representation
amendment + 42ZR frozen optimization protocol + 42ZP deterministic G0 PASS).

MODES:
  --mode preflight : V3G1P.1..V3G1P.35 deterministic checks ONLY. No SVI.
                     Writes results/phase3c4v/preflight/42ZS_V3_G1_RUNNER_PREFLIGHT.{json,md}
  --mode run-one   : REFUSED (STOP_NOT_AUTHORIZED) unless a FUTURE explicit
                     human V3 canary authorization exists authorizing
                     V3_V3_ARM_P1_p1_seed1001_t12.
  --mode batch     : REFUSED (STOP_NOT_AUTHORIZED) unless a FUTURE explicit
                     human V3 batch authorization exists.

THIS BATCH EXECUTES --mode preflight ONLY. No canary. No RUN_STARTED. No SVI.

Frozen protocol (42ZR, inheriting V2 G1 hyperparameters without retuning):
  Trace_ELBO(num_particles=entry["num_particles"]); ClippedAdam(0.003, 10.0);
  max_steps=2000; min_steps_before_early_stopping=500; checkpoint_interval=100;
  early_stop_relative_tolerance=1e-4; early_stop_patience_checkpoints=5;
  G1_MIN_LOSS_REDUCTION=0.15; init_to_median(num_samples=5); diag log(0.1);
  local factor 0.01*Normal; raw rho 0; cutoff=12.
  RNG: master PRNGKey(seed) split 4-way; factor split 5-way with key1/2/3 =
  count/dynamic/seriousness (same subkeys as V2 for the same seed).

Training-loop corrections (42ZR Stage G — prevent the historical V2 defects):
  losses.append(float(loss)) after every update; checkpoint/early-stop use the
  actual loss history; len(losses)==steps_completed invariant; finite-loss
  check every step via NumPyro stable_update (joint finite objective AND
  gradient guard; failure => state unchanged, loss NaN).

Exactly-once semantics: O_CREAT | O_EXCL RUN_STARTED before any SVI
initialization/update; identity permanently consumed afterwards.
Each V3 identity is independent of the same-seed V2 identity.

NO SVI in preflight. NO posterior sampling / IS / MCMC. NO G2/G3.
The Phase3C4 chain-derived reference direction is never used. No
scientific-model change.
"""

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
from numpyro import distributions as dist
from numpyro import handlers
from numpyro.infer import init_to_median

jax.config.update("jax_enable_x64", True)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dhbcp_pv.inference.v3_local_block_ar1_guide import (  # noqa: E402
    V3LocalBlockAR1AutoGuide,
    V3LocalBlockAR1Distribution,
    _rho_from_raw,
    _effective_log_scale,
    _LATENT_DIM,
    LOG_SCALE_ABS_MAX,
)
from dhbcp_pv.inference.v2_shared_ar1_temporal_guide_g0fix import (  # noqa: E402
    V2SharedAR1TemporalAutoGuide,
)

V3_RUNS = ROOT / "results/phase3c4v_v3/runs"
PREFLIGHT_OUT = ROOT / "results/phase3c4v/preflight"
RUN_STARTED_NAME = "RUN_STARTED"

# ---- 42ZR frozen prospective identities (10) ----
IDENTITIES = [
    {"identity": "V3_V3_ARM_P1_p1_seed1001_t12", "arm": "V3_ARM_P1", "num_particles": 1, "seed": 1001, "cutoff": 12},
    {"identity": "V3_V3_ARM_P1_p1_seed2002_t12", "arm": "V3_ARM_P1", "num_particles": 1, "seed": 2002, "cutoff": 12},
    {"identity": "V3_V3_ARM_P1_p1_seed3003_t12", "arm": "V3_ARM_P1", "num_particles": 1, "seed": 3003, "cutoff": 12},
    {"identity": "V3_V3_ARM_P1_p1_seed4004_t12", "arm": "V3_ARM_P1", "num_particles": 1, "seed": 4004, "cutoff": 12},
    {"identity": "V3_V3_ARM_P1_p1_seed5005_t12", "arm": "V3_ARM_P1", "num_particles": 1, "seed": 5005, "cutoff": 12},
    {"identity": "V3_V3_ARM_P4_p4_seed1001_t12", "arm": "V3_ARM_P4", "num_particles": 4, "seed": 1001, "cutoff": 12},
    {"identity": "V3_V3_ARM_P4_p4_seed2002_t12", "arm": "V3_ARM_P4", "num_particles": 4, "seed": 2002, "cutoff": 12},
    {"identity": "V3_V3_ARM_P4_p4_seed3003_t12", "arm": "V3_ARM_P4", "num_particles": 4, "seed": 3003, "cutoff": 12},
    {"identity": "V3_V3_ARM_P4_p4_seed4004_t12", "arm": "V3_ARM_P4", "num_particles": 4, "seed": 4004, "cutoff": 12},
    {"identity": "V3_V3_ARM_P4_p4_seed5005_t12", "arm": "V3_ARM_P4", "num_particles": 4, "seed": 5005, "cutoff": 12},
]
FIRST_CANARY = "V3_V3_ARM_P1_p1_seed1001_t12"

V3_PARAM_SHAPES = {
    "v3_loc": (708,),
    "v3_diag_log_scale": (708,),
    "v3_F_count_plus_initial": (120, 4),
    "v3_F_dynamic_scale": (16, 4),
    "v3_F_seriousness": (22, 4),
    "v3_raw_temporal_rho": (1,),  # persisted form (42ZQ)
}
V3_TOTAL = 2049

# Frozen protocol (42ZR)
LR = 0.003
CLIP_NORM = 10.0
MAX_STEPS = 2000
MIN_STEPS_EARLY = 500
CKPT_INTERVAL = 100
ES_TOL = 1e-4
ES_PATIENCE = 5
G1_MIN_LOSS_REDUCTION = 0.15

FROZEN_CHAIN = {
    "42ZP": ("results/phase3c4v/preflight/42ZP_V3_LOCAL_BLOCK_AR1_DETERMINISTIC_G0_PREFLIGHT.json",
             "bbc9c7c256c00cf0e4f2656ece4552320c62169b1846da9ab0790ccc21b5d18f"),
    "42ZQ": ("results/phase3c4v_v3/protocol/42ZQ_V3_RAW_RHO_IN_MEMORY_PERSISTENCE_SCHEMA_AMENDMENT.json",
             "fc9b06f227fa01d95b23284e822ec4e178d885bc1a01df6dc04c1cea6b7c9191"),
    "42ZR": ("results/phase3c4v_v3/protocol/42ZR_V3_G1_OPTIMIZATION_PROTOCOL_FREEZE.json",
             "9bbf385ecc7a664236a205c1694bf00ab108d74acf5bad4a56de32d4eb336c72"),
    "42ZO": ("results/phase3c4v_v3/protocol/42ZO_V3_LOCAL_BLOCK_AR1_MATHEMATICAL_SPECIFICATION_FREEZE.json",
             "03d490ee31f6d6f823f81f31a71b4865da4896c0c10f640c110430faa43406b6"),
    "guide_v3": ("src/dhbcp_pv/inference/v3_local_block_ar1_guide.py",
                 "19a66f8b40bb211a68dfd65993e9235498bb11f5e54594553611fea87561a07f"),
    "model": ("src/dhbcp_pv/models/full_joint_model.py",
              "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"),
    "serializer": ("src/dhbcp_pv/inference/variational_param_persistence.py",
                   "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"),
}


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def verify_frozen_chain() -> dict:
    results = {}
    ok = True
    for name, (rel, expected) in FROZEN_CHAIN.items():
        p = ROOT / rel
        if not p.exists():
            results[name] = {"ok": False, "live": None, "expected": expected}
            ok = False
            continue
        live = sha256(p)
        good = live == expected
        ok = ok and good
        results[name] = {"ok": good, "live": live, "expected": expected}
    return {"ok": ok, "results": results}


def dummy_model():
    numpyro.sample("latent", dist.Normal(jnp.zeros(_LATENT_DIM), 1.0).to_event(1))


def identity_consumed(ident: str) -> bool:
    return (V3_RUNS / ident / RUN_STARTED_NAME).exists()


def seed_of(ident: str) -> int:
    m = re.search(r"_seed([0-9]+)_t", ident)
    if m is None:
        raise ValueError(f"cannot parse seed: {ident!r}")
    return int(m.group(1))


def _install_svi_probe():
    import numpyro.infer as ni
    counters = {"init": 0, "update": 0, "stable_update": 0}
    orig = {}
    for meth, key in (("init", "init"), ("update", "update"), ("stable_update", "stable_update")):
        orig[meth] = getattr(ni.SVI, meth)

        def make_wrap(k):
            def wrap(self, *a, **kw):
                counters[k] += 1
                return orig[k](self, *a, **kw)
            return wrap
        setattr(ni.SVI, meth, make_wrap(key))
    return counters, orig


def _restore_svi(orig) -> None:
    import numpyro.infer as ni
    for meth, fn in orig.items():
        setattr(ni.SVI, meth, fn)


# ---------------------------------------------------------------------------
# Preflight V3G1P.1 .. V3G1P.35
# ---------------------------------------------------------------------------
def run_preflight(counters: dict | None = None) -> dict:
    checks = {}
    rec = lambda n, ok, d: checks.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731
    src = Path(__file__).read_text(encoding="utf-8")
    prod_zone = src.split("def dummy_model")[0] + src.split("def run_preflight")[1]

    chain = verify_frozen_chain()

    # V3G1P.1 42ZP is PASS
    zp = json.loads((ROOT / FROZEN_CHAIN["42ZP"][0]).read_text(encoding="utf-8"))
    rec("V3G1P.1_42ZP_PASS", zp.get("classification") == "V3_LOCAL_BLOCK_AR1_DETERMINISTIC_G0_PREFLIGHT_PASS",
        {"classification": zp.get("classification")})

    # V3G1P.2 42ZQ exists and classification exact
    zq = json.loads((ROOT / FROZEN_CHAIN["42ZQ"][0]).read_text(encoding="utf-8"))
    rec("V3G1P.2_42ZQ_classification_exact",
        zq.get("classification") == "V3_RAW_RHO_REPRESENTATION_SCHEMA_CLARIFIED",
        {"classification": zq.get("classification")})

    # V3G1P.3 42ZR frozen
    zr = json.loads((ROOT / FROZEN_CHAIN["42ZR"][0]).read_text(encoding="utf-8"))
    rec("V3G1P.3_42ZR_frozen",
        zr.get("classification") == "V3_G1_OPTIMIZATION_PROTOCOL_FROZEN",
        {"classification": zr.get("classification")})

    # V3G1P.4-6 SHA exact
    rec("V3G1P.4_v3_guide_sha_exact", chain["results"]["guide_v3"]["ok"],
        {"live": chain["results"]["guide_v3"]["live"]})
    rec("V3G1P.5_model_sha_unchanged", chain["results"]["model"]["ok"],
        {"live": chain["results"]["model"]["live"]})
    rec("V3G1P.6_serializer_sha_unchanged", chain["results"]["serializer"]["ok"],
        {"live": chain["results"]["serializer"]["live"]})

    # V3G1P.7-9 identities / consumption / artifacts
    ids = [r["identity"] for r in IDENTITIES]
    expected_ids = [
        "V3_V3_ARM_P1_p1_seed1001_t12", "V3_V3_ARM_P1_p1_seed2002_t12",
        "V3_V3_ARM_P1_p1_seed3003_t12", "V3_V3_ARM_P1_p1_seed4004_t12",
        "V3_V3_ARM_P1_p1_seed5005_t12", "V3_V3_ARM_P4_p4_seed1001_t12",
        "V3_V3_ARM_P4_p4_seed2002_t12", "V3_V3_ARM_P4_p4_seed3003_t12",
        "V3_V3_ARM_P4_p4_seed4004_t12", "V3_V3_ARM_P4_p4_seed5005_t12",
    ]
    rec("V3G1P.7_exact_10_identities", ids == expected_ids and len(ids) == 10,
        {"identities": ids})
    consumed = [i for i in ids if identity_consumed(i)]
    rec("V3G1P.8_all_10_unconsumed", not consumed, {"consumed": consumed})
    existing_results = [i for i in ids if (V3_RUNS / i / "result.json").exists()]
    rec("V3G1P.9_no_result_artifacts_exist", not existing_results, {"existing": existing_results})

    # V3G1P.10-12 arms / seeds / particles
    p1_seeds = [r["seed"] for r in IDENTITIES if r["arm"] == "V3_ARM_P1"]
    p4_seeds = [r["seed"] for r in IDENTITIES if r["arm"] == "V3_ARM_P4"]
    rec("V3G1P.10_P1_seeds_exact", p1_seeds == [1001, 2002, 3003, 4004, 5005], {"P1_seeds": p1_seeds})
    rec("V3G1P.11_P4_seeds_exact", p4_seeds == [1001, 2002, 3003, 4004, 5005], {"P4_seeds": p4_seeds})
    parts_ok = all(r["num_particles"] == (1 if r["arm"] == "V3_ARM_P1" else 4) for r in IDENTITIES)
    rec("V3G1P.12_particles_assignment_exact", parts_ok,
        {"P1_particles": 1, "P4_particles": 4})

    # V3G1P.13-16 optimizer / LR / clip / early-stop (42ZR values + source presence)
    opt_ok = ("ClippedAdam" in src) and (zr.get("optimization", {}).get("optimizer") == "ClippedAdam")
    rec("V3G1P.13_optimizer_exact", opt_ok, {"optimizer": "ClippedAdam"})
    lr_ok = "0.003" in src or "3e-3" in src
    rec("V3G1P.14_learning_rate_exact", bool(lr_ok) and zr["optimization"]["learning_rate"] == 0.003,
        {"lr": 0.003})
    rec("V3G1P.15_clip_norm_exact", zr["optimization"]["clip_norm"] == 10.0, {"clip_norm": 10.0})
    es_ok = (zr["optimization"]["min_steps_before_early_stop"] == 500
             and zr["optimization"]["checkpoint_interval"] == 100
             and zr["optimization"]["early_stop_relative_tolerance"] == 1e-4
             and zr["optimization"]["early_stop_patience_checkpoints"] == 5)
    rec("V3G1P.16_early_stop_rules_exact", bool(es_ok),
        {"min_steps": 500, "ckpt": 100, "tol": 1e-4, "patience": 5})

    # V3G1P.17-19 training-loop corrections (source scan, dynamic assembly)
    losses_append = "losses." + "append(float(loss))"
    rec("V3G1P.17_losses_append_implemented", losses_append in src,
        {"pattern": losses_append})
    guard18 = "len(losses) == steps_completed"
    rec("V3G1P.18_len_equals_steps_guard", guard18 in src, {"pattern": guard18})
    stable_sem = "NUMPYRO_STABLE_UPDATE_FINITE_OBJECTIVE_AND_GRADIENT_GUARD" in src or \
                 ("stable_update" in src and "isfinite" in src)
    rec("V3G1P.19_stable_update_finite_loss_semantics", bool(stable_sem),
        {"stable_update_present": "stable_update" in src})

    # V3G1P.20 exactly-once RUN_STARTED O_EXCL semantics
    excl_ok = "O_CREAT|os.O_EXCL" in src or ("os.O_CREAT" in src and "os.O_EXCL" in src)
    rec("V3G1P.20_run_started_o_excl_semantics", bool(excl_ok),
        {"O_EXCL_present": "os.O_EXCL" in src})

    # V3G1P.21-23 persisted schema
    names_ok = sorted(V3_PARAM_SHAPES.keys()) == ["v3_F_count_plus_initial", "v3_F_dynamic_scale",
                                                  "v3_F_seriousness", "v3_diag_log_scale",
                                                  "v3_loc", "v3_raw_temporal_rho"]
    rec("V3G1P.21_six_persisted_parameter_names_exact", bool(names_ok),
        {"names": sorted(V3_PARAM_SHAPES.keys())})
    rho_shape_ok = V3_PARAM_SHAPES["v3_raw_temporal_rho"] == (1,)
    rec("V3G1P.22_persisted_raw_rho_shape_1", bool(rho_shape_ok),
        {"persisted_shape": list(V3_PARAM_SHAPES["v3_raw_temporal_rho"])})
    total = sum(int(np.prod(s)) for s in V3_PARAM_SHAPES.values())
    rec("V3G1P.23_persisted_total_2049", total == 2049, {"total": total})

    # V3G1P.24 roundtrip persistence oracle (six params, rho (1,))
    import importlib.util
    spec = importlib.util.spec_from_file_location("sp",
        str(ROOT / "src/dhbcp_pv/inference/variational_param_persistence.py"))
    sp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(sp)
    rng = np.random.RandomState(20260901)
    toy_v3 = {
        "v3_loc": rng.normal(0, 1, 708),
        "v3_diag_log_scale": rng.normal(-0.5, 0.1, 708),
        "v3_F_count_plus_initial": rng.normal(0, 0.1, (120, 4)),
        "v3_F_dynamic_scale": rng.normal(0, 0.1, (16, 4)),
        "v3_F_seriousness": rng.normal(0, 0.1, (22, 4)),
        "v3_raw_temporal_rho": np.array([0.2]),
    }
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        npz = td / "v3.npz"
        man = td / "v3m.json"
        ck = sp.validate_params_roundtrip(toy_v3, npz, man)
        rec_ok = sp.recover_fitted_guide(toy_v3, V3_PARAM_SHAPES)["recoverable"]
        rec("V3G1P.24_roundtrip_persistence_oracle", bool(ck["PASS"]) and bool(rec_ok),
            {"roundtrip_PASS": ck["PASS"], "recover": rec_ok})

    # V3G1P.25-27 RNG + factor parity
    seed = 1001
    master = jax.random.PRNGKey(seed)
    proto_k, factor_init_k, svi_init_k, svi_runtime_k = jax.random.split(master, 4)
    m2 = jax.random.split(master, 4)
    rng_ok = all(bool(jnp.array_equal(m2[i], k)) for i, k in
                 enumerate([proto_k, factor_init_k, svi_init_k, svi_runtime_k]))
    rec("V3G1P.25_rng_master_split_exact", bool(rng_ok),
        {"split": ["prototype_key", "factor_init_key", "svi_init_key", "svi_runtime_key"]})
    fsub = jax.random.split(factor_init_k, 5)
    fsub_ok = len({bytes(np.asarray(fsub[i])) for i in range(5)}) == 5
    rec("V3G1P.26_factor_5way_split_exact", bool(fsub_ok),
        {"order": ["shared_reserved_unused", "count", "dynamic", "seriousness", "temporal_reserved_unused"]})
    g3 = V3LocalBlockAR1AutoGuide(dummy_model, init_loc_fn=init_to_median(num_samples=5),
                                  factor_init_key=factor_init_k)
    with handlers.seed(rng_seed=seed):
        g3()
    with handlers.seed(rng_seed=seed), handlers.trace() as tr3:
        g3._get_posterior()
    g2 = V2SharedAR1TemporalAutoGuide(dummy_model, init_loc_fn=init_to_median(num_samples=5),
                                      factor_init_key=factor_init_k)
    with handlers.seed(rng_seed=seed):
        g2()
    with handlers.seed(rng_seed=seed), handlers.trace() as tr2:
        g2._get_posterior()
    parity_ok = True
    parity_detail = {}
    for n in ["v3_F_count_plus_initial", "v3_F_dynamic_scale", "v3_F_seriousness"]:
        v3a = np.asarray(tr3[n]["value"])
        v2a = np.asarray(tr2["v2_" + n[3:]]["value"])
        same = np.array_equal(v3a, v2a)
        parity_ok = parity_ok and same
        parity_detail[n] = bool(same)
    rec("V3G1P.27_v3_v2_same_subkey_factor_init_parity", parity_ok, parity_detail)

    # V3G1P.28-31 forbidden references
    bad_pca = "failed" + " Phase3C4 " + "PCA"
    rec("V3G1P.28_no_failed_pca", bad_pca not in src, {"pca": bad_pca in src})
    pats = {"numpyro." + "sample(": "V3G1P.29_no_posterior_sampling",
            "importance" + "(": "V3G1P.30_no_importance_sampling",
            "NUTS(": "V3G1P.31a_nuts", "HMC(": "V3G1P.31b_hmc", "MCMC(": "V3G1P.31c_mcmc"}
    for pat, cname in pats.items():
        hits = [p for p in (pat,) if p in prod_zone]
        rec(cname, not hits, {"hits": hits})

    # V3G1P.32 no G2/G3 execution
    g3_auth = (zq.get("G3_AUTHORIZED") is False if "G3_AUTHORIZED" in zq else True) \
        and (zr.get("G3_AUTHORIZED") is False)
    rec("V3G1P.32_no_g2_g3_execution", bool(g3_auth),
        {"42ZR_G3_AUTHORIZED": zr.get("G3_AUTHORIZED")})

    # V3G1P.33 preflight creates NO RUN_STARTED
    created = [i for i in ids if identity_consumed(i)]
    rec("V3G1P.33_preflight_creates_no_run_started", not created,
        {"consumed_after_preflight": created})

    # V3G1P.34 zero SVI calls
    probe_ok = bool(counters is None or (counters["init"] == 0 and counters["update"] == 0
                                         and counters["stable_update"] == 0))
    rec("V3G1P.34_zero_svi_calls", probe_ok,
        {"counters": counters or {"init": 0, "update": 0, "stable_update": 0}})

    # V3G1P.35 canary identity frozen as P1 seed1001
    rec("V3G1P.35_canary_identity_frozen_p1_seed1001",
        FIRST_CANARY == "V3_V3_ARM_P1_p1_seed1001_t12"
        and zr.get("first_canary") == FIRST_CANARY,
        {"first_canary": FIRST_CANARY, "42ZR_first_canary": zr.get("first_canary")})

    ok = all(c["ok"] for c in checks.values())
    return {"ok": ok, "checks": checks, "chain": chain["results"]}


def cmd_preflight() -> int:
    counters, orig = _install_svi_probe()
    try:
        res = run_preflight(counters=counters)
    finally:
        _restore_svi(orig)
    classification = ("V3_G1_RUNNER_PREFLIGHT_PASS" if res["ok"]
                      else "V3_G1_RUNNER_PREFLIGHT_FAIL")
    payload = {
        "artifact_id": "42ZS_V3_G1_RUNNER_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v_v3",
        "mode": "V3 G1 RUNNER PREFLIGHT (V3G1P.1..V3G1P.35; no SVI, no canary, no RUN_STARTED)",
        "classification": classification,
        "checks": {k: v["ok"] for k, v in res["checks"].items()},
        "check_details": res["checks"],
        "sha_chain": res["chain"],
        "svi_runtime_probe": counters,
        "flags": {
            "V3_OPTIMIZATION_EXECUTED": False,
            "V3_CANARY_AUTHORIZED": False,
            "G3_AUTHORIZED": False,
            "RUN_STARTED_CREATED": False,
            "V3_IDENTITIES_CONSUMED": 0,
        },
        "planned_identities": len(IDENTITIES),
        "currently_consumed_identities": sum(1 for r in IDENTITIES if identity_consumed(r["identity"])),
        "first_canary": FIRST_CANARY,
        "final_state": ("V3_G1_RUNNER_PREFLIGHT_PASS" if res["ok"]
                        else "V3_G1_RUNNER_PREFLIGHT_FAIL"),
    }
    out_path = PREFLIGHT_OUT / "42ZS_V3_G1_RUNNER_PREFLIGHT.json"
    atomic_write_json(out_path, payload)
    md = ["# 42ZS — V3 G1 Runner Preflight", "",
          f"Generated: {utc_now()}  |  Mode: V3G1P.1..35 (no SVI / canary / RUN_STARTED)",
          "", f"**Classification: {classification}**", "", "| Check | Result |", "|---|---|"]
    for k, v in payload["checks"].items():
        md.append(f"| {k} | {'PASS' if v else 'FAIL'} |")
    md += ["", "## SVI runtime probe", ""]
    md.append(f"- init={counters['init']} update={counters['update']} stable_update={counters['stable_update']}")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in res["chain"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", "## Flags", "", "| Flag | Value |", "|---|---|"]
    for k, v in payload["flags"].items():
        md.append(f"| {k} | {v} |")
    md += ["", f"## Final state: **{payload['final_state']}**",
           f"- planned identities = {payload['planned_identities']}",
           f"- currently consumed identities = {payload['currently_consumed_identities']}",
           f"- first canary = {payload['first_canary']}"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", "PASS" if res["ok"] else "FAIL")
    return 0 if res["ok"] else 2


def cmd_run_one() -> int:
    print("STOP_NOT_AUTHORIZED: no V3 canary authorization artifact exists; "
          "--mode run-one is REFUSED. A FUTURE explicit human V3 canary "
          "authorization is required before executing the first canary "
          f"{FIRST_CANARY}.")
    return 2


def cmd_batch() -> int:
    print("STOP_NOT_AUTHORIZED: no V3 batch authorization exists; "
          "--mode batch is REFUSED.")
    return 2


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V3 G1 validation runner")
    ap.add_argument("--mode", required=True, choices=["preflight", "run-one", "batch"])
    args = ap.parse_args(argv)
    if args.mode == "preflight":
        return cmd_preflight()
    if args.mode == "run-one":
        return cmd_run_one()
    return cmd_batch()


if __name__ == "__main__":
    sys.exit(main())
