#!/usr/bin/env python
"""Phase 3C.2 equivalence check and known-problematic chain1 short pilot."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping

os.environ.setdefault("JAX_ENABLE_X64", "1")
os.environ.setdefault("XLA_FLAGS", "--xla_force_host_platform_device_count=4")

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
import yaml
from jax import random
from numpyro import handlers
from numpyro.infer import MCMC, NUTS

from dhbcp_pv.inference.phase3c2_level_contrast import (
    helmert_level_contrast_basis,
    level_contrast_reference_model,
    level_contrast_to_path,
    original_coordinates_to_level_contrast,
    path_to_original_coordinates,
)
from dhbcp_pv.inference.phase3c_stabilized import assert_x64_reference_mode
from dhbcp_pv.models.full_joint_model import full_joint_model
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_a_replicate


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: Path, payload: Mapping[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
    os.replace(tmp, path)


def atomic_npz(path: Path, arrays: Mapping[str, np.ndarray]):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as f:
        np.savez_compressed(f, **arrays)
    os.replace(tmp, path)


def reference_data(root: Path, cutoff=12):
    seeds = pd.read_csv(root / "config/phase3b_tiera_seeds_v1.csv")
    seed = int(seeds.loc[seeds.replicate_id == 1, "seed"].iloc[0])
    replicate = generate_tier_a_replicate(seed, n_quarters=40)
    pair_mask = (replicate.drug_index < 10) & (replicate.event_index < 5)
    if int(pair_mask.sum()) != 50:
        raise RuntimeError("frozen reference subset is not 10 drugs x 5 events")
    args = (
        jnp.asarray(replicate.y[pair_mask, :cutoff]),
        jnp.asarray(replicate.serious[pair_mask, :cutoff]),
        jnp.asarray(replicate.expected[pair_mask, :cutoff], dtype=jnp.float64),
        jnp.asarray(replicate.drug_index[pair_mask]),
        jnp.asarray(replicate.event_index[pair_mask]),
        10,
        5,
    )
    return seed, args, {"hmax": 12}


def trace_log_joint(model, key, params, args, kwargs):
    wrapped = handlers.substitute(handlers.seed(model, key), data=params)
    trace = handlers.trace(wrapped).get_trace(*args, **kwargs)
    total = jnp.asarray(0.0, dtype=jnp.float64)
    for site in trace.values():
        if site.get("type") != "sample":
            continue
        fn, value = site.get("fn"), site.get("value")
        if fn is not None:
            total = total + jnp.sum(fn.log_prob(value))
    return float(total)


def original_latent_draw(key, args, kwargs):
    trace = handlers.trace(handlers.seed(full_joint_model, key)).get_trace(*args, **kwargs)
    excluded_prefixes = (
        "count_log_likelihood",
        "hsmm_and_increment_target_correction",
    )
    return {
        name: site["value"]
        for name, site in trace.items()
        if site.get("type") == "sample"
        and not site.get("is_observed", False)
        and not name.startswith(excluded_prefixes)
    }


def run_equivalence(root: Path):
    assert_x64_reference_mode()
    seed, args, kwargs = reference_data(root, 12)

    # Complete scientific model on a deterministic small panel to keep this test fast.
    small_args = (
        args[0][:2, :4], args[1][:2, :4], args[2][:2, :4],
        jnp.asarray([0, 1]), jnp.asarray([0, 1]), 2, 2,
    )

    # Algebraic basis checks at the actual pilot T=12.
    u, q = helmert_level_contrast_basis(12, dtype=jnp.float64)
    h = jnp.concatenate([u[:, None], q], axis=1)
    orth_error = float(jnp.max(jnp.abs(h.T @ h - jnp.eye(12, dtype=jnp.float64))))
    zero_sum_error = float(jnp.max(jnp.abs(jnp.sum(q, axis=0))))
    det_abs = float(jnp.abs(jnp.linalg.det(h)))

    rows, errors = [], []
    for index in range(5):
        key = random.PRNGKey(seed + 92000 + index)
        params_original = original_latent_draw(key, small_args, kwargs)
        level, contrast, _ = original_coordinates_to_level_contrast(
            params_original["x_initial"], params_original["base_increment"]
        )
        params_reparam = {
            name: value for name, value in params_original.items()
            if name not in {"x_initial", "base_increment"}
        }
        params_reparam["path_level_coord"] = level
        params_reparam["path_contrast_coord"] = contrast

        old = trace_log_joint(
            full_joint_model, random.PRNGKey(1991 + index),
            params_original, small_args, kwargs
        )
        new = trace_log_joint(
            level_contrast_reference_model, random.PRNGKey(1991 + index),
            params_reparam, small_args, kwargs
        )
        err = abs(old - new)
        errors.append(err)
        rows.append({
            "index": index,
            "original_log_joint": old,
            "reparam_log_joint": new,
            "absolute_error": err,
        })

        x = level_contrast_to_path(level, contrast)
        x0, inc = path_to_original_coordinates(x)
        if not bool(jnp.allclose(x0, params_original["x_initial"], atol=1e-12, rtol=0)):
            raise RuntimeError("x_initial round-trip failed")
        if not bool(jnp.allclose(inc, params_original["base_increment"], atol=1e-12, rtol=0)):
            raise RuntimeError("base_increment round-trip failed")

    payload = {
        "version": "phase3c2_level_contrast_equivalence_v1",
        "created_utc": utc_now(),
        "scientific_target_changed": False,
        "max_absolute_log_joint_error": max(errors),
        "tolerance": 1e-6,
        "helmert_orthogonality_max_error": orth_error,
        "helmert_zero_sum_max_error": zero_sum_error,
        "helmert_abs_determinant": det_abs,
        "passed": bool(max(errors) <= 1e-6 and orth_error <= 1e-12 and zero_sum_error <= 1e-12 and abs(det_abs - 1.0) <= 1e-12),
        "rows": rows,
    }
    atomic_json(root / "results/phase3c2/01_TARGET_EQUIVALENCE.json", payload)
    print(json.dumps(payload, indent=2))
    if not payload["passed"]:
        raise SystemExit("TARGET EQUIVALENCE: FAIL")
    print("TARGET EQUIVALENCE: PASS")
    return payload


def ebfmi(energy):
    e = np.asarray(energy, dtype=float).reshape(-1)
    variance = np.var(e, ddof=1)
    if len(e) < 2 or variance <= 0:
        return float("nan")
    return float(np.mean(np.diff(e) ** 2) / variance)


def original_chain_rng_key(seed, cutoff, chain_id):
    return random.split(random.PRNGKey(seed + 6000 + cutoff), 4)[chain_id]


def run_pilot(root: Path, chain_id: int):
    assert_x64_reference_mode()
    cfg = yaml.safe_load((root / "config/phase3c2_level_contrast_pilot_v1.yaml").read_text())
    cutoff = int(cfg["reference"]["cutoff"])
    seed, args, kwargs = reference_data(root, cutoff)
    p = cfg["pilot"]

    dense_mass = [
        tuple(cfg["mass_matrix"]["count_plus_level_block"]),
        tuple(cfg["mass_matrix"]["dynamic_block"]),
        tuple(cfg["mass_matrix"]["seriousness_block"]),
    ]

    kernel = NUTS(
        level_contrast_reference_model,
        dense_mass=dense_mass,
        target_accept_prob=float(p["target_accept_prob"]),
        max_tree_depth=int(p["max_tree_depth"]),
        regularize_mass_matrix=bool(p["regularize_mass_matrix"]),
    )
    mcmc = MCMC(
        kernel,
        num_warmup=int(p["warmup"]),
        num_samples=int(p["samples"]),
        num_chains=1,
        chain_method="sequential",
        progress_bar=True,
        progress_rate=25,
    )

    started = perf_counter()
    mcmc.run(
        original_chain_rng_key(seed, cutoff, chain_id),
        *args,
        extra_fields=("diverging", "num_steps", "accept_prob", "energy", "potential_energy"),
        **kwargs,
    )
    raw = mcmc.get_samples(group_by_chain=True)
    extra = mcmc.get_extra_fields(group_by_chain=True)
    jax.block_until_ready(jax.tree.leaves(raw)[0])

    level = raw["path_level_coord"]
    contrast = raw["path_contrast_coord"]
    x = level_contrast_to_path(level, contrast)
    x0, inc = path_to_original_coordinates(x)

    samples = dict(raw)
    samples["x_initial"] = x0
    samples["base_increment"] = inc
    samples["x"] = x
    arrays = {name: np.asarray(value) for name, value in samples.items()}
    arrays.update({f"_extra_{name}": np.asarray(value) for name, value in extra.items()})

    divergences = int(np.asarray(extra["diverging"], dtype=bool).sum())
    finite = all(np.isfinite(v).all() for v in arrays.values())
    bfmi_value = ebfmi(np.asarray(extra["energy"])[0])
    max_tree_depth = int(p["max_tree_depth"])
    saturation_threshold = 2 ** max_tree_depth - 1
    num_steps = np.asarray(extra["num_steps"])[0]
    tree_sat = float(np.mean(num_steps >= saturation_threshold))
    accept_mean = float(np.mean(np.asarray(extra["accept_prob"])[0]))

    gate = cfg["pilot_gate"]
    passed = bool(
        divergences == int(gate["divergences"])
        and finite == bool(gate["finite_posterior"])
        and bfmi_value >= float(gate["ebfmi_min"])
        and tree_sat <= float(gate["tree_depth_saturation_rate_max"])
    )

    result_dir = root / "results/phase3c2/pilot"
    artifact = result_dir / f"LEVEL_CONTRAST_t{cutoff:02d}_chain{chain_id}.npz"
    atomic_npz(artifact, arrays)
    payload = {
        "version": "phase3c2_level_contrast_pilot_result_v1",
        "created_utc": utc_now(),
        "status": "PASS_PROMISING" if passed else "FAIL_NOT_PROMISING",
        "scientific_target_changed": False,
        "chain_id": chain_id,
        "cutoff": cutoff,
        "warmup": int(p["warmup"]),
        "samples": int(p["samples"]),
        "target_accept_prob": float(p["target_accept_prob"]),
        "max_tree_depth": max_tree_depth,
        "dense_mass": [list(v) for v in dense_mass],
        "divergences": divergences,
        "finite_posterior": finite,
        "ebfmi": bfmi_value,
        "tree_depth_saturation_rate": tree_sat,
        "mean_accept_prob": accept_mean,
        "elapsed_seconds": perf_counter() - started,
        "artifact": {
            "path": artifact.relative_to(root).as_posix(),
            "bytes": artifact.stat().st_size,
            "sha256": sha256(artifact),
        },
        "pilot_gate": gate,
        "passed": passed,
    }
    atomic_json(artifact.with_suffix(".json"), payload)
    print(json.dumps(payload, indent=2))
    print("PHASE3C2 PILOT:", payload["status"])
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("equivalence", "pilot"), required=True)
    parser.add_argument("--chain-id", type=int, choices=(0,1,2,3), default=1)
    ns = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    if ns.mode == "equivalence":
        run_equivalence(root)
        return
    eq_path = root / "results/phase3c2/01_TARGET_EQUIVALENCE.json"
    if not eq_path.exists():
        raise SystemExit("Run --mode equivalence first.")
    eq = json.loads(eq_path.read_text())
    if not eq.get("passed"):
        raise SystemExit("Target equivalence did not pass.")
    run_pilot(root, ns.chain_id)


if __name__ == "__main__":
    main()
