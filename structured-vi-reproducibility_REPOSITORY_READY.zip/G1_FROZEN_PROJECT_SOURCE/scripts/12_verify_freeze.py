from __future__ import annotations
import sys
from importlib.metadata import version, PackageNotFoundError

EXPECTED = {
    "numpy":"2.5.2","pandas":"3.0.5","pyarrow":"25.0.1","scipy":"1.18.0",
    "scikit-learn":"1.9.0","jax":"0.11.0","jaxlib":"0.11.0","numpyro":"0.21.0",
    "duckdb":"1.5.4","PyYAML":"6.0.3","matplotlib":"3.11.1","arviz":"1.2.0",
    "ruptures":"1.1.10",
}
bad = []
if sys.version_info[:2] != (3,12):
    bad.append(f"Python expected 3.12.x, got {sys.version.split()[0]}")
for pkg, want in EXPECTED.items():
    try:
        got = version(pkg)
    except PackageNotFoundError:
        bad.append(f"{pkg}: missing (expected {want})")
        continue
    if got != want:
        bad.append(f"{pkg}: expected {want}, got {got}")
if bad:
    print("FREEZE CHECK FAILED")
    print("\\n".join(bad))
    raise SystemExit(2)
print("FREEZE CHECK PASSED")
