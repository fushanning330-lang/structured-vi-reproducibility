"""Q2 supplementary simulation — frozen metric library (shared).

Artifact: Q2_simulation_metrics.py
Frozen: 2026-08-23 (protocol repair, V2). PRE-EXECUTION; no fitting here.

All metrics reuse the frozen DHBCP-PV G2/G3 definitions (43S/43W) where a
definition exists, or the frozen Q2 known-target definitions from
Q2_SIMULATION_PROTOCOL_FREEZE_V2.

F1 REPAIR: the known-target mean metric is the mean-VECTOR L2 error
  d_mu = ||m_q - m_star||_2, with m_star = 0 in this synthetic design,
  so d_mu = ||m_q||_2.  The previously proposed signed elementwise
  covariance-mean error is REMOVED and must not be used as a primary
  known-target metric; no such implementation exists in this module.

No universal PASS/FAIL threshold is defined here; ENG_TOL is a numerical
equality tolerance only (not a scientific stability threshold).
"""

from __future__ import annotations

import numpy as np

ENG_TOL = 1e-6


# ---------------------------------------------------------------------------
# cross-replicate metrics (frozen G2/G3 definitions)
# ---------------------------------------------------------------------------
def location_l2(m1: np.ndarray, m2: np.ndarray) -> float:
    """43S location_l2_distance: L2 distance between replicate posterior means."""
    return float(np.linalg.norm(np.asarray(m1) - np.asarray(m2)))


def marginal_scale_cv(scales: np.ndarray) -> float:
    """43S marginal_scale_cv_across_coords: population CV (ddof=0) across coords."""
    s = np.asarray(scales, dtype=np.float64)
    return float(s.std(ddof=0) / (s.mean() + 1e-300))


def principal_angle_sin_norm(U1: np.ndarray, U2: np.ndarray) -> float:
    """43S principal_angle_sin_F: || sin(theta) ||_2 between factor subspaces.

    Computed via SVD of Q1^T Q2 where Q1, Q2 are orthonormal bases.
    """
    Q1, _ = np.linalg.qr(np.asarray(U1, dtype=np.float64))
    Q2, _ = np.linalg.qr(np.asarray(U2, dtype=np.float64))
    _, sv, _ = np.linalg.svd(Q1.T @ Q2)
    sv = np.clip(sv, -1.0, 1.0)
    return float(np.linalg.norm(np.sqrt(np.maximum(0.0, 1.0 - sv**2))))


def projection_frobenius(U1: np.ndarray, U2: np.ndarray) -> float:
    """43S projection_frobenius_distance: ||P1 - P2||_F for subspace projections."""
    P1 = np.asarray(U1, dtype=np.float64) @ np.linalg.pinv(np.asarray(U1, dtype=np.float64))
    P2 = np.asarray(U2, dtype=np.float64) @ np.linalg.pinv(np.asarray(U2, dtype=np.float64))
    return float(np.linalg.norm(P1 - P2, ord="fro"))


def procrustes_raw_residual(U1: np.ndarray, U2: np.ndarray) -> float:
    """43S procrustes_raw_residual: raw-only orthogonal Procrustes residual."""
    Q1, _ = np.linalg.qr(np.asarray(U1, dtype=np.float64))
    Q2, _ = np.linalg.qr(np.asarray(U2, dtype=np.float64))
    U, _, Vt = np.linalg.svd(Q2.T @ Q1)
    Q_opt = U @ Vt
    return float(np.linalg.norm(Q1 - Q2 @ Q_opt, ord="fro"))


def covariance_relative_frobenius(S1: np.ndarray, S2: np.ndarray) -> float:
    """43W sigma_relative_frobenius: ||S1-S2||_F / 0.5(||S1||_F + ||S2||_F)."""
    S1 = np.asarray(S1, dtype=np.float64); S2 = np.asarray(S2, dtype=np.float64)
    denom = 0.5 * (np.linalg.norm(S1, ord="fro") + np.linalg.norm(S2, ord="fro"))
    assert denom > 0.0, "deterministic abort: non-positive denominator (no epsilon fallback)"
    return float(np.linalg.norm(S1 - S2, ord="fro") / denom)


def correlation_rmse(S1: np.ndarray, S2: np.ndarray) -> float:
    """43W correlation_rmse: RMSE over strict upper triangle of correlation matrices."""
    S1 = np.asarray(S1, dtype=np.float64); S2 = np.asarray(S2, dtype=np.float64)
    def corr(S):
        d = np.sqrt(np.diag(S))
        assert np.all(d > 0), "no epsilon fallback"
        return S / np.outer(d, d)
    R1, R2 = corr(S1), corr(S2)
    iu = np.triu_indices(S1.shape[0], k=1)
    return float(np.sqrt(np.mean((R1[iu] - R2[iu]) ** 2)))


def normalized_spectrum_l2(S1: np.ndarray, S2: np.ndarray) -> float:
    """43W spectrum_l2_distance: L2 between trace-normalized eigen-spectra."""
    S1 = np.asarray(S1, dtype=np.float64); S2 = np.asarray(S2, dtype=np.float64)
    def spec(S):
        ev = np.linalg.eigvalsh(S)
        t = ev.sum()
        assert t > 0.0, "trace > 0 required"
        return ev / t
    return float(np.linalg.norm(spec(S1) - spec(S2)))


def component_relative_frobenius(A1: np.ndarray, A2: np.ndarray) -> float:
    """43W component_relative_frobenius_B/L: relative Frobenius of a component."""
    A1 = np.asarray(A1, dtype=np.float64); A2 = np.asarray(A2, dtype=np.float64)
    return covariance_relative_frobenius(A1, A2)


def low_rank_trace_share(L: np.ndarray, Sigma: np.ndarray) -> float:
    """43W per-run low_rank_trace_share: tr(L)/tr(Sigma)."""
    return float(np.trace(L) / np.trace(Sigma))


# ---------------------------------------------------------------------------
# known-target metrics (frozen Q2 definitions; F1-repaired)
# ---------------------------------------------------------------------------
def mean_vector_l2_error_to_target(m_q: np.ndarray, m_star: np.ndarray) -> float:
    """F1 REPAIR: d_mu = ||m_q - m_star||_2.  Synthetic target m_star = 0."""
    return float(np.linalg.norm(np.asarray(m_q, dtype=np.float64) - np.asarray(m_star, dtype=np.float64)))


def covariance_error_to_target(Sigma_hat: np.ndarray, Sigma_star: np.ndarray) -> float:
    """Known-target covariance relative Frobenius error to Sigma*."""
    return covariance_relative_frobenius(Sigma_hat, Sigma_star)


def analytic_gaussian_kl(m_q: np.ndarray, Sigma_q: np.ndarray,
                         m_star: np.ndarray, Sigma_star: np.ndarray) -> float:
    """KL(q || p) for q=N(m_q,Sigma_q), p=N(m_star,Sigma_star), both Gaussian.

    KL = 0.5 [ tr(Sigma*^{-1} Sigma_q) + (m_q-m*)^T Sigma*^{-1} (m_q-m*)
               - d + log|Sigma*| - log|Sigma_q| ]

    Sigma_q = B_q + U_q U_q^T handled by caller: pass the full Sigma_q.
    Uses solve/eigvalsh only (float64); no sampling.
    """
    d = m_q.shape[0]
    diff = np.asarray(m_q, dtype=np.float64) - np.asarray(m_star, dtype=np.float64)
    Sstar = np.asarray(Sigma_star, dtype=np.float64)
    Sq = np.asarray(Sigma_q, dtype=np.float64)
    Sstar_inv = np.linalg.inv(Sstar)
    tr_term = np.trace(Sstar_inv @ Sq)
    quad = diff @ Sstar_inv @ diff
    sign_ls, logdet_s = np.linalg.slogdet(Sstar)
    sign_lq, logdet_q = np.linalg.slogdet(Sq)
    assert sign_ls > 0 and sign_lq > 0, "positive-definite required for analytic KL"
    return float(0.5 * (tr_term + quad - d + logdet_s - logdet_q))
