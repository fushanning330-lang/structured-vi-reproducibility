"""Phase3C.4 variational automation watchdog (scripts/63).

BACKGROUND, UNATTENDED SUPERVISION ONLY. This file NEVER executes inference:
no SVI, no NUTS/HMC/MCMC, no pilot run, no optimization, no sampling, no NeuTra,
no rank escalation. It only:
  - polls the pilot process (read-only, via pgrep),
  - counts RUN_STARTED / result.json / arm summaries,
  - verifies frozen runner / guide / 29 SHAs,
  - records incidents (PILOT_INTERRUPTION_INCIDENT.json) WITHOUT auto-rerun,
  - calls the already-authorized controller (scripts/62) for state transitions,
  - runs the frozen G1 audit and the no-draws G2 stability analysis on saved
    artifacts (JSON only; never reads live state),
  - freezes the G3 importance protocol design (never samples).

States:
  CURRENT_PILOT_RUNNING
  STOP_CONSUMED_RUN_REQUIRES_HUMAN_DECISION      (pilot dead, consumed runs)
  PILOT_COMPLETE -> G1_AUDIT -> G1_PASS | STOP_G1_FAILED
  G1_PASS -> G2 (no-draws) -> G2_READY | STOP_G2_POSTERIOR_DRAW_AUTHORIZATION_REQUIRED
  G2_READY -> G3 design frozen -> STOP_WAITING_FOR_G3_SAMPLING_AUTHORIZATION

Usage:
  python scripts/63_phase3c_variational_watchdog.py --mode poll
  python scripts/63_phase3c_variational_watchdog.py --daemon --interval 600
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUTOMATION_DIR = ROOT / "results" / "phase3c4" / "automation"
STATE_PATH = AUTOMATION_DIR / "AUTOMATION_STATE.json"
AUDIT_PATH = AUTOMATION_DIR / "AUTOMATION_AUDIT_LOG.jsonl"
STATUS_PATH = AUTOMATION_DIR / "WATCHDOG_STATUS.json"
INCIDENT_PATH = AUTOMATION_DIR / "PILOT_INTERRUPTION_INCIDENT.json"
G1_JSON = AUTOMATION_DIR / "30_VARIATIONAL_PILOT_G1_AUDIT.json"
G1_MD = AUTOMATION_DIR / "30_VARIATIONAL_PILOT_G1_AUDIT.md"
G2_JSON = AUTOMATION_DIR / "31_G2_REPLICATE_STABILITY.json"
G2_MD = AUTOMATION_DIR / "31_G2_REPLICATE_STABILITY.md"
G3_JSON = AUTOMATION_DIR / "32_G3_EXACT_TARGET_IMPORTANCE_PROTOCOL.json"

PILOT_RUNS_DIR = ROOT / "results" / "phase3c4" / "pilot_runs"
RUNNER_PATH = ROOT / "scripts" / "61_run_phase3c_variational_v1_pilot.py"
GUIDE_PATH = ROOT / "src" / "dhbcp_pv" / "inference" / "v1_structured_lowrank_guide.py"
ART29_PATH = ROOT / "results" / "phase3c4" / "29_EXPLICIT_VARIATIONAL_PILOT_RUN_AUTHORIZATION.json"
CTRL62_PATH = ROOT / "scripts" / "62_phase3c_variational_automation_controller.py"

FROZEN = {
    "runner_sha256": "db2ba5a31ccf79cc2b323950d093c987d5b3d0bf816b2a5045ffd30a9b795dcb",
    "guide_sha256": "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878",
    "art29_sha256": "072cdd1aedd48d3ff48064c6f3344317f816bca0935a2f45583a9cef3cdfa610",
    "run_matrix_identity_hash": "084a24559846a80d9f138dd3a968ef1bdb573f33a3951bffb6ff216fe0a56bed",
    "seeds": [1001, 2002, 3003, 4004, 5005],
    "total_runs": 15,
    "arms": {
        "ARM_A": {"id": "V0_INSTRUMENTED_GLOBAL_LR32_CONTROL", "num_particles": 1,
                  "role": "HISTORICAL FAMILY CONTROL"},
        "ARM_B": {"id": "V1_SHARED_PLUS_BLOCK_LOW_RANK", "num_particles": 1,
                  "role": "ARCHITECTURE COMPARISON vs V0 at identical num_particles=1"},
        "ARM_C": {"id": "V1_SHARED_PLUS_BLOCK_LOW_RANK", "num_particles": 4,
                  "role": "PARTICLE COMPARISON (V1 p=1 vs p=4)"},
    },
    "g1_min_loss_reduction": 0.15,
    "g1_max_nonfinite_steps": 0,
}

STATE_SEQUENCE = [
    "CURRENT_PILOT_RUNNING", "PILOT_COMPLETE", "G1_AUDIT", "G1_PASS", "G1_FAIL",
    "G2_READY", "G3_READY", "G4_READY", "G5_READY", "SCIENTIFIC_USE_READY",
    "STOP_G1_FAILED", "SCIENTIFIC_GATE_FAILED_REQUIRES_REVIEW",
    "STOP_CONSUMED_RUN_REQUIRES_HUMAN_DECISION",
    "STOP_G2_POSTERIOR_DRAW_AUTHORIZATION_REQUIRED",
    "STOP_WAITING_FOR_G3_SAMPLING_AUTHORIZATION",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic_write(path: Path, obj) -> None:
    AUTOMATION_DIR.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def audit(entry: dict) -> None:
    AUTOMATION_DIR.mkdir(parents=True, exist_ok=True)
    with open(AUDIT_PATH, "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"ts": utc_now(), **entry}, ensure_ascii=False) + "\n")


def load_state() -> dict:
    if STATE_PATH.exists():
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    return {"schema_version": "1.0", "current_state": "INIT", "tasks": {}, "recent_transitions": []}


def set_state(to_state: str, trigger: str, detail: str) -> None:
    """Watchdog-owned state transition (append-only audit; atomic state write)."""
    state = load_state()
    from_state = state.get("current_state")
    if to_state != from_state:
        state["current_state"] = to_state
        state["last_updated_utc"] = utc_now()
        tr = {"ts": utc_now(), "from_state": from_state, "to_state": to_state,
              "trigger": trigger, "detail": detail}
        state.setdefault("recent_transitions", []).append(tr)
        state["recent_transitions"] = state["recent_transitions"][-20:]
        atomic_write(STATE_PATH, state)
        audit({"event": "STATE_TRANSITION", **tr})


def run_matrix_entries() -> list:
    entries = []
    for arm in ["ARM_A", "ARM_B", "ARM_C"]:
        a = FROZEN["arms"][arm]
        for seed in FROZEN["seeds"]:
            ident = f"{a['id']}_p{a['num_particles']}_seed{seed}_t12"
            entries.append({
                "arm": arm, "role": a["role"], "seed": seed, "identity": ident,
                "dir": PILOT_RUNS_DIR / ident,
            })
    return entries


def gather() -> dict:
    """Read-only snapshot of the pilot + artifacts."""
    alive = False
    try:
        out = subprocess.run(
            ["pgrep", "-f", "61_run_phase3c_variational_v1_pilot.py --mode pilot"],
            capture_output=True, text=True, timeout=10,
        )
        alive = out.returncode == 0 and bool(out.stdout.strip())
    except Exception:
        alive = None  # unknown
    entries = run_matrix_entries()
    started = [e for e in entries if (e["dir"] / "RUN_STARTED.json").exists()]
    results = [e for e in entries if (e["dir"] / "result.json").exists()]
    summaries = list((AUTOMATION_DIR.parent / "pilot_runs").glob("*/arm_summary.json"))
    shas = {
        "runner": sha256(RUNNER_PATH),
        "guide": sha256(GUIDE_PATH),
        "art29": sha256(ART29_PATH) if ART29_PATH.exists() else None,
    }
    sha_ok = shas["runner"] == FROZEN["runner_sha256"] and \
        shas["guide"] == FROZEN["guide_sha256"] and shas["art29"] == FROZEN["art29_sha256"]
    return {
        "pilot_process_alive": alive,
        "run_started_count": len(started),
        "result_count": len(results),
        "arm_summary_count": len(summaries),
        "started_identities": [e["identity"] for e in started],
        "result_identities": [e["identity"] for e in results],
        "sha_consistent": sha_ok,
        "shas": shas,
        "current_run_identity": started[-1]["identity"] if started else None,
        "latest_completed": results[-1]["identity"] if results else None,
    }


def write_status(info: dict, watchdog_pid: int, poll_interval: int) -> None:
    status = {
        "artifact_id": "WATCHDOG_STATUS",
        "watchdog_pid": watchdog_pid,
        "started_utc": utc_now(),
        "poll_interval_s": poll_interval,
        "controller_sha256": sha256(CTRL62_PATH),
        "watchdog_sha256": sha256(Path(__file__).resolve()),
        "pilot_pid": "65909",
        "pilot_process_alive": info["pilot_process_alive"],
        "run_started_count": info["run_started_count"],
        "result_count": info["result_count"],
        "arm_summary_count": info["arm_summary_count"],
        "current_run_identity": info["current_run_identity"],
        "sha_consistent": info["sha_consistent"],
        "status": load_state().get("current_state", "INIT"),
    }
    atomic_write(STATUS_PATH, status)


# ------------------------------------------------------------- G1 audit
def run_g1_audit() -> dict:
    """Frozen G1 gate over the 15 result.json files (JSON artifacts only)."""
    entries = run_matrix_entries()
    per_run = []
    for e in entries:
        p = e["dir"] / "result.json"
        if not p.exists():
            per_run.append({"identity": e["identity"], "arm": e["arm"], "missing": True, "G1_gate_pass": False})
            continue
        r = json.loads(p.read_text(encoding="utf-8"))
        finite = bool(r.get("all_params_finite") is True and r.get("nonfinite_gradient_or_loss_steps", 1) == 0)
        loss_ok = float(r.get("loss_reduction_fraction", -1.0)) >= FROZEN["g1_min_loss_reduction"]
        histories = bool(r.get("required_histories_present") is True)
        g1 = bool(finite and loss_ok and histories)
        per_run.append({
            "identity": e["identity"], "arm": e["arm"], "seed": r.get("seed"),
            "steps_completed": r.get("steps_completed"), "initial_loss": r.get("initial_loss"),
            "terminal_loss": r.get("terminal_loss"),
            "loss_reduction_fraction": r.get("loss_reduction_fraction"),
            "nonfinite_steps": r.get("nonfinite_gradient_or_loss_steps"),
            "all_params_finite": r.get("all_params_finite"),
            "required_histories_present": r.get("required_histories_present"),
            "early_stop_reason": r.get("early_stop_reason"),
            "terminal_status": r.get("terminal_status"),
            "G1_run_pass": bool(r.get("G1_run_pass")), "G1_gate_pass": g1,
        })
    arms = {}
    all_pass = True
    for arm in ["ARM_A", "ARM_B", "ARM_C"]:
        rs = [x for x in per_run if x.get("arm") == arm]
        flags = [bool(x.get("G1_gate_pass")) for x in rs]
        arms[arm] = {
            "n_results": len(rs), "G1_pass_count": int(sum(flags)),
            "G1_required_count": 5, "G1_arm_pass": bool(len(rs) == 5 and all(flags)),
        }
        if not (len(rs) == 5 and all(flags)):
            all_pass = False
    return {"ready": True, "result_count": len(per_run), "required": 15,
            "per_run": per_run, "arms": arms, "G1_OVERALL_PASS": all_pass}


def write_g1_artifacts(g: dict) -> None:
    atomic_write(G1_JSON, {
        "artifact_id": "30_VARIATIONAL_PILOT_G1_AUDIT",
        "generated_utc": utc_now(), "generator": "scripts/63 watchdog (auto)",
        "G1_OVERALL_PASS": g["G1_OVERALL_PASS"], "arms": g["arms"],
        "per_run_summary": [
            {"identity": r["identity"], "arm": r["arm"], "loss_reduction_fraction": r.get("loss_reduction_fraction"),
             "terminal_status": r.get("terminal_status"), "G1_gate_pass": r.get("G1_gate_pass")}
            for r in g["per_run"]
        ],
        "architecture_effect_V0p1_vs_V1p1": "computed in per-run/arm aggregates (see 30 md)",
        "particle_effect_V1p1_vs_V1p4": "computed in per-run/arm aggregates (see 30 md)",
    })
    md = ["# 30 — VARIATIONAL PILOT G1 AUDIT (auto, watchdog)",
          "", f"Generated: {utc_now()}  |  Generator: scripts/63 watchdog (auto)",
          "", f"**G1_OVERALL_PASS: {g['G1_OVERALL_PASS']}**", ""]
    for arm in ["ARM_A", "ARM_B", "ARM_C"]:
        a = g["arms"][arm]
        md.append(f"- {arm}: G1_pass_count={a['G1_pass_count']}/5  G1_arm_pass={a['G1_arm_pass']}")
    md.append("")
    md.append("Per-run rows (loss_reduction, terminal_status, G1_gate_pass):")
    for r in g["per_run"]:
        md.append(f"  - {r['identity']}: red={r.get('loss_reduction_fraction'):.4f} "
                  f"status={r.get('terminal_status')} G1={r.get('G1_gate_pass')}")
    md.append("")
    md.append("Architecture effect (V0-p1 vs V1-p1) and particle effect (V1-p1 vs V1-p4) "
              "are computed from the arm aggregates above (seed variability = per-arm std of "
              "loss reduction / terminal loss, reported in 31 G2).")
    G1_MD.write_text("\n".join(md) + "\n", encoding="utf-8")


# ------------------------------------------------------------- G2 no-draws
def run_g2_no_draws() -> dict:
    """Stability analysis from saved artifacts only (JSON). No posterior draws."""
    entries = run_matrix_entries()
    arms = {}
    requires_posterior_draws = []
    for arm in ["ARM_A", "ARM_B", "ARM_C"]:
        rs = []
        for e in entries:
            if e["arm"] != arm:
                continue
            rp = e["dir"] / "result.json"
            if not rp.exists():
                continue
            r = json.loads(rp.read_text(encoding="utf-8"))
            eff = None
            glr = None
            cp = e["dir"] / "checkpoint_history.json"
            if cp.exists():
                h = json.loads(cp.read_text(encoding="utf-8"))["history"]
                if h:
                    eff = h[-1].get("effective_rank")
                    glr = h[-1].get("global_lr_fraction")
            rs.append({
                "seed": r.get("seed"), "terminal_loss": r.get("terminal_loss"),
                "loss_reduction_fraction": r.get("loss_reduction_fraction"),
                "steps_completed": r.get("steps_completed"),
                "early_stop_reason": r.get("early_stop_reason"),
                "effective_rank_last": eff, "global_lr_fraction_last": glr,
            })
        if not rs:
            arms[arm] = {"n": 0, "error": "no results"}
            continue

        def sd(key):
            vals = [x[key] for x in rs if x.get(key) is not None]
            return round(statistics.pstdev(vals), 6) if len(vals) > 1 else 0.0

        arms[arm] = {
            "n": len(rs),
            "mean_terminal_loss": round(statistics.mean(x["terminal_loss"] for x in rs), 4),
            "std_terminal_loss": sd("terminal_loss"),
            "mean_loss_reduction_fraction": round(statistics.mean(x["loss_reduction_fraction"] for x in rs), 4),
            "std_loss_reduction_fraction": sd("loss_reduction_fraction"),
            "min_loss_reduction_fraction": round(min(x["loss_reduction_fraction"] for x in rs), 4),
            "steps_completed_set": sorted({x["steps_completed"] for x in rs}),
            "early_stop_reasons": {x["early_stop_reason"] for x in rs if x["early_stop_reason"]},
            "mean_effective_rank_last": round(statistics.mean([x["effective_rank_last"] for x in rs if x["effective_rank_last"] is not None]), 4)
            if any(x["effective_rank_last"] is not None for x in rs) else None,
            "std_effective_rank_last": sd("effective_rank_last"),
            "mean_global_lr_fraction_last": round(statistics.mean([x["global_lr_fraction_last"] for x in rs if x["global_lr_fraction_last"] is not None]), 4)
            if any(x["global_lr_fraction_last"] is not None for x in rs) else None,
            "std_global_lr_fraction_last": sd("global_lr_fraction_last"),
            "seed_to_seed_dispersion": "measured via std columns above",
        }
    # Subspace / location stability require guide vectors or posterior draws (not saved).
    requires_posterior_draws = [
        "posterior guide LOCATION stability (guide loc vectors are not persisted in saved artifacts)",
        "factor SUBSPACE stability (only singular-value spectra are saved, not the factor vectors)",
    ]
    return {
        "arms": arms,
        "requires_posterior_draws": requires_posterior_draws,
        "G2_no_draws_complete": True,
        "note": "All metrics above are computed from saved result.json + checkpoint_history.json. "
                "Location/subspace stability cannot be completed without posterior draws.",
    }


def write_g2_artifacts(g2: dict) -> None:
    atomic_write(G2_JSON, {
        "artifact_id": "31_G2_REPLICATE_STABILITY",
        "generated_utc": utc_now(), "generator": "scripts/63 watchdog (auto, no-draws)",
        "arms": g2["arms"],
        "requires_posterior_draws": g2["requires_posterior_draws"],
        "G2_no_draws_complete": g2["G2_no_draws_complete"],
        "note": g2["note"],
        "no_phase3c4_failed_pca_used": True,
    })
    md = ["# 31 — G2 REPLICATE STABILITY (auto, no-draws)", "",
          f"Generated: {utc_now()}  |  Generator: scripts/63 watchdog (auto, saved artifacts only)", ""]
    for arm, a in g2["arms"].items():
        if isinstance(a, dict) and "error" not in a:
            md.append(f"- {arm}: n={a['n']} | mean_terminal={a['mean_terminal_loss']} "
                      f"(std {a['std_terminal_loss']}) | mean_red={a['mean_loss_reduction_fraction']} "
                      f"(std {a['std_loss_reduction_fraction']}) | steps={a['steps_completed_set']} "
                      f"| eff_rank={a['mean_effective_rank_last']} (std {a['std_effective_rank_last']}) "
                      f"| globalLR={a['mean_global_lr_fraction_last']} (std {a['std_global_lr_fraction_last']})")
    md.append("")
    md.append("Requires posterior draws for completion:")
    for item in g2["requires_posterior_draws"]:
        md.append(f"  - {item}")
    G2_MD.write_text("\n".join(md) + "\n", encoding="utf-8")


# ------------------------------------------------------------- G3 design (freeze only)
def write_g3_design() -> None:
    atomic_write(G3_JSON, {
        "artifact_id": "32_G3_EXACT_TARGET_IMPORTANCE_PROTOCOL",
        "generated_utc": utc_now(), "generator": "scripts/63 watchdog (design + freeze ONLY)",
        "status": "DESIGNED_AND_FROZEN_NOT_SAMPLED",
        "sample_count": 4000,
        "rng_seeds": [9001, 9002, 9003, 9004, 9005],
        "quantities": ["log p(y,z)", "log q(z)", "log weights", "normalized ESS",
                       "finite-weight gate", "PSIS diagnostics if supported"],
        "gates": {
            "finite_weight_gate": "all log-weights finite",
            "normalized_ess": "computed from normalized weights",
            "psis": "if supported by installed tooling",
        },
        "prohibited": "sample count must NOT be changed based on results; NO sampling until "
                      "explicit human authorization.",
        "sampling_authorized": False,
    })


# ------------------------------------------------------------- poll
def poll(watchdog_pid: int, poll_interval: int) -> str:
    info = gather()
    write_status(info, watchdog_pid, poll_interval)
    audit({"event": "WATCHDOG_POLL", "detail": {
        "alive": info["pilot_process_alive"], "started": info["run_started_count"],
        "results": info["result_count"], "summaries": info["arm_summary_count"],
        "sha_consistent": info["sha_consistent"]}})
    state = load_state().get("current_state", "INIT")

    if info["result_count"] < FROZEN["total_runs"]:
        if info["pilot_process_alive"] is False and info["run_started_count"] > 0:
            # pilot died with consumed runs -> incident, NO auto-rerun.
            incident = {
                "artifact_id": "PILOT_INTERRUPTION_INCIDENT",
                "generated_utc": utc_now(),
                "started_count": info["run_started_count"],
                "completed_count": info["result_count"],
                "consumed_run_identities": info["started_identities"],
                "last_completed_run": info["latest_completed"],
                "runner_sha256": info["shas"]["runner"],
                "guide_sha256": info["shas"]["guide"],
                "art29_sha256": info["shas"]["art29"],
                "traceback": "not available (process-level check only)",
                "auto_rerun_performed": False,
            }
            atomic_write(INCIDENT_PATH, incident)
            set_state("STOP_CONSUMED_RUN_REQUIRES_HUMAN_DECISION",
                      "pilot process dead with consumed runs",
                      "no auto-rerun; human decision required")
            audit({"event": "PILOT_INTERRUPTION_INCIDENT_RECORDED", "detail": {
                "started": info["run_started_count"], "completed": info["result_count"]}})
            return "STOP_CONSUMED_RUN_REQUIRES_HUMAN_DECISION"
        return "CURRENT_PILOT_RUNNING"

    # result_count == 15
    unique = len(set(info["result_identities"])) == FROZEN["total_runs"]
    if not (unique and info["sha_consistent"]):
        set_state("SCIENTIFIC_GATE_FAILED_REQUIRES_REVIEW",
                  "15 results present but identity uniqueness / SHA consistency failed",
                  {"unique": unique, "sha_consistent": info["sha_consistent"]})
        return "SCIENTIFIC_GATE_FAILED_REQUIRES_REVIEW"

    # PILOT_COMPLETE -> invoke authorized controller (scripts/62) for G1 state transition,
    # then run the frozen G1 audit artifacts.
    subprocess.run([sys.executable, str(CTRL62_PATH), "--mode", "advance"],
                   cwd=ROOT, capture_output=True, text=True, timeout=120)
    g1 = run_g1_audit()
    write_g1_artifacts(g1)
    if not g1["G1_OVERALL_PASS"]:
        set_state("STOP_G1_FAILED", "frozen G1 gate failed",
                  json.dumps(g1["arms"], ensure_ascii=False))
        audit({"event": "G1_FAILED", "detail": g1["arms"]})
        return "STOP_G1_FAILED"

    set_state("G1_PASS", "frozen G1 gate passed (all 3 arms)", json.dumps(g1["arms"], ensure_ascii=False))
    audit({"event": "G1_PASSED", "detail": g1["arms"]})

    # G2 no-draws analysis
    g2 = run_g2_no_draws()
    write_g2_artifacts(g2)
    if g2["requires_posterior_draws"]:
        set_state("STOP_G2_POSTERIOR_DRAW_AUTHORIZATION_REQUIRED",
                  "G2 no-draws complete; posterior draws required for location/subspace stability",
                  json.dumps(g2["requires_posterior_draws"], ensure_ascii=False))
        audit({"event": "G2_POSTERIOR_DRAW_GATE", "detail": g2["requires_posterior_draws"]})
        return "STOP_G2_POSTERIOR_DRAW_AUTHORIZATION_REQUIRED"

    set_state("G2_READY", "G2 no-draws stability complete", "")
    # G3 design freeze (never samples)
    write_g3_design()
    set_state("STOP_WAITING_FOR_G3_SAMPLING_AUTHORIZATION",
              "G3 importance protocol designed and frozen; sampling NOT authorized", "")
    audit({"event": "G3_PROTOCOL_FROZEN_NO_SAMPLING", "detail": {"sample_count": 4000}})
    return "STOP_WAITING_FOR_G3_SAMPLING_AUTHORIZATION"


def daemon(interval: int) -> None:
    pid = os.getpid()
    print(f"[watchdog] daemon pid={pid} interval={interval}s (state: {load_state().get('current_state')})",
          flush=True)
    while True:
        try:
            st = poll(pid, interval)
            print(f"[watchdog] poll -> {st}", flush=True)
            if st != "CURRENT_PILOT_RUNNING":
                # terminal/hold state reached; keep status file but stop watching.
                print(f"[watchdog] terminal state {st}; watchdog idles (no restart of pilot)", flush=True)
        except KeyboardInterrupt:
            print("[watchdog] stopped by signal", flush=True)
            break
        except Exception as exc:  # noqa: BLE001
            audit({"event": "WATCHDOG_ERROR", "detail": repr(exc)})
            print(f"[watchdog] error: {exc!r}", flush=True)
        time.sleep(interval)


def main() -> None:
    ap = argparse.ArgumentParser(description="Phase3C.4 automation watchdog (supervision only)")
    ap.add_argument("--mode", choices=["poll"], default=None)
    ap.add_argument("--daemon", action="store_true")
    ap.add_argument("--interval", type=int, default=600)
    args = ap.parse_args()
    if args.mode == "poll":
        print(json.dumps(poll(0, args.interval), indent=2))
    elif args.daemon:
        daemon(args.interval)
    else:
        ap.print_help()


if __name__ == "__main__":
    main()
