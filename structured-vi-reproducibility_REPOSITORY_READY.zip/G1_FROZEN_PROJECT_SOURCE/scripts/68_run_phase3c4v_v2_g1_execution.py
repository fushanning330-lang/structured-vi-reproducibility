#!/usr/bin/env python3
"""Phase3C.4V V2 — FINAL EXECUTION-CAPABLE V2 G1 RUNNER (scripts/68).

Replaces scripts/67 as the EXECUTION runner (42L human adjudication:
V2_PRECANARY_EXECUTION_RUNNER_REQUIRED). scripts/67 remains the historical
authorization / readiness-preflight runner and is NOT modified.

Modes (--mode preflight | canary | validation):
  --mode preflight  : deterministic source/protocol/readiness checks ONLY.
                      The ONLY mode authorized now. Writes
                      results/phase3c4v/preflight/42M_V2_G1_EXECUTION_RUNNER_PREFLIGHT.{json,md}
  --mode canary     : REFUSED (STOP_NOT_AUTHORIZED, non-zero exit) unless a
                      FUTURE separate explicit human canary authorization
                      artifact exists at
                      results/phase3c4v_v2/authorizations/V2_G1_CANARY_AUTHORIZATION.json
                      with AUTHORIZED=true AND binding the exact SHA256 of
                      42J/42L/corrected guide/scripts68/model/serializer/
                      scripts51/seed CSV/generator AND the exact canary
                      identity V2_V2_ARM_P1_p1_seed1001_t12
                      (arm=V2_ARM_P1, particles=1, seed=1001, cutoff=12).
  --mode validation : REFUSED unless a FUTURE separate explicit full-
                      validation authorization artifact exists. Canary
                      authorization NEVER implies validation authorization.

The future authorized execution path (implemented below, NOT executed in
this task) uses exactly:
  objective     Trace_ELBO(num_particles=entry["num_particles"])
  optimizer     ClippedAdam(step_size=0.003, clip_norm=10.0)
  maximum_steps 2000 | minimum_steps_before_early_stopping 500
  checkpoint_interval 100 | early_stop_relative_tolerance 1e-4
  early_stop_patience_checkpoints 5
  guide         V2SharedAR1TemporalAutoGuide (corrected canonical source)
  target        frozen full_joint_model, cutoff 12
  RNG           master=PRNGKey(seed); split(4) -> prototype_key,
                factor_init_key (guide), svi_init_key (SVI.init),
                svi_runtime_key (training updates ONLY)
  one-shot      results/phase3c4v_v2/runs/<identity>/RUN_STARTED (atomic,
                BEFORE SVI.init; preflight NEVER creates it)
  persistence   frozen variational_param_persistence.py (save_params/
                validate_params_roundtrip) -> final_svi_params.npz +
                final_svi_params_manifest.json, exact roundtrip required
  terminal      result.json written LAST
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)  # MUST be set before numpyro import

import jax.numpy as jnp
import numpy as np
import numpyro

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

# ---------------------------------------------------------------------------
# Frozen SHA chain (live-verified at 42M generation time; 42L binds here).
# ---------------------------------------------------------------------------
EXPECTED = {
    "42E": "c50a2bac39d0c5a5c257a0c62f1b94189b4275e08f91621ff6153959fcf33bc5",
    "42F": "e60c654259ef7763bc00c9315ef6cdb214b35fc5270e725aa7a5b90e87df3066",
    "42H": "b3a8ee28d0729fb055b4d45eb8b0a66ae8e0a425905fdde58acd5b51cd7ef363",
    "42I": "7efb62e588de1a83f3618818c1ebd9d150301482e35fcac2f42ce7c3b7f22cc1",
    "42J": "115ebec9ee98aaa81afaca093698179739ca37a820c417c297bb1c36eb953e8f",
    "42K": "c4062492bb863362dadd329a7fa0da71f9ba442e0bc016a975816df12d232b66",
    "42L": "b07694be61b9dfb4609ccd4bb8baa13d8e70c6233035f5214791c56bf07ca267",
    "guide_fix": "51e23a5c68d34d1d164b20a362cffc4667dedb39da6324426a6674783fa40fdb",
    "scripts66": "1185f5952f70c6dfdf27f7295244ec5a6dd5c907e59c3fd86ab4ecec9ecfc121",
    "scripts67": "1fab70d72ea8046ce7aebd288f50d495fcdc1ac10858f13ac4dc0f123b9fb0bc",
    "model": "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c",
    "v1_guide": "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878",
    "scripts64": "6879309eaf50505da8b923fe4705a48581d21f4c91bf4dfddaaffb98019a0ade",
    "serializer": "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803",
    "scripts51": "1239716a2c73ed1faf3f6085a8bce361553c81c9ad4245bb9149845c45bcff4f",
    "seed_csv": "2054361bc280a975b9694f1de40cad87884da9bf7bd1c9fbbd691faea229c7db",
    "generator": "5617a62697337fbdfb2ded19f6a3ef8ce2061d6ab0bf91437272391f14bf3f8a",
}

FROZEN_PATHS = {
    "42E": "results/phase3c4v/audit/42E_V2_AR1_TEMPORAL_MATHEMATICAL_SPECIFICATION_FREEZE.json",
    "42F": "results/phase3c4v/audit/42F_V2_AR1_NUMERICAL_SAFETY_AMENDMENT.json",
    "42H": "results/phase3c4v/audit/42H_V2_G0_HUMAN_SOURCE_AUDIT_AND_SCALE_SAFETY_DECISION.json",
    "42I": "results/phase3c4v/preflight/42I_V2_AR1_CORRECTIVE_IMPLEMENTATION_G0_PREFLIGHT.json",
    "42J": "results/phase3c4v/protocol/42J_V2_G1_OPTIMIZATION_PROTOCOL_FREEZE.json",
    "42K": "results/phase3c4v/preflight/42K_V2_G1_RUNNER_READINESS_PREFLIGHT.json",
    "42L": "results/phase3c4v/audit/42L_V2_PRECANARY_HUMAN_ADJUDICATION.json",
    "guide_fix": "src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py",
    "scripts66": "scripts/66_phase3c4v_v2_corrective_deterministic_g0_preflight.py",
    "scripts67": "scripts/67_run_phase3c4v_v2_g1_validation.py",
    "model": "src/dhbcp_pv/models/full_joint_model.py",
    "v1_guide": "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py",
    "scripts64": "scripts/64_run_phase3c4v_parameter_persistent_validation.py",
    "serializer": "src/dhbcp_pv/inference/variational_param_persistence.py",
    "scripts51": "scripts/51_run_phase3c_nuts.py",
    "seed_csv": "config/phase3b_tiera_seeds_v1.csv",
    "generator": "src/dhbcp_pv/sim/hierarchical_phase3b.py",
}

# ---------------------------------------------------------------------------
# Frozen protocol (must match 42J "3_inherited_frozen_protocol" exactly).
# ---------------------------------------------------------------------------
TRAINING = {
    "objective": "Trace_ELBO",
    "optimizer": "ClippedAdam",
    "learning_rate": 0.003,
    "clip_norm": 10.0,
    "maximum_steps": 2000,
    "minimum_steps_before_early_stopping": 500,
    "checkpoint_interval": 100,
    "early_stop_relative_tolerance": 1e-4,
    "early_stop_patience_checkpoints": 5,
    "diag_initial": "log(0.1)",
    "factor_init": "0.01 * Normal(0, I)",
    "rho_raw_init": 0.0,
    "seeds": [1001, 2002, 3003, 4004, 5005],
    "no_phase3c4_pca": True,
    "no_post_hoc_changes": True,
}
CUTOFF = 12
LATENT_DIM = 708
LOG_SCALE_ABS_MAX = 300.0

V2_NS = ROOT / "results/phase3c4v_v2"
V2_RUNS = V2_NS / "runs"
V2_AUTHS = V2_NS / "authorizations"
CANARY_AUTH_PATH = V2_AUTHS / "V2_G1_CANARY_AUTHORIZATION.json"
VALIDATION_AUTH_PATH = V2_AUTHS / "V2_G1_VALIDATION_AUTHORIZATION.json"
RUN_STARTED_NAME = "RUN_STARTED"

CANARY_IDENTITY = {
    "identity": "V2_V2_ARM_P1_p1_seed1001_t12",
    "arm": "V2_ARM_P1",
    "num_particles": 1,
    "seed": 1001,
    "cutoff": 12,
}
CANARY_AUTH_BINDS = ["42J", "42L", "guide_fix", "scripts68", "model", "serializer",
                     "scripts51", "seed_csv", "generator"]


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def load_json(rel: str):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def _auth_artifact(path: Path):
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {"unreadable": True}


# ---------------------------------------------------------------------------
# Frozen chain / protocol / identity verification.
# ---------------------------------------------------------------------------
def verify_frozen_chain(root: Path, include_self: bool = False) -> dict:
    results = {}
    ok = True
    for name, rel in FROZEN_PATHS.items():
        p = root / rel
        exp = EXPECTED[name]
        live = sha256(p) if p.exists() else "MISSING"
        match = live == exp
        results[name] = {"expected": exp, "live": live, "ok": match}
        ok = ok and match
    if include_self:
        self_sha = sha256(Path(__file__).resolve())
        results["scripts68"] = {"expected": self_sha, "live": self_sha, "ok": True}
    return {"ok": ok, "results": results}


def check_42i_pass(root: Path) -> dict:
    d = load_json(FROZEN_PATHS["42I"])
    return {
        "classification": d.get("classification"),
        "overall": d.get("checks", {}).get("OVERALL"),
        "ok": d.get("classification") == "V2_CORRECTIVE_G0_PREFLIGHT_PASS"
              and d.get("checks", {}).get("OVERALL") == "PASS",
    }


def check_42j_protocol_exact(root: Path) -> dict:
    j42 = load_json(FROZEN_PATHS["42J"])
    proto = j42.get("3_inherited_frozen_protocol", {})
    mismatches = []
    for k, v in TRAINING.items():
        if proto.get(k) != v:
            mismatches.append({"field": k, "42J": proto.get(k), "runner": v})
    ok = not mismatches and j42.get("classification") == "V2_G1_OPTIMIZATION_PROTOCOL_FROZEN"
    return {"ok": ok, "mismatches": mismatches, "classification": j42.get("classification")}


def check_42l_present(root: Path) -> dict:
    p = root / FROZEN_PATHS["42L"]
    if not p.exists():
        return {"ok": False, "reason": "42L missing"}
    d = json.loads(p.read_text(encoding="utf-8"))
    return {
        "ok": d.get("classification") == "V2_PRECANARY_EXECUTION_RUNNER_REQUIRED"
              and d.get("1_adjudication_42I", {}).get("42I_FINAL_RESULT") == "V2_CORRECTIVE_G0_PREFLIGHT_PASS",
        "classification": d.get("classification"),
    }


def check_run_matrix(root: Path) -> dict:
    j42 = load_json(FROZEN_PATHS["42J"])
    matrix = j42.get("4_run_matrix", {})
    identities = matrix.get("identities", [])
    arms = matrix.get("arms", [])
    by_arm = {}
    for r in identities:
        by_arm.setdefault(r["arm"], []).append(r["seed"])
    canary = j42.get("5_future_canary_identity", {})
    expected = {
        "V2_ARM_P1": (1, [1001, 2002, 3003, 4004, 5005]),
        "V2_ARM_P4": (4, [1001, 2002, 3003, 4004, 5005]),
    }
    ok = len(identities) == 10
    detail = {"total_identities": len(identities)}
    for aname, (np_, seeds_) in expected.items():
        arm = next((a for a in arms if a.get("id") == aname), None)
        seeds = sorted(by_arm.get(aname, []))
        match = arm is not None and arm.get("num_particles") == np_ and seeds == sorted(seeds_)
        ok = ok and match
        detail[aname] = {"num_particles": arm.get("num_particles") if arm else None,
                         "seeds": seeds, "exact": match}
    canary_ok = bool(
        canary.get("identity") == CANARY_IDENTITY["identity"]
        and canary.get("arm") == CANARY_IDENTITY["arm"]
        and canary.get("num_particles") == CANARY_IDENTITY["num_particles"]
        and canary.get("seed") == CANARY_IDENTITY["seed"]
        and canary.get("cutoff") == CANARY_IDENTITY["cutoff"]
        and canary.get("authorized") is False
    )
    detail["canary"] = {"identity": canary.get("identity"), "exact": canary_ok,
                        "authorized": canary.get("authorized")}
    return {"ok": ok and canary_ok, "detail": detail}


def check_zero_consumed(root: Path) -> dict:
    j42 = load_json(FROZEN_PATHS["42J"])
    identities = [r["identity"] for r in j42["4_run_matrix"]["identities"]]
    consumed = []
    if V2_RUNS.exists():
        for ident in identities:
            rd = V2_RUNS / ident
            if (rd / RUN_STARTED_NAME).exists() or (rd / "result.json").exists():
                consumed.append(ident)
    return {"ok": not consumed, "consumed": consumed, "n_consumed": len(consumed)}


def check_auth_state(root: Path) -> dict:
    ca = _auth_artifact(CANARY_AUTH_PATH)
    va = _auth_artifact(VALIDATION_AUTH_PATH)
    j42 = load_json(FROZEN_PATHS["42J"])
    j42_canary = j42.get("1_authorization_state", {}).get("V2_CANARY_AUTHORIZED")
    j42_valid = j42.get("1_authorization_state", {}).get("V2_VALIDATION_AUTHORIZED")
    return {
        "ok": ca is None and va is None and j42_canary is False and j42_valid is False,
        "canary_artifact_present": ca is not None,
        "validation_artifact_present": va is not None,
        "42J_V2_CANARY_AUTHORIZED": j42_canary,
        "42J_V2_VALIDATION_AUTHORIZED": j42_valid,
    }


# ---------------------------------------------------------------------------
# Authorization guards (used by cmd_canary/cmd_validation; negative-tested by
# preflight). SHA / source / protocol validation happens BEFORE any
# RUN_STARTED creation; refusal exits non-zero.
# ---------------------------------------------------------------------------
def _chain_ok_for_auth(root: Path) -> bool:
    chain = verify_frozen_chain(root, include_self=True)
    return bool(chain["ok"])


def guard_canary(root: Path) -> dict:
    if not _chain_ok_for_auth(root):
        return {"refused": True, "reason": "STOP_SHA_MISMATCH: frozen chain mismatch before canary guard."}
    auth = _auth_artifact(CANARY_AUTH_PATH)
    if auth is None:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: no V2 G1 canary authorization artifact exists."}
    if not bool(auth.get("AUTHORIZED", False)):
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: canary authorization artifact exists but AUTHORIZED != true."}
    binds = auth.get("binds_sha256", {})
    bind_ok = True
    for name in CANARY_AUTH_BINDS:
        if name == "scripts68":
            exp = sha256(Path(__file__).resolve())
        else:
            exp = EXPECTED.get(name)
        if not exp or binds.get(name) != exp:
            bind_ok = False
    if not bind_ok:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: canary authorization SHA binding mismatch."}
    ident = auth.get("identity", {})
    ident_ok = bool(
        ident.get("identity") == CANARY_IDENTITY["identity"]
        and ident.get("arm") == CANARY_IDENTITY["arm"]
        and ident.get("num_particles") == CANARY_IDENTITY["num_particles"]
        and ident.get("seed") == CANARY_IDENTITY["seed"]
        and ident.get("cutoff") == CANARY_IDENTITY["cutoff"]
    )
    if not ident_ok:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: canary authorization identity mismatch."}
    return {"refused": False, "reason": "AUTHORIZED"}


def guard_validation(root: Path) -> dict:
    if not _chain_ok_for_auth(root):
        return {"refused": True, "reason": "STOP_SHA_MISMATCH: frozen chain mismatch before validation guard."}
    auth = _auth_artifact(VALIDATION_AUTH_PATH)
    if auth is None:
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: no V2 G1 full-validation authorization artifact exists "
                          "(canary authorization NEVER implies validation authorization)."}
    if not bool(auth.get("AUTHORIZED", False)):
        return {"refused": True,
                "reason": "STOP_NOT_AUTHORIZED: validation authorization artifact exists but AUTHORIZED != true."}
    return {"refused": False, "reason": "AUTHORIZED"}


# ---------------------------------------------------------------------------
# One-shot RUN_STARTED guard (future execution; preflight NEVER creates it).
# ---------------------------------------------------------------------------
def acquire_run_started(run_dir: Path, identity: str, extra: dict | None = None) -> dict:
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    marker = run_dir / RUN_STARTED_NAME
    if marker.exists():
        return {"acquired": False, "reason": "STOP_IDENTITY_ALREADY_CONSUMED: RUN_STARTED exists; "
                                             "identity is permanently consumed and never rerun."}
    payload = {"identity": identity, "status": "V2_RUN_CONSUMED", "created_utc": utc_now()}
    if extra:
        payload.update(extra)
    tmp = run_dir / (RUN_STARTED_NAME + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    tmp.replace(marker)  # atomic create
    return {"acquired": True, "reason": "RUN_STARTED created (one-shot)."}


# ---------------------------------------------------------------------------
# V2 factor diagnostics (deterministic; used at checkpoints in future runs).
# ---------------------------------------------------------------------------
_BLOCK_SEG = {
    "count_plus_initial": [(0, 70), (108, 158)],
    "dynamic_scale": [(70, 86)],
    "seriousness": [(86, 108)],
    "temporal_path": [(158, 708)],
}
_BLOCK_ORDER = ["count_plus_initial", "dynamic_scale", "seriousness", "temporal_path"]


def v2_factor_diagnostics(params: dict) -> dict:
    """Deterministic V2 factor spectrum + semantic block covariance budget.

    U = [F_shared | emb(count) | emb(dynamic) | emb(seriousness)] (708, 28);
    effective diag scale s2 = exp(2*clip(v2_diag_log_scale, -300, 300)).
    """
    F_shared = jnp.asarray(params["v2_F_shared"])
    F_count = jnp.asarray(params["v2_F_count_plus_initial"])
    F_dynamic = jnp.asarray(params["v2_F_dynamic_scale"])
    F_serious = jnp.asarray(params["v2_F_seriousness"])
    from dhbcp_pv.inference.v2_shared_ar1_temporal_guide_g0fix import V2SharedAR1TemporalAutoGuide
    U = V2SharedAR1TemporalAutoGuide._build_u(F_shared, F_count, F_dynamic, F_serious)
    sv = jnp.linalg.svdvals(U)
    p = sv ** 2 / jnp.sum(sv ** 2)
    eff_rank = float(jnp.exp(-jnp.sum(p * jnp.where(p > 0, jnp.log(p), 0.0))))
    num_rank = int(jnp.sum(sv > sv[0] * 1e-6))
    u_diag = jnp.sum(U ** 2, axis=1)
    dls = jnp.asarray(params["v2_diag_log_scale"])
    s2 = jnp.exp(2.0 * jnp.clip(dls, -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))
    total = float(jnp.sum(u_diag) + jnp.sum(s2))
    blocks = {}
    for name in _BLOCK_ORDER:
        idx = jnp.concatenate([jnp.arange(a, b) for a, b in _BLOCK_SEG[name]])
        blocks[name] = float(jnp.sum(u_diag[idx]))
    frac = float(jnp.sum(u_diag)) / max(total, 1e-300)
    return {
        "singular_values": [float(x) for x in sv],
        "numerical_rank": num_rank,
        "effective_rank": eff_rank,
        "global_low_rank_variance_fraction": frac,
        "blocks": blocks,
        "factor_frobenius_norms": {
            "F_shared": float(jnp.linalg.norm(F_shared)),
            "F_count_plus_initial": float(jnp.linalg.norm(F_count)),
            "F_dynamic_scale": float(jnp.linalg.norm(F_dynamic)),
            "F_seriousness": float(jnp.linalg.norm(F_serious)),
        },
        "rho": float(0.99 * jnp.tanh(jnp.asarray(params["v2_raw_temporal_rho"]))),
        "diag_effective_min": float(jnp.min(jnp.clip(dls, -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))),
        "diag_effective_max": float(jnp.max(jnp.clip(dls, -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))),
        "diag_canonical_min": float(jnp.min(dls)),
        "diag_canonical_max": float(jnp.max(dls)),
        "clip_below": int(jnp.sum(dls < -LOG_SCALE_ABS_MAX)),
        "clip_above": int(jnp.sum(dls > LOG_SCALE_ABS_MAX)),
    }


def _all_params_finite(params: dict) -> bool:
    return all(bool(jnp.isfinite(jnp.asarray(v)).all()) for v in params.values())


# ---------------------------------------------------------------------------
# FUTURE AUTHORIZED EXECUTION PATH (implemented; NEVER invoked in this task).
# ---------------------------------------------------------------------------
def _run_identity_future(root: Path, entry: dict, auth_kind: str) -> str:
    """Single V2 G1 run. Reachable ONLY after an explicit future human
    authorization has passed the corresponding guard. Follows the frozen
    Phase3C4V training semantics (scripts/64) with V2-specific diagnostics.

    Sequence: 1 authorization validated (guard) -> 2 frozen SHA chain ->
    3 identity validated -> 4 ensure unconsumed -> 5 RUN_STARTED ->
    6 data -> 7 guide -> 8 SVI -> 9 SVI.init(svi_init_key) ->
    10 frozen update loop (svi_runtime_key) -> 11 checkpoint diagnostics ->
    12 final params -> 13 persistence -> 14 on-disk validation ->
    15 result.json LAST.
    """
    from numpyro.infer import SVI, Trace_ELBO
    from numpyro.optim import ClippedAdam
    from dhbcp_pv.models.full_joint_model import full_joint_model as TARGET
    from dhbcp_pv.inference.v2_shared_ar1_temporal_guide_g0fix import V2SharedAR1TemporalAutoGuide
    from dhbcp_pv.inference.variational_param_persistence import (
        save_params, load_params, validate_params_roundtrip, params_sha256,
    )
    import importlib.util
    spec = importlib.util.spec_from_file_location("frozen_51_68", root / "scripts/51_run_phase3c_nuts.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    out_dir = V2_RUNS / entry["identity"]
    # ---- 1-4: guards + chain validated by caller; identity fixed here ----
    seed = entry["seed"]
    master = jax.random.PRNGKey(seed)
    prototype_key, factor_init_key, svi_init_key, svi_runtime_key = jax.random.split(master, 4)
    prototype_key = jnp.asarray(prototype_key, dtype=jnp.uint32)
    factor_init_key = jnp.asarray(factor_init_key, dtype=jnp.uint32)
    svi_init_key = jnp.asarray(svi_init_key, dtype=jnp.uint32)
    svi_runtime_key = jnp.asarray(svi_runtime_key, dtype=jnp.uint32)

    # ---- 5: one-shot RUN_STARTED BEFORE SVI.init (preflight never runs this) ----
    guard = acquire_run_started(out_dir, entry["identity"],
                                extra={"seed": seed, "arm": entry["arm"],
                                       "num_particles": entry["num_particles"],
                                       "cutoff": entry["cutoff"], "auth_kind": auth_kind})
    if not guard["acquired"]:
        return "STOP_IDENTITY_ALREADY_CONSUMED"

    run_started_utc = utc_now()
    run_t0 = time.perf_counter()
    try:
        # ---- 6: frozen reference data ----
        data_seed, args, kwargs = mod.reference_data(root, entry["cutoff"])
        # ---- 7: guide ----
        guide = V2SharedAR1TemporalAutoGuide(
            TARGET, prefix="v2", init_loc_fn=numpyro.infer.init_to_median,
            factor_init_key=factor_init_key,
        )
        with numpyro.handlers.seed(rng_seed=prototype_key):
            guide._setup_prototype(*args, **kwargs)
        # ---- 8-9: SVI + SVI.init with svi_init_key ----
        svi = SVI(
            TARGET, guide,
            ClippedAdam(step_size=TRAINING["learning_rate"], clip_norm=TRAINING["clip_norm"]),
            Trace_ELBO(num_particles=entry["num_particles"]),
        )
        state = svi.init(svi_init_key, *args, **kwargs)
        # ---- 10: training updates derived ONLY from svi_runtime_key ----
        state = state._replace(rng_key=svi_runtime_key)

        max_steps = TRAINING["maximum_steps"]
        ckpt_interval = TRAINING["checkpoint_interval"]
        min_es_steps = TRAINING["minimum_steps_before_early_stopping"]
        es_tol = TRAINING["early_stop_relative_tolerance"]
        es_patience = TRAINING["early_stop_patience_checkpoints"]

        losses = []
        finite_flags = []
        rho_trajectory = []
        diag_effective_trajectory = []
        diag_canonical_trajectory = []
        clip_occupancy_trajectory = []
        factor_norm_trajectory = []
        factor_spectrum_history = []
        block_budget_history = []
        ckpt_history = []
        nonfinite_steps = 0
        patience_count = 0
        prev_ckpt_loss = None
        early_stop_reason = "max_steps_reached"
        steps_completed = 0

        for step in range(max_steps):
            state, loss = svi.stable_update(state, *args, **kwargs)
            losses.append(float(loss))
            finite = bool(jnp.isfinite(loss))
            finite_flags.append(finite)
            if not finite:
                nonfinite_steps += 1
            steps_completed = step + 1

            if (steps_completed % ckpt_interval == 0) or (steps_completed == max_steps):
                params = svi.get_params(state)
                diag = v2_factor_diagnostics(params)
                factor_spectrum_history.append(diag["singular_values"])
                block_budget_history.append(diag["blocks"])
                rho_trajectory.append(diag["rho"])
                diag_effective_trajectory.append([diag["diag_effective_min"], diag["diag_effective_max"]])
                diag_canonical_trajectory.append([diag["diag_canonical_min"], diag["diag_canonical_max"]])
                clip_occupancy_trajectory.append([diag["clip_below"], diag["clip_above"]])
                factor_norm_trajectory.append(diag["factor_frobenius_norms"])
                all_finite = _all_params_finite(params)
                window = [l for l, f in zip(losses[-ckpt_interval:], finite_flags[-ckpt_interval:]) if f]
                ckpt_loss = float(np.mean(window)) if window else float("nan")
                ckpt_history.append({
                    "step": steps_completed, "checkpoint_loss": ckpt_loss,
                    "all_params_finite": all_finite,
                    "global_low_rank_variance_fraction": diag["global_low_rank_variance_fraction"],
                    "numerical_rank": diag["numerical_rank"], "effective_rank": diag["effective_rank"],
                    "rho": diag["rho"],
                    "diag_effective_min": diag["diag_effective_min"],
                    "diag_effective_max": diag["diag_effective_max"],
                    "clip_below": diag["clip_below"], "clip_above": diag["clip_above"],
                })
                if steps_completed >= min_es_steps and prev_ckpt_loss is not None and window:
                    denom = max(abs(prev_ckpt_loss), 1e-12)
                    rel_improve = (prev_ckpt_loss - ckpt_loss) / denom
                    patience_count = patience_count + 1 if rel_improve < es_tol else 0
                    if patience_count >= es_patience:
                        early_stop_reason = "early_stop_patience"
                        break
                if window:
                    prev_ckpt_loss = ckpt_loss

        # ---- 12: final parameter extraction + diagnostics ----
        final_params = svi.get_params(state)
        initial_loss = float(losses[0])
        terminal_loss = float(losses[-1])
        loss_red = (initial_loss - terminal_loss) / max(abs(initial_loss), 1e-12)
        all_params_finite_final = _all_params_finite(final_params)
        param_schema = {k: [int(x) for x in jnp.shape(v)] for k, v in final_params.items()}
        total_elements = int(sum(int(jnp.size(v)) for v in final_params.values()))
        n_outside = int(jnp.sum(jnp.asarray(final_params["v2_diag_log_scale"]) < -LOG_SCALE_ABS_MAX)) + \
            int(jnp.sum(jnp.asarray(final_params["v2_diag_log_scale"]) > LOG_SCALE_ABS_MAX))
        clip_occupancy = {
            "count_below_neg300": int(jnp.sum(jnp.asarray(final_params["v2_diag_log_scale"]) < -LOG_SCALE_ABS_MAX)),
            "count_above_pos300": int(jnp.sum(jnp.asarray(final_params["v2_diag_log_scale"]) > LOG_SCALE_ABS_MAX)),
            "proportion_outside": n_outside / LATENT_DIM,
        }
        final_diag = v2_factor_diagnostics(final_params)

        # ---- 13: persistence via the FROZEN serializer ----
        persist_params = {
            k: np.asarray(v) for k, v in final_params.items()
        }
        # frozen serializer promotes 0-d -> (1,); keep scalar semantics.
        if persist_params["v2_raw_temporal_rho"].ndim == 0:
            persist_params["v2_raw_temporal_rho"] = np.asarray([float(persist_params["v2_raw_temporal_rho"])])
        npz_path = out_dir / "final_svi_params.npz"
        manifest_path = out_dir / "final_svi_params_manifest.json"
        try:
            man = save_params(persist_params, npz_path, manifest_path)
            loaded = load_params(npz_path)
            rt = validate_params_roundtrip(persist_params, npz_path, manifest_path)
            persistence_pass = bool(rt.get("PASS"))
            persistence_artifact = {
                "roundtrip_pass": rt.get("PASS"),
                "n_parameters": man.get("n_parameters"),
                "npz_sha256": man.get("npz_sha256"),
                "params_sha256": params_sha256(persist_params),
                "IN_MEMORY_PARAMETER_SEMANTICS": "scalar" if jnp.ndim(final_params["v2_raw_temporal_rho"]) == 0 else "array",
                "PERSISTED_REPRESENTATION": "one-element array" if persist_params["v2_raw_temporal_rho"].shape == (1,) else "other",
                "loaded_rho_shape": list(loaded["v2_raw_temporal_rho"].shape),
            }
        except Exception as exc:  # noqa: BLE001
            persistence_pass = False
            persistence_artifact = {"error": repr(exc), "roundtrip_pass": False}

        # ---- 11/14: diagnostics artifacts (before result.json) ----
        np.savez(out_dir / "training_history.npz",
                 losses=np.asarray(losses, dtype=np.float64),
                 finite_flags=np.asarray(finite_flags, dtype=bool))
        atomic_write_json(out_dir / "rho_trajectory.json", {"trajectory": rho_trajectory})
        atomic_write_json(out_dir / "diag_scale_trajectory.json", {
            "effective_min_max": diag_effective_trajectory,
            "canonical_min_max": diag_canonical_trajectory,
        })
        atomic_write_json(out_dir / "clip_boundary_occupancy.json", {
            "checkpoints": clip_occupancy_trajectory, "final": clip_occupancy,
        })
        atomic_write_json(out_dir / "factor_frobenius_history.json", {"trajectory": factor_norm_trajectory})
        atomic_write_json(out_dir / "factor_spectrum_history.json", {"history": factor_spectrum_history})
        atomic_write_json(out_dir / "block_budget_history.json", {"history": block_budget_history})
        atomic_write_json(out_dir / "checkpoint_history.json", {"history": ckpt_history})
        atomic_write_json(out_dir / "PARAMETER_PERSISTENCE_VALIDATION.json", persistence_artifact)

        # ---- on-disk validation ----
        mandatory = ["training_history.npz", "rho_trajectory.json", "diag_scale_trajectory.json",
                     "clip_boundary_occupancy.json", "factor_frobenius_history.json",
                     "factor_spectrum_history.json", "block_budget_history.json",
                     "checkpoint_history.json", "PARAMETER_PERSISTENCE_VALIDATION.json",
                     "final_svi_params.npz", "final_svi_params_manifest.json"]
        od_ok = True
        for m in mandatory:
            fp = out_dir / m
            if not (fp.exists() and fp.stat().st_size > 0):
                od_ok = False
        try:
            json.loads((out_dir / "checkpoint_history.json").read_text(encoding="utf-8"))
            json.loads((out_dir / "PARAMETER_PERSISTENCE_VALIDATION.json").read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            od_ok = False
        required_diagnostics_present = bool(od_ok and losses and finite_flags and ckpt_history
                                            and factor_spectrum_history and block_budget_history)

        # ---- failure semantics (Stage K) ----
        if nonfinite_steps > 0:
            terminal_status = "FAILED_NONFINITE_LOSS"
        elif not all_params_finite_final:
            terminal_status = "FAILED_NONFINITE_PARAMETER"
        elif not persistence_pass:
            terminal_status = "COMPLETED_OPTIMIZATION_BUT_PARAMETER_PERSISTENCE_FAILED"
        elif not required_diagnostics_present:
            terminal_status = "COMPLETED_OPTIMIZATION_BUT_DIAGNOSTIC_ARTIFACT_WRITE_FAILED"
        elif early_stop_reason == "early_stop_patience":
            terminal_status = "COMPLETED_EARLY_STOPPED"
        else:
            terminal_status = "COMPLETED_G1_VALID_RUN"
        valid_run = bool(terminal_status == "COMPLETED_G1_VALID_RUN" and persistence_pass
                         and required_diagnostics_present)

        # ---- 15: result.json LAST ----
        run_ended_utc = utc_now()
        elapsed = time.perf_counter() - run_t0
        result = {
            "identity": entry["identity"], "arm": entry["arm"],
            "num_particles": entry["num_particles"], "seed": seed, "cutoff": entry["cutoff"],
            "steps_completed": steps_completed,
            "initial_loss": initial_loss, "terminal_loss": terminal_loss,
            "loss_reduction_fraction": float(loss_red),
            "nonfinite_loss_steps": nonfinite_steps,
            "all_params_finite": all_params_finite_final,
            "early_stop_reason": early_stop_reason,
            "terminal_status": terminal_status,
            "VALID_V2_G1_RUN": valid_run,
            "required_diagnostics_present": required_diagnostics_present,
            "parameter_persistence_status": "PASS" if persistence_pass else "FAILED",
            "clip_boundary_occupancy": clip_occupancy,
            "final_diag_scale": {"effective_min": final_diag["diag_effective_min"],
                                 "effective_max": final_diag["diag_effective_max"],
                                 "canonical_min": final_diag["diag_canonical_min"],
                                 "canonical_max": final_diag["diag_canonical_max"]},
            "final_rho": final_diag["rho"],
            "final_factor_frobenius_norms": final_diag["factor_frobenius_norms"],
            "final_factor_singular_values": final_diag["singular_values"],
            "final_global_low_rank_variance_fraction": final_diag["global_low_rank_variance_fraction"],
            "final_block_covariance_budget": final_diag["blocks"],
            "final_parameter_schema": param_schema,
            "total_parameter_elements": total_elements,
            "checkpoint_count": len(ckpt_history),
            "checkpoint_history": ckpt_history,
            "started_utc": run_started_utc, "ended_utc": run_ended_utc,
            "elapsed_seconds": float(elapsed),
            "runner_sha256": sha256(Path(__file__).resolve()),
            "guide_sha256": sha256(root / FROZEN_PATHS["guide_fix"]),
            "data_seed": int(data_seed),
            "rng_identity": {
                "prototype_key": np.asarray(prototype_key).tolist(),
                "factor_init_key": np.asarray(factor_init_key).tolist(),
                "svi_init_key": np.asarray(svi_init_key).tolist(),
                "svi_runtime_key": np.asarray(svi_runtime_key).tolist(),
            },
            "persistence": persistence_artifact,
        }
        atomic_write_json(out_dir / "result.json", result)
        return terminal_status
    except Exception as exc:  # noqa: BLE001
        atomic_write_json(out_dir / "FAILURE.json",
                          {"status": "FAILED_EXCEPTION_AFTER_RUN_STARTED", "error": repr(exc),
                           "started_utc": run_started_utc, "ended_utc": utc_now(),
                           "note": "RUN_STARTED identity remains consumed; no automatic rerun."})
        return "FAILED_EXCEPTION_AFTER_RUN_STARTED"


# ---------------------------------------------------------------------------
# Source-level presence audit (preflight checks 13-18).
# ---------------------------------------------------------------------------
def source_presence_audit(root: Path) -> dict:
    src = Path(__file__).resolve().read_text(encoding="utf-8")
    checks = {
        "svi_constructor": "SVI(" in src,
        "svi_init_call": "svi.init(" in src,
        "svi_update_call": "svi.update(" in src,
        "svi_stable_update_call": "svi.stable_update(" in src,
        "trace_elbo_particles": 'Trace_ELBO(num_particles=entry["num_particles"])' in src,
        "clippedadam_exact": 'ClippedAdam(step_size=TRAINING["learning_rate"], '
                             'clip_norm=TRAINING["clip_norm"])' in src
                             and TRAINING["learning_rate"] == 0.003 and TRAINING["clip_norm"] == 10.0,
        "persistence_save": "save_params(" in src,
        "persistence_roundtrip": "validate_params_roundtrip(" in src,
        "one_shot_guard": "RUN_STARTED" in src and "acquire_run_started(" in src,
    }
    # terminal ordering: result.json write appears after the last persistence
    # / diagnostic artifact write in the source text. Use FIRST occurrences
    # (the audit's own search literals occur later in the file and would
    # otherwise be picked up by rfind).
    i_result = src.find('out_dir / "result.json"')
    i_npz = src.find('out_dir / "final_svi_params.npz"')
    i_manifest = src.find('out_dir / "final_svi_params_manifest.json"')
    i_ckpt = src.find('out_dir / "checkpoint_history.json"')
    i_persist = src.find('out_dir / "PARAMETER_PERSISTENCE_VALIDATION.json"')
    checks["result_json_written_last"] = bool(
        i_result > 0 and i_result > i_npz and i_result > i_manifest
        and i_result > i_ckpt and i_result > i_persist
    )
    ok = all(checks.values())
    return {"ok": ok, "checks": checks}


# ---------------------------------------------------------------------------
# Runtime SVI probe (preflight check 19: real runtime proof that preflight
# invoked no SVI calls).
# ---------------------------------------------------------------------------
def _install_svi_probe():
    import numpyro.infer as _inf
    counters = {"init": 0, "update": 0, "stable_update": 0}
    orig = {}
    for name in counters:
        orig[name] = getattr(_inf.SVI, name)

        def _mk(n):
            def wrapper(self, *a, **k):
                counters[n] += 1
                return orig[n](self, *a, **k)
            return wrapper
        setattr(_inf.SVI, name, _mk(name))
    return counters, orig


def _restore_svi(orig):
    import numpyro.infer as _inf
    for name, fn in orig.items():
        setattr(_inf.SVI, name, fn)


# ---------------------------------------------------------------------------
# Preflight.
# ---------------------------------------------------------------------------
def run_preflight(root: Path, counters: dict | None = None) -> dict:
    chain = verify_frozen_chain(root, include_self=True)
    i42 = check_42i_pass(root)
    j42p = check_42j_protocol_exact(root)
    l42 = check_42l_present(root)
    matrix = check_run_matrix(root)
    consumed = check_zero_consumed(root)
    auths = check_auth_state(root)
    guards = {
        "canary_refused": bool(guard_canary(root)["refused"]),
        "canary_reason": guard_canary(root)["reason"],
        "validation_refused": bool(guard_validation(root)["refused"]),
        "validation_reason": guard_validation(root)["reason"],
    }
    guards_ok = bool(guards["canary_refused"] and guards["validation_refused"])
    src = source_presence_audit(root)
    V2_RUNS.mkdir(parents=True, exist_ok=True)
    V2_AUTHS.mkdir(parents=True, exist_ok=True)
    # runtime probe: SVI call counters installed by cmd_preflight around the
    # ENTIRE preflight; if any SVI.init/update/stable_update were invoked
    # during preflight, counters would be non-zero.
    if counters is None:
        counters = {"init": 0, "update": 0, "stable_update": 0}
    probe = {"SVI_init_called": counters["init"] > 0,
             "SVI_update_called": counters["update"] > 0,
             "SVI_stable_update_called": counters["stable_update"] > 0,
             "counters": counters}
    probe_ok = bool(not probe["SVI_init_called"] and not probe["SVI_update_called"]
                    and not probe["SVI_stable_update_called"])
    ok = bool(chain["ok"] and i42["ok"] and j42p["ok"] and l42["ok"] and matrix["ok"]
              and consumed["ok"] and auths["ok"] and guards_ok and src["ok"] and probe_ok)
    return {
        "ok": ok,
        "chain": chain["results"],
        "42I": i42,
        "42J_protocol": j42p,
        "42L": l42,
        "run_matrix": matrix["detail"],
        "consumed": consumed,
        "authorizations": auths,
        "negative_guards": guards,
        "source_presence": src["checks"],
        "svi_runtime_probe": probe,
        "scientific_target_unchanged": chain["results"]["model"]["ok"],
        "namespace": {"runs": str(V2_RUNS), "authorizations": str(V2_AUTHS)},
    }


def cmd_preflight(root: Path) -> int:
    # Install the SVI runtime probe BEFORE any preflight work and keep it
    # active for the ENTIRE preflight, so the counters prove that no
    # SVI.init / SVI.update / SVI.stable_update was invoked.
    counters, _orig = _install_svi_probe()
    try:
        res = run_preflight(root, counters=counters)
    finally:
        _restore_svi(_orig)
    classification = (
        "V2_G1_EXECUTION_RUNNER_READY_FOR_CANARY_AUTHORIZATION" if res["ok"]
        else "V2_G1_EXECUTION_RUNNER_NOT_READY"
    )
    c = res["chain"]
    payload = {
        "artifact_id": "42M_V2_G1_EXECUTION_RUNNER_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "mode": "V2 G1 EXECUTION RUNNER PREFLIGHT (deterministic checks only; no SVI, no canary, no validation)",
        "classification": classification,
        "checks": {
            "1_frozen_shas_all": all(v["ok"] for v in c.values()),
            "2_42I_pass": res["42I"]["ok"],
            "3_42J_protocol_exact": res["42J_protocol"]["ok"],
            "4_42L_adjudication_present": res["42L"]["ok"],
            "5_corrected_guide_sha": c.get("guide_fix", {}).get("ok", False),
            "6_run_identities_exact_10": res["run_matrix"]["total_identities"] == 10,
            "7_canary_identity_exact": res["run_matrix"]["canary"]["exact"],
            "8_zero_consumed_identities": res["consumed"]["n_consumed"] == 0,
            "9_canary_not_permitted_now": res["authorizations"]["canary_artifact_present"] is False,
            "10_validation_not_permitted_now": res["authorizations"]["validation_artifact_present"] is False,
            "11_canary_without_auth_refuses": res["negative_guards"]["canary_refused"],
            "12_validation_without_auth_refuses": res["negative_guards"]["validation_refused"],
            "13_real_svi_execution_in_source": res["source_presence"]["svi_constructor"]
                and res["source_presence"]["svi_init_call"]
                and res["source_presence"]["svi_stable_update_call"],
            "14_trace_elbo_binding": res["source_presence"]["trace_elbo_particles"],
            "15_clippedadam_binding_exact": res["source_presence"]["clippedadam_exact"],
            "16_persistence_calls_present": res["source_presence"]["persistence_save"]
                and res["source_presence"]["persistence_roundtrip"],
            "17_one_shot_guard_present": res["source_presence"]["one_shot_guard"],
            "18_terminal_result_ordering": res["source_presence"]["result_json_written_last"],
            "19_preflight_svi_calls_zero": res["svi_runtime_probe"]["counters"]["init"] == 0
                and res["svi_runtime_probe"]["counters"]["update"] == 0
                and res["svi_runtime_probe"]["counters"]["stable_update"] == 0,
            "20_no_run_started_created": res["consumed"]["n_consumed"] == 0,
            "21_no_identity_consumed": res["consumed"]["n_consumed"] == 0,
            "22_scientific_target_unchanged": res["scientific_target_unchanged"],
            "OVERALL": "PASS" if res["ok"] else "FAIL",
        },
        "sha_chain": res["chain"],
        "42I": res["42I"],
        "42J_protocol": res["42J_protocol"],
        "42L": res["42L"],
        "run_matrix": res["run_matrix"],
        "consumed_identities": res["consumed"],
        "authorization_state": res["authorizations"],
        "negative_mode_guards": res["negative_guards"],
        "source_presence": res["source_presence"],
        "svi_runtime_probe": res["svi_runtime_probe"],
        "namespace": res["namespace"],
        "flags": {
            "V2_CANARY_AUTHORIZED": False,
            "V2_VALIDATION_AUTHORIZED": False,
            "V2_OPTIMIZATION_EXECUTED": False,
            "NEW_INFERENCE_RUN": False,
            "NEW_OPTIMIZATION_RUN": False,
            "POSTERIOR_DRAWS_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "G3_AUTHORIZED": False,
            "SCIENTIFIC_TARGET_MODIFIED": False,
            "V1_MODIFIED": False,
            "FAILED_PHASE3C4_PCA_USED": False,
        },
        "created_files": [
            "scripts/68_run_phase3c4v_v2_g1_execution.py",
            "results/phase3c4v/audit/42L_V2_PRECANARY_HUMAN_ADJUDICATION.json",
            "results/phase3c4v/audit/42L_V2_PRECANARY_HUMAN_ADJUDICATION.md",
            "results/phase3c4v/preflight/42M_V2_G1_EXECUTION_RUNNER_PREFLIGHT.json",
            "results/phase3c4v/preflight/42M_V2_G1_EXECUTION_RUNNER_PREFLIGHT.md",
        ],
        "modified_files": [],
        "final_state": ("V2_G1_EXECUTION_INFRASTRUCTURE_COMPLETE" if res["ok"]
                        else "V2_G1_EXECUTION_INFRASTRUCTURE_INCOMPLETE"),
        "waiting_for": ("STOP_WAITING_FOR_EXPLICIT_HUMAN_CANARY_AUTHORIZATION" if res["ok"]
                        else "STOP_WAITING_FOR_EXECUTION_RUNNER_FIX"),
    }
    out_path = root / "results/phase3c4v/preflight/42M_V2_G1_EXECUTION_RUNNER_PREFLIGHT.json"
    atomic_write_json(out_path, payload)
    md = ["# 42M — V2 G1 EXECUTION RUNNER PREFLIGHT", "",
          f"Generated: {utc_now()}  |  Mode: V2 G1 EXECUTION RUNNER PREFLIGHT "
          "(deterministic checks only; no SVI, no canary, no validation)", "",
          f"**Classification: {classification}**", "",
          "| Check | Result |", "|---|---|"]
    for k, v in payload["checks"].items():
        md.append(f"| {k} | {'PASS' if v else 'FAIL'} |")
    md += ["", "## SVI runtime probe (preflight)", ""]
    md.append(f"- SVI.init called = {payload['svi_runtime_probe']['counters']['init'] > 0} | "
              f"SVI.update called = {payload['svi_runtime_probe']['counters']['update'] > 0} | "
              f"SVI.stable_update called = {payload['svi_runtime_probe']['counters']['stable_update'] > 0}")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in res["chain"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", "## Negative mode guards", ""]
    md.append(f"- canary: refused={res['negative_guards']['canary_refused']} — {res['negative_guards']['canary_reason']}")
    md.append(f"- validation: refused={res['negative_guards']['validation_refused']} — {res['negative_guards']['validation_reason']}")
    md += ["", "## Flags", "", "| Flag | Value |", "|---|---|"]
    for k, v in payload["flags"].items():
        md.append(f"| {k} | {v} |")
    md += ["", f"## Final state: **{payload['final_state']}**", f"- {payload['waiting_for']}"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", payload["checks"]["OVERALL"])
    return 0 if res["ok"] else 2


def cmd_canary(root: Path) -> int:
    g = guard_canary(root)
    if g["refused"]:
        print(g["reason"])
        return 2
    print("V2 canary authorization validated; executing canary identity...")
    _run_identity_future(root, dict(CANARY_IDENTITY), auth_kind="canary")
    return 0


def cmd_validation(root: Path) -> int:
    g = guard_validation(root)
    if g["refused"]:
        print(g["reason"])
        return 2
    j42 = load_json(FROZEN_PATHS["42J"])
    identities = j42["4_run_matrix"]["identities"]
    print("V2 validation authorization validated; executing remaining frozen identities...")
    for entry in identities:
        if entry["identity"] == CANARY_IDENTITY["identity"]:
            continue  # canary identity is never rerun by validation
        _run_identity_future(root, entry, auth_kind="validation")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V2 G1 execution runner (preflight only now)")
    ap.add_argument("--mode", required=True, choices=["preflight", "canary", "validation"])
    args = ap.parse_args(argv)
    if args.mode == "preflight":
        return cmd_preflight(ROOT)
    if args.mode == "canary":
        return cmd_canary(ROOT)
    return cmd_validation(ROOT)


if __name__ == "__main__":
    sys.exit(main())
