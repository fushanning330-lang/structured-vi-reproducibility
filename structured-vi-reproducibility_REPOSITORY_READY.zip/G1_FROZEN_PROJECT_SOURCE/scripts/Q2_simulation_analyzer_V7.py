"""Q2 supplementary simulation — Evidence Analyzer V7 (read-only, eligibility-aware).

Artifact: Q2_simulation_analyzer_V7.py
Frozen: 2026-08-23 (V7 numerical-safety amendment). PRE-STRESS-TEST / PRE-EXECUTION.
The analyzer ONLY reads persisted run artifacts (NPZ + JSON per run) produced by
the authorized Module B batch. It never refits and never regenerates runs.

V7 additions vs V6.1 (V6.1 retained as historical artifact):
  (E1) ELIGIBILITY-AWARE RECONCILIATION: expected identities come from
       Q2_SIMULATION_ELIGIBILITY_MATRIX_V7.csv (execute_v7=true -> 239).
       MB_T01_P1_1001 is CONSUMED_ENGINEERING_FAILURE_V6_1 (historical
       attrition, must_not_rerun, replacement_seed=NONE) and is NOT part of
       expected; any stray file for a consumed identity is reported separately
       (consumed_files_found) and never counted as unexpected.
  (E2) R-PREFIX PRESERVES HISTORICAL ATTRITION: R5/R10/R20 prefixes are taken
       from the frozen per-cell seed list in order, then restricted to eligible
       AND successfully persisted runs. For T01/P1 the frozen first-5 includes
       the consumed seed 1001 -> max evaluable R5=4, R10=9, R20=19. No prefix
       shifting, no backfill.

All V6.1 scientific/robustness logic unchanged: Stage I / Stage II /
known-target metrics, R5/R10/R20 definitions, no significance tests, no
universal threshold; MB_* file scope; fixed CSV schemas; no-crash for
successful=0/1.
"""

from __future__ import annotations

import csv
import itertools
import json
from collections import Counter
from pathlib import Path

import numpy as np

from Q2_simulation_metrics_V4 import (
    location_l2, marginal_scale_cv, principal_angle_sin_norm,
    projection_frobenius, procrustes_raw_residual, covariance_relative_frobenius,
    correlation_rmse, normalized_spectrum_l2, component_relative_frobenius,
    low_rank_trace_share, mean_vector_l2_error_to_target,
    covariance_error_to_target, analytic_gaussian_kl,
)
from Q2_simulation_target_generator_V4 import TARGET_MAP

STAGE_I_KEYS = ["location_l2", "marginal_scale_cv", "principal_angle_sin_F",
                "projection_frobenius", "raw_procrustes"]
STAGE_I_PAIRWISE_KEYS = ["location_l2", "principal_angle_sin_F",
                         "projection_frobenius", "raw_procrustes"]
STAGE_II_PAIRWISE_KEYS = ["covariance_relative_frobenius", "correlation_rmse",
                          "normalized_spectrum_l2", "B_relative_frobenius",
                          "L_relative_frobenius"]
PAIRWISE_KEYS = STAGE_I_PAIRWISE_KEYS + STAGE_II_PAIRWISE_KEYS
KNOWN_TARGET_KEYS = ["mean_vector_l2_error_to_target", "covariance_error_to_target",
                     "analytic_gaussian_kl"]

PER_RUN_FIELDS = ["run_id", "target_id", "particles", "optimizer_seed",
                  "conditioning", "trace_share", "steps", "low_rank_trace_share",
                  "known_mean_vector_l2", "known_covariance_error", "known_analytic_kl"]
PAIRWISE_FIELDS = ["cell", "particles", "run_a", "run_b"] + PAIRWISE_KEYS

RECONCILIATION_FILE = "Q2_SIMULATION_RUN_MATRIX_RECONCILIATION.json"
ELIGIBILITY_CSV_DEFAULT = "results/q2_supplementary_simulation/Q2_SIMULATION_ELIGIBILITY_MATRIX_V7.csv"


# ---------------------------------------------------------------------------
# (E1) eligibility-aware identities
# ---------------------------------------------------------------------------
def load_eligibility(eligibility_csv: Path) -> dict[str, dict]:
    """Read eligibility matrix; returns run_id -> row dict."""
    out = {}
    with open(eligibility_csv, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            out[r["run_id"]] = {
                "target_id": r["target_id"],
                "particles": r["particles"],
                "conditioning": r["conditioning"],
                "trace_share": float(r["trace_share"]),
                "optimizer_seed": int(r["optimizer_seed"]),
                "replicate_prefix": r["replicate_prefix"],
                "eligibility": r["eligibility"],
                "execute_v7": r["execute_v7"].strip().lower() == "true",
                "must_not_rerun": r["must_not_rerun"].strip().lower() == "true",
            }
    return out


def _expected_identities(elig: dict[str, dict]) -> dict[str, dict]:
    """Expected Module-B identities for V7 = execute_v7=true (239)."""
    return {rid: meta for rid, meta in elig.items() if meta["execute_v7"]}


def _consumed_identities(elig: dict[str, dict]) -> dict[str, dict]:
    """Consumed (historical attrition) identities = execute_v7=false."""
    return {rid: meta for rid, meta in elig.items() if not meta["execute_v7"]}


def _cell_eligible_seeds(elig: dict[str, dict]) -> dict[tuple, list[int]]:
    """Per-cell ordered eligible optimizer seeds (frozen order, consumed excluded)."""
    cells = {}
    for rid, meta in elig.items():
        if not meta["execute_v7"]:
            continue
        key = (meta["target_id"], meta["particles"])
        cells.setdefault(key, []).append(meta["optimizer_seed"])
    for k in cells:
        cells[k].sort()
    return cells


def reconcile_run_matrix(run_dir: Path, seed_matrix_csv: Path,
                         eligibility_csv: Path | None = None) -> dict:
    """Reconcile expected (239 eligible) vs observed. Read-only."""
    elig = load_eligibility(eligibility_csv or ELIGIBILITY_CSV_DEFAULT)
    expected = _expected_identities(elig)
    consumed = _consumed_identities(elig)

    all_json = sorted(run_dir.rglob("MB_*.json"))
    all_npz = sorted(run_dir.rglob("MB_*.npz"))
    dup_rids = sorted({rid for rid, c in Counter(jf.stem for jf in all_json).items() if c > 1} |
                      {rid for rid, c in Counter(nz.stem for nz in all_npz).items() if c > 1})

    successful, failed = {}, {}
    json_only_anomaly, npz_only_anomaly = {}, {}
    consumed_files = {}
    for jf in all_json:
        rid = jf.stem
        meta = json.loads(jf.read_text(encoding="utf-8"))
        if rid in consumed:
            consumed_files[rid] = meta.get("status", "file_present")
            continue                       # historical attrition, not a V7 identity
        if meta.get("status") == "ENGINEERING_FAILED":
            failed[rid] = meta
        elif (jf.with_suffix(".npz")).exists():
            successful[rid] = meta
        else:
            json_only_anomaly[rid] = meta
    for nz in all_npz:
        rid = nz.stem
        if rid in consumed:
            consumed_files.setdefault(rid, "npz_present")
            continue
        if not (nz.with_suffix(".json")).exists():
            npz_only_anomaly[rid] = None

    overlap = sorted(set(successful) & set(failed))
    for rid in overlap:
        successful.pop(rid, None)

    observed_ids = (set(successful) | set(failed) |
                    set(json_only_anomaly) | set(npz_only_anomaly))
    missing = sorted(set(expected) - observed_ids)
    unexpected = sorted(observed_ids - set(expected))

    attrition = len(failed) + len(missing)
    anomaly = bool(json_only_anomaly or npz_only_anomaly)
    if dup_rids or unexpected or overlap or anomaly:
        verdict = "FAIL"
        reason = ("duplicate and/or unexpected identity detected; "
                  "scientific summary BLOCKED")
    elif attrition > 0:
        verdict = "PASS_WITH_ATTENTION"
        reason = ("engineering attrition present; original identities preserved, "
                  "no replacement; human adjudication decides evaluability")
    else:
        verdict = "PASS"
        reason = "all 239 eligible identities observed successful; no attrition"

    return {
        "artifact": "Q2_SIMULATION_RUN_MATRIX_RECONCILIATION",
        "expected_identities": len(expected),
        "consumed_historical_attrition": len(consumed),
        "consumed_identity": sorted(consumed),
        "consumed_files_found": sorted(consumed_files),
        "observed_successful": len(successful),
        "observed_failed": len(failed),
        "missing": missing,
        "missing_count": len(missing),
        "duplicate": dup_rids,
        "duplicate_count": len(dup_rids),
        "unexpected": unexpected,
        "unexpected_count": len(unexpected),
        "json_only_anomaly": sorted(json_only_anomaly),
        "npz_only_anomaly": sorted(npz_only_anomaly),
        "overlap_failed_successful": overlap,
        "attrition": attrition,
        "verdict": verdict,
        "reason": reason,
        "gate": "scientific summary ALLOWED" if verdict in ("PASS", "PASS_WITH_ATTENTION")
                else "scientific summary BLOCKED",
    }


def load_run(npz_path: Path, json_path: Path) -> dict:
    meta = json.loads(Path(json_path).read_text(encoding="utf-8"))
    npz = np.load(npz_path)
    return {
        **meta,
        "m_q": npz["m_q"], "U_q": npz["U_q"], "Sigma_q": npz["Sigma_q"],
        "B_q": npz["B_q"], "L_q": npz["L_q"],
    }


def cell_pairwise(runs: list[dict]) -> list[dict]:
    pairs = []
    for (i, j) in itertools.combinations(range(len(runs)), 2):
        a, b = runs[i], runs[j]
        pair = {
            "cell": a["target_id"],
            "particles": a["particles"],
            "run_a": a["run_id"], "run_b": b["run_id"],
        }
        pair["location_l2"] = location_l2(a["m_q"], b["m_q"])
        pair["principal_angle_sin_F"] = principal_angle_sin_norm(a["U_q"], b["U_q"])
        pair["projection_frobenius"] = projection_frobenius(a["U_q"], b["U_q"])
        pair["raw_procrustes"] = procrustes_raw_residual(a["U_q"], b["U_q"])
        pair["covariance_relative_frobenius"] = covariance_relative_frobenius(a["Sigma_q"], b["Sigma_q"])
        pair["correlation_rmse"] = correlation_rmse(a["Sigma_q"], b["Sigma_q"])
        pair["normalized_spectrum_l2"] = normalized_spectrum_l2(a["Sigma_q"], b["Sigma_q"])
        pair["B_relative_frobenius"] = component_relative_frobenius(a["B_q"], b["B_q"])
        pair["L_relative_frobenius"] = component_relative_frobenius(a["L_q"], b["L_q"])
        pairs.append(pair)
    return pairs


def cell_marginal_cv(runs: list[dict], d: int = 60) -> float:
    scale_mat = np.array([np.sqrt(np.diag(r["Sigma_q"])) for r in runs], dtype=np.float64)
    _, _, cv = marginal_scale_cv(scale_mat)
    finite = cv[np.isfinite(cv)]
    return float(np.nanmean(finite)) if finite.size else float("nan")


def summarize_numeric(values: list[float]) -> dict:
    a = np.asarray(values, dtype=np.float64)
    if a.size == 0:
        return {"n": 0, "mean": float("nan"), "sd": float("nan"),
                "min": float("nan"), "max": float("nan")}
    return {"n": int(a.size), "mean": float(a.mean()), "sd": float(a.std(ddof=0)),
            "min": float(a.min()), "max": float(a.max())}


def _write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        if rows:
            w.writerows(rows)


def analyze_run_dir(run_dir: Path, seed_matrix_csv: Path,
                    out_dir: Path | None = None,
                    eligibility_csv: Path | None = None) -> dict:
    run_dir = Path(run_dir)
    out_dir = Path(out_dir) if out_dir else run_dir / "analysis_v7"
    out_dir.mkdir(parents=True, exist_ok=True)
    elig = load_eligibility(eligibility_csv or ELIGIBILITY_CSV_DEFAULT)

    recon = reconcile_run_matrix(run_dir, seed_matrix_csv, eligibility_csv or ELIGIBILITY_CSV_DEFAULT)
    (out_dir / RECONCILIATION_FILE).write_text(
        json.dumps(recon, indent=2, ensure_ascii=False, default=float), encoding="utf-8")

    if recon["verdict"] == "FAIL":
        return {
            "n_runs_loaded": 0,
            "reconciliation": recon,
            "scientific_summary": "BLOCKED: duplicate/unexpected identity detected",
        }

    runs = []
    for jf in sorted(run_dir.glob("MB_*.json")):
        rid = jf.stem
        if rid in {k for k, v in _consumed_identities(elig).items()}:
            continue                       # consumed identity never enters scientific runs
        meta = json.loads(jf.read_text(encoding="utf-8"))
        if meta.get("status") == "ENGINEERING_FAILED":
            continue
        npz = jf.with_suffix(".npz")
        if npz.exists():
            runs.append(load_run(npz, jf))

    cells = {}
    for r in runs:
        cells.setdefault((r["target_id"], r["particles"]), []).append(r)
    for k in cells:
        cells[k].sort(key=lambda r: r["optimizer_seed"])

    # (E2) eligible per-cell seeds (frozen order, consumed excluded)
    eligible_seeds = _cell_eligible_seeds(elig)

    per_run_rows = []
    pairwise_rows = []
    cell_summaries = []
    r_prefix_summaries = []
    known_target_summaries = []
    adjudication = []

    for (target_id, particles), runs_cell in sorted(cells.items()):
        conditioning = runs_cell[0]["conditioning"]
        trace_share = runs_cell[0]["trace_share"]
        mcv = cell_marginal_cv(runs_cell)
        for r in runs_cell:
            per_run_rows.append({
                "run_id": r["run_id"], "target_id": target_id,
                "particles": particles, "optimizer_seed": r["optimizer_seed"],
                "conditioning": conditioning, "trace_share": trace_share,
                "steps": r.get("steps", ""),
                "low_rank_trace_share": r["low_rank_trace_share"],
                "known_mean_vector_l2": r["known_target"]["mean_vector_l2_error_to_target"],
                "known_covariance_error": r["known_target"]["covariance_error_to_target"],
                "known_analytic_kl": r["known_target"]["analytic_gaussian_kl"],
            })
        pw = cell_pairwise(runs_cell)
        for p in pw:
            pairwise_rows.append(p)
        share_cell = summarize_numeric([r["low_rank_trace_share"] for r in runs_cell])
        kt_cell = {k: summarize_numeric([r["known_target"][k] for r in runs_cell])
                   for k in KNOWN_TARGET_KEYS}
        cell_summaries.append({
            "target_id": target_id, "particles": particles,
            "conditioning": conditioning, "trace_share": trace_share,
            "n_runs": len(runs_cell), "n_pairs": len(pw),
            "marginal_scale_cv": mcv,
            "stage_I": {k: summarize_numeric([p[k] for p in pw]) for k in STAGE_I_PAIRWISE_KEYS},
            "stage_II": {k: summarize_numeric([p[k] for p in pw]) for k in STAGE_II_PAIRWISE_KEYS},
            "low_rank_trace_share": share_cell,
            "known_target": kt_cell,
        })
        known_target_summaries.append({
            "target_id": target_id, "particles": particles,
            "conditioning": conditioning, "trace_share": trace_share,
            "n_runs": len(runs_cell),
            **kt_cell,
        })
        # (E2) R-prefix: frozen order restricted to eligible seeds; no shifting/backfill
        seeds_eligible = eligible_seeds.get((target_id, particles), [])
        frozen_all = [m["optimizer_seed"] for rid, m in sorted(elig.items())
                      if m["target_id"] == target_id and m["particles"] == particles]
        for R, n in (("R5", 5), ("R10", 10), ("R20", 20)):
            prefix_seeds = frozen_all[:n]                 # frozen prefix (may include consumed)
            subset = [r for r in runs_cell if r["optimizer_seed"] in prefix_seeds
                      and r["optimizer_seed"] in seeds_eligible]
            max_evaluable = sum(1 for s in prefix_seeds if s in seeds_eligible)
            if len(subset) >= 2:
                spw = cell_pairwise(subset)
                smcv = cell_marginal_cv(subset)
                share_sub = summarize_numeric([r["low_rank_trace_share"] for r in subset])
                kt_sub = {k: summarize_numeric([r["known_target"][k] for r in subset])
                          for k in KNOWN_TARGET_KEYS}
                r_prefix_summaries.append({
                    "target_id": target_id, "particles": particles,
                    "conditioning": conditioning, "trace_share": trace_share,
                    "R": R, "n_runs": len(subset), "n_pairs": len(spw),
                    "max_evaluable": max_evaluable,
                    "marginal_scale_cv": smcv,
                    "stage_I": {k: summarize_numeric([p[k] for p in spw]) for k in STAGE_I_PAIRWISE_KEYS},
                    "stage_II": {k: summarize_numeric([p[k] for p in spw]) for k in STAGE_II_PAIRWISE_KEYS},
                    "low_rank_trace_share": share_sub,
                    "known_target": kt_sub,
                })
        adjudication.append({
            "target_id": target_id, "particles": particles,
            "note": "Descriptive within-cell summaries only; no significance testing; "
                    "no cross-cell pairs; pairwise distances not independent observations; "
                    "historical attrition preserved (consumed seed 1001 excluded, no backfill).",
            "marginal_scale_cv": mcv,
        })

    _write_csv(out_dir / "per_run_known_target.csv", PER_RUN_FIELDS, per_run_rows)
    _write_csv(out_dir / "pairwise_metrics.csv", PAIRWISE_FIELDS, pairwise_rows)
    (out_dir / "cell_summaries.json").write_text(
        json.dumps(cell_summaries, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    (out_dir / "r_prefix_summaries.json").write_text(
        json.dumps(r_prefix_summaries, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    (out_dir / "known_target_summaries.json").write_text(
        json.dumps(known_target_summaries, indent=2, ensure_ascii=False, default=float), encoding="utf-8")
    (out_dir / "human_adjudication_handoff.json").write_text(
        json.dumps(adjudication, indent=2, ensure_ascii=False, default=float), encoding="utf-8")

    return {
        "n_runs_loaded": len(runs),
        "n_cells": len(cells),
        "n_cell_summaries": len(cell_summaries),
        "n_known_target_summaries": len(known_target_summaries),
        "n_r_prefix_summaries": len(r_prefix_summaries),
        "reconciliation": recon,
        "outputs": {p.name: str(p) for p in out_dir.iterdir() if p.is_file()},
    }


if __name__ == "__main__":
    import sys
    run_dir = sys.argv[1] if len(sys.argv) > 1 else "results/q2_supplementary_simulation/module_b"
    seed_csv = "results/q2_supplementary_simulation/Q2_SIMULATION_SEED_MATRIX.csv"
    result = analyze_run_dir(run_dir, seed_csv)
    print(json.dumps(result, indent=2, ensure_ascii=False))
