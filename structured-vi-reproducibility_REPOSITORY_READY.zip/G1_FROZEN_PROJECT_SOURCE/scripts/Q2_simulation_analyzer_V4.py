"""Q2 supplementary simulation — Evidence Analyzer V4 (read-only).

Artifact: Q2_simulation_analyzer_V4.py
Frozen: 2026-08-23 (V4 executor semantics repair). PRE-EXECUTION.
The analyzer ONLY reads persisted run artifacts (NPZ + JSON per run) produced by
the authorized Module B batch. It never refits and never regenerates runs.

Outputs (per frozen cell, R=20, and the same frozen prefixes R5/R10/R20):
  Stage I   : location L2, marginal-scale CV (G2 parity), principal-angle sin_F,
              projection Frobenius, raw Procrustes
  Stage II  : covariance relative Frobenius, correlation RMSE, normalized spectrum
              L2, B relative Frobenius, L relative Frobenius, low-rank trace share
  Known-target: mean-vector L2, covariance target error, analytic Gaussian KL

Pairwise metrics are computed WITHIN the same cell only (no cross-cell pairs).
Pairwise distances are NOT treated as independent observations; no significance
testing is performed. Outputs: per-run CSV, pairwise CSV, cell summaries,
R5/R10/R20 summaries, known-target summaries, human-adjudication handoff.
"""

from __future__ import annotations

import csv
import itertools
import json
from pathlib import Path

import numpy as np

from Q2_simulation_metrics_V4 import (
    location_l2, marginal_scale_cv, principal_angle_sin_norm,
    projection_frobenius, procrustes_raw_residual, covariance_relative_frobenius,
    correlation_rmse, normalized_spectrum_l2, component_relative_frobenius,
    low_rank_trace_share, mean_vector_l2_error_to_target,
    covariance_error_to_target, analytic_gaussian_kl,
)

STAGE_I_KEYS = ["location_l2", "marginal_scale_cv", "principal_angle_sin_F",
                "projection_frobenius", "raw_procrustes"]
STAGE_II_KEYS = ["covariance_relative_frobenius", "correlation_rmse",
                 "normalized_spectrum_l2", "B_relative_frobenius",
                 "L_relative_frobenius", "low_rank_trace_share"]
KNOWN_TARGET_KEYS = ["mean_vector_l2_error_to_target", "covariance_error_to_target",
                     "analytic_gaussian_kl"]
# pairwise fields (marginal_scale_cv is a cell-level single value, NOT a pairwise field)
PAIRWISE_KEYS = [k for k in STAGE_I_KEYS + STAGE_II_KEYS if k != "marginal_scale_cv"]


def load_run(npz_path: Path, json_path: Path) -> dict:
    """Load one persisted run (NPZ arrays + JSON metadata)."""
    meta = json.loads(Path(json_path).read_text(encoding="utf-8"))
    npz = np.load(npz_path)
    return {
        **meta,
        "m_q": npz["m_q"], "U_q": npz["U_q"], "Sigma_q": npz["Sigma_q"],
        "B_q": npz["B_q"], "L_q": npz["L_q"],
    }


def cell_pairwise(runs: list[dict]) -> list[dict]:
    """Pairwise metrics within one cell (all pairs of distinct run_ids)."""
    pairs = []
    for (i, j) in itertools.combinations(range(len(runs)), 2):
        a, b = runs[i], runs[j]
        pair = {
            "cell": a["target_id"],
            "particles": a["particles"],
            "run_a": a["run_id"], "run_b": b["run_id"],
        }
        pair["location_l2"] = location_l2(a["m_q"], b["m_q"])
        pair["principal_angle_sin_F"] = principal_angle_sin_norm(a["U_q"], b["U_q"])
        pair["projection_frobenius"] = projection_frobenius(a["U_q"], b["U_q"])
        pair["raw_procrustes"] = procrustes_raw_residual(a["U_q"], b["U_q"])
        pair["covariance_relative_frobenius"] = covariance_relative_frobenius(a["Sigma_q"], b["Sigma_q"])
        pair["correlation_rmse"] = correlation_rmse(a["Sigma_q"], b["Sigma_q"])
        pair["normalized_spectrum_l2"] = normalized_spectrum_l2(a["Sigma_q"], b["Sigma_q"])
        pair["B_relative_frobenius"] = component_relative_frobenius(a["B_q"], b["B_q"])
        pair["L_relative_frobenius"] = component_relative_frobenius(a["L_q"], b["L_q"])
        pair["low_rank_trace_share"] = low_rank_trace_share(b["L_q"], b["Sigma_q"])
        pairs.append(pair)
    return pairs


def cell_marginal_cv(runs: list[dict], d: int = 60) -> float:
    """G2-parity marginal-scale CV: one call on (R, d) scale matrix; finite coords only."""
    scale_mat = np.array([np.sqrt(np.diag(r["Sigma_q"])) for r in runs], dtype=np.float64)
    _, _, cv = marginal_scale_cv(scale_mat)
    finite = cv[np.isfinite(cv)]
    return float(np.nanmean(finite)) if finite.size else float("nan")


def summarize_numeric(values: list[float]) -> dict:
    a = np.asarray(values, dtype=np.float64)
    if a.size == 0:
        return {"n": 0, "mean": float("nan"), "sd": float("nan"),
                "min": float("nan"), "max": float("nan")}
    return {"n": int(a.size), "mean": float(a.mean()), "sd": float(a.std(ddof=0)),
            "min": float(a.min()), "max": float(a.max())}


def analyze_run_dir(run_dir: Path, seed_matrix_csv: Path,
                    out_dir: Path | None = None) -> dict:
    """Analyze persisted runs; write CSVs/summaries/handoff. Read-only on runs."""
    run_dir = Path(run_dir)
    out_dir = Path(out_dir) if out_dir else run_dir / "analysis_v4"
    out_dir.mkdir(parents=True, exist_ok=True)

    # load all persisted runs
    runs = []
    for jf in sorted(run_dir.glob("*.json")):
        npz = jf.with_suffix(".npz")
        if npz.exists():
            runs.append(load_run(npz, jf))

    # group by (target_id, particles) — same cell = same target_id + particles
    cells = {}
    for r in runs:
        cells.setdefault((r["target_id"], r["particles"]), []).append(r)
    for k in cells:
        cells[k].sort(key=lambda r: r["optimizer_seed"])

    # seed prefix rules from frozen seed matrix (per cell: first 5/10/20 seeds)
    prefix_map = {}
    with open(seed_matrix_csv, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row["module"] == "B":
                key = (row["conditioning"], row["trace_share"], row["particles"])
                prefix_map.setdefault(key, []).append(int(row["seed"]))

    per_run_rows = []
    pairwise_rows = []
    cell_summaries = []
    r_prefix_summaries = []
    known_target_summaries = []
    adjudication = []

    for (target_id, particles), runs_cell in sorted(cells.items()):
        conditioning = runs_cell[0]["conditioning"]
        trace_share = runs_cell[0]["trace_share"]
        # cell marginal-scale CV (G2 parity, single call on (R,d))
        mcv = cell_marginal_cv(runs_cell)
        # known-target (per run)
        for r in runs_cell:
            per_run_rows.append({
                "run_id": r["run_id"], "target_id": target_id,
                "particles": particles, "optimizer_seed": r["optimizer_seed"],
                "conditioning": conditioning, "trace_share": trace_share,
                "steps": r.get("steps", ""),
                "known_mean_vector_l2": r["known_target"]["mean_vector_l2_error_to_target"],
                "known_covariance_error": r["known_target"]["covariance_error_to_target"],
                "known_analytic_kl": r["known_target"]["analytic_gaussian_kl"],
            })
        # pairwise within cell
        pw = cell_pairwise(runs_cell)
        for p in pw:
            pairwise_rows.append(p)
        # cell summary (Stage I/II pairwise + known-target)
        cell_summaries.append({
            "target_id": target_id, "particles": particles,
            "conditioning": conditioning, "trace_share": trace_share,
            "n_runs": len(runs_cell), "n_pairs": len(pw),
            "marginal_scale_cv": mcv,
            **{k: summarize_numeric([p[k] for p in pw]) for k in PAIRWISE_KEYS},
            "known_target": {k: summarize_numeric([r["known_target"][k] for r in runs_cell])
                             for k in KNOWN_TARGET_KEYS},
        })
        # R5/R10/R20 prefixes (same frozen seed list; R=5 first 5, R=10 first 10, R=20 all)
        seeds = prefix_map.get((conditioning, trace_share, particles), [])
        for R, n in (("R5", 5), ("R10", 10), ("R20", 20)):
            subset = [r for r in runs_cell if r["optimizer_seed"] in seeds[:n]]
            if len(subset) >= 2:
                spw = cell_pairwise(subset)
                r_prefix_summaries.append({
                    "target_id": target_id, "particles": particles,
                    "R": R, "n_runs": len(subset), "n_pairs": len(spw),
                    **{k: summarize_numeric([p[k] for p in spw]) for k in PAIRWISE_KEYS},
                })
        # adjudication handoff (descriptive only)
        adjudication.append({
            "target_id": target_id, "particles": particles,
            "note": "Descriptive within-cell summaries only; no significance testing; "
                    "no cross-cell pairs; pairwise distances not independent observations.",
            "marginal_scale_cv": mcv,
        })

    # write outputs
    with open(out_dir / "per_run_known_target.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(per_run_rows[0].keys())); w.writeheader(); w.writerows(per_run_rows)
    with open(out_dir / "pairwise_metrics.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(pairwise_rows[0].keys())); w.writeheader(); w.writerows(pairwise_rows)
    with open(out_dir / "cell_summaries.json", "w", encoding="utf-8") as f:
        json.dump(cell_summaries, f, indent=2, ensure_ascii=False, default=float)
    with open(out_dir / "r_prefix_summaries.json", "w", encoding="utf-8") as f:
        json.dump(r_prefix_summaries, f, indent=2, ensure_ascii=False, default=float)
    with open(out_dir / "known_target_summaries.json", "w", encoding="utf-8") as f:
        json.dump(known_target_summaries, f, indent=2, ensure_ascii=False, default=float)
    with open(out_dir / "human_adjudication_handoff.json", "w", encoding="utf-8") as f:
        json.dump(adjudication, f, indent=2, ensure_ascii=False, default=float)

    return {
        "n_runs_loaded": len(runs),
        "n_cells": len(cells),
        "outputs": {p.name: str(p) for p in out_dir.iterdir() if p.is_file()},
    }


if __name__ == "__main__":
    import sys
    run_dir = sys.argv[1] if len(sys.argv) > 1 else "results/q2_supplementary_simulation/module_b"
    seed_csv = "results/q2_supplementary_simulation/Q2_SIMULATION_SEED_MATRIX.csv"
    result = analyze_run_dir(run_dir, seed_csv)
    print(json.dumps(result, indent=2, ensure_ascii=False))
