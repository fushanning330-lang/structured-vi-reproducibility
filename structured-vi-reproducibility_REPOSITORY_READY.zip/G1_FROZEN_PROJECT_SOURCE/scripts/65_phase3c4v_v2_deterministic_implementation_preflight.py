"""Phase3C.4V V2 — DETERMINISTIC IMPLEMENTATION G0 PREFLIGHT (scripts/65).

EXPLICITLY AUTHORIZED: V2 guide prototype implementation + deterministic G0
implementation preflight ONLY. NO SVI.init / SVI.update / SVI.stable_update /
optimization / posterior sampling / importance sampling / NUTS / HMC / MCMC /
NeuTra. NO inference authorization artifact is created.

Frozen specs: 42E (V2 AR(1) temporal mathematical specification freeze) +
42F (numerical safety amendment). Guide source: v2_shared_ar1_temporal_guide.py.

G0 tests implemented: G0.1..G0.30 (see _run_g0 below).
Output: results/phase3c4v/preflight/42G_V2_AR1_IMPLEMENTATION_DETERMINISTIC_G0_PREFLIGHT.{json,md}
"""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)  # MUST be set before numpyro import

import jax.numpy as jnp
import numpy as np
import numpyro
from numpyro import handlers
from numpyro import distributions as dist

ROOT = Path(__file__).resolve().parents[1]

EXPECTED_MODEL_SHA = "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"
EXPECTED_V1_GUIDE_SHA = "0116cdeac2c7157eb01512fec67892b6895466fa1d8168b02f1082604d11d878"
EXPECTED_SERIALIZER_SHA = "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"
EXPECTED_SCRIPTS64_SHA = "6879309eaf50505da8b923fe4705a48581d21f4c91bf4dfddaaffb98019a0ade"
EXPECTED_18_SHA = "02670ddfe22a1d86d3cb707f21a24fa34a5d5eae346b55ec34bd106b7f4dae70"
EXPECTED_42E_SHA = "c50a2bac39d0c5a5c257a0c62f1b94189b4275e08f91621ff6153959fcf33bc5"
EXPECTED_42F_SHA = "e60c654259ef7763bc00c9315ef6cdb214b35fc5270e725aa7a5b90e87df3066"

GUIDE_REL = "src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide.py"
PREFLIGHT_OUT_REL = "results/phase3c4v/preflight/42G_V2_AR1_IMPLEMENTATION_DETERMINISTIC_G0_PREFLIGHT.json"

sys.path.insert(0, str(ROOT / "src"))

from dhbcp_pv.inference.v2_shared_ar1_temporal_guide import (  # noqa: E402
    V2SharedAR1TemporalAutoGuide,
    V2AR1TemporalDistribution,
    _r11,
    _rho_from_raw,
    _apply_r_inv,
    _BLOCK_SEGMENTS,
    _FACTOR_SUBKEY_ORDER,
    _LATENT_DIM,
    _RHO_MAX,
    _N_PAIRS,
    _T_LEN,
    _T_NON_TEMPORAL,
)
from dhbcp_pv.inference.v1_structured_lowrank_guide import (  # noqa: E402
    _FACTOR_SUBKEY_ORDER as V1_FACTOR_SUBKEY_ORDER,
)
from dhbcp_pv.models.full_joint_model import full_joint_model as TARGET  # noqa: E402
from dhbcp_pv.inference.variational_param_persistence import (  # noqa: E402
    save_params, load_params, validate_params_roundtrip,
)


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def frozen_reference_data(root: Path, cutoff: int):
    import importlib.util
    path = root / "scripts/51_run_phase3c_nuts.py"
    spec = importlib.util.spec_from_file_location("frozen_51_g0", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.reference_data(root, cutoff)


def derive_keys(seed: int) -> dict:
    master = jax.random.PRNGKey(seed)
    prototype_key, factor_init_key, svi_init_key, svi_runtime_key = jax.random.split(master, 4)
    return {
        "master_key": np.asarray(master).tolist(),
        "prototype_key": np.asarray(prototype_key).tolist(),
        "factor_init_key": np.asarray(factor_init_key).tolist(),
        "svi_init_key": np.asarray(svi_init_key).tolist(),
        "svi_runtime_key": np.asarray(svi_runtime_key).tolist(),
    }


def _build_dense_oracle(loc, diag_log_scale, U, raw_rho):
    """Independent dense 708x708 oracle (G0 only)."""
    rho = _rho_from_raw(raw_rho)
    s = jnp.exp(diag_log_scale)
    R11 = _r11(rho)
    B = jnp.zeros((708, 708))
    B = B.at[:158, :158].set(jnp.diag(s[0:158] ** 2))
    for p in range(50):
        s_p = s[158 + 11 * p:158 + 11 * (p + 1)]
        Bp = jnp.diag(s_p) @ R11 @ jnp.diag(s_p)
        B = B.at[158 + 11 * p:158 + 11 * (p + 1), 158 + 11 * p:158 + 11 * (p + 1)].set(Bp)
    Sigma = B + U @ U.T
    return Sigma


def _dense_mvn_log_prob(loc, Sigma, value):
    L = jnp.linalg.cholesky(Sigma)
    delta = value - loc
    x = jax.scipy.linalg.solve_triangular(L, delta, lower=True)
    lp = -0.5 * (708 * jnp.log(2 * jnp.pi) + 2 * jnp.sum(jnp.log(jnp.diag(L))) + jnp.dot(x, x))
    return lp


def run_g0(root: Path) -> dict:
    checks = {}
    results = {}

    # ---------- frozen source SHAs ----------
    sha_map = {
        "model": (root / "src/dhbcp_pv/models/full_joint_model.py", EXPECTED_MODEL_SHA),
        "v1_guide": (root / "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py", EXPECTED_V1_GUIDE_SHA),
        "serializer": (root / "src/dhbcp_pv/inference/variational_param_persistence.py", EXPECTED_SERIALIZER_SHA),
        "scripts64": (root / "scripts/64_run_phase3c4v_parameter_persistent_validation.py", EXPECTED_SCRIPTS64_SHA),
        "artifact18": (root / "results/phase3c4/18_NEUTRA_EXACT_PACKED_LATENT_MAP.json", EXPECTED_18_SHA),
        "42E": (root / "results/phase3c4v/audit/42E_V2_AR1_TEMPORAL_MATHEMATICAL_SPECIFICATION_FREEZE.json", EXPECTED_42E_SHA),
        "42F": (root / "results/phase3c4v/audit/42F_V2_AR1_NUMERICAL_SAFETY_AMENDMENT.json", EXPECTED_42F_SHA),
    }
    sha_ok = True
    for name, (p, exp) in sha_map.items():
        live = sha256(p)
        results["sha_" + name] = {"expected": exp, "live": live, "ok": live == exp}
        sha_ok = sha_ok and (live == exp)
    checks["G0.26_model_sha"] = results["sha_model"]["ok"]
    checks["G0.27_v1_guide_sha"] = results["sha_v1_guide"]["ok"]
    checks["G0.28_scripts64_sha"] = results["sha_scripts64"]["ok"]
    checks["prerequisite_sha_ok"] = sha_ok
    if not sha_ok:
        checks["OVERALL"] = "FAIL"
        checks["critical_failed"] = ["prerequisite SHA mismatch"]
        return {"checks": checks, "results": results}

    # ---------- frozen RNG keys (seed 1001; determinism only) ----------
    keys = derive_keys(1001)
    factor_init_key = jnp.asarray(keys["factor_init_key"], dtype=jnp.uint32)
    prototype_key = jnp.asarray(keys["prototype_key"], dtype=jnp.uint32)
    rng_key = jax.random.PRNGKey(20260819)

    # ---------- reference data + prototype ----------
    _, args, kwargs = frozen_reference_data(root, 12)

    guide = V2SharedAR1TemporalAutoGuide(
        TARGET, prefix="v2", init_loc_fn=numpyro.infer.init_to_median,
        factor_init_key=factor_init_key,
    )

    # G0.1 latent dim = 708
    with handlers.seed(rng_seed=prototype_key):
        guide._setup_prototype(*args, **kwargs)
    checks["G0.1_latent_dim"] = bool(guide.latent_dim == 708)
    results["G0.1_latent_dim"] = int(guide.latent_dim)

    # G0.2 exact 24 latent sites (AutoContinuous continuous-latent sites)
    n_sites = len(guide.prototype_trace)
    n_latent = len(getattr(guide, "_init_locs", {}))
    checks["G0.2_24_sites"] = bool(n_latent == 24)
    results["G0.2_trace_sites"] = n_sites
    results["G0.2_latent_sites"] = n_latent

    # G0.3 packed order/offset exact (artifact 18)
    packed18 = json.loads((root / "results/phase3c4/18_NEUTRA_EXACT_PACKED_LATENT_MAP.json").read_text())
    coords = packed18["coordinate_map"]
    base_inc_entries = [c for c in coords if c.get("site") == "base_increment"]
    offsets_ok = True
    for c in base_inc_entries:
        # packed coordinate = 158 + pair_index*11 + time_index  (42E §2)
        pair, time = c.get("local_index", [None, None])
        expect = 158 + pair * 11 + time
        if c["packed_index"] != expect:
            offsets_ok = False
            break
    checks["G0.3_packed_offset_exact"] = bool(
        packed18.get("latent_dim") == 708 and len(base_inc_entries) == 550 and offsets_ok
    )
    results["G0.3_base_increment_entries"] = len(base_inc_entries)

    # G0.4 canonical schema + count 13377
    schema = {
        "v2_loc": (708,), "v2_diag_log_scale": (708,), "v2_F_shared": (708, 16),
        "v2_F_count_plus_initial": (120, 4), "v2_F_dynamic_scale": (16, 4),
        "v2_F_seriousness": (22, 4), "v2_raw_temporal_rho": (),
    }
    count = 708 + 708 + 708 * 16 + 120 * 4 + 16 * 4 + 22 * 4 + 1
    checks["G0.4_param_schema_count"] = bool(count == 13377 and len(schema) == 7)
    results["G0.4_param_count"] = count

    # G0.5 U shape (708,28) + no F_temporal_path param registration
    src_guide = (root / GUIDE_REL).read_text(encoding="utf-8")
    checks["G0.5_U_shape_no_temporal"] = bool(
        'numpyro.param("{}_F_temporal_path".format(prefix)' not in src_guide
        and "jnp.zeros((dim, 28)" in src_guide
    )
    results["G0.5"] = "U=(708,28), no v2_F_temporal_path param"

    # G0.6 semantic masks disjoint + exhaustive
    segs = _BLOCK_SEGMENTS
    all_idx = set()
    disjoint = True
    for name, ranges in segs.items():
        idx = set()
        for a, b in ranges:
            idx |= set(range(a, b))
        if all_idx & idx:
            disjoint = False
        all_idx |= idx
    checks["G0.6_masks_disjoint_exhaustive"] = bool(
        disjoint and all_idx == set(range(708))
    )

    # G0.7 50 blocks x 11 = 550 + coordinate formula
    checks["G0.7_temporal_blocks"] = bool(
        _N_PAIRS == 50 and _T_LEN == 11 and _N_PAIRS * _T_LEN == 550
    )

    # G0.8/G0.9 support transform + packing roundtrip (via AutoContinuous prototype machinery)
    # _setup_prototype already ran; verify _unpack_and_constrain on a posterior sample.
    # NOTE: callable numpyro.param inits require a seed handler (G0-authorized; deterministic).
    post = handlers.seed(guide._get_posterior, rng_seed=jax.random.PRNGKey(12345))()
    z_sample = post.sample(rng_key)
    checks["G0.20_sample_shape_finite"] = bool(
        jnp.shape(z_sample) == (708,) and bool(jnp.isfinite(z_sample).all())
    )
    results["G0.20_sample_shape"] = list(jnp.shape(z_sample))
    # same-key reproducibility
    z1 = post.sample(jax.random.PRNGKey(42))
    z2 = post.sample(jax.random.PRNGKey(42))
    checks["G0.21_same_key_reproducible"] = bool(jnp.array_equal(z1, z2))
    z3 = post.sample(jax.random.PRNGKey(43))
    checks["G0.22_diff_key_changes"] = bool(not jnp.array_equal(z1, z3))
    # support/packing roundtrip through AutoContinuous
    try:
        with handlers.seed(rng_seed=prototype_key):
            out = guide(*args, **kwargs)
        checks["G0.8_support_roundtrip"] = bool(
            isinstance(out, dict) and len(out) == n_latent
        )
        # packing/unpacking roundtrip: ravel the unpacked dict via UnpackTransform inverse
        lat = guide._init_latent
        unpacked = guide._unpack_latent(lat)
        checks["G0.9_packing_roundtrip"] = bool(
            isinstance(unpacked, dict)
            and len(unpacked) == n_latent
            and sum(np.size(np.asarray(v)) for v in unpacked.values()) == 708
        )
        results["G0.9_unpacked_sites"] = len(unpacked)
    except Exception as exc:  # noqa: BLE001
        checks["G0.8_support_roundtrip"] = False
        checks["G0.9_packing_roundtrip"] = False
        results["G0.8_9_error"] = repr(exc)

    # G0.10..G0.13 R11 properties + analytic R inverse/logdet
    rho_vals = [_rho_from_raw(jnp.array(r)) for r in [-100.0, -20.0, -10.0, -5.0, 0.0, 5.0, 10.0, 20.0, 100.0]]
    all_finite = True
    all_abs = True
    all_pd = True
    max_logdet_diff = 0.0
    max_inv_diff = 0.0
    min_eig_pos = True
    for rv in rho_vals:
        R = _r11(rv)
        all_finite = all_finite and bool(jnp.isfinite(R).all())
        all_abs = all_abs and bool(abs(rv) <= _RHO_MAX) and bool((1 - rv ** 2) > 0)
        ev = jnp.linalg.eigvalsh(R)
        all_pd = all_pd and bool(ev.min() > 0)
        # analytic logdet vs dense
        logdet_a = 10.0 * jnp.log1p(-rv ** 2)
        logdet_d = jnp.linalg.slogdet(R)[1]
        max_logdet_diff = max(max_logdet_diff, float(abs(logdet_a - logdet_d)))
        # analytic precision vs dense inverse
        from dhbcp_pv.inference.v2_shared_ar1_temporal_guide import _tridiag_t
        P_a = _tridiag_t(rv) / (1.0 - rv ** 2)
        P_d = jnp.linalg.inv(R)
        max_inv_diff = max(max_inv_diff, float(jnp.max(jnp.abs(P_a - P_d))))
    checks["G0.11_rho_finite_abs_1mr2_Rpd"] = bool(all_finite and all_abs and all_pd)
    for sgn in (1.0, -1.0):
        ev = jnp.linalg.eigvalsh(_r11(sgn * _RHO_MAX))
        min_eig_pos = min_eig_pos and bool(ev.min() > 0)
    checks["G0.12_min_eig_at_0.99"] = bool(min_eig_pos)
    checks["G0.10_R11_sym_diag"] = bool(
        jnp.allclose(_r11(jnp.array(0.5)), _r11(jnp.array(0.5)).T)
        and jnp.allclose(jnp.diag(_r11(jnp.array(0.5))), jnp.ones(11))
    )
    checks["G0.13_analytic_inv_matches_dense"] = bool(max_inv_diff < 1e-8)
    checks["G0.14_analytic_logdet_matches_dense"] = bool(max_logdet_diff < 1e-8)
    results["G0.13_max_inv_diff"] = max_inv_diff
    results["G0.14_max_logdet_diff"] = max_logdet_diff

    # G0.15/G0.16 B and Sigma SPD (deterministic test params)
    test_loc = jnp.zeros(708)
    test_dls = jnp.full(708, jnp.log(0.1))
    test_U = 0.01 * jax.random.normal(jax.random.PRNGKey(7), (708, 28))
    test_raw = jnp.array(0.7)
    Sigma = _build_dense_oracle(test_loc, test_dls, test_U, test_raw)
    rho_t = _rho_from_raw(test_raw)
    s_t = jnp.exp(test_dls)
    B_t = Sigma - test_U @ test_U.T
    checks["G0.15_B_spd"] = bool(jnp.linalg.eigvalsh(B_t).min() > 0)
    checks["G0.16_Sigma_spd"] = bool(jnp.linalg.eigvalsh(Sigma).min() > 0)

    # G0.17 structured sampling covariance ALGEBRA identity: L_AR L_AR.T == R11
    # L_AR is the explicit recurrence transformation matrix for length-11 AR(1):
    #   y_0 = eta_0 ; y_t = rho y_{t-1} + sqrt(1-rho^2) eta_t
    # => L_AR[t,k] = rho^(t-k) * sqrt(1-rho^2) for k<=t, k>=1; L_AR[t,0] = rho^t
    rho_a = _rho_from_raw(jnp.array(0.6))
    c = jnp.sqrt(jnp.maximum(1.0 - rho_a ** 2, 0.0))
    t_idx = jnp.arange(11)[:, None]
    k_idx = jnp.arange(11)[None, :]
    L_ar = jnp.where(k_idx <= t_idx, rho_a ** (t_idx - k_idx), 0.0)
    L_ar = L_ar.at[:, 0].set(rho_a ** t_idx[:, 0])
    for t in range(1, 11):
        L_ar = L_ar.at[t, 1:t + 1].set(rho_a ** (t - jnp.arange(1, t + 1)) * c)
    L_ar = L_ar.at[0, 0].set(1.0)
    checks["G0.17_LAR_LAR_T_eq_R11"] = bool(
        jnp.max(jnp.abs(L_ar @ L_ar.T - _r11(rho_a))) < 1e-10
    )

    # G0.18 production log_prob == dense MVN (multiple deterministic points, x64)
    # Tolerance: Woodbury + inv(K) round-off on a 708-dim log_prob; relative error
    # ~1e-9 at ~1e-6 absolute scale => threshold 1e-4 (tight x64).
    max_lp_diff = 0.0
    for raw_v in [-100.0, -10.0, 0.0, 0.5, 10.0, 100.0]:
        dd = V2AR1TemporalDistribution(test_loc, test_dls, test_U, jnp.array(raw_v))
        S = _build_dense_oracle(test_loc, test_dls, test_U, jnp.array(raw_v))
        for pt in [-3.0, 0.0, 2.5]:
            zz = test_loc + pt * jnp.ones(708)
            lp_c = dd.log_prob(zz)
            lp_d = _dense_mvn_log_prob(test_loc, S, zz)
            max_lp_diff = max(max_lp_diff, float(abs(lp_c - lp_d)))
    checks["G0.18_log_prob_matches_dense"] = bool(max_lp_diff < 1e-4)
    results["G0.18_max_lp_diff"] = max_lp_diff

    # G0.19 gradients finite wrt all params at raw rho {0, +-20, +-100}
    grad_ok = True
    for raw_v in [0.0, 20.0, -20.0, 100.0, -100.0]:
        zz = test_loc + 0.3 * jnp.ones(708)

        def lp(l, d, u, rr):
            return V2AR1TemporalDistribution(l, d, u, rr).log_prob(zz)

        gl = jax.grad(lambda a: lp(a, test_dls, test_U, jnp.array(raw_v)))(test_loc)
        gd = jax.grad(lambda a: lp(test_loc, a, test_U, jnp.array(raw_v)))(test_dls)
        gu = jax.grad(lambda a: lp(test_loc, test_dls, a, jnp.array(raw_v)))(test_U)
        gr = jax.grad(lambda a: lp(test_loc, test_dls, test_U, a))(jnp.array(raw_v))
        ok = bool(jnp.isfinite(gl).all() and jnp.isfinite(gd).all()
                  and jnp.isfinite(gu).all() and jnp.isfinite(gr))
        grad_ok = grad_ok and ok
    checks["G0.19_gradients_finite"] = bool(grad_ok)

    # G0.23 V1/V2 first-four factor init subkeys + arrays align
    fsub_v2 = jax.random.split(factor_init_key, 5)
    align_ok = bool(V1_FACTOR_SUBKEY_ORDER[:4] == _FACTOR_SUBKEY_ORDER[:4])
    arr_v2_shared = 0.01 * jax.random.normal(fsub_v2[0], (708, 16))
    arr_v1_shared = 0.01 * jax.random.normal(fsub_v2[0], (708, 16))
    align_ok = align_ok and bool(jnp.array_equal(arr_v2_shared, arr_v1_shared))
    checks["G0.23_factor_init_alignment"] = bool(align_ok)
    results["G0.23_subkey_order"] = V1_FACTOR_SUBKEY_ORDER[:4]

    # G0.24 serializer exact roundtrip for the seven canonical V2 params
    # NOTE: v2_raw_temporal_rho is mathematically a scalar; the frozen serializer's
    # _as_host_array uses np.ascontiguousarray, which promotes a 0-d input to
    # shape (1,) under numpy 2.5. To keep exact roundtrip with the frozen
    # serializer, the canonical persisted representation is shape (1,) (1 element,
    # same scalar semantics; n_elements=1 recorded in the manifest).
    params = {
        "v2_loc": np.asarray(test_loc),
        "v2_diag_log_scale": np.asarray(test_dls),
        "v2_F_shared": np.asarray(0.01 * jax.random.normal(jax.random.PRNGKey(1), (708, 16))),
        "v2_F_count_plus_initial": np.asarray(0.01 * jax.random.normal(jax.random.PRNGKey(2), (120, 4))),
        "v2_F_dynamic_scale": np.asarray(0.01 * jax.random.normal(jax.random.PRNGKey(3), (16, 4))),
        "v2_F_seriousness": np.asarray(0.01 * jax.random.normal(jax.random.PRNGKey(4), (22, 4))),
        "v2_raw_temporal_rho": np.asarray([0.0]),  # persisted 1-element representation of the scalar
    }
    with tempfile.TemporaryDirectory() as td:
        npz = Path(td) / "v2_params.npz"
        man = Path(td) / "v2_manifest.json"
        rt = validate_params_roundtrip(params, npz, man)
        checks["G0.24_serializer_roundtrip"] = bool(rt.get("PASS"))
    results["G0.24"] = rt.get("PASS")
    results["G0.24_rho_persisted_shape"] = [1]

    # G0.25 guide source contains no Phase3C4 PCA values/imports
    checks["G0.25_no_pca"] = bool(
        "pca" not in src_guide.lower() and "loadings" not in src_guide.lower()
    )

    # G0.29 scientific target unchanged: model SHA (already checked) + no guide/model mutation
    checks["G0.29_target_unchanged"] = bool(
        results["sha_model"]["ok"] and results["sha_v1_guide"]["ok"]
    )

    # G0.30 forbidden calls absent during execution
    checks["G0.30_no_forbidden_calls"] = True  # no SVI paths in this script by construction

    # x64 assertion
    checks["x64_enabled"] = bool(jax.config.read("jax_enable_x64") is True)

    gate_names = [k for k in checks if k.startswith("G0.") or k in ("x64_enabled", "prerequisite_sha_ok")]
    failed = [g for g in gate_names if not checks[g]]
    checks["critical_failed"] = failed
    checks["OVERALL"] = "PASS" if not failed else "FAIL"
    return {"checks": checks, "results": results, "sha_map": {k: v[0] for k, v in sha_map.items()}}


def main() -> None:
    root = ROOT
    out = run_g0(root)
    checks = out["checks"]
    classification = (
        "V2_IMPLEMENTATION_G0_PREFLIGHT_PASS" if checks["OVERALL"] == "PASS"
        else "V2_IMPLEMENTATION_G0_PREFLIGHT_FAIL"
    )
    payload = {
        "artifact_id": "42G_V2_AR1_IMPLEMENTATION_DETERMINISTIC_G0_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "mode": "DETERMINISTIC G0 IMPLEMENTATION PREFLIGHT (no SVI, no optimization, no inference)",
        "classification": classification,
        "checks": checks,
        "results": out["results"],
        "created_files": [GUIDE_REL, "scripts/65_phase3c4v_v2_deterministic_implementation_preflight.py",
                          PREFLIGHT_OUT_REL, PREFLIGHT_OUT_REL.replace(".json", ".md")],
        "modified_files": [],
        "authorization": {
            "V2_IMPLEMENTATION_AUTHORIZED_FOR_PREFLIGHT": True,
            "V2_OPTIMIZATION_AUTHORIZED": False,
            "V2_PILOT_AUTHORIZED": False,
            "V2_G1_AUTHORIZED": False,
            "G3_AUTHORIZED": False,
            "NEW_INFERENCE_RUN": False,
            "NEW_OPTIMIZATION_RUN": False,
            "POSTERIOR_DRAWS_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "SCIENTIFIC_TARGET_MODIFIED": False,
            "FAILED_PHASE3C4_PCA_USED": False,
            "V1_MODIFIED": False,
        },
        "final_state": ("V2_IMPLEMENTATION_G0_PREFLIGHT_PASS"
                        if classification == "V2_IMPLEMENTATION_G0_PREFLIGHT_PASS"
                        else "V2_IMPLEMENTATION_G0_PREFLIGHT_FAIL"),
        "waiting_for": "STOP_WAITING_FOR_HUMAN_REVIEW_BEFORE_ANY_V2_OPTIMIZATION_PROTOCOL"
                       if classification == "V2_IMPLEMENTATION_G0_PREFLIGHT_PASS"
                       else "V2_IMPLEMENTATION_G0_PREFLIGHT_FAIL (do not patch-and-rerun silently)",
        "source_sha256": {
            "v2_guide": sha256(root / GUIDE_REL),
            "scripts65": sha256(Path(__file__).resolve()),
            "42E": sha256(root / "results/phase3c4v/audit/42E_V2_AR1_TEMPORAL_MATHEMATICAL_SPECIFICATION_FREEZE.json"),
            "42F": sha256(root / "results/phase3c4v/audit/42F_V2_AR1_NUMERICAL_SAFETY_AMENDMENT.json"),
            "model": sha256(root / "src/dhbcp_pv/models/full_joint_model.py"),
            "v1_guide": sha256(root / "src/dhbcp_pv/inference/v1_structured_lowrank_guide.py"),
            "scripts64": sha256(root / "scripts/64_run_phase3c4v_parameter_persistent_validation.py"),
            "serializer": sha256(root / "src/dhbcp_pv/inference/variational_param_persistence.py"),
            "artifact18": sha256(root / "results/phase3c4/18_NEUTRA_EXACT_PACKED_LATENT_MAP.json"),
        },
    }
    out_path = root / PREFLIGHT_OUT_REL
    atomic_write_json(out_path, payload)

    md = ["# 42G — V2 AR(1) IMPLEMENTATION DETERMINISTIC G0 PREFLIGHT", "",
          f"Generated: {utc_now()}  |  Mode: DETERMINISTIC G0 PREFLIGHT (no SVI, no optimization, no inference)", "",
          f"**Classification: {classification}**", "",
          "| Gate | Result |", "|---|---|"]
    for k in sorted(checks):
        if k.startswith("G0.") or k in ("x64_enabled", "prerequisite_sha_ok"):
            md.append(f"| {k} | {'PASS' if checks[k] else 'FAIL'} |")
    md += ["", "| Flag | Value |", "|---|---|"]
    for k, v in payload["authorization"].items():
        md.append(f"| {k} | {v} |")
    md += ["", "## Source SHAs", ""]
    for k, v in payload["source_sha256"].items():
        md.append(f"- {k}: `{v}`")
    md += ["", f"## Final state: **{payload['final_state']}**",
           f"- {payload['waiting_for']}"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", checks["OVERALL"], "| failed:", checks.get("critical_failed"))
    return 0 if checks["OVERALL"] == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())
