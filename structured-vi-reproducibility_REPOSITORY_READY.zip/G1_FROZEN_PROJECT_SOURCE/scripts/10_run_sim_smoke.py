from __future__ import annotations
import json
from pathlib import Path
from dhbcp_pv.sim.generator import SimConfig, simulate_panel

def main():
    root = Path(__file__).resolve().parents[1]
    out = root/"results/smoke"
    out.mkdir(parents=True, exist_ok=True)
    cfg = SimConfig()
    df = simulate_panel(cfg)
    df.to_csv(out/"simulated_pair_quarters.csv", index=False)
    summary = {
        "engineering_only": True,
        "n_rows": int(len(df)),
        "n_pairs": int(df.pair_id.nunique()),
        "n_quarters": int(df.quarter_index.nunique()),
        "total_reports": int(df.y_reports.sum()),
        "total_serious": int(df.s_serious.sum()),
        "state_counts": {str(k): int(v) for k,v in df.state.value_counts().to_dict().items()},
        "seed": cfg.seed,
    }
    (out/"smoke_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
