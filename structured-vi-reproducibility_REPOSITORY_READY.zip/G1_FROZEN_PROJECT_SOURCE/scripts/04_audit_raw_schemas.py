from __future__ import annotations
import json
from pathlib import Path
from dhbcp_pv.data import faers, canada

def main():
    root = Path(__file__).resolve().parents[1]
    out = {"faers": {}, "canada": None}
    for qdir in sorted((root/"data/raw/faers").glob("faers_ascii_*q*")):
        if qdir.is_dir():
            out["faers"][qdir.name] = faers.audit_headers(qdir)

    cdir = root/"data/raw/canada/extract"
    if cdir.exists():
        out["canada"] = canada.audit_headers(cdir)

    path = root/"data/manifests/schema_audit.json"
    path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(path)

if __name__ == "__main__":
    main()
