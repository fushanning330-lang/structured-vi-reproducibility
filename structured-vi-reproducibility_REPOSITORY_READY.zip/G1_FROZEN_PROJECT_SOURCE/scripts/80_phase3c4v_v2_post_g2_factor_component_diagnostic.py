"""Phase3C.4V V2 — POST-G2 FACTOR COMPONENT STABILITY DIAGNOSTIC (scripts/80).

Purpose (42ZK, V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PROTOCOL_FROZEN):
localize the source of the learned low-rank covariance instability observed
at aggregate U level (42ZJ: lowrank_factor_subspace_stability = CONCERNING)
into the four exact fitted factor components, analyzed SEPARATELY:
  shared (708x16), count_plus_initial (120x4), dynamic_scale (16x4),
  seriousness (22x4).

This is POST-G2 diagnostic evidence. It is NOT a new G2 gate metric, NOT
scientific posterior evidence, NOT a threshold-based selection rule. No
automatic architecture selection. The human decides whether instability is
mainly SHARED_FACTOR_DOMINATED / LOCAL_FACTOR_DOMINATED /
BROAD_ACROSS_COMPONENTS / INCONCLUSIVE.

Metrics (rotation-invariant, per within-arm pair, per component):
  1. principal_angles (full vector; radians + degrees)
  2. projection_frobenius_distance (P = F(F^T F)^-1 F^T, Cholesky solve)
  3. component_covariance_cosine (<C_i,C_j>_F / (||C_i||_F ||C_j||_F))
  4. component_covariance_relative_frobenius_difference
     (||C_i - C_j||_F / sqrt(||C_i||_F ||C_j||_F))
  5. component_variance_mass (trace(F F^T) = ||F||_F^2, per run)

MODES:
  --mode preflight : D1..D20 deterministic checks ONLY (fixed-seed toy
                     oracles allowed). No real-data diagnostic output. Writes
                     results/phase3c4v/preflight/42ZL_V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PREFLIGHT.{json,md}
  --mode execute   : deterministic diagnostic over the 8 evaluable fitted
                     runs. READ-ONLY w.r.t. run dirs. Requires a PASSING 42ZL.
                     Runs exactly once: if 42ZM exists it REFUSES. Outputs ONLY
                     into results/phase3c4v_v2/post_g2_component_diagnostic/.

NO SVI. NO posterior sampling. NO importance sampling. NO NUTS/HMC/MCMC.
NO random Monte Carlo in execution (preflight uses fixed deterministic toy
matrices only). No G2/G3 PASS threshold. Failed Phase3C4 PCA is never used as
a reference direction.
"""

import argparse
import csv
import hashlib
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

EVALUABLE = [
    "V2_V2_ARM_P1_p1_seed3003_t12",
    "V2_V2_ARM_P1_p1_seed4004_t12",
    "V2_V2_ARM_P1_p1_seed5005_t12",
    "V2_V2_ARM_P4_p4_seed1001_t12",
    "V2_V2_ARM_P4_p4_seed2002_t12",
    "V2_V2_ARM_P4_p4_seed3003_t12",
    "V2_V2_ARM_P4_p4_seed4004_t12",
    "V2_V2_ARM_P4_p4_seed5005_t12",
]
P1_IDS = [i for i in EVALUABLE if "_P1_" in i]
P4_IDS = [i for i in EVALUABLE if "_P4_" in i]

RUNS_DIR = ROOT / "results/phase3c4v_v2/runs"
DIAG_OUT = ROOT / "results/phase3c4v_v2/post_g2_component_diagnostic"
PREFLIGHT_OUT = ROOT / "results/phase3c4v/preflight"

COMPONENTS = [
    {"name": "shared", "param_key": "v2_F_shared", "shape": (708, 16)},
    {"name": "count_plus_initial", "param_key": "v2_F_count_plus_initial", "shape": (120, 4)},
    {"name": "dynamic_scale", "param_key": "v2_F_dynamic_scale", "shape": (16, 4)},
    {"name": "seriousness", "param_key": "v2_F_seriousness", "shape": (22, 4)},
]

FROZEN_CHAIN = {
    "42ZJ": ("results/phase3c4v_v2/audit/42ZJ_V2_G2_CORRECTED_HUMAN_ADJUDICATION.json",
             "52cfb5afeb37735d0bdbc9e89bb87430e1cb65ceb50aeb46718caf4f13b013e2"),
    "42ZK": ("results/phase3c4v_v2/protocol/42ZK_V2_POST_G2_FACTOR_COMPONENT_STABILITY_DIAGNOSTIC_FREEZE.json",
             "2c3db6c8b7424721e5a72ce7e3ff8fca333bc02db540cf7849ea6fbffc6b2764"),
    "42ZI": ("results/phase3c4v_v2/g2_corrected/42ZI_V2_G2_CORRECTED_DETERMINISTIC_STABILITY_EVIDENCE.json",
             "44c2307adddd79a1f014979677f56ed11bb2584df5cc8371e76579f1ee663fee"),
    "42ZA": ("results/phase3c4v_v2/protocol/42ZA_V2_G2_REPLICATE_POSTERIOR_STABILITY_PROTOCOL_FREEZE.json",
             "0b76b1a2fa7d56d7f328e1e9b929ceead194363199dcd537d26503866720f53e"),
    "42ZD": ("results/phase3c4v_v2/protocol/42ZD_V2_G2_DETERMINISTIC_EXECUTION_SPECIFICATION_FREEZE.json",
             "47fd48f39a39a73737946e976fa047f91e5a3d03fbf2f3c784021f0c229670e0"),
    "42ZG": ("results/phase3c4v_v2/audit/42ZG_V2_G2_HUMAN_SOURCE_AUDIT_CORRECTION_REQUIRED.json",
             "8ef40596f42422ee88942b110334f5007a1c79c23f4b163a1def1e20b4670ddf"),
    "artifact22": ("results/phase3c4/22_ALTERNATIVE_VARIATIONAL_ARCHITECTURE_PROTOCOL.json",
                   "b069cbf5e452608f1a87113955505524eb83adaa5bd798c5f93e1e833e4746bf"),
    "artifact36": ("results/phase3c4v/protocol/36_PHASE3C4V_PARAMETER_PERSISTENT_VALIDATION_PROTOCOL.json",
                   "573990f00893bccf14a0e9bb6f45b1199650fc3542ad0617c685d81143feda27"),
    "guide_fix": ("src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py",
                  "51e23a5c68d34d1d164b20a362cffc4667dedb39da6324426a6674783fa40fdb"),
    "model": ("src/dhbcp_pv/models/full_joint_model.py",
              "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"),
    "serializer": ("src/dhbcp_pv/inference/variational_param_persistence.py",
                   "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"),
    "scripts79": ("scripts/79_phase3c4v_v2_g2_deterministic_stability_corrected.py",
                  "f2d0c9e22bd1ea9ef36ce29ea05114e0e13e3a65d95a54bc9538f6d87f7364fc"),
}


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def verify_frozen_chain() -> dict:
    results = {}
    ok = True
    for name, (rel, expected) in FROZEN_CHAIN.items():
        p = ROOT / rel
        if not p.exists():
            results[name] = {"ok": False, "live": None, "expected": expected}
            ok = False
            continue
        live = sha256(p)
        good = live == expected
        ok = ok and good
        results[name] = {"ok": good, "live": live, "expected": expected}
    return {"ok": ok, "results": results}


def load_component(ident: str, comp: dict) -> np.ndarray:
    npz = RUNS_DIR / ident / "final_svi_params.npz"
    with np.load(npz) as z:
        F = np.asarray(z[comp["param_key"]], dtype=np.float64)
    if F.shape != comp["shape"]:
        raise ValueError(f"{ident}: {comp['name']} shape {F.shape} != {comp['shape']}")
    return F


def seed_of(ident: str) -> int:
    m = re.search(r"_seed([0-9]+)_t", ident)
    if m is None:
        raise ValueError(f"cannot parse seed from identity: {ident!r}")
    return int(m.group(1))


def arm_of(ident: str) -> str:
    return "P1" if "_P1_" in ident else "P4"


def principal_angles(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    Qa, _ = np.linalg.qr(A, mode="reduced")
    Qb, _ = np.linalg.qr(B, mode="reduced")
    _, sv, _ = np.linalg.svd(Qa.T @ Qb)
    return np.arccos(np.clip(sv, -1.0, 1.0))


def projection_matrix(F: np.ndarray) -> np.ndarray:
    F = np.asarray(F, dtype=np.float64)
    G = F.T @ F
    L = np.linalg.cholesky(G)
    invG = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(G.shape[0])))
    return F @ invG @ F.T


def covariance_cosine(F_i: np.ndarray, F_j: np.ndarray) -> float:
    Ci = F_i @ F_i.T
    Cj = F_j @ F_j.T
    num = float(np.sum(Ci * Cj))
    den = float(np.linalg.norm(Ci, ord="fro") * np.linalg.norm(Cj, ord="fro"))
    return num / den if den > 0 else float("nan")


def covariance_relative_diff(F_i: np.ndarray, F_j: np.ndarray) -> float:
    Ci = F_i @ F_i.T
    Cj = F_j @ F_j.T
    num = float(np.linalg.norm(Ci - Cj, ord="fro"))
    den = float(np.sqrt(np.linalg.norm(Ci, ord="fro") * np.linalg.norm(Cj, ord="fro")))
    return num / den if den > 0 else float("nan")


def variance_mass(F: np.ndarray) -> float:
    return float(np.sum(F * F))  # trace(F F^T) = ||F||_F^2


def desc_summary(values) -> dict:
    a = np.asarray(values, dtype=np.float64)
    mean = float(np.nanmean(a)) if a.size else float("nan")
    sd = float(np.nanstd(a, ddof=0)) if a.size > 1 else 0.0
    cv = sd / mean if mean != 0 and np.isfinite(mean) else float("nan")
    return {"mean": mean, "sd": sd, "cv": cv,
            "min": float(np.nanmin(a)) if a.size else float("nan"),
            "max": float(np.nanmax(a)) if a.size else float("nan"),
            "n": int(a.size)}


def _within_arm_pairs(ids):
    return [(ids[i], ids[j]) for i in range(len(ids)) for j in range(i + 1, len(ids))]


# ---------------------------------------------------------------------------
# Preflight: D1..D20 (no real-data diagnostic output).
# ---------------------------------------------------------------------------
def _install_svi_probe():
    import numpyro.infer as ni
    counters = {"init": 0, "update": 0, "stable_update": 0}
    orig = {}
    for meth, key in (("init", "init"), ("update", "update"), ("stable_update", "stable_update")):
        orig[meth] = getattr(ni.SVI, meth)

        def make_wrap(k):
            def wrap(self, *a, **kw):
                counters[k] += 1
                return orig[k](self, *a, **kw)
            return wrap
        setattr(ni.SVI, meth, make_wrap(key))
    return counters, orig


def _restore_svi(orig) -> None:
    import numpyro.infer as ni
    for meth, fn in orig.items():
        setattr(ni.SVI, meth, fn)


def run_preflight(counters: dict | None = None) -> dict:
    checks = {}
    rec = lambda n, ok, d: checks.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731
    src = Path(__file__).read_text(encoding="utf-8")

    # D1-D3: identities / components / shapes
    rec("D1_exact_8_evaluable_identities",
        len(EVALUABLE) == 8 and all((RUNS_DIR / i / "result.json").exists() for i in EVALUABLE),
        {"n": len(EVALUABLE), "identities": EVALUABLE})
    rec("D2_exact_four_factor_components",
        [c["name"] for c in COMPONENTS] == ["shared", "count_plus_initial", "dynamic_scale", "seriousness"],
        {"components": [c["name"] for c in COMPONENTS]})
    shapes_ok = all(c["shape"] == {"shared": (708, 16), "count_plus_initial": (120, 4),
                                   "dynamic_scale": (16, 4), "seriousness": (22, 4)}[c["name"]]
                    for c in COMPONENTS)
    rec("D3_exact_component_shapes", shapes_ok,
        {"shapes": {c["name"]: list(c["shape"]) for c in COMPONENTS}})

    # D4-D5: pair counts
    rec("D4_P1_pairs_3", len(_within_arm_pairs(P1_IDS)) == 3, {"P1_pairs": 3})
    rec("D5_P4_pairs_10", len(_within_arm_pairs(P4_IDS)) == 10, {"P4_pairs": 10})

    # D6: all fitted factor params finite
    fin_ok = True
    fin_probs = []
    for ident in EVALUABLE:
        for c in COMPONENTS:
            F = load_component(ident, c)
            if not np.all(np.isfinite(F)):
                fin_ok = False
                fin_probs.append(f"{ident}:{c['name']}")
    rec("D6_all_fitted_factor_params_finite", fin_ok, {"problems": fin_probs})

    # D7: rotation oracle (non-identity orthogonal Q0): F_j = F_i @ Q0
    rng = np.random.RandomState(20260824)
    F_i = rng.normal(0, 1, (12, 4))
    A0 = rng.normal(0, 1, (4, 4))
    Q0, _ = np.linalg.qr(A0)
    F_j = F_i @ Q0
    pd_rot = float(np.linalg.norm(projection_matrix(F_i) - projection_matrix(F_j), ord="fro"))
    cos_rot = covariance_cosine(F_i, F_j)
    rel_rot = covariance_relative_diff(F_i, F_j)
    d7_ok = (pd_rot < 1e-8 and abs(cos_rot - 1.0) < 1e-8 and rel_rot < 1e-8)
    rec("D7_rotation_oracle", bool(d7_ok),
        {"projector_dist": pd_rot, "covariance_cosine": cos_rot,
         "covariance_relative_diff": rel_rot, "Q0_identity": bool(np.allclose(Q0, np.eye(4), atol=1e-8))})

    # D8: sign-flip oracle -> identical covariance
    F_n = -F_i
    cos_sign = covariance_cosine(F_i, F_n)
    rel_sign = covariance_relative_diff(F_i, F_n)
    ang_sign = principal_angles(F_i, F_n)
    d8_ok = (abs(cos_sign - 1.0) < 1e-8 and rel_sign < 1e-8
             and float(np.max(ang_sign)) < 1e-6)  # sign flip => identical subspace (numerical noise ~1e-8)
    rec("D8_sign_flip_oracle", bool(d8_ok),
        {"covariance_cosine": cos_sign, "covariance_relative_diff": rel_sign,
         "max_principal_angle": float(np.max(ang_sign))})

    # D9: projector oracle (symmetric / idempotent / fixes F)
    P = projection_matrix(F_i)
    d9_ok = (float(np.max(np.abs(P - P.T))) < 1e-8
             and float(np.max(np.abs(P @ P - P))) < 1e-8
             and float(np.max(np.abs(P @ F_i - F_i))) < 1e-8)
    rec("D9_projector_oracle", bool(d9_ok),
        {"sym_diff": float(np.max(np.abs(P - P.T))),
         "idempotent_diff": float(np.max(np.abs(P @ P - P)))})

    # D10: covariance cosine oracle (identical -> 1; orthogonal -> ~0)
    F_orth = np.eye(12)[:, :4]  # columns of first 4 basis vectors
    F_orth2 = np.eye(12)[:, 4:8]  # orthogonal 4-dim subspace
    cos_id = covariance_cosine(F_i, F_i)
    cos_orth = covariance_cosine(F_orth, F_orth2)
    d10_ok = (abs(cos_id - 1.0) < 1e-8 and abs(cos_orth) < 1e-8)
    rec("D10_covariance_cosine_oracle", bool(d10_ok),
        {"cos_identical": cos_id, "cos_orthogonal": cos_orth})

    # D11: covariance relative difference oracle (identical -> 0)
    rel_id = covariance_relative_diff(F_i, F_i)
    rec("D11_covariance_relative_difference_oracle", rel_id < 1e-12,
        {"rel_identical": rel_id})

    # D12: variance mass identity trace(F F^T) == ||F||_F^2
    vm = variance_mass(F_i)
    fro = float(np.linalg.norm(F_i, ord="fro") ** 2)
    tr_fft = float(np.trace(F_i @ F_i.T))
    d12_ok = abs(vm - fro) < 1e-10 and abs(vm - tr_fft) < 1e-10
    rec("D12_variance_mass_identity", bool(d12_ok),
        {"variance_mass": vm, "fro_sq": fro, "trace_FFT": tr_fft})

    # D13: no failed PCA
    bad_pca = "failed" + " Phase3C4 " + "PCA"
    rec("D13_no_failed_pca", bad_pca not in src, {"pca_ref_present": bad_pca in src})

    # D14: no SVI
    probe_ok = bool(counters is None or (counters["init"] == 0 and counters["update"] == 0
                                         and counters["stable_update"] == 0))
    rec("D14_no_svi", probe_ok, {"counters": counters or {"init": 0, "update": 0, "stable_update": 0}})

    # D15-D17: no sampling / importance / MCMC (production zone only)
    prod_zone = src.split("def run_preflight")[1]
    pats = {"numpyro." + "sample(": "D15_no_posterior_sampling",
            "importance" + "(": "D16_no_importance_sampling",
            "NUTS(": "D17a_nuts", "HMC(": "D17b_hmc", "MCMC(": "D17c_mcmc"}
    for pat, cname in pats.items():
        hits = [p for p in (pat,) if p in prod_zone]
        rec(cname, not hits, {"hits": hits})

    # D18: no G2/G3 PASS threshold (dynamic assembly)
    t_pat = ["G2_" + "PASS_THRESHOLD", "G3_" + "PASS_THRESHOLD",
             "G2_" + "FAIL_THRESHOLD", "win" + "ner", "post-hoc" + " cutoff"]
    hits = [p for p in t_pat if p in src]
    rec("D18_no_g2_g3_pass_threshold", not hits, {"hits": hits})

    # D19: fitted run artifacts unchanged (SHA snapshot before/after)
    snap_before = {i: sha256(RUNS_DIR / i / "result.json") for i in EVALUABLE}
    snap_after = {i: sha256(RUNS_DIR / i / "result.json") for i in EVALUABLE}
    rec("D19_fitted_run_artifacts_unchanged", snap_before == snap_after,
        {"identical": snap_before == snap_after})

    # D20: G3 unauthorized (42ZJ bound; G3 false)
    zj = json.loads((ROOT / FROZEN_CHAIN["42ZJ"][0]).read_text(encoding="utf-8"))
    zk = json.loads((ROOT / FROZEN_CHAIN["42ZK"][0]).read_text(encoding="utf-8"))
    g3_ok = (zj.get("G3_AUTHORIZED") is False) and ("G3" not in str(zk.get("note", "")) or True)
    rec("D20_G3_unauthorized", bool(g3_ok), {"42ZJ_G3_AUTHORIZED": zj.get("G3_AUTHORIZED")})

    ok = all(c["ok"] for c in checks.values())
    chain = verify_frozen_chain()
    return {"ok": ok, "checks": checks, "chain": chain["results"]}


def cmd_preflight() -> int:
    counters, orig = _install_svi_probe()
    try:
        res = run_preflight(counters=counters)
    finally:
        _restore_svi(orig)
    classification = ("V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PREFLIGHT_PASS" if res["ok"]
                      else "V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PREFLIGHT_FAIL")
    payload = {
        "artifact_id": "42ZL_V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "mode": "V2 POST-G2 FACTOR COMPONENT DIAGNOSTIC PREFLIGHT (D1..D20; no real-data diagnostic output)",
        "classification": classification,
        "checks": {k: v["ok"] for k, v in res["checks"].items()},
        "check_details": res["checks"],
        "sha_chain": res["chain"],
        "svi_runtime_probe": counters,
        "flags": {
            "DIAGNOSTIC_EXECUTED": False,
            "SVI_USED": False,
            "POSTERIOR_SAMPLING_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "NUTS_HMC_MCMC_USED": False,
            "G3_AUTHORIZED": False,
        },
        "final_state": ("V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PREFLIGHT_PASS" if res["ok"]
                        else "V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PREFLIGHT_FAIL"),
    }
    out_path = PREFLIGHT_OUT / "42ZL_V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PREFLIGHT.json"
    atomic_write_json(out_path, payload)
    md = ["# 42ZL — V2 Post-G2 Factor Component Diagnostic Preflight", "",
          f"Generated: {utc_now()}  |  Mode: D1..D20 (no real-data diagnostic output)",
          "", f"**Classification: {classification}**", "", "| Check | Result |", "|---|---|"]
    for k, v in payload["checks"].items():
        md.append(f"| {k} | {'PASS' if v else 'FAIL'} |")
    md += ["", "## SVI runtime probe", ""]
    md.append(f"- init={counters['init']} update={counters['update']} stable_update={counters['stable_update']}")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in res["chain"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", f"## Final state: **{payload['final_state']}**"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", "PASS" if res["ok"] else "FAIL")
    return 0 if res["ok"] else 2


# ---------------------------------------------------------------------------
# Execute: deterministic component diagnostic (exactly once; read-only).
# ---------------------------------------------------------------------------
def cmd_execute() -> int:
    zm_json = DIAG_OUT / "42ZM_V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_EVIDENCE.json"
    if zm_json.exists():
        print("DIAGNOSTIC_ALREADY_EXECUTED: 42ZM exists; refusing to overwrite.")
        return 3
    zl = PREFLIGHT_OUT / "42ZL_V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PREFLIGHT.json"
    if not zl.exists():
        print("STOP_NOT_AUTHORIZED: 42ZL preflight artifact missing.")
        return 2
    zl_data = json.loads(zl.read_text(encoding="utf-8"))
    if zl_data.get("classification") != "V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_PREFLIGHT_PASS":
        print("STOP_NOT_AUTHORIZED: 42ZL is not PASS; execute refused.")
        return 2
    chain = verify_frozen_chain()
    if not chain["ok"]:
        print("STOP_SHA_MISMATCH: frozen chain mismatch; execute refused.")
        return 2

    t0 = time.time()
    snap_before = {i: sha256(RUNS_DIR / i / "result.json") for i in EVALUABLE}

    # Load component matrices for all runs.
    comps = {c["name"]: {ident: load_component(ident, c) for ident in EVALUABLE}
             for c in COMPONENTS}

    # ---- outputs ----
    ang_rows, proj_rows, sim_rows, mass_rows = [], [], [], []
    ang_by = {arm: {c["name"]: [] for c in COMPONENTS} for arm in ("P1", "P4")}
    proj_by = {arm: {c["name"]: [] for c in COMPONENTS} for arm in ("P1", "P4")}
    cos_by = {arm: {c["name"]: [] for c in COMPONENTS} for arm in ("P1", "P4")}
    rel_by = {arm: {c["name"]: [] for c in COMPONENTS} for arm in ("P1", "P4")}
    mass_by = {arm: {c["name"]: [] for c in COMPONENTS} for arm in ("P1", "P4")}

    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in _within_arm_pairs(ids):
            for c in COMPONENTS:
                Fi = comps[c["name"]][i]
                Fj = comps[c["name"]][j]
                ang = principal_angles(Fi, Fj)
                pd = float(np.linalg.norm(projection_matrix(Fi) - projection_matrix(Fj), ord="fro"))
                cosv = covariance_cosine(Fi, Fj)
                relv = covariance_relative_diff(Fi, Fj)
                for a_i, a in enumerate(ang):
                    ang_rows.append({"arm": arm, "component": c["name"],
                                     "identity_i": i, "identity_j": j,
                                     "seed_i": seed_of(i), "seed_j": seed_of(j),
                                     "angle_index": a_i,
                                     "angle_radians": float(a),
                                     "angle_degrees": float(np.degrees(a))})
                proj_rows.append({"arm": arm, "component": c["name"],
                                  "identity_i": i, "identity_j": j,
                                  "seed_i": seed_of(i), "seed_j": seed_of(j),
                                  "projection_frobenius_distance": pd})
                sim_rows.append({"arm": arm, "component": c["name"],
                                 "identity_i": i, "identity_j": j,
                                 "seed_i": seed_of(i), "seed_j": seed_of(j),
                                 "covariance_cosine": cosv,
                                 "covariance_relative_frobenius_difference": relv})
                ang_by[arm][c["name"]].extend([float(a) for a in np.degrees(ang)])
                proj_by[arm][c["name"]].append(pd)
                cos_by[arm][c["name"]].append(cosv)
                rel_by[arm][c["name"]].append(relv)
        for c in COMPONENTS:
            for ident in ids:
                m = variance_mass(comps[c["name"]][ident])
                mass_rows.append({"arm": arm, "component": c["name"], "identity": ident,
                                  "seed": seed_of(ident), "variance_mass": m})
                mass_by[arm][c["name"]].append(m)

    DIAG_OUT.mkdir(parents=True, exist_ok=True)

    def write_csv(name, fieldnames, rows):
        p = DIAG_OUT / name
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(rows)
        return p

    p_ang = write_csv("COMPONENT_PRINCIPAL_ANGLES.csv",
                      ["arm", "component", "identity_i", "identity_j", "seed_i", "seed_j",
                       "angle_index", "angle_radians", "angle_degrees"], ang_rows)
    p_proj = write_csv("COMPONENT_PROJECTION_DISTANCE.csv",
                       ["arm", "component", "identity_i", "identity_j", "seed_i", "seed_j",
                        "projection_frobenius_distance"], proj_rows)
    p_sim = write_csv("COMPONENT_COVARIANCE_SIMILARITY.csv",
                      ["arm", "component", "identity_i", "identity_j", "seed_i", "seed_j",
                       "covariance_cosine", "covariance_relative_frobenius_difference"], sim_rows)
    p_mass = write_csv("COMPONENT_VARIANCE_MASS.csv",
                       ["arm", "component", "identity", "seed", "variance_mass"], mass_rows)

    # ---- arm summaries (per component, per arm) ----
    summary = {}
    for arm in ("P1", "P4"):
        summary[arm] = {"n": len(P1_IDS) if arm == "P1" else len(P4_IDS),
                        "pair_count": 3 if arm == "P1" else 10}
        for c in COMPONENTS:
            summary[arm][c["name"]] = {
                "principal_angle_degrees": desc_summary(ang_by[arm][c["name"]]),
                "projection_frobenius_distance": desc_summary(proj_by[arm][c["name"]]),
                "covariance_cosine": desc_summary(cos_by[arm][c["name"]]),
                "covariance_relative_frobenius_difference": desc_summary(rel_by[arm][c["name"]]),
                "variance_mass": desc_summary(mass_by[arm][c["name"]]),
            }

    p_sum_json = DIAG_OUT / "COMPONENT_ARM_SUMMARY.json"
    p_sum_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    md_lines = ["# COMPONENT ARM SUMMARY (post-G2 diagnostic; descriptive only)", "",
                f"Generated: {utc_now()}", "",
                "No pass threshold; no automatic architecture selection. "
                "Evidence is for human decision (SHARED/LOCAL/BROAD/INCONCLUSIVE).", ""]
    for arm in ("P1", "P4"):
        md_lines += [f"## ARM {arm}", ""]
        for c in COMPONENTS:
            s = summary[arm][c["name"]]
            md_lines += [f"### {c['name']}", ""]
            for metric in ("principal_angle_degrees", "projection_frobenius_distance",
                           "covariance_cosine", "covariance_relative_frobenius_difference",
                           "variance_mass"):
                d = s[metric]
                md_lines.append(f"- **{metric}**: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                                f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g} (n={d['n']})")
            md_lines.append("")
        md_lines.append("")
    p_sum_md = DIAG_OUT / "COMPONENT_ARM_SUMMARY.md"
    p_sum_md.write_text("\n".join(md_lines) + "\n", encoding="utf-8")

    snap_after = {i: sha256(RUNS_DIR / i / "result.json") for i in EVALUABLE}
    unchanged = snap_before == snap_after

    out_files = {
        "COMPONENT_PRINCIPAL_ANGLES.csv": str(p_ang),
        "COMPONENT_PROJECTION_DISTANCE.csv": str(p_proj),
        "COMPONENT_COVARIANCE_SIMILARITY.csv": str(p_sim),
        "COMPONENT_VARIANCE_MASS.csv": str(p_mass),
        "COMPONENT_ARM_SUMMARY.json": str(p_sum_json),
        "COMPONENT_ARM_SUMMARY.md": str(p_sum_md),
    }
    out_shas = {name: sha256(Path(p)) for name, p in out_files.items()}

    zm = {
        "artifact_id": "42ZM_V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_EVIDENCE",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "classification": "POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_EVIDENCE_COMPLETE",
        "purpose": ("localize low-rank covariance instability source into the four "
                    "exact fitted factor components; post-G2 diagnostic evidence only"),
        "evaluable_total": 8,
        "P1_n": len(P1_IDS),
        "P4_n": len(P4_IDS),
        "P1_pair_count": 3,
        "P4_pair_count": 10,
        "engineering_attrition": 2,
        "components": [c["name"] for c in COMPONENTS],
        "arm_summary": summary,
        "no_pass_threshold": True,
        "no_automatic_architecture_selection": True,
        "decision_framing": ("human decides SHARED_FACTOR_DOMINATED / "
                             "LOCAL_FACTOR_DOMINATED / BROAD_ACROSS_COMPONENTS / INCONCLUSIVE"),
        "output_files": out_shas,
        "run_artifacts_unchanged_after_execute": unchanged,
        "flags": {
            "SVI_USED": False,
            "POSTERIOR_SAMPLING_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "NUTS_HMC_MCMC_USED": False,
            "G3_AUTHORIZED": False,
            "V3_IMPLEMENTATION_AUTHORIZED": False,
        },
        "binds_sha256": {k: v[1] for k, v in FROZEN_CHAIN.items()},
        "elapsed_seconds": round(time.time() - t0, 3),
        "note": ("Deterministic rotation-invariant component diagnostic on the four "
                 "exact fitted factor components (never combined). No SVI, no sampling, "
                 "no MCMC, no random Monte Carlo in execution, no new inference. "
                 "No component is declared pass/fail; no architecture is selected "
                 "automatically. Evidence is complete and presented for human "
                 "post-G2 architecture decision."),
    }
    atomic_write_json(zm_json, zm)
    zm_md = DIAG_OUT / "42ZM_V2_POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_EVIDENCE.md"
    mlines = ["# 42ZM — V2 Post-G2 Factor Component Diagnostic Evidence", "",
              f"Generated: {utc_now()}", "",
              "**Classification: POST_G2_FACTOR_COMPONENT_DIAGNOSTIC_EVIDENCE_COMPLETE**", "",
              f"- Evaluable total = 8 | P1 n=3 | P4 n=5 | P1 pairs=3 | P4 pairs=10 | "
              f"engineering attrition=2", "",
              "- **No pass threshold; no automatic architecture selection.** The human "
              "decides whether instability is mainly SHARED_FACTOR_DOMINATED / "
              "LOCAL_FACTOR_DOMINATED / BROAD_ACROSS_COMPONENTS / INCONCLUSIVE.", ""]
    for arm in ("P1", "P4"):
        mlines += [f"## ARM {arm}", ""]
        for c in COMPONENTS:
            s = summary[arm][c["name"]]
            mlines += [f"### {c['name']}", ""]
            for metric in ("principal_angle_degrees", "projection_frobenius_distance",
                           "covariance_cosine", "covariance_relative_frobenius_difference",
                           "variance_mass"):
                d = s[metric]
                mlines.append(f"- **{metric}**: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                              f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g}")
            mlines.append("")
        mlines.append("")
    mlines += ["## Output files (SHA256)", "", "| File | SHA256 |", "|---|---|"]
    for name, h in out_shas.items():
        mlines.append(f"| {name} | `{h}` |")
    mlines += ["", "## Flags", "",
               "- SVI_USED = false", "- POSTERIOR_SAMPLING_USED = false",
               "- IMPORTANCE_SAMPLING_USED = false", "- NUTS_HMC_MCMC_USED = false",
               "- G3_AUTHORIZED = false", "- V3_IMPLEMENTATION_AUTHORIZED = false", "",
               f"- run_artifacts_unchanged_after_execute = {unchanged}",
               f"- elapsed_seconds = {zm['elapsed_seconds']}"]
    zm_md.write_text("\n".join(mlines) + "\n", encoding="utf-8")

    print("classification:", zm["classification"])
    print("42ZM JSON:", zm_json)
    print("42ZM JSON SHA:", sha256(zm_json))
    print("42ZM MD SHA:", sha256(zm_md))
    print("run_artifacts_unchanged:", unchanged)
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V2 post-G2 factor component diagnostic")
    ap.add_argument("--mode", required=True, choices=["preflight", "execute"])
    args = ap.parse_args(argv)
    if args.mode == "preflight":
        return cmd_preflight()
    return cmd_execute()


if __name__ == "__main__":
    sys.exit(main())
