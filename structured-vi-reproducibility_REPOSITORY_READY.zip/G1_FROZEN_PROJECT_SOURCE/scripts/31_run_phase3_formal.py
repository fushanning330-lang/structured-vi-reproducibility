from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from dhbcp_pv.baselines.registry import PRIMARY_METHODS, run_all_baselines
from dhbcp_pv.evaluation.metrics import (
    discrimination_metrics,
    ranking_metrics,
    state_metrics,
    temporal_metrics,
)
from dhbcp_pv.inference.filtering import batch_operational_filter
from dhbcp_pv.sim.formal_phase3 import SCENARIOS, generate_formal_replicate


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _rows_for_metrics(replicate_id: int, scenario: str, method: str, values: dict[str, float]) -> list[dict[str, object]]:
    return [
        {"replicate_id": replicate_id, "scenario": scenario, "method": method, "metric": key, "value": value, "operational_filtering": True}
        for key, value in values.items()
    ]


def run_replicate(
    replicate_id: int,
    seed: int,
    config: dict[str, object],
    config_sha: str,
    code_sha: str,
    environment_sha: str,
) -> dict[str, object]:
    started = time.perf_counter()
    simulated = generate_formal_replicate(seed, config)
    primary = batch_operational_filter(simulated.y, simulated.serious, simulated.expected, hmax=12)
    hmax8 = batch_operational_filter(simulated.y, simulated.serious, simulated.expected, hmax=8)
    hmax16 = batch_operational_filter(simulated.y, simulated.serious, simulated.expected, hmax=16)
    method_scores = {"DHBCP_PV_V2": primary.score}
    method_alerts = {"DHBCP_PV_V2": primary.alert}
    for method in PRIMARY_METHODS:
        method_scores[method] = np.zeros_like(primary.score)
        method_alerts[method] = np.zeros_like(primary.alert)
    for pair in range(simulated.y.shape[0]):
        output = run_all_baselines(simulated.y[pair], simulated.expected[pair])
        for method, values in output.items():
            method_scores[method][pair] = values.score
            method_alerts[method][pair] = values.alert
    formal_rows: list[dict[str, object]] = []
    state_rows: list[dict[str, object]] = []
    temporal_rows: list[dict[str, object]] = []
    ranking_rows: list[dict[str, object]] = []
    sensitivity_rows: list[dict[str, object]] = []
    for scenario in SCENARIOS:
        pair_mask = simulated.scenario == scenario
        n_pairs = int(pair_mask.sum())
        pair_index = np.repeat(np.arange(n_pairs), int(config["quarters"]))
        quarter = np.tile(np.arange(1, int(config["quarters"]) + 1), n_pairs)
        truth = simulated.is_true_signal[pair_mask].reshape(-1)
        change = np.repeat(simulated.true_change_quarter[pair_mask], int(config["quarters"]))
        for method in ("DHBCP_PV_V2",) + PRIMARY_METHODS:
            score = method_scores[method][pair_mask].reshape(-1)
            alert = method_alerts[method][pair_mask].reshape(-1)
            formal_rows.extend(_rows_for_metrics(replicate_id, scenario, method, discrimination_metrics(truth, score)))
            temporal_rows.extend(_rows_for_metrics(replicate_id, scenario, method, temporal_metrics(alert, pair_index, quarter, change)))
            ranking_rows.extend(_rows_for_metrics(replicate_id, scenario, method, ranking_metrics(truth, score, alert, pair_index, quarter)))
        state_values = state_metrics(
            simulated.true_state[pair_mask].reshape(-1),
            simulated.true_log_rr[pair_mask].reshape(-1),
            primary.state_probability[pair_mask].reshape(-1, 4),
            primary.x_mean[pair_mask].reshape(-1),
            primary.x_sd[pair_mask].reshape(-1),
            primary.p_persist_h2[pair_mask].reshape(-1),
            primary.p_change[pair_mask].reshape(-1),
            pair_index,
            change,
        )
        state_rows.extend(_rows_for_metrics(replicate_id, scenario, "DHBCP_PV_V2", state_values))
        for hmax, result in ((8, hmax8), (12, primary), (16, hmax16)):
            values = discrimination_metrics(truth, result.score[pair_mask].reshape(-1))
            for metric, value in values.items():
                sensitivity_rows.append({"replicate_id": replicate_id, "scenario": scenario, "sensitivity_type": "Hmax", "parameter_value": hmax, "cost_ratio": 5, "lambda_severity": 1, "metric": metric, "value": value, "operational_filtering": True})
        state_probability = primary.state_probability[pair_mask]
        p_x_positive = 0.5 * (1.0 + np.vectorize(__import__("math").erf)(primary.x_mean[pair_mask] / np.maximum(primary.x_sd[pair_mask], 1e-10) / np.sqrt(2.0)))
        p_dangerous = (state_probability[:, :, 1] + state_probability[:, :, 2]) * p_x_positive
        for cost_ratio in (2, 5, 10):
            for severity_lambda in (0, 1, 2):
                delta = p_dangerous * cost_ratio * (1.0 + severity_lambda * primary.p_serious[pair_mask]) - (1.0 - p_dangerous)
                alert = delta > 0
                for metric, value in temporal_metrics(alert.reshape(-1), pair_index, quarter, change).items():
                    if metric in {"detected_within_2q", "prechange_false_alert"}:
                        sensitivity_rows.append({"replicate_id": replicate_id, "scenario": scenario, "sensitivity_type": "decision", "parameter_value": f"cost={cost_ratio};lambda={severity_lambda}", "cost_ratio": cost_ratio, "lambda_severity": severity_lambda, "metric": metric, "value": value, "operational_filtering": True})
    sample_input = []
    sample_output = []
    if replicate_id == 1:
        for quarter_index in range(5):
            sample_input.append({"replicate_id": 1, "scenario": str(simulated.scenario[0]), "oa_row": int(simulated.oa_row[0]), "pair_id": str(simulated.pair_id[0]), "quarter": quarter_index + 1, "y": int(simulated.y[0, quarter_index]), "s": int(simulated.serious[0, quarter_index]), "m_expected": float(simulated.expected[0, quarter_index]), "true_state": str(simulated.true_state[0, quarter_index]), "true_log_rr": float(simulated.true_log_rr[0, quarter_index]), "is_true_signal": bool(simulated.is_true_signal[0, quarter_index])})
            sample_output.append({"replicate_id": 1, "scenario": str(simulated.scenario[0]), "oa_row": int(simulated.oa_row[0]), "pair_id": str(simulated.pair_id[0]), "quarter": quarter_index + 1, "method": "DHBCP_PV_V2", "score": float(primary.score[0, quarter_index]), "alert": bool(primary.alert[0, quarter_index]), "posterior_x_mean": float(primary.x_mean[0, quarter_index]), "posterior_x_sd": float(primary.x_sd[0, quarter_index]), "p_background": float(primary.state_probability[0, quarter_index, 0]), "p_emerging": float(primary.state_probability[0, quarter_index, 1]), "p_persistent": float(primary.state_probability[0, quarter_index, 2]), "p_waning": float(primary.state_probability[0, quarter_index, 3]), "p_change": float(primary.p_change[0, quarter_index]), "p_persist_h2": float(primary.p_persist_h2[0, quarter_index]), "p_serious": float(primary.p_serious[0, quarter_index]), "delta_expected_loss": float(primary.delta_expected_loss[0, quarter_index]), "operational_filtering": True, "config_sha256": config_sha, "seed": seed})
    return {
        "replicate_id": replicate_id,
        "seed": seed,
        "config_sha256": config_sha,
        "code_tree_sha256": code_sha,
        "environment_sha256": environment_sha,
        "status": "COMPLETE",
        "wall_clock_seconds": time.perf_counter() - started,
        "formal_rows": formal_rows,
        "state_rows": state_rows,
        "temporal_rows": temporal_rows,
        "ranking_rows": ranking_rows,
        "sensitivity_rows": sensitivity_rows,
        "failure_rows": [],
        "sample_input": sample_input,
        "sample_output": sample_output,
    }


def _aggregate(result_dir: Path, checkpoints: list[dict[str, object]]) -> None:
    formal = pd.DataFrame(row for payload in checkpoints for row in payload["formal_rows"])
    state = pd.DataFrame(row for payload in checkpoints for row in payload["state_rows"])
    temporal = pd.DataFrame(row for payload in checkpoints for row in payload["temporal_rows"])
    ranking = pd.DataFrame(row for payload in checkpoints for row in payload["ranking_rows"])
    sensitivity = pd.DataFrame(row for payload in checkpoints for row in payload["sensitivity_rows"])
    summary_rows = []
    dhbcp = formal[formal.method == "DHBCP_PV_V2"][["replicate_id", "scenario", "metric", "value"]].rename(columns={"value": "dhbcp_value"})
    merged = formal.merge(dhbcp, on=["replicate_id", "scenario", "metric"], how="left")
    merged["paired_difference_dhbcp_minus_method"] = merged.dhbcp_value - merged.value
    for (scenario, method, metric), group in merged.groupby(["scenario", "method", "metric"], sort=True):
        summary_rows.append({"scenario": scenario, "method": method, "metric": metric, "mean": group.value.mean(), "median": group.value.median(), "q025": group.value.quantile(0.025), "q975": group.value.quantile(0.975), "paired_difference_mean": group.paired_difference_dhbcp_minus_method.mean(), "paired_difference_q025": group.paired_difference_dhbcp_minus_method.quantile(0.025), "paired_difference_q975": group.paired_difference_dhbcp_minus_method.quantile(0.975), "replicates": group.replicate_id.nunique(), "operational_filtering": True})
    pd.DataFrame(summary_rows).to_csv(result_dir / "48_PHASE3_FORMAL_SIMULATION_SUMMARY.csv", index=False)
    state.to_csv(result_dir / "49_PHASE3_STATE_METRICS.csv", index=False)
    temporal.to_csv(result_dir / "50_PHASE3_TEMPORAL_METRICS.csv", index=False)
    ranking.to_csv(result_dir / "51_PHASE3_RANKING_METRICS.csv", index=False)
    sensitivity.to_csv(result_dir / "52_PHASE3_SENSITIVITY_SUMMARY.csv", index=False)
    failures = pd.DataFrame(row for payload in checkpoints for row in payload["failure_rows"])
    if failures.empty:
        failures = pd.DataFrame(columns=["replicate_id", "scenario", "oa_row", "pair_id", "cutoff", "exception", "retry_count", "status"])
    failures.to_csv(result_dir / "53_PHASE3_FAILURE_LOG.csv", index=False)
    first = checkpoints[0]
    pd.DataFrame(first["sample_input"]).to_csv(result_dir / "formal_simulation_input_sample.csv", index=False)
    pd.DataFrame(first["sample_output"]).to_csv(result_dir / "posterior_filtering_output_sample.csv", index=False)
    formal.head(100).to_csv(result_dir / "replicate_level_metrics_sample.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-replicates", type=int, default=200)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    result_dir = root / "results/phase3"
    checkpoint_dir = result_dir / "checkpoints"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    freeze = json.loads((result_dir / "46_PHASE3_FORMAL_SIMULATION_FREEZE.json").read_text())
    config_path = root / "config/phase3_formal_sim_v1.yaml"
    if sha256(config_path) != freeze["formal_config_sha256"]:
        raise SystemExit("Formal configuration changed after freeze")
    seed_path = root / freeze["seed_manifest"]["path"]
    if sha256(seed_path) != freeze["seed_manifest"]["sha256"]:
        raise SystemExit("Seed manifest changed after freeze")
    config = yaml.safe_load(config_path.read_text())
    seeds = pd.read_csv(seed_path)
    expected_ids = list(range(1, min(args.max_replicates, 200) + 1))
    for replicate_id in expected_ids:
        path = checkpoint_dir / f"replicate_{replicate_id:03d}.json"
        if path.exists():
            continue
        seed = int(seeds.loc[seeds.replicate_id == replicate_id, "seed"].iloc[0])
        try:
            payload = run_replicate(replicate_id, seed, config, freeze["formal_config_sha256"], freeze["code_tree_sha256"], freeze["environment_sha256"])
        except Exception as error:
            payload = {"replicate_id": replicate_id, "seed": seed, "status": "FAILED", "exception": f"{type(error).__name__}: {error}"}
        path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        print(f"replicate {replicate_id:03d}/{expected_ids[-1]:03d}: {payload['status']}", flush=True)
    checkpoints = [json.loads((checkpoint_dir / f"replicate_{replicate_id:03d}.json").read_text()) for replicate_id in expected_ids]
    failures = [payload for payload in checkpoints if payload.get("status") != "COMPLETE"]
    if failures:
        raise SystemExit(f"{len(failures)} formal replicate checkpoints failed; rerun after deterministic fix")
    if len(expected_ids) == 200:
        _aggregate(result_dir, checkpoints)
        print("formal simulation complete: 200/200 checkpoints aggregated", flush=True)


if __name__ == "__main__":
    main()

