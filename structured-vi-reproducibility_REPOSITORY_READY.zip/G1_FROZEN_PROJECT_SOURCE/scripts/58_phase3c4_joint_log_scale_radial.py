import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path

os.environ.setdefault("JAX_ENABLE_X64", "true")

import jax.numpy as jnp
import numpy as np
import numpyro
import numpyro.distributions as dist
from jax import random
from numpyro import handlers


# ---------------------------------------------------------------------
# Frozen Phase 3C.4 constants
# ---------------------------------------------------------------------

EXPECTED_FREEZE_SHA256 = (
    "a9c46037e0543c097c473afffbeaf2e4cc685ae89d8d177139f0db814dfe9b01"
)

LAMBDA = 0.25
REFERENCE_SCALE = 0.5

EQUIVALENCE_TOL = 1e-6
RECONSTRUCTION_TOL = 1e-12


def sha256(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


def load_phase3c3_module(root: Path):
    path = (
        root /
        "scripts/57_phase3c3_background_scale_transport.py"
    )

    spec = importlib.util.spec_from_file_location(
        "phase3c3_existing",
        path,
    )

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    return module


def verify_freeze(root: Path):
    path = (
        root /
        "results/phase3c4/"
        "04_PHASE3C4_SELECTED_LAMBDA_FREEZE.json"
    )

    if not path.exists():
        raise RuntimeError(
            "Phase 3C.4 selected-lambda freeze is missing."
        )

    actual = sha256(path)

    if actual != EXPECTED_FREEZE_SHA256:
        raise RuntimeError(
            "Phase 3C.4 freeze SHA256 mismatch.\n"
            f"expected={EXPECTED_FREEZE_SHA256}\n"
            f"actual={actual}"
        )

    freeze = json.loads(
        path.read_text()
    )

    if float(freeze["selected_lambda"]) != LAMBDA:
        raise RuntimeError(
            "Frozen lambda mismatch."
        )

    return path, freeze, actual


def phase3c4_transport_model(
    y,
    serious,
    expected,
    drug_index,
    event_index,
    n_drugs,
    n_events,
    *,
    hmax,
):
    """
    Frozen Phase 3C.4 coordinate map.

    Old target coordinates:
        dynamic_sd[0:4]
        base_increment

    New primitive coordinates:
        q0, q1, q2
        dynamic_sd3
        u

    q0 = (log(sd0)+log(sd1)+log(sd2))/sqrt(3)
    q1 = (log(sd0)-log(sd1))/sqrt(2)
    q2 = (log(sd0)+log(sd1)-2log(sd2))/sqrt(6)

    g  = exp(q0/sqrt(3))
    a4 = (g/0.5)**0.25
    base_increment = a4*u

    Full constrained-coordinate Jacobian:
        sqrt(3)*q0 + M*log(a4)

    Auxiliary densities are exactly cancelled.
    """

    # --------------------------------------------------------------
    # q0/q1/q2: unconstrained real coordinates.
    # Auxiliary densities are cancelled exactly.
    # --------------------------------------------------------------

    q_aux = dist.Normal(0.0, 1.0)

    q0 = numpyro.sample(
        "phase3c4_q0",
        q_aux,
    )
    numpyro.factor(
        "phase3c4_q0_aux_cancel",
        -q_aux.log_prob(q0),
    )

    q1 = numpyro.sample(
        "phase3c4_q1",
        q_aux,
    )
    numpyro.factor(
        "phase3c4_q1_aux_cancel",
        -q_aux.log_prob(q1),
    )

    q2 = numpyro.sample(
        "phase3c4_q2",
        q_aux,
    )
    numpyro.factor(
        "phase3c4_q2_aux_cancel",
        -q_aux.log_prob(q2),
    )

    # --------------------------------------------------------------
    # dynamic_sd[3] is unchanged and therefore remains a positive
    # primitive coordinate.
    # --------------------------------------------------------------

    sd3_aux_dist = dist.LogNormal(
        0.0,
        1.0,
    )

    sd3 = numpyro.sample(
        "phase3c4_dynamic_sd3",
        sd3_aux_dist,
    )

    numpyro.factor(
        "phase3c4_dynamic_sd3_aux_cancel",
        -sd3_aux_dist.log_prob(sd3),
    )

    # --------------------------------------------------------------
    # Orthogonal inverse transform q -> log(sd0:2).
    # --------------------------------------------------------------

    sqrt2 = jnp.sqrt(
        jnp.asarray(
            2.0,
            dtype=jnp.float64,
        )
    )

    sqrt3 = jnp.sqrt(
        jnp.asarray(
            3.0,
            dtype=jnp.float64,
        )
    )

    sqrt6 = jnp.sqrt(
        jnp.asarray(
            6.0,
            dtype=jnp.float64,
        )
    )

    l0 = (
        q0 / sqrt3
        + q1 / sqrt2
        + q2 / sqrt6
    )

    l1 = (
        q0 / sqrt3
        - q1 / sqrt2
        + q2 / sqrt6
    )

    l2 = (
        q0 / sqrt3
        - 2.0 * q2 / sqrt6
    )

    sd0 = jnp.exp(l0)
    sd1 = jnp.exp(l1)
    sd2 = jnp.exp(l2)

    dynamic_sd = jnp.stack(
        [
            sd0,
            sd1,
            sd2,
            sd3,
        ]
    )

    # --------------------------------------------------------------
    # Symmetric geometric dynamic scale.
    # --------------------------------------------------------------

    g = jnp.exp(
        q0 / sqrt3
    )

    scale = (
        g /
        REFERENCE_SCALE
    ) ** LAMBDA

    # --------------------------------------------------------------
    # Radial path coordinate u.
    # --------------------------------------------------------------

    n_pairs = int(
        y.shape[0]
    )

    n_quarters = int(
        y.shape[1]
    )

    increment_shape = (
        n_pairs,
        n_quarters - 1,
    )

    u_aux_dist = (
        dist.Normal(0.0, 1.0)
        .expand(increment_shape)
        .to_event(2)
    )

    u = numpyro.sample(
        "phase3c4_u",
        u_aux_dist,
    )

    numpyro.factor(
        "phase3c4_u_aux_cancel",
        -u_aux_dist.log_prob(u),
    )

    base_increment = (
        scale *
        u
    )

    # --------------------------------------------------------------
    # Deterministic audit sites.
    # --------------------------------------------------------------

    numpyro.deterministic(
        "phase3c4_dynamic_sd",
        dynamic_sd,
    )

    numpyro.deterministic(
        "phase3c4_geometric_scale",
        g,
    )

    numpyro.deterministic(
        "phase3c4_transport_scale",
        scale,
    )

    numpyro.deterministic(
        "phase3c4_base_increment",
        base_increment,
    )

    # --------------------------------------------------------------
    # Exact full constrained-coordinate Jacobian.
    #
    # q0,q1,q2 -> sd0,sd1,sd2:
    #     log|J| = l0+l1+l2 = sqrt(3)*q0
    #
    # u -> base_increment:
    #     log|J| = M*log(scale)
    #
    # Cross-derivatives do not alter determinant because the full
    # Jacobian is block triangular.
    # --------------------------------------------------------------

    m = int(
        np.prod(
            increment_shape
        )
    )

    scale_log_jacobian = (
        sqrt3 * q0
    )

    path_log_jacobian = (
        jnp.asarray(
            m,
            dtype=jnp.float64,
        )
        * jnp.log(scale)
    )

    total_log_jacobian = (
        scale_log_jacobian
        + path_log_jacobian
    )

    numpyro.factor(
        "phase3c4_transport_jacobian",
        total_log_jacobian,
    )

    # --------------------------------------------------------------
    # Scientific model remains unchanged.
    # Only the coordinates used to represent dynamic_sd/base_increment
    # are changed.
    # --------------------------------------------------------------

    phase3c3 = _PHASE3C3

    original_with_transport = handlers.condition(
        phase3c3.full_joint_model,
        data={
            "dynamic_sd":
                dynamic_sd,
            "base_increment":
                base_increment,
        },
    )

    original_with_transport(
        y,
        serious,
        expected,
        drug_index,
        event_index,
        n_drugs,
        n_events,
        hmax=hmax,
    )


def run_equivalence(root: Path):

    _, _, freeze_sha = verify_freeze(
        root
    )

    print(
        "PHASE3C4 SELECTED-LAMBDA FREEZE VERIFICATION: PASS"
    )
    print(
        "FREEZE SHA256:",
        freeze_sha,
    )

    phase3c3 = _PHASE3C3

    seed, args, kwargs = (
        phase3c3.reference_data(
            root,
            cutoff=12,
        )
    )

    # Same lightweight panel used in Phase 3C.3.
    small_args = (
        args[0][:2, :4],
        args[1][:2, :4],
        args[2][:2, :4],
        jnp.asarray([0, 1]),
        jnp.asarray([0, 1]),
        2,
        2,
    )

    records = []

    max_density_residual = 0.0
    max_increment_error = 0.0
    max_dynamic_sd_error = 0.0
    max_log_scale_error = 0.0
    max_x_error = 0.0
    max_background_drift = 0.0

    sqrt2 = jnp.sqrt(
        jnp.asarray(
            2.0,
            dtype=jnp.float64,
        )
    )

    sqrt3 = jnp.sqrt(
        jnp.asarray(
            3.0,
            dtype=jnp.float64,
        )
    )

    sqrt6 = jnp.sqrt(
        jnp.asarray(
            6.0,
            dtype=jnp.float64,
        )
    )

    for index in range(5):

        key = random.PRNGKey(
            seed + 94000 + index
        )

        original_params = (
            phase3c3.original_latent_draw(
                key,
                small_args,
                kwargs,
            )
        )

        original_trace = (
            phase3c3.conditioned_trace(
                phase3c3.full_joint_model,
                key,
                original_params,
                small_args,
                kwargs,
            )
        )

        original_log_joint = (
            phase3c3.trace_log_joint(
                original_trace
            )
        )

        dynamic_sd = jnp.asarray(
            original_params[
                "dynamic_sd"
            ],
            dtype=jnp.float64,
        )

        original_increment = jnp.asarray(
            original_params[
                "base_increment"
            ],
            dtype=jnp.float64,
        )

        # ----------------------------------------------------------
        # Forward transform original -> Phase 3C.4 coordinates.
        # ----------------------------------------------------------

        l0 = jnp.log(
            dynamic_sd[0]
        )
        l1 = jnp.log(
            dynamic_sd[1]
        )
        l2 = jnp.log(
            dynamic_sd[2]
        )

        q0 = (
            l0 + l1 + l2
        ) / sqrt3

        q1 = (
            l0 - l1
        ) / sqrt2

        q2 = (
            l0 + l1
            - 2.0 * l2
        ) / sqrt6

        g = jnp.exp(
            q0 / sqrt3
        )

        scale = (
            g /
            REFERENCE_SCALE
        ) ** LAMBDA

        u = (
            original_increment /
            scale
        )

        transformed_params = {
            name: value
            for name, value
            in original_params.items()
            if name not in {
                "dynamic_sd",
                "base_increment",
            }
        }

        transformed_params[
            "phase3c4_q0"
        ] = q0

        transformed_params[
            "phase3c4_q1"
        ] = q1

        transformed_params[
            "phase3c4_q2"
        ] = q2

        transformed_params[
            "phase3c4_dynamic_sd3"
        ] = dynamic_sd[3]

        transformed_params[
            "phase3c4_u"
        ] = u

        transformed_trace = (
            phase3c3.conditioned_trace(
                phase3c4_transport_model,
                key,
                transformed_params,
                small_args,
                kwargs,
            )
        )

        transformed_log_joint = (
            phase3c3.trace_log_joint(
                transformed_trace
            )
        )

        # ----------------------------------------------------------
        # Reconstruction checks.
        # ----------------------------------------------------------

        reconstructed_sd = jnp.asarray(
            transformed_trace[
                "phase3c4_dynamic_sd"
            ]["value"],
            dtype=jnp.float64,
        )

        reconstructed_increment = jnp.asarray(
            transformed_trace[
                "base_increment"
            ]["value"],
            dtype=jnp.float64,
        )

        original_x = jnp.asarray(
            original_trace[
                "x"
            ]["value"],
            dtype=jnp.float64,
        )

        transformed_x = jnp.asarray(
            transformed_trace[
                "x"
            ]["value"],
            dtype=jnp.float64,
        )

        drift = jnp.asarray(
            transformed_trace[
                "drift"
            ]["value"],
            dtype=jnp.float64,
        )

        dynamic_sd_error = float(
            jnp.max(
                jnp.abs(
                    dynamic_sd
                    - reconstructed_sd
                )
            )
        )

        increment_error = float(
            jnp.max(
                jnp.abs(
                    original_increment
                    - reconstructed_increment
                )
            )
        )

        x_error = float(
            jnp.max(
                jnp.abs(
                    original_x
                    - transformed_x
                )
            )
        )

        background_drift = abs(
            float(
                drift[0]
            )
        )

        # Explicit inverse-log-scale roundtrip.
        rl0 = (
            q0 / sqrt3
            + q1 / sqrt2
            + q2 / sqrt6
        )

        rl1 = (
            q0 / sqrt3
            - q1 / sqrt2
            + q2 / sqrt6
        )

        rl2 = (
            q0 / sqrt3
            - 2.0 * q2 / sqrt6
        )

        log_scale_error = float(
            jnp.max(
                jnp.abs(
                    jnp.asarray(
                        [l0, l1, l2]
                    )
                    -
                    jnp.asarray(
                        [rl0, rl1, rl2]
                    )
                )
            )
        )

        # ----------------------------------------------------------
        # Exact full constrained-coordinate log Jacobian.
        # ----------------------------------------------------------

        m = int(
            np.prod(
                original_increment.shape
            )
        )

        log_jacobian = float(
            sqrt3 * q0
            +
            jnp.asarray(
                m,
                dtype=jnp.float64,
            )
            * jnp.log(
                scale
            )
        )

        density_residual = float(
            transformed_log_joint
            - original_log_joint
            - log_jacobian
        )

        abs_density_residual = abs(
            density_residual
        )

        max_density_residual = max(
            max_density_residual,
            abs_density_residual,
        )

        max_increment_error = max(
            max_increment_error,
            increment_error,
        )

        max_dynamic_sd_error = max(
            max_dynamic_sd_error,
            dynamic_sd_error,
        )

        max_log_scale_error = max(
            max_log_scale_error,
            log_scale_error,
        )

        max_x_error = max(
            max_x_error,
            x_error,
        )

        max_background_drift = max(
            max_background_drift,
            background_drift,
        )

        records.append({
            "index":
                index,

            "q0":
                float(q0),

            "q1":
                float(q1),

            "q2":
                float(q2),

            "geometric_scale":
                float(g),

            "transport_scale":
                float(scale),

            "M":
                m,

            "log_abs_det_jacobian":
                log_jacobian,

            "original_log_joint":
                original_log_joint,

            "transformed_log_joint":
                transformed_log_joint,

            "density_equivalence_residual":
                density_residual,

            "absolute_density_residual":
                abs_density_residual,

            "dynamic_sd_reconstruction_error":
                dynamic_sd_error,

            "log_scale_roundtrip_error":
                log_scale_error,

            "increment_reconstruction_error":
                increment_error,

            "x_reconstruction_error":
                x_error,

            "background_drift_abs":
                background_drift,
        })

        print(
            f"draw={index} "
            f"q0={float(q0):+.8f} "
            f"scale={float(scale):.8f} "
            f"logJ={log_jacobian:+.12f} "
            f"density_residual="
            f"{density_residual:+.3e} "
            f"sd_error="
            f"{dynamic_sd_error:.3e} "
            f"increment_error="
            f"{increment_error:.3e} "
            f"x_error="
            f"{x_error:.3e}"
        )

    passed = bool(
        max_density_residual
        <= EQUIVALENCE_TOL

        and max_dynamic_sd_error
        <= RECONSTRUCTION_TOL

        and max_log_scale_error
        <= RECONSTRUCTION_TOL

        and max_increment_error
        <= RECONSTRUCTION_TOL

        and max_x_error
        <= RECONSTRUCTION_TOL

        and max_background_drift
        <= 1e-12
    )

    output = {
        "phase":
            "Phase 3C.4",

        "mode":
            "target_equivalence",

        "selected_lambda_freeze_sha256":
            freeze_sha,

        "transport_family":
            "JOINT_LOG_SCALE_RADIAL_ORTHOGONALIZATION",

        "lambda":
            LAMBDA,

        "reference_scale":
            REFERENCE_SCALE,

        "equivalence_tolerance":
            EQUIVALENCE_TOL,

        "reconstruction_tolerance":
            RECONSTRUCTION_TOL,

        "n_test_draws":
            len(records),

        "max_absolute_density_residual":
            max_density_residual,

        "max_dynamic_sd_reconstruction_error":
            max_dynamic_sd_error,

        "max_log_scale_roundtrip_error":
            max_log_scale_error,

        "max_increment_reconstruction_error":
            max_increment_error,

        "max_x_reconstruction_error":
            max_x_error,

        "max_background_drift_abs":
            max_background_drift,

        "records":
            records,

        "passed":
            passed,

        "nuts_run":
            False,
    }

    output_path = (
        root /
        "results/phase3c4/"
        "06_PHASE3C4_TARGET_EQUIVALENCE.json"
    )

    phase3c3.atomic_json(
        output_path,
        output,
    )

    print(
        "\n=== PHASE 3C.4 TARGET EQUIVALENCE ==="
    )

    print(
        "max absolute density residual:",
        f"{max_density_residual:.3e}",
    )

    print(
        "max dynamic_sd reconstruction error:",
        f"{max_dynamic_sd_error:.3e}",
    )

    print(
        "max log-scale roundtrip error:",
        f"{max_log_scale_error:.3e}",
    )

    print(
        "max increment reconstruction error:",
        f"{max_increment_error:.3e}",
    )

    print(
        "max x reconstruction error:",
        f"{max_x_error:.3e}",
    )

    print(
        "max |background drift|:",
        f"{max_background_drift:.3e}",
    )

    print("\nWROTE:")
    print(output_path)

    if passed:
        print(
            "\nPHASE3C4 TARGET EQUIVALENCE: PASS"
        )
    else:
        print(
            "\nPHASE3C4 TARGET EQUIVALENCE: FAIL"
        )
        raise SystemExit(2)

    print("NO NUTS WAS RUN")


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--mode",
        choices=[
            "equivalence",
        ],
        required=True,
    )

    args = parser.parse_args()

    root = Path(".").resolve()

    if args.mode == "equivalence":
        run_equivalence(
            root
        )


_ROOT = Path(".").resolve()
_PHASE3C3 = load_phase3c3_module(
    _ROOT
)


if __name__ == "__main__":
    main()
