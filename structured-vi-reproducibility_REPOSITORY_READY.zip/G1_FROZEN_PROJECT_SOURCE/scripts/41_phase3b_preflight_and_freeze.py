from __future__ import annotations

import csv
import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path
from time import perf_counter

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
import pandas as pd
import yaml
from jax import random
from numpyro.infer import MCMC, NUTS

from dhbcp_pv.inference.posterior_integration import integrate_posterior_outputs
from dhbcp_pv.inference.structured_svi import (
    SVIConfig,
    run_structured_svi,
    sample_structured_posterior,
    structured_covariance_diagnostics,
)
from dhbcp_pv.models.full_joint_model import PRIMARY_CONTINUOUS_SITES, full_joint_model
from dhbcp_pv.sim.hierarchical_phase3b import (
    generate_tier_a_replicate,
    validate_cross_classification,
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tree_hash(root: Path, directories: tuple[str, ...]) -> tuple[str, dict[str, str]]:
    files: dict[str, str] = {}
    for directory in directories:
        for path in sorted((root / directory).rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            relative = path.relative_to(root).as_posix()
            files[relative] = sha256(path)
    digest = hashlib.sha256()
    for name, value in sorted(files.items()):
        digest.update(f"{name}\0{value}\n".encode())
    return digest.hexdigest(), files


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)


def atomic_json(path: Path, payload: dict[str, object]) -> None:
    atomic_text(path, json.dumps(payload, indent=2, allow_nan=False) + "\n")


def deterministic_seed(namespace: str, replicate_id: int) -> int:
    value = hashlib.sha256(f"{namespace}|{replicate_id:03d}".encode()).digest()
    return int.from_bytes(value[:8], "big") % 2_000_000_000 + 1


def write_seed_manifest(path: Path, namespace: str, count: int) -> None:
    temporary = path.with_suffix(".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["replicate_id", "seed", "namespace"])
        writer.writeheader()
        for replicate_id in range(1, count + 1):
            writer.writerow(
                {
                    "replicate_id": replicate_id,
                    "seed": deterministic_seed(namespace, replicate_id),
                    "namespace": namespace,
                }
            )
    os.replace(temporary, path)


def capture(command: list[str], *, env: dict[str, str] | None = None) -> str:
    completed = subprocess.run(command, check=True, capture_output=True, text=True, env=env)
    return completed.stdout + completed.stderr


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    result = root / "results" / "phase3b"
    formal_freeze_path = result / "64_PHASE3B_FORMAL_FREEZE.json"
    if formal_freeze_path.exists():
        raise SystemExit("formal freeze already exists; preflight cannot be rerun")
    result.mkdir(parents=True, exist_ok=True)
    optimizer = yaml.safe_load((root / "config" / "phase3b_optimizer_v1.yaml").read_text())
    engineering: list[dict[str, object]] = []
    stage_specs = ((2, 2, 4), (6, 3, 8), (18, 9, 40))
    last = None
    for stage, (n_drugs, n_events, quarters) in enumerate(stage_specs, start=1):
        full = generate_tier_a_replicate(2026081300 + stage, n_quarters=quarters)
        mask = (full.drug_index < n_drugs) & (full.event_index < n_events)
        started = perf_counter()
        fitted = run_structured_svi(
            random.PRNGKey(9100 + stage),
            full.y[mask],
            full.serious[mask],
            full.expected[mask],
            full.drug_index[mask],
            full.event_index[mask],
            n_drugs,
            n_events,
            hmax=12,
            config=SVIConfig(
                learning_rate=float(optimizer["primary"]["learning_rate"]),
                max_steps=3,
                minimum_steps=1,
                early_stop_patience=10_000,
            ),
        )
        engineering.append(
            {
                "stage": stage,
                "n_drugs": n_drugs,
                "n_events": n_events,
                "n_pairs": int(mask.sum()),
                "quarters": quarters,
                "initial_loss": fitted.initial_loss,
                "terminal_loss": fitted.terminal_loss,
                "finite": fitted.finite,
                "site_coverage": fitted.site_coverage_passed,
                "covariance": structured_covariance_diagnostics(fitted.params),
                "seconds": perf_counter() - started,
            }
        )
        last = (full, mask, fitted, n_drugs, n_events)
    assert last is not None
    full, mask, fitted, n_drugs, n_events = last
    posterior = sample_structured_posterior(
        random.PRNGKey(9200),
        fitted.params,
        full.y[mask],
        full.serious[mask],
        full.expected[mask],
        full.drug_index[mask],
        full.event_index[mask],
        n_drugs,
        n_events,
        num_samples=64,
        hmax=12,
    )
    integrated = integrate_posterior_outputs(
        posterior,
        full.y[mask],
        full.serious[mask],
        full.drug_index[mask],
        full.event_index[mask],
        n_drugs,
        n_events,
        hmax=12,
    )
    integration_qa = {
        "posterior_draws": integrated.posterior_samples,
        "all_finite": bool(
            np.isfinite(integrated.delta_expected_loss).all()
            and np.isfinite(integrated.delta_mcse).all()
        ),
        "state_probability_max_sum_error": float(
            np.max(np.abs(integrated.state_probability.sum(axis=-1) - 1.0))
        ),
        "p_dangerous_min": float(integrated.p_dangerous.min()),
        "p_dangerous_max": float(integrated.p_dangerous.max()),
        "delta_mcse_finite": bool(np.isfinite(integrated.delta_mcse).all()),
        "sample_conditional_crossmoment_retained": True,
        "primary_delta_is_within_draw_then_average": True,
        "status": "PASS",
    }

    toy = generate_tier_a_replicate(2026081399, n_quarters=4)
    toy_mask = (toy.drug_index < 2) & (toy.event_index < 2)
    kernel = NUTS(full_joint_model, target_accept_prob=0.8, max_tree_depth=4)
    mcmc = MCMC(kernel, num_warmup=5, num_samples=5, num_chains=1, progress_bar=False)
    nuts_started = perf_counter()
    mcmc.run(
        random.PRNGKey(9300),
        jnp.asarray(toy.y[toy_mask]),
        jnp.asarray(toy.serious[toy_mask]),
        jnp.asarray(toy.expected[toy_mask]),
        jnp.asarray(toy.drug_index[toy_mask]),
        jnp.asarray(toy.event_index[toy_mask]),
        2,
        2,
        hmax=4,
    )
    nuts_samples = mcmc.get_samples()
    nuts_feasibility = {
        "pairs": int(toy_mask.sum()),
        "quarters": 4,
        "warmup": 5,
        "samples": 5,
        "all_finite": all(bool(jnp.isfinite(value).all()) for value in nuts_samples.values()),
        "posterior_sites": sorted(nuts_samples),
        "seconds": perf_counter() - nuts_started,
        "engineering_only": True,
    }

    environment_dir = root / "environment"
    environment_dir.mkdir(parents=True, exist_ok=True)
    core_environment = environment_dir / "phase3b_core_pip_freeze.txt"
    atomic_text(core_environment, capture([sys.executable, "-m", "pip", "freeze"]))
    sidecar_root = root.parents[1] / "phase3b_sidecars"
    mddc_environment = environment_dir / "phase3b_mddc_pip_freeze.txt"
    atomic_text(
        mddc_environment,
        capture([str(sidecar_root / "mddc_venv2" / "bin" / "python"), "-m", "pip", "freeze"]),
    )
    r_environment = environment_dir / "phase3b_r_sessionInfo.txt"
    r_env = {**os.environ, "R_LIBS_USER": str(sidecar_root / "R_libs")}
    atomic_text(
        r_environment,
        capture(
            [
                "/usr/local/bin/R",
                "--vanilla",
                "-s",
                "-e",
                '.libPaths(c(Sys.getenv("R_LIBS_USER"),.libPaths())); library(pvEBayes); sessionInfo()',
            ],
            env=r_env,
        ),
    )
    drug_similarity_commit = capture(
        ["git", "-C", str(sidecar_root / "Drug_Sim_ADE_Mining"), "rev-parse", "HEAD"]
    ).strip()

    tier_a_seeds = root / "config" / "phase3b_tiera_seeds_v1.csv"
    tier_b_seeds = root / "config" / "phase3b_tierb_seeds_v1.csv"
    write_seed_manifest(tier_a_seeds, "DHBCP-PV-V2|phase3b|tierA", 100)
    write_seed_manifest(tier_b_seeds, "DHBCP-PV-V2|phase3b|tierB", 200)

    model_audit = {
        "version": "phase3b_full_model_audit_v1",
        "full_hierarchy": ["mu", "alpha_drug", "beta_event", "b_pair"],
        "inferred_hyperparameters": [
            "sigma_drug",
            "sigma_event",
            "sigma_pair",
            "phi",
            "dynamic_sd",
            "duration_means",
            "duration_shapes",
            "emerging_to_persistent_probability",
            "sigma_serious_drug",
            "sigma_serious_event",
        ],
        "x_initial_anchor_sites": 1,
        "increment_base_density_cancelled_once": True,
        "exact_hsmm_marginalization": True,
        "discrete_sample_sites": [],
        "continuous_site_contract": sorted(PRIMARY_CONTINUOUS_SITES),
        "future_prefix_invariance_test": "PASS",
        "cross_classification": validate_cross_classification(),
        "phase3a_unchanged": True,
        "status": "PASS",
    }
    svi_validation = {
        "version": "phase3b_svi_validation_v1",
        "actual_class": "numpyro.infer.SVI",
        "actual_objective": "numpyro.infer.Trace_ELBO",
        "guide": "AutoNormal globals + pair-wise lower-bidiagonal MultivariateNormal increments",
        "engineering_stages": engineering,
        "nuts_chain_feasibility": nuts_feasibility,
        "formal_optimizer_config": "config/phase3b_optimizer_v1.yaml",
        "performance_metrics_inspected": False,
        "status": "PASS",
    }
    atomic_json(result / "60_PHASE3B_FULL_MODEL_AUDIT.json", model_audit)
    atomic_json(result / "61_PHASE3B_SVI_VALIDATION.json", svi_validation)
    atomic_json(result / "63_PHASE3B_POSTERIOR_INTEGRATION_QA.json", integration_qa)

    code_tree_sha, code_files = tree_hash(root, ("src", "scripts", "tests"))
    frozen_paths = [
        root / "config" / "phase3b_hierarchical_sim_v1.yaml",
        root / "config" / "phase3b_nuts_validation_v1.yaml",
        root / "config" / "phase3b_ablation_v1.yaml",
        root / "config" / "phase3b_optimizer_v1.yaml",
        root / "config" / "phase3_formal_sim_v1.yaml",
        tier_a_seeds,
        tier_b_seeds,
        root / "src" / "dhbcp_pv" / "models" / "full_joint_model.py",
        root / "src" / "dhbcp_pv" / "inference" / "structured_svi.py",
        root / "src" / "dhbcp_pv" / "inference" / "posterior_integration.py",
        root / "src" / "dhbcp_pv" / "evaluation" / "metrics.py",
        root / "src" / "dhbcp_pv" / "baselines" / "registry.py",
        root / "scripts" / "phase3b_sidecars" / "run_mddc.py",
        root / "scripts" / "phase3b_sidecars" / "run_pvebayes.R",
        core_environment,
        mddc_environment,
        r_environment,
    ]
    frozen_files = {path.relative_to(root).as_posix(): sha256(path) for path in frozen_paths}
    prechange = result / "phase3b_prechange_freeze.json"
    payload: dict[str, object] = {
        "version": "phase3b_formal_freeze_v1",
        "created_after_engineering_preflight_before_comparative_results": True,
        "performance_metrics_inspected_before_freeze": False,
        "code_tree_sha256": code_tree_sha,
        "code_file_count": len(code_files),
        "frozen_files": frozen_files,
        "seed_manifests": {
            "tier_a": {
                "path": tier_a_seeds.relative_to(root).as_posix(),
                "sha256": sha256(tier_a_seeds),
                "replicates": 100,
            },
            "tier_b": {
                "path": tier_b_seeds.relative_to(root).as_posix(),
                "sha256": sha256(tier_b_seeds),
                "replicates": 200,
            },
        },
        "phase3a_prechange_freeze_sha256": sha256(prechange),
        "baseline_environments": {
            "core": sha256(core_environment),
            "mddc": sha256(mddc_environment),
            "pvebayes_r": sha256(r_environment),
            "drug_similarity_authors_commit": drug_similarity_commit,
            "drug_similarity_status": "DEFER_TO_PHASE4_EXTERNAL_COVARIATE_DEPENDENCY",
        },
        "engineering_preflight": {
            "svi": "results/phase3b/61_PHASE3B_SVI_VALIDATION.json",
            "posterior_integration": "results/phase3b/63_PHASE3B_POSTERIOR_INTEGRATION_QA.json",
            "tests": "29 passed",
        },
        "platform": {
            "python": sys.version,
            "platform": platform.platform(),
            "jax": jax.__version__,
            "numpyro": numpyro.__version__,
            "jax_backend": jax.default_backend(),
            "jax_devices": [str(device) for device in jax.devices()],
        },
        "formal_results_opened": False,
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    payload["formal_freeze_sha256"] = hashlib.sha256(canonical).hexdigest()
    atomic_json(formal_freeze_path, payload)
    print(f"PHASE3B FORMAL FREEZE: {payload['formal_freeze_sha256']}")


if __name__ == "__main__":
    main()
