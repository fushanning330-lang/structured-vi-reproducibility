"""Q2 supplementary simulation — frozen metric library V3 (metric-parity repaired).

Artifact: Q2_simulation_metrics_V3.py
Frozen: 2026-08-23 (metric-parity repair, V3). PRE-EXECUTION; no fitting here.

V3 changes vs V2 (V2 retained as historical artifact):
  FIX1: marginal_scale_cv now strictly reuses the frozen G2 definition:
        input scale_mat shape (n_runs, d); mean/std along axis=0 with ddof=0;
        cv = np.where(mean != 0, sd / mean, np.nan) under errstate; NO epsilon
        fallback; returns (mean, sd, cv) each of length d; downstream aggregates
        only finite cv coordinates.
  FIX2: procrustes_raw_residual is raw-only (exact frozen G2 formula):
        C = F_a.T @ F_b; U,_,Vt = svd(C); R = Vt.T @ U.T; d = ||F_a - F_b @ R||_F.
        No QR normalization, no symmetric normalization, no scale normalization.
  FIX6: normalized_spectrum_l2 explicitly uses eigvalsh(Sigma)[::-1] (descending)
        before trace normalization (exact parity with frozen definition).

All metrics reuse the frozen DHBCP-PV G2/G3 definitions (43S/43W). No universal
PASS/FAIL threshold is defined; ENG_TOL is a numerical equality tolerance only.
"""

from __future__ import annotations

import numpy as np

ENG_TOL = 1e-6


# ---------------------------------------------------------------------------
# cross-replicate metrics (frozen G2/G3 definitions)
# ---------------------------------------------------------------------------
def location_l2(m1: np.ndarray, m2: np.ndarray) -> float:
    """43S location_l2_distance: L2 distance between replicate posterior means."""
    return float(np.linalg.norm(np.asarray(m1) - np.asarray(m2)))


def marginal_scale_cv(scale_mat: np.ndarray):
    """43S marginal_scale_cv_across_coords (FROZEN G2 FORMULA, exact parity).

    Parameters
    ----------
    scale_mat : np.ndarray, shape (n_runs, d)
        Replicate scale vectors stacked by row.

    Returns
    -------
    mean : np.ndarray, shape (d,)
        np.mean(scale_mat, axis=0)
    sd : np.ndarray, shape (d,)
        np.std(scale_mat, axis=0, ddof=0)
    cv : np.ndarray, shape (d,)
        np.where(mean != 0, sd / mean, np.nan)  (no epsilon fallback)
    """
    sm = np.asarray(scale_mat, dtype=np.float64)
    if sm.ndim != 2:
        raise ValueError(f"scale_mat must be 2-D (n_runs, d); got shape {sm.shape}")
    mean = np.mean(sm, axis=0)
    sd = np.std(sm, axis=0, ddof=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        cv = np.where(mean != 0, sd / mean, np.nan)
    return mean, sd, cv


def principal_angle_sin_norm(U1: np.ndarray, U2: np.ndarray) -> float:
    """43S principal_angle_sin_F: || sin(theta) ||_2 between factor subspaces.

    Computed via SVD of Q1^T Q2 where Q1, Q2 are orthonormal bases.
    """
    Q1, _ = np.linalg.qr(np.asarray(U1, dtype=np.float64))
    Q2, _ = np.linalg.qr(np.asarray(U2, dtype=np.float64))
    _, sv, _ = np.linalg.svd(Q1.T @ Q2)
    sv = np.clip(sv, -1.0, 1.0)
    return float(np.linalg.norm(np.sqrt(np.maximum(0.0, 1.0 - sv**2))))


def projection_frobenius(U1: np.ndarray, U2: np.ndarray) -> float:
    """43S projection_frobenius_distance: ||P1 - P2||_F for subspace projections."""
    P1 = np.asarray(U1, dtype=np.float64) @ np.linalg.pinv(np.asarray(U1, dtype=np.float64))
    P2 = np.asarray(U2, dtype=np.float64) @ np.linalg.pinv(np.asarray(U2, dtype=np.float64))
    return float(np.linalg.norm(P1 - P2, ord="fro"))


def procrustes_raw_residual(F_a: np.ndarray, F_b: np.ndarray) -> float:
    """43S procrustes_raw_residual (RAW-ONLY, exact frozen G2 formula).

    C = F_a.T @ F_b
    U, _, Vt = np.linalg.svd(C)
    R = Vt.T @ U.T
    d = ||F_a - F_b @ R||_F

    No QR normalization, no symmetric normalization, no scale normalization.
    """
    Fa = np.asarray(F_a, dtype=np.float64)
    Fb = np.asarray(F_b, dtype=np.float64)
    C = Fa.T @ Fb
    U, _, Vt = np.linalg.svd(C)
    R = Vt.T @ U.T
    return float(np.linalg.norm(Fa - Fb @ R, ord="fro"))


def covariance_relative_frobenius(S1: np.ndarray, S2: np.ndarray) -> float:
    """43W sigma_relative_frobenius: ||S1-S2||_F / 0.5(||S1||_F + ||S2||_F)."""
    S1 = np.asarray(S1, dtype=np.float64); S2 = np.asarray(S2, dtype=np.float64)
    denom = 0.5 * (np.linalg.norm(S1, ord="fro") + np.linalg.norm(S2, ord="fro"))
    assert denom > 0.0, "deterministic abort: non-positive denominator (no epsilon fallback)"
    return float(np.linalg.norm(S1 - S2, ord="fro") / denom)


def correlation_rmse(S1: np.ndarray, S2: np.ndarray) -> float:
    """43W correlation_rmse: RMSE over strict upper triangle of correlation matrices."""
    S1 = np.asarray(S1, dtype=np.float64); S2 = np.asarray(S2, dtype=np.float64)
    def corr(S):
        d = np.sqrt(np.diag(S))
        assert np.all(d > 0), "no epsilon fallback"
        return S / np.outer(d, d)
    R1, R2 = corr(S1), corr(S2)
    iu = np.triu_indices(S1.shape[0], k=1)
    return float(np.sqrt(np.mean((R1[iu] - R2[iu]) ** 2)))


def normalized_spectrum_l2(S1: np.ndarray, S2: np.ndarray) -> float:
    """43W spectrum_l2_distance (exact parity): descending eigvalsh then trace-normalize.

    eigs = eigvalsh(Sigma)[::-1]  (explicit descending order)
    p    = eigs / eigs.sum()
    """
    S1 = np.asarray(S1, dtype=np.float64); S2 = np.asarray(S2, dtype=np.float64)
    def spec(S):
        eigs = np.linalg.eigvalsh(S)[::-1]   # descending
        t = eigs.sum()
        assert t > 0.0, "trace > 0 required"
        return eigs / t
    return float(np.linalg.norm(spec(S1) - spec(S2)))


def component_relative_frobenius(A1: np.ndarray, A2: np.ndarray) -> float:
    """43W component_relative_frobenius_B/L: relative Frobenius of a component."""
    A1 = np.asarray(A1, dtype=np.float64); A2 = np.asarray(A2, dtype=np.float64)
    return covariance_relative_frobenius(A1, A2)


def low_rank_trace_share(L: np.ndarray, Sigma: np.ndarray) -> float:
    """43W per-run low_rank_trace_share: tr(L)/tr(Sigma)."""
    return float(np.trace(L) / np.trace(Sigma))


# ---------------------------------------------------------------------------
# known-target metrics (frozen Q2 definitions; F1-repaired in V2, kept in V3)
# ---------------------------------------------------------------------------
def mean_vector_l2_error_to_target(m_q: np.ndarray, m_star: np.ndarray) -> float:
    """F1 REPAIR (V2): d_mu = ||m_q - m_star||_2.  Synthetic target m_star = 0."""
    return float(np.linalg.norm(np.asarray(m_q, dtype=np.float64) - np.asarray(m_star, dtype=np.float64)))


def covariance_error_to_target(Sigma_hat: np.ndarray, Sigma_star: np.ndarray) -> float:
    """Known-target covariance relative Frobenius error to Sigma*."""
    return covariance_relative_frobenius(Sigma_hat, Sigma_star)


def analytic_gaussian_kl(m_q: np.ndarray, Sigma_q: np.ndarray,
                         m_star: np.ndarray, Sigma_star: np.ndarray) -> float:
    """KL(q || p) for q=N(m_q,Sigma_q), p=N(m_star,Sigma_star), both Gaussian.

    KL = 0.5 [ tr(Sigma*^{-1} Sigma_q) + (m_q-m*)^T Sigma*^{-1} (m_q-m*)
               - d + log|Sigma*| - log|Sigma_q| ]

    Uses solve/eigvalsh only (float64); no sampling.
    """
    d = m_q.shape[0]
    diff = np.asarray(m_q, dtype=np.float64) - np.asarray(m_star, dtype=np.float64)
    Sstar = np.asarray(Sigma_star, dtype=np.float64)
    Sq = np.asarray(Sigma_q, dtype=np.float64)
    Sstar_inv = np.linalg.inv(Sstar)
    tr_term = np.trace(Sstar_inv @ Sq)
    quad = diff @ Sstar_inv @ diff
    sign_ls, logdet_s = np.linalg.slogdet(Sstar)
    sign_lq, logdet_q = np.linalg.slogdet(Sq)
    assert sign_ls > 0 and sign_lq > 0, "positive-definite required for analytic KL"
    return float(0.5 * (tr_term + quad - d + logdet_s - logdet_q))
