"""Single-use ENGINEERING-ONLY V7 stress-test runner.

NOT SCIENTIFIC EVIDENCE.
Runs exactly ST01-ST04 from the frozen V7 engineering stress-test protocol.
Never invokes the official 239-identity scheduler.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from Q2_simulation_module_b_V7 import (
    EngineeringFailure,
    engineering_failure_record,
    fit_one,
    persist_failure,
    persist_run,
)

EXPECTED_SOURCE_SHA256 = {
    "Q2_simulation_target_generator_V4.py": "daf890ec155ac6a1a2887e8c65bed035ec5b2c96e897647a69e23870cd8054bf",
    "Q2_simulation_metrics_V4.py": "7a008dbdcc8cb5cf82be11d9816507ad1e43f58ca0bbe80606bb160b33da9144",
    "Q2_simulation_module_b_V7.py": "e25608eb108fd5b685ffacc2d037a711abce60ca46a7be64d3f6ea8c25eb34f7",
}

STRESS_ROWS = [
    {
        "stress_id": "ST01",
        "particles": "P1",
        "conditioning": "well_conditioned",
        "trace_share": "0.05",
        "seed": 91001,
        "replicate_prefix": "ENGINEERING_ONLY",
        "scenario": "ENGINEERING_STRESS_ST01",
    },
    {
        "stress_id": "ST02",
        "particles": "P4",
        "conditioning": "well_conditioned",
        "trace_share": "0.05",
        "seed": 91002,
        "replicate_prefix": "ENGINEERING_ONLY",
        "scenario": "ENGINEERING_STRESS_ST02",
    },
    {
        "stress_id": "ST03",
        "particles": "P1",
        "conditioning": "moderately_ill_conditioned",
        "trace_share": "0.30",
        "seed": 91003,
        "replicate_prefix": "ENGINEERING_ONLY",
        "scenario": "ENGINEERING_STRESS_ST03",
    },
    {
        "stress_id": "ST04",
        "particles": "P4",
        "conditioning": "moderately_ill_conditioned",
        "trace_share": "0.30",
        "seed": 91004,
        "replicate_prefix": "ENGINEERING_ONLY",
        "scenario": "ENGINEERING_STRESS_ST04",
    },
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_frozen_sources() -> dict:
    here = Path(__file__).resolve().parent
    checked = {}
    for name, expected in EXPECTED_SOURCE_SHA256.items():
        path = here / name
        if not path.exists():
            raise RuntimeError(f"FROZEN_SOURCE_MISSING: {path}")
        actual = sha256(path)
        checked[name] = {"expected": expected, "actual": actual, "match": actual == expected}
        if actual != expected:
            raise RuntimeError(f"FROZEN_SOURCE_SHA_MISMATCH: {name}: {actual} != {expected}")
    return checked


def ensure_stress_output_fresh(out_dir: Path) -> None:
    """Stress test is one-time. No resume, overwrite, or rerun."""
    out_dir = Path(out_dir)
    patterns = (
        "MB_*.json",
        "MB_*.npz",
        "stress_manifest.json",
        "stress_batch_stopped.json",
    )
    existing = []
    if out_dir.exists():
        for pat in patterns:
            existing.extend(sorted(out_dir.glob(pat)))
    if existing:
        raise RuntimeError(
            "ENGINEERING_STRESS_OUTPUT_NOT_FRESH_ABORT: "
            + ", ".join(p.name for p in existing[:20])
        )


def main() -> None:
    source_hashes = verify_frozen_sources()

    out = Path("results/q2_supplementary_simulation/engineering_stress_test")
    ensure_stress_output_fresh(out)
    out.mkdir(parents=True, exist_ok=True)

    attempted = []
    completed = []
    failed = []

    for row in STRESS_ROWS:
        attempted.append(row["stress_id"])
        try:
            rec = fit_one(row)
            rec["stress_id"] = row["stress_id"]
            rec["engineering_only"] = True
            rec["scientific_evidence_eligible"] = False
            persist_run(rec, out)
            completed.append({
                "stress_id": row["stress_id"],
                "run_id": rec["run_id"],
                "status": "COMPLETED",
                "steps": rec["steps"],
            })
        except EngineeringFailure as exc:
            fail = engineering_failure_record(row, exc.stage, exc)
            fail["stress_id"] = row["stress_id"]
            fail["engineering_only"] = True
            fail["scientific_evidence_eligible"] = False
            persist_failure(fail, out)
            failed.append(fail)
            (out / "stress_batch_stopped.json").write_text(
                json.dumps(
                    {
                        "artifact": "Q2_SIMULATION_V7_ENGINEERING_STRESS_BATCH_STOPPED",
                        "classification": "ENGINEERING_ONLY_NOT_FOR_SCIENTIFIC_ANALYSIS",
                        "reason": "engineering failure; STOP; no rerun; await ChatGPT adjudication",
                        "failed_identity": fail,
                        "completed_before_stop": len(completed),
                    },
                    indent=2,
                    ensure_ascii=False,
                    default=float,
                ),
                encoding="utf-8",
            )
            break
        except Exception as exc:
            fail = engineering_failure_record(row, "stress_runner_unknown", exc)
            fail["stress_id"] = row["stress_id"]
            fail["engineering_only"] = True
            fail["scientific_evidence_eligible"] = False
            persist_failure(fail, out)
            failed.append(fail)
            (out / "stress_batch_stopped.json").write_text(
                json.dumps(
                    {
                        "artifact": "Q2_SIMULATION_V7_ENGINEERING_STRESS_BATCH_STOPPED",
                        "classification": "ENGINEERING_ONLY_NOT_FOR_SCIENTIFIC_ANALYSIS",
                        "reason": "unexpected engineering exception; STOP; no rerun; await ChatGPT adjudication",
                        "failed_identity": fail,
                        "completed_before_stop": len(completed),
                    },
                    indent=2,
                    ensure_ascii=False,
                    default=float,
                ),
                encoding="utf-8",
            )
            break

    manifest = {
        "artifact": "Q2_SIMULATION_V7_ENGINEERING_STRESS_MANIFEST",
        "classification": "ENGINEERING_ONLY_NOT_FOR_SCIENTIFIC_ANALYSIS",
        "scientific_evidence_eligible": False,
        "planned": 4,
        "attempted": len(attempted),
        "completed": len(completed),
        "failed": len(failed),
        "attempted_stress_ids": attempted,
        "completed_runs": completed,
        "failed_runs": failed,
        "frozen_source_sha256": source_hashes,
        "batch_status": "PASS_ALL_4" if len(completed) == 4 and not failed else "STOPPED_ON_FAILURE",
        "governance": {
            "one_attempt_per_stress_identity": True,
            "no_rerun": True,
            "no_replacement": True,
            "stop_on_first_failure": True,
            "not_for_manuscript": True,
        },
    }
    (out / "stress_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False, default=float),
        encoding="utf-8",
    )

    print(json.dumps({
        "stress_test": manifest["batch_status"],
        "attempted": manifest["attempted"],
        "completed": manifest["completed"],
        "failed": manifest["failed"],
        "output_dir": str(out),
    }, indent=2))


if __name__ == "__main__":
    main()
