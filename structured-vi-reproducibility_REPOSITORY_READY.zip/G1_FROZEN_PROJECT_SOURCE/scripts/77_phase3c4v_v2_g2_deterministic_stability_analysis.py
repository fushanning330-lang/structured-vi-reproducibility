#!/usr/bin/env python3
"""Phase3C.4V V2 — DETERMINISTIC G2 REPLICATE POSTERIOR STABILITY ANALYSIS (scripts/77).

READ-ONLY / OFFLINE engineering preflight for G2. Computes NOTHING
scientifically in this task; --mode preflight verifies that the frozen G2
metrics (42ZA, 36 g2_followup_metrics) are ANALYTICALLY computable from the
persisted fitted-guide parameters WITHOUT new posterior draws or new inference.

G2 basis (frozen): 36 protocol g2_followup_metrics.note — "After Phase3C4V
completes, G2 uses the SAVED fitted-guide parameters directly (no posterior
draws required)". V2 guide: Sigma = B + U U^T (B = blockdiag(diag(s^2[0:158]),
B_1..B_50), B_p = S_p R_11(rho) S_p, U = (708,28)).

Modes: --mode preflight | --mode execute.
THIS TASK RUNS --mode preflight ONLY. G2_EXECUTED = false.

NO SVI. NO posterior sampling. NO importance sampling. NO NUTS/HMC/MCMC.
NO fitted-result-dependent threshold.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]

LOG_SCALE_ABS_MAX = 300.0
RHO_MAX = 0.99
LATENT_DIM = 708
FACTOR_DIM = 28
V2_TOTAL_ELEMENTS = 13377
EXPECTED_PARAMS = ["v2_loc", "v2_diag_log_scale", "v2_F_shared",
                   "v2_F_count_plus_initial", "v2_F_dynamic_scale",
                   "v2_F_seriousness", "v2_raw_temporal_rho"]

EVALUABLE = [
    "V2_V2_ARM_P1_p1_seed3003_t12", "V2_V2_ARM_P1_p1_seed4004_t12",
    "V2_V2_ARM_P1_p1_seed5005_t12",
    "V2_V2_ARM_P4_p4_seed1001_t12", "V2_V2_ARM_P4_p4_seed2002_t12",
    "V2_V2_ARM_P4_p4_seed3003_t12", "V2_V2_ARM_P4_p4_seed4004_t12",
    "V2_V2_ARM_P4_p4_seed5005_t12",
]

FROZEN_CHAIN = {
    "artifact22": "results/phase3c4/22_ALTERNATIVE_VARIATIONAL_ARCHITECTURE_PROTOCOL.json",
    "42J": "results/phase3c4v/protocol/42J_V2_G1_OPTIMIZATION_PROTOCOL_FREEZE.json",
    "42Z": "results/phase3c4v_v2/audit/42Z_V2_G1_FINAL_COHORT_CLOSEOUT.json",
    "42ZA": "results/phase3c4v_v2/protocol/42ZA_V2_G2_REPLICATE_POSTERIOR_STABILITY_PROTOCOL_FREEZE.json",
    "guide_fix": "src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py",
    "model": "src/dhbcp_pv/models/full_joint_model.py",
    "serializer": "src/dhbcp_pv/inference/variational_param_persistence.py",
    "scripts51": "scripts/51_run_phase3c_nuts.py",
    "seed_csv": "config/phase3b_tiera_seeds_v1.csv",
    "generator": "src/dhbcp_pv/sim/hierarchical_phase3b.py",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def atomic_write_json(path: Path, obj) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


# ---------------------------------------------------------------------------
# Deterministic analytic building blocks (numpy float64; no SVI, no sampling).
# ---------------------------------------------------------------------------
def build_u(p) -> np.ndarray:
    Fs = np.asarray(p["v2_F_shared"], dtype=np.float64)             # (708,16)
    Fc = np.asarray(p["v2_F_count_plus_initial"], dtype=np.float64)  # (120,4)
    Fd = np.asarray(p["v2_F_dynamic_scale"], dtype=np.float64)       # (16,4)
    Fser = np.asarray(p["v2_F_seriousness"], dtype=np.float64)       # (22,4)
    U = np.zeros((LATENT_DIM, FACTOR_DIM), dtype=np.float64)
    U[:, 0:16] = Fs
    U[0:70, 16:20] = Fc[0:70]
    U[108:158, 16:20] = Fc[70:120]
    U[70:86, 20:24] = Fd
    U[86:108, 24:28] = Fser
    return U


def build_covariance(p) -> tuple[np.ndarray, np.ndarray]:
    """Sigma = B + U U^T (708x708 dense, float64). B: diag(s^2[0:158]) +
    50 AR(1) blocks S_p R_11(rho) S_p over [158,708)."""
    dls = np.clip(np.asarray(p["v2_diag_log_scale"], dtype=np.float64),
                  -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX)
    s = np.exp(dls)
    rho = float(RHO_MAX * np.tanh(np.asarray(p["v2_raw_temporal_rho"]).item()))
    B = np.zeros((LATENT_DIM, LATENT_DIM), dtype=np.float64)
    B[np.arange(158), np.arange(158)] = s[:158] ** 2
    R11 = np.fromfunction(lambda i, j: rho ** np.abs(i - j), (11, 11))
    for blk in range(50):
        a = 158 + 11 * blk
        S = np.diag(s[a:a + 11])
        B[a:a + 11, a:a + 11] = S @ R11 @ S
    U = build_u(p)
    return B + U @ U.T, U


def analytic_marginal_var_sq(p) -> np.ndarray:
    """s^2 + rowsum(U^2) — analytic diagonal of Sigma (independent code path)."""
    dls = np.clip(np.asarray(p["v2_diag_log_scale"], dtype=np.float64),
                  -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX)
    s2 = np.exp(2.0 * dls)
    U = build_u(p)
    return s2 + np.sum(U * U, axis=1)


def projection_matrix(U: np.ndarray) -> np.ndarray:
    """P = F (F^T F)^{-1} F^T via Cholesky solve (rotation/sign-invariant).

    G = L L^T  =>  G^{-1} = L^{-T} L^{-1}: solve L first, then L^T."""
    F = np.asarray(U, dtype=np.float64)
    G = F.T @ F
    L = np.linalg.cholesky(G)
    invG = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(G.shape[0])))
    return F @ invG @ F.T


def principal_angles(U1: np.ndarray, U2: np.ndarray) -> np.ndarray:
    """Principal angles between the column subspaces (SVD of Q1^T Q2)."""
    Q1, _ = np.linalg.qr(np.asarray(U1, dtype=np.float64))
    Q2, _ = np.linalg.qr(np.asarray(U2, dtype=np.float64))
    sv = np.linalg.svd(Q1.T @ Q2, compute_uv=False)
    return np.arccos(np.clip(sv, -1.0, 1.0))


def location_l2(loc1, loc2) -> float:
    return float(np.linalg.norm(np.asarray(loc1, dtype=np.float64)
                                - np.asarray(loc2, dtype=np.float64)))


# ---------------------------------------------------------------------------
# Preflight unit checks (NO SVI / NO sampling).
# ---------------------------------------------------------------------------
def run_preflight(root: Path) -> dict:
    checks = {}

    def rec(name, ok, detail):
        checks[name] = {"ok": bool(ok), "detail": detail}

    src = Path(__file__).resolve().read_text(encoding="utf-8")
    t0 = time.perf_counter()

    # 1) x64
    rec("x64_float64", bool(np.finfo(np.float64).dtype == np.float64),
        {"dtype": str(np.finfo(np.float64).dtype)})

    # 2-4) identities + schemas
    id_ok = True
    schema_detail = {}
    params_all = []
    for ident in EVALUABLE:
        npz = root / "results/phase3c4v_v2/runs" / ident / "final_svi_params.npz"
        if not npz.exists():
            id_ok = False
            schema_detail[ident] = "MISSING npz"
            continue
        with np.load(npz, allow_pickle=False) as z:
            keys = sorted(z.files)
            total = sum(int(z[k].size) for k in z.files)
        ok_i = (keys == sorted(EXPECTED_PARAMS)) and (total == V2_TOTAL_ELEMENTS)
        id_ok = id_ok and ok_i
        schema_detail[ident] = {"n_params": len(keys), "total": total, "ok": ok_i}
        if ok_i:
            with np.load(npz, allow_pickle=False) as z:
                params_all.append({k: np.asarray(z[k]) for k in EXPECTED_PARAMS})
    rec("exact_8_identities", id_ok, {"n": len(EVALUABLE), "detail": schema_detail})
    rec("no_unusable_p1", ("V2_V2_ARM_P1_p1_seed1001_t12" not in EVALUABLE)
                          and ("V2_V2_ARM_P1_p1_seed2002_t12" not in EVALUABLE),
        {"identities": EVALUABLE})

    # 5) analytic covariance construction on the FIRST evaluable run
    p0 = params_all[0] if params_all else None
    cov_ok = False
    cov_detail = {}
    if p0 is not None:
        Sigma, U = build_covariance(p0)
        sym = np.allclose(Sigma, Sigma.T, atol=1e-8)
        eigmin = float(np.linalg.eigvalsh(Sigma).min())
        pd = eigmin > 0.0
        analytic_diag = analytic_marginal_var_sq(p0)
        diag_match = float(np.max(np.abs(np.diag(Sigma) - analytic_diag)))
        cov_ok = sym and pd and diag_match < 1e-6
        cov_detail = {"symmetric": bool(sym), "min_eigval": eigmin, "PD": bool(pd),
                      "max_abs_diag_diff": diag_match, "U_shape": list(U.shape)}
    rec("analytic_covariance", cov_ok, cov_detail)

    # 6) oracle: deterministic TOY parameters -> analytic vs dense oracle
    #    (toy factor columns 7 <= 8 rows so the factor space is full rank)
    toy = {
        "v2_loc": np.zeros(8),
        "v2_diag_log_scale": np.full(8, -0.5),
        "v2_F_shared": np.random.RandomState(7).normal(0, 0.1, (8, 4)),
        "v2_F_count_plus_initial": np.random.RandomState(8).normal(0, 0.1, (8, 1)),
        "v2_F_dynamic_scale": np.random.RandomState(9).normal(0, 0.1, (8, 1)),
        "v2_F_seriousness": np.random.RandomState(10).normal(0, 0.1, (8, 1)),
        "v2_raw_temporal_rho": np.array([0.2]),
    }
    # toy oracle: construct Sigma via an INDEPENDENT dense loop (no shared code)
    s_t = np.exp(np.clip(toy["v2_diag_log_scale"], -300, 300))
    Bt = np.zeros((8, 8))
    Bt[np.arange(8), np.arange(8)] = s_t ** 2  # toy: no AR1 blocks (all diag-only)
    Ut = np.hstack([toy["v2_F_shared"], toy["v2_F_count_plus_initial"],
                    toy["v2_F_dynamic_scale"], toy["v2_F_seriousness"]])
    Sigma_toy = Bt + Ut @ Ut.T
    diag_toy_analytic = s_t ** 2 + np.sum(Ut * Ut, axis=1)
    diag_match_toy = float(np.max(np.abs(np.diag(Sigma_toy) - diag_toy_analytic)))
    P = projection_matrix(Ut)
    P_sym = bool(np.allclose(P, P.T, atol=1e-8))
    P_idem = bool(np.allclose(P @ P, P, atol=1e-8))
    P_fix = bool(np.allclose(P @ Ut, Ut, atol=1e-8))
    ang = principal_angles(Ut, Ut @ np.eye(Ut.shape[1]))
    ang_ok = bool(np.all(np.isfinite(ang)) and np.all(ang >= 0.0))
    loc2 = location_l2(np.zeros(8), np.ones(8))
    loc_l2_ok = bool(abs(loc2 - np.sqrt(8.0)) < 1e-9)
    toy_ok = (diag_match_toy < 1e-10 and P_sym and P_idem and P_fix and ang_ok
              and loc_l2_ok)
    rec("formula_oracle", toy_ok,
        {"toy_diag_max_diff": diag_match_toy, "P_symmetric": P_sym,
         "P_idempotent": P_idem, "P_fixes_F": P_fix,
         "principal_angles_ok": ang_ok, "loc_l2_ok": loc_l2_ok})

    # 7) no SVI / no sampling / no MCMC (source scan; patterns assembled
    #    dynamically so the scan's own literals cannot self-match)
    forbidden = ["from numpyro.infer import " + "SVI",
                 "svi." + "init(", "svi." + "update(", "svi." + "stable_update(",
                 "numpyro." + "sample(", "." + "sample(", "NU" + "TS(",
                 "H" + "MC(", "MC" + "MC(", "importance" + "(", "Importance" + "Sampling"]
    hits = [f for f in forbidden if f in src]
    rec("no_svi_sampling_mcmc", not hits, {"hits": hits})

    # 8) no fitted-result-dependent threshold (no PASS/FAIL threshold constants;
    #    patterns assembled dynamically to avoid self-matching)
    t_thr = "THRES" + "HOLD"
    t_cut = "PASS_" + "CUTOFF"
    t_lr = ">=" + " 0.15"
    t_g2p = "G2_" + "PASS"
    t_g2f = "G2_" + "FAIL"
    threshold_hits = [l for l in src.splitlines()
                      if (t_thr in l or t_cut in l or t_lr in l
                          or t_g2p in l or t_g2f in l)]
    rec("no_fitted_threshold", not threshold_hits, {"hits": threshold_hits})

    # 9) source SHA chain
    chain = {}
    ok_chain = True
    for name, rel in FROZEN_CHAIN.items():
        p = root / rel
        live = sha256(p) if p.exists() else "MISSING"
        match = True  # bound values verified at 42ZA creation; here verify presence/readability
        chain[name] = {"live": live, "exists": p.exists()}
        ok_chain = ok_chain and p.exists()
    rec("source_chain", ok_chain, {"n_sources": len(chain),
                                   "missing": [k for k, v in chain.items() if not v["exists"]]})

    elapsed = time.perf_counter() - t0
    ok = all(v["ok"] for v in checks.values())
    return {"ok": ok, "checks": checks, "elapsed_seconds": elapsed,
            "G2_EXECUTED": False}


def cmd_preflight(root: Path) -> int:
    res = run_preflight(root)
    classification = ("V2_G2_DETERMINISTIC_ANALYSIS_PREFLIGHT_PASS" if res["ok"]
                      else "V2_G2_DETERMINISTIC_ANALYSIS_PREFLIGHT_FAIL")
    payload = {
        "artifact_id": "42ZB_V2_G2_DETERMINISTIC_ANALYSIS_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "mode": "V2 G2 DETERMINISTIC ANALYSIS PREFLIGHT (read-only; no SVI, no sampling, no G2 execution)",
        "classification": classification,
        "checks": res["checks"],
        "G2_EXECUTED": False,
        "G2_POSTERIOR_DRAWS_REQUIRED": False,
        "G2_NEW_INFERENCE_REQUIRED": False,
        "elapsed_seconds": res["elapsed_seconds"],
        "flags": {
            "SVI_INIT": False, "SVI_UPDATE": False, "SVI_STABLE_UPDATE": False,
            "POSTERIOR_SAMPLING": False, "IMPORTANCE_SAMPLING": False,
            "NUTS_HMC_MCMC": False, "G2_EXECUTED": False, "G3_AUTHORIZED": False,
        },
    }
    out = root / "results/phase3c4v/preflight/42ZB_V2_G2_DETERMINISTIC_ANALYSIS_PREFLIGHT.json"
    atomic_write_json(out, payload)
    md = [f"# 42ZB — V2 G2 DETERMINISTIC ANALYSIS PREFLIGHT", "",
          f"**Classification: {classification}**", "",
          f"- G2_EXECUTED = **{False}** | G2_POSTERIOR_DRAWS_REQUIRED = **False** | "
          f"G2_NEW_INFERENCE_REQUIRED = **False**", "",
          "| Check | Result |", "|---|---|"]
    for k, v in res["checks"].items():
        md.append(f"| {k} | {'PASS' if v['ok'] else 'FAIL'} |")
    md += ["", "The G2 metrics (42ZA) are analytically computable from persisted "
              "fitted-guide parameters; NO posterior draws or new inference are "
              "required. G2 scientific analysis is NOT executed in this task."]
    (out.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", "PASS" if res["ok"] else "FAIL")
    return 0 if res["ok"] else 2


def cmd_execute(root: Path) -> int:
    print("G2_EXECUTE_NOT_AUTHORIZED_IN_THIS_TASK: --mode execute is NOT run.")
    return 2


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V2 G2 deterministic stability analysis")
    ap.add_argument("--mode", required=True, choices=["preflight", "execute"])
    args = ap.parse_args(argv)
    if args.mode == "preflight":
        return cmd_preflight(ROOT)
    return cmd_execute(ROOT)


if __name__ == "__main__":
    sys.exit(main())
