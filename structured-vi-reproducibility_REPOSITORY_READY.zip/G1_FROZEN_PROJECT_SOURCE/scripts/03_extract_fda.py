from __future__ import annotations
import zipfile
from pathlib import Path

def main():
    root = Path(__file__).resolve().parents[1]
    raw = root / "data/raw/faers"
    for zpath in sorted(raw.glob("faers_ascii_*.zip")):
        target = raw / zpath.stem
        if target.exists():
            continue
        target.mkdir()
        with zipfile.ZipFile(zpath) as z:
            z.extractall(target)
        print("extracted", zpath.name)

if __name__ == "__main__":
    main()
