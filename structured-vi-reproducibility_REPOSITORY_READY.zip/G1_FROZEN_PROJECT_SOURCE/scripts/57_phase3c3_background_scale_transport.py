#!/usr/bin/env python
"""Phase 3C.3 frozen background-scale transport target-equivalence test."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping

os.environ.setdefault("JAX_ENABLE_X64", "1")
os.environ.setdefault(
    "XLA_FLAGS",
    "--xla_force_host_platform_device_count=4",
)

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
import yaml
import numpyro
import numpyro.distributions as dist
from jax import random
from numpyro import handlers
from numpyro.infer import MCMC, NUTS

from dhbcp_pv.models.full_joint_model import full_joint_model
from dhbcp_pv.sim.hierarchical_phase3b import generate_tier_a_replicate


EXPECTED_PROTOCOL_SHA256 = (
    "4ffd40d9c1ac80ad989d0adc310ab75719f35d8bc882207ae64fe9675484aa0d"
)

LAMBDA = 0.25
REFERENCE_SCALE = 0.5
EQUIVALENCE_TOL = 1e-6
RECONSTRUCTION_TOL = 1e-12


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False)
    )
    os.replace(tmp, path)


def reference_data(root: Path, cutoff: int = 12):
    seeds = pd.read_csv(
        root / "config/phase3b_tiera_seeds_v1.csv"
    )

    seed = int(
        seeds.loc[
            seeds.replicate_id == 1,
            "seed",
        ].iloc[0]
    )

    replicate = generate_tier_a_replicate(
        seed,
        n_quarters=40,
    )

    pair_mask = (
        (replicate.drug_index < 10)
        & (replicate.event_index < 5)
    )

    if int(pair_mask.sum()) != 50:
        raise RuntimeError(
            "frozen reference subset is not 10 drugs x 5 events"
        )

    args = (
        jnp.asarray(
            replicate.y[pair_mask, :cutoff]
        ),
        jnp.asarray(
            replicate.serious[pair_mask, :cutoff]
        ),
        jnp.asarray(
            replicate.expected[pair_mask, :cutoff],
            dtype=jnp.float64,
        ),
        jnp.asarray(
            replicate.drug_index[pair_mask]
        ),
        jnp.asarray(
            replicate.event_index[pair_mask]
        ),
        10,
        5,
    )

    return seed, args, {"hmax": 12}


def conditioned_trace(
    model,
    key,
    params,
    args,
    kwargs,
):
    wrapped = handlers.substitute(
        handlers.seed(model, key),
        data=params,
    )

    return handlers.trace(wrapped).get_trace(
        *args,
        **kwargs,
    )


def trace_log_joint(trace) -> float:
    total = jnp.asarray(
        0.0,
        dtype=jnp.float64,
    )

    for site in trace.values():
        if site.get("type") != "sample":
            continue

        fn = site.get("fn")
        value = site.get("value")

        if fn is not None:
            total = total + jnp.sum(
                fn.log_prob(value)
            )

    return float(total)


def original_latent_draw(
    key,
    args,
    kwargs,
):
    trace = handlers.trace(
        handlers.seed(
            full_joint_model,
            key,
        )
    ).get_trace(
        *args,
        **kwargs,
    )

    return {
        name: site["value"]
        for name, site in trace.items()
        if site.get("type") == "sample"
        and not site.get(
            "is_observed",
            False,
        )
    }


def phase3c3_transport_model(
    y,
    serious,
    expected,
    drug_index,
    event_index,
    n_drugs,
    n_events,
    *,
    hmax,
):
    """
    Frozen Phase 3C.3 coordinate map.

    a = (dynamic_sd[0] / 0.5)**0.25
    base_increment = a * z

    Auxiliary sampling densities are exactly cancelled.
    The original full_joint_model remains the scientific target.
    """

    dynamic_sd_aux_dist = (
        dist.LogNormal(0.0, 1.0)
        .expand([4])
        .to_event(1)
    )

    dynamic_sd = numpyro.sample(
        "phase3c3_dynamic_sd",
        dynamic_sd_aux_dist,
    )

    numpyro.factor(
        "phase3c3_dynamic_sd_aux_cancel",
        -dynamic_sd_aux_dist.log_prob(
            dynamic_sd
        ),
    )

    n_pairs = int(y.shape[0])
    n_quarters = int(y.shape[1])

    increment_shape = (
        n_pairs,
        n_quarters - 1,
    )

    z_aux_dist = (
        dist.Normal(0.0, 1.0)
        .expand(increment_shape)
        .to_event(2)
    )

    z = numpyro.sample(
        "phase3c3_z",
        z_aux_dist,
    )

    numpyro.factor(
        "phase3c3_z_aux_cancel",
        -z_aux_dist.log_prob(z),
    )

    scale = (
        dynamic_sd[0]
        / REFERENCE_SCALE
    ) ** LAMBDA

    # Frozen background drift is exactly zero.
    base_increment = scale * z

    numpyro.deterministic(
        "phase3c3_transport_scale",
        scale,
    )

    numpyro.deterministic(
        "phase3c3_base_increment",
        base_increment,
    )

    m = int(np.prod(increment_shape))

    log_abs_det_jacobian = (
        jnp.asarray(
            m,
            dtype=jnp.float64,
        )
        * jnp.log(scale)
    )

    numpyro.factor(
        "phase3c3_transport_jacobian",
        log_abs_det_jacobian,
    )

    original_with_transport = handlers.condition(
        full_joint_model,
        data={
            "dynamic_sd": dynamic_sd,
            "base_increment": base_increment,
        },
    )

    original_with_transport(
        y,
        serious,
        expected,
        drug_index,
        event_index,
        n_drugs,
        n_events,
        hmax=hmax,
    )


def run_equivalence(root: Path) -> None:
    protocol_path = (
        root
        / "results/phase3c3/"
        "00_PHASE3C3_PROTOCOL_FREEZE.json"
    )

    if not protocol_path.exists():
        raise RuntimeError(
            "Phase 3C.3 protocol freeze is missing."
        )

    protocol_sha = sha256(protocol_path)

    if protocol_sha != EXPECTED_PROTOCOL_SHA256:
        raise RuntimeError(
            "Phase 3C.3 protocol freeze SHA256 mismatch.\n"
            f"expected={EXPECTED_PROTOCOL_SHA256}\n"
            f"actual={protocol_sha}"
        )

    print("PHASE3C3 PROTOCOL FREEZE VERIFICATION: PASS")
    print("PROTOCOL SHA256:", protocol_sha)

    seed, args, kwargs = reference_data(
        root,
        cutoff=12,
    )

    # Same lightweight equivalence panel strategy used previously.
    small_args = (
        args[0][:2, :4],
        args[1][:2, :4],
        args[2][:2, :4],
        jnp.asarray([0, 1]),
        jnp.asarray([0, 1]),
        2,
        2,
    )

    records = []

    max_density_residual = 0.0
    max_increment_error = 0.0
    max_x_error = 0.0
    max_background_drift = 0.0

    for index in range(5):
        key = random.PRNGKey(
            seed + 93000 + index
        )

        original_params = original_latent_draw(
            key,
            small_args,
            kwargs,
        )

        original_trace = conditioned_trace(
            full_joint_model,
            key,
            original_params,
            small_args,
            kwargs,
        )

        original_log_joint = trace_log_joint(
            original_trace
        )

        dynamic_sd = jnp.asarray(
            original_params["dynamic_sd"],
            dtype=jnp.float64,
        )

        original_increment = jnp.asarray(
            original_params["base_increment"],
            dtype=jnp.float64,
        )

        drift = jnp.asarray(
            original_trace["drift"]["value"],
            dtype=jnp.float64,
        )

        background_drift = abs(
            float(drift[0])
        )

        max_background_drift = max(
            max_background_drift,
            background_drift,
        )

        if background_drift > 1e-12:
            raise RuntimeError(
                "Frozen Phase 3C.3 assumption violated: "
                f"drift[0]={float(drift[0])}"
            )

        scale = (
            dynamic_sd[0]
            / REFERENCE_SCALE
        ) ** LAMBDA

        z = original_increment / scale

        transformed_params = {
            name: value
            for name, value
            in original_params.items()
            if name not in {
                "dynamic_sd",
                "base_increment",
            }
        }

        transformed_params[
            "phase3c3_dynamic_sd"
        ] = dynamic_sd

        transformed_params[
            "phase3c3_z"
        ] = z

        transformed_trace = conditioned_trace(
            phase3c3_transport_model,
            key,
            transformed_params,
            small_args,
            kwargs,
        )

        transformed_log_joint = trace_log_joint(
            transformed_trace
        )

        reconstructed_increment = jnp.asarray(
            transformed_trace[
                "base_increment"
            ]["value"],
            dtype=jnp.float64,
        )

        original_x = jnp.asarray(
            original_trace["x"]["value"],
            dtype=jnp.float64,
        )

        transformed_x = jnp.asarray(
            transformed_trace["x"]["value"],
            dtype=jnp.float64,
        )

        increment_error = float(
            jnp.max(
                jnp.abs(
                    original_increment
                    - reconstructed_increment
                )
            )
        )

        x_error = float(
            jnp.max(
                jnp.abs(
                    original_x
                    - transformed_x
                )
            )
        )

        m = int(
            np.prod(
                original_increment.shape
            )
        )

        log_jacobian = float(
            m * jnp.log(scale)
        )

        # New coordinate density must equal:
        # old density + log|J|.
        density_residual = float(
            transformed_log_joint
            - original_log_joint
            - log_jacobian
        )

        abs_density_residual = abs(
            density_residual
        )

        max_density_residual = max(
            max_density_residual,
            abs_density_residual,
        )

        max_increment_error = max(
            max_increment_error,
            increment_error,
        )

        max_x_error = max(
            max_x_error,
            x_error,
        )

        record = {
            "index": index,
            "dynamic_sd_background":
                float(dynamic_sd[0]),
            "scale":
                float(scale),
            "M": m,
            "log_abs_det_jacobian":
                log_jacobian,
            "original_log_joint":
                original_log_joint,
            "transformed_log_joint":
                transformed_log_joint,
            "density_equivalence_residual":
                density_residual,
            "absolute_density_residual":
                abs_density_residual,
            "increment_reconstruction_error":
                increment_error,
            "x_reconstruction_error":
                x_error,
            "background_drift_abs":
                background_drift,
        }

        records.append(record)

        print(
            f"draw={index} "
            f"scale={float(scale):.8f} "
            f"logJ={log_jacobian:.12f} "
            f"density_residual="
            f"{density_residual:.3e} "
            f"increment_error="
            f"{increment_error:.3e} "
            f"x_error={x_error:.3e}"
        )

    passed = bool(
        max_density_residual
        <= EQUIVALENCE_TOL
        and max_increment_error
        <= RECONSTRUCTION_TOL
        and max_x_error
        <= RECONSTRUCTION_TOL
        and max_background_drift
        <= 1e-12
    )

    output = {
        "phase": "Phase 3C.3",
        "mode": "target_equivalence",
        "protocol_sha256":
            protocol_sha,
        "transport_family":
            "BACKGROUND_SD",
        "lambda":
            LAMBDA,
        "reference_scale":
            REFERENCE_SCALE,
        "equivalence_tolerance":
            EQUIVALENCE_TOL,
        "reconstruction_tolerance":
            RECONSTRUCTION_TOL,
        "n_test_draws":
            len(records),
        "max_absolute_density_residual":
            max_density_residual,
        "max_increment_reconstruction_error":
            max_increment_error,
        "max_x_reconstruction_error":
            max_x_error,
        "max_background_drift_abs":
            max_background_drift,
        "records":
            records,
        "passed":
            passed,
    }

    output_path = (
        root
        / "results/phase3c3/"
        "01_PHASE3C3_TARGET_EQUIVALENCE.json"
    )

    atomic_json(
        output_path,
        output,
    )

    print("\n=== PHASE 3C.3 TARGET EQUIVALENCE ===")
    print(
        "max absolute density residual:",
        f"{max_density_residual:.3e}",
    )
    print(
        "max increment reconstruction error:",
        f"{max_increment_error:.3e}",
    )
    print(
        "max x reconstruction error:",
        f"{max_x_error:.3e}",
    )
    print(
        "max |background drift|:",
        f"{max_background_drift:.3e}",
    )

    print("\nWROTE:")
    print(output_path)

    if passed:
        print(
            "\nPHASE3C3 TARGET EQUIVALENCE: PASS"
        )
    else:
        print(
            "\nPHASE3C3 TARGET EQUIVALENCE: FAIL"
        )
        raise SystemExit(2)



def atomic_npz(
    path: Path,
    arrays: Mapping[str, np.ndarray],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")

    with tmp.open("wb") as f:
        np.savez_compressed(f, **arrays)

    os.replace(tmp, path)


def ebfmi(energy) -> float:
    e = np.asarray(energy, dtype=float).reshape(-1)

    if e.size < 2:
        return float("nan")

    variance = np.var(e, ddof=1)

    if not np.isfinite(variance) or variance <= 0:
        return float("nan")

    return float(
        np.mean(np.diff(e) ** 2) / variance
    )


def original_chain_rng_key(
    seed: int,
    cutoff: int,
    chain_id: int,
):
    return random.split(
        random.PRNGKey(seed + 6000 + cutoff),
        4,
    )[chain_id]


def verify_phase3c3_protocol(root: Path) -> str:
    protocol_path = (
        root
        / "results/phase3c3/"
        "00_PHASE3C3_PROTOCOL_FREEZE.json"
    )

    if not protocol_path.exists():
        raise RuntimeError(
            "Phase 3C.3 protocol freeze is missing."
        )

    actual = sha256(protocol_path)

    if actual != EXPECTED_PROTOCOL_SHA256:
        raise RuntimeError(
            "Phase 3C.3 protocol freeze SHA256 mismatch.\n"
            f"expected={EXPECTED_PROTOCOL_SHA256}\n"
            f"actual={actual}"
        )

    return actual


def load_pilot_config(root: Path):
    path = (
        root
        / "config/"
        "phase3c3_background_scale_pilot_v1.yaml"
    )

    cfg = yaml.safe_load(path.read_text())

    if cfg["transport"]["family"] != "BACKGROUND_SD":
        raise RuntimeError("Frozen transport family mismatch.")

    if float(cfg["transport"]["lambda"]) != LAMBDA:
        raise RuntimeError("Frozen lambda mismatch.")

    if (
        cfg["protocol_freeze"]["sha256"]
        != EXPECTED_PROTOCOL_SHA256
    ):
        raise RuntimeError(
            "Pilot config protocol SHA256 mismatch."
        )

    return path, cfg


def run_phase3c3_preflight(root: Path) -> None:
    protocol_sha = verify_phase3c3_protocol(root)
    _, cfg = load_pilot_config(root)

    cutoff = int(cfg["reference"]["cutoff"])
    seed, args, kwargs = reference_data(
        root,
        cutoff=cutoff,
    )

    # Site names do not depend on using all 50 pairs.
    small_args = (
        args[0][:2, :4],
        args[1][:2, :4],
        args[2][:2, :4],
        jnp.asarray([0, 1]),
        jnp.asarray([0, 1]),
        2,
        2,
    )

    trace = handlers.trace(
        handlers.seed(
            phase3c3_transport_model,
            random.PRNGKey(seed + 94000),
        )
    ).get_trace(
        *small_args,
        **kwargs,
    )

    latent_sites = {
        name
        for name, site in trace.items()
        if site.get("type") == "sample"
        and not site.get("is_observed", False)
    }

    dense_blocks = [
        tuple(
            cfg["mass_matrix"][
                "count_plus_initial_block"
            ]
        ),
        tuple(
            cfg["mass_matrix"]["dynamic_block"]
        ),
        tuple(
            cfg["mass_matrix"][
                "seriousness_block"
            ]
        ),
    ]

    diagonal_sites = set(
        cfg["mass_matrix"]["diagonal_site"]
    )

    configured_latents = set().union(
        *[set(block) for block in dense_blocks],
        diagonal_sites,
    )

    missing = configured_latents - latent_sites
    unconfigured = latent_sites - configured_latents

    expected_observed = {
        "dynamic_sd",
        "base_increment",
    }

    observed_failures = []

    for name in expected_observed:
        site = trace.get(name)

        if site is None:
            observed_failures.append(
                f"{name}: missing"
            )
        elif not site.get("is_observed", False):
            observed_failures.append(
                f"{name}: not observed"
            )

    print(
        "PHASE3C3 PROTOCOL FREEZE VERIFICATION: PASS"
    )
    print("PROTOCOL SHA256:", protocol_sha)

    print("\n=== PHASE 3C.3 MASS-MATRIX PREFLIGHT ===")

    print("\nUNOBSERVED NUTS LATENTS:")
    for name in sorted(latent_sites):
        print(" ", name)

    print("\nDENSE MASS BLOCKS:")
    for block in dense_blocks:
        print(" ", block)

    print("\nDIAGONAL SITES:")
    for name in sorted(diagonal_sites):
        print(" ", name)

    if missing:
        print("\nMISSING CONFIGURED SITES:")
        for name in sorted(missing):
            print(" ", name)

    if unconfigured:
        print("\nUNCONFIGURED LATENTS:")
        for name in sorted(unconfigured):
            print(" ", name)

    if observed_failures:
        print("\nCONDITIONING FAILURES:")
        for msg in observed_failures:
            print(" ", msg)

    passed = bool(
        not missing
        and not unconfigured
        and not observed_failures
    )

    if not passed:
        print("\nPHASE3C3 MASS-MATRIX PREFLIGHT: FAIL")
        raise SystemExit(2)

    print(
        "\nPHASE3C3 MASS-MATRIX PREFLIGHT: PASS"
    )
    print("NO NUTS WAS RUN")


def run_pilot(
    root: Path,
    chain_id: int,
) -> dict:
    # Repeat all preflight checks immediately before
    # the expensive frozen run.
    run_phase3c3_preflight(root)

    protocol_sha = verify_phase3c3_protocol(root)
    config_path, cfg = load_pilot_config(root)

    eq_path = (
        root
        / "results/phase3c3/"
        "01_PHASE3C3_TARGET_EQUIVALENCE.json"
    )

    if not eq_path.exists():
        raise SystemExit(
            "Run --mode equivalence first."
        )

    equivalence = json.loads(eq_path.read_text())

    if not equivalence.get("passed"):
        raise SystemExit(
            "Phase3C3 target equivalence did not pass."
        )

    frozen_chain = int(
        cfg["pilot"]["chain_id"]
    )

    if chain_id != frozen_chain:
        raise SystemExit(
            f"Frozen Pilot permits chain {frozen_chain} only."
        )

    cutoff = int(cfg["reference"]["cutoff"])
    seed, args, kwargs = reference_data(
        root,
        cutoff=cutoff,
    )

    p = cfg["pilot"]

    dense_mass = [
        tuple(
            cfg["mass_matrix"][
                "count_plus_initial_block"
            ]
        ),
        tuple(
            cfg["mass_matrix"]["dynamic_block"]
        ),
        tuple(
            cfg["mass_matrix"][
                "seriousness_block"
            ]
        ),
    ]

    kernel = NUTS(
        phase3c3_transport_model,
        dense_mass=dense_mass,
        target_accept_prob=float(
            p["target_accept_prob"]
        ),
        max_tree_depth=int(
            p["max_tree_depth"]
        ),
        regularize_mass_matrix=bool(
            p["regularize_mass_matrix"]
        ),
    )

    mcmc = MCMC(
        kernel,
        num_warmup=int(p["warmup"]),
        num_samples=int(p["samples"]),
        num_chains=1,
        chain_method="sequential",
        progress_bar=True,
        progress_rate=25,
    )

    started = perf_counter()

    mcmc.run(
        original_chain_rng_key(
            seed,
            cutoff,
            chain_id,
        ),
        *args,
        extra_fields=(
            "diverging",
            "num_steps",
            "accept_prob",
            "energy",
            "potential_energy",
        ),
        **kwargs,
    )

    raw = mcmc.get_samples(
        group_by_chain=True
    )

    extra = mcmc.get_extra_fields(
        group_by_chain=True
    )

    jax.block_until_ready(
        jax.tree.leaves(raw)[0]
    )

    dynamic_sd = raw[
        "phase3c3_dynamic_sd"
    ]

    z = raw["phase3c3_z"]

    scale = (
        dynamic_sd[..., 0]
        / REFERENCE_SCALE
    ) ** LAMBDA

    base_increment = (
        scale[..., None, None] * z
    )

    x_initial = raw["x_initial"]

    x = jnp.concatenate(
        [
            x_initial[..., None],
            x_initial[..., None]
            + jnp.cumsum(
                base_increment,
                axis=-1,
            ),
        ],
        axis=-1,
    )

    samples = dict(raw)

    samples["dynamic_sd"] = dynamic_sd
    samples["base_increment"] = base_increment
    samples["x"] = x
    samples[
        "phase3c3_transport_scale"
    ] = scale

    arrays = {
        name: np.asarray(value)
        for name, value in samples.items()
    }

    arrays.update(
        {
            f"_extra_{name}":
                np.asarray(value)
            for name, value in extra.items()
        }
    )

    divergences = int(
        np.asarray(
            extra["diverging"],
            dtype=bool,
        ).sum()
    )

    finite = all(
        np.isfinite(value).all()
        for value in arrays.values()
    )

    bfmi_value = ebfmi(
        np.asarray(extra["energy"])[0]
    )

    max_tree_depth = int(
        p["max_tree_depth"]
    )

    saturation_threshold = (
        2 ** max_tree_depth - 1
    )

    num_steps = np.asarray(
        extra["num_steps"]
    )[0]

    tree_sat = float(
        np.mean(
            num_steps
            >= saturation_threshold
        )
    )

    accept_mean = float(
        np.mean(
            np.asarray(
                extra["accept_prob"]
            )[0]
        )
    )

    gate = cfg["pilot_gate"]

    passed = bool(
        divergences
        == int(gate["divergences"])
        and finite
        == bool(gate["finite_posterior"])
        and bfmi_value
        >= float(gate["ebfmi_min"])
        and tree_sat
        <= float(
            gate[
                "tree_depth_saturation_rate_max"
            ]
        )
    )

    result_dir = (
        root
        / "results/phase3c3/pilot"
    )

    artifact = (
        result_dir
        / f"BACKGROUND_SD_t{cutoff:02d}"
          f"_chain{chain_id}.npz"
    )

    atomic_npz(
        artifact,
        arrays,
    )

    payload = {
        "version":
            "phase3c3_background_scale_pilot_result_v1",
        "status":
            "PASS_PROMISING"
            if passed
            else "FAIL_NOT_PROMISING",
        "scientific_target_changed": False,
        "protocol_sha256": protocol_sha,
        "pilot_config_sha256":
            sha256(config_path),
        "transport_family":
            "BACKGROUND_SD",
        "lambda": LAMBDA,
        "chain_id": chain_id,
        "cutoff": cutoff,
        "warmup": int(p["warmup"]),
        "samples": int(p["samples"]),
        "target_accept_prob":
            float(p["target_accept_prob"]),
        "max_tree_depth":
            max_tree_depth,
        "dense_mass":
            [list(v) for v in dense_mass],
        "diagonal_site":
            cfg["mass_matrix"][
                "diagonal_site"
            ],
        "divergences":
            divergences,
        "finite_posterior":
            finite,
        "ebfmi":
            bfmi_value,
        "tree_depth_saturation_rate":
            tree_sat,
        "mean_accept_prob":
            accept_mean,
        "elapsed_seconds":
            perf_counter() - started,
        "artifact": {
            "path":
                artifact.relative_to(
                    root
                ).as_posix(),
            "bytes":
                artifact.stat().st_size,
            "sha256":
                sha256(artifact),
        },
        "pilot_gate":
            gate,
        "passed":
            passed,
    }

    atomic_json(
        artifact.with_suffix(".json"),
        payload,
    )

    print(
        json.dumps(
            payload,
            indent=2,
            ensure_ascii=False,
        )
    )

    print(
        "\nPHASE3C3 PILOT:",
        payload["status"],
    )

    return payload


def main() -> None:
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--mode",
        choices=[
            "equivalence",
            "preflight",
            "pilot",
        ],
        required=True,
    )

    parser.add_argument(
        "--chain-id",
        type=int,
        choices=[1],
        default=1,
    )

    parsed = parser.parse_args()

    root = Path(".").resolve()

    if parsed.mode == "equivalence":
        run_equivalence(root)
        return

    if parsed.mode == "preflight":
        run_phase3c3_preflight(root)
        return

    run_pilot(
        root,
        parsed.chain_id,
    )


if __name__ == "__main__":
    main()
