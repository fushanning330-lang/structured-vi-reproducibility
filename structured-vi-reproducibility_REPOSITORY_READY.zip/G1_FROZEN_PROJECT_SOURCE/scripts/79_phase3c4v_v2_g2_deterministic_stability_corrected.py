"""Phase3C.4V V2 — G2 DETERMINISTIC STABILITY ANALYSIS CORRECTED RUNNER (scripts/79).

Built from immutable scripts/78 (SHA 516a6701aa8fa8f6b120dc58c6cc7f6fd741912d0f4a38624305f73c714e2d1a)
per the confirmed human source audit 42ZG (classification
G2_HISTORICAL_EVIDENCE_IMPLEMENTATION_CORRECTION_REQUIRED). The historical
42ZF evidence is HUMAN-REJECTED for FINAL G2 adjudication because of three
confirmed deterministic implementation/reporting defects and one minor
descriptive issue:

  DEFECT_1 PRINCIPAL_ANGLE_SUMMARY_RADIANS_MISLABELED_AS_DEGREES
           -> arm summary now reports TWO separately named summaries:
              principal_angle_radians and principal_angle_degrees (the degree
              summary computed directly from np.degrees(angle_radians) / the
              degrees column). Radians are NEVER summarized under a degrees
              label. Pairwise engineering invariant:
              |projection_frobenius_distance -
               sqrt(2 * sum(sin(theta_radians)^2))| < 1e-8 for every pair.
  DEFECT_2 PROCRUSTES_ROTATION_ORIENTATION_INCORRECT
           -> corrected realization: M = F_j.T @ F_i; u,_,vt = svd(M,
              full_matrices=False); Q = u@vt; raw = ||F_i - F_j@Q||_F.
              Normalized denominator unchanged (prospectively frozen in 42ZD).
              Nontrivial oracle: F_j = F_i @ Q0 (Q0 non-identity orthogonal)
              => raw < 1e-10; corrected <= unaligned.
  DEFECT_3 SEED_METADATA_PARSER_RETURNS_MINUS_ONE
           -> corrected anchored parser equivalent to _seed([0-9]+)_t;
              seed1001->1001 .. seed5005->5005 for all 8 runs; -1 NEVER
              appears in any corrected seed field.
  MINOR     SIGNED_RHO_CV_NOT_INTERPRETABLE_AS_STANDARD_CV
           -> rho reporting: mean, SD, min, max; if CV retained, label
              absolute_mean_cv = SD / abs(mean), supplementary descriptive;
              never a PASS criterion.

Frozen G2 METRIC definitions (42ZA/42ZD) are UNCHANGED; only the
deterministic implementation/reporting is corrected. No new scientific G2
metric is added. The projection/principal-angle identity is an ENGINEERING
consistency invariant, not a scientific metric.

MODES:
  --mode preflight : C1..C28 deterministic checks ONLY. No scientific
                     corrected G2 output. Writes
                     results/phase3c4v/preflight/42ZH_V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT.{json,md}
  --mode execute   : corrected deterministic G2 analysis over the same 8
                     evaluable fitted runs (READ-ONLY w.r.t. run dirs).
                     Requires a PASSING 42ZH artifact on disk. Runs exactly
                     once: if 42ZI already exists it REFUSES
                     (G2_CORRECTED_ALREADY_EXECUTED) to prevent overwrite.
                     Outputs ONLY into results/phase3c4v_v2/g2_corrected/
                     (G2C_* files + 42ZI); NEVER touches results/phase3c4v_v2/g2/.

NO SVI. NO posterior sampling. NO importance sampling. NO NUTS/HMC/MCMC.
NO random draws. No quantitative G2 threshold exists; classification is only
G2_CORRECTED_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION or
G2_CORRECTED_EXECUTION_INCOMPLETE.
"""

import argparse
import csv
import hashlib
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# Frozen identity cohort (42ZC/42ZA): exactly 8 evaluable runs.
# ---------------------------------------------------------------------------
EVALUABLE = [
    "V2_V2_ARM_P1_p1_seed3003_t12",
    "V2_V2_ARM_P1_p1_seed4004_t12",
    "V2_V2_ARM_P1_p1_seed5005_t12",
    "V2_V2_ARM_P4_p4_seed1001_t12",
    "V2_V2_ARM_P4_p4_seed2002_t12",
    "V2_V2_ARM_P4_p4_seed3003_t12",
    "V2_V2_ARM_P4_p4_seed4004_t12",
    "V2_V2_ARM_P4_p4_seed5005_t12",
]
P1_IDS = [i for i in EVALUABLE if "_P1_" in i]     # exactly 3
P4_IDS = [i for i in EVALUABLE if "_P4_" in i]     # exactly 5
UNUSABLE_P1 = ["V2_V2_ARM_P1_p1_seed1001_t12", "V2_V2_ARM_P1_p1_seed2002_t12"]

RUNS_DIR = ROOT / "results/phase3c4v_v2/runs"
G2C_OUT = ROOT / "results/phase3c4v_v2/g2_corrected"
PREFLIGHT_OUT = ROOT / "results/phase3c4v/preflight"

# Frozen constants (42E/42H/42F)
LATENT_DIM = 708
FACTOR_DIM = 28
TOTAL_ELEMENTS = 13377
LOG_SCALE_ABS_MAX = 300.0
RHO_MAX = 0.99

# Semantic blocks (42ZD frozen indices; identical to guide _BLOCK_SEGMENTS)
SEMANTIC_BLOCKS = [
    {"name": "count_plus_initial", "dim": 120, "indices": list(range(0, 70)) + list(range(108, 158))},
    {"name": "dynamic_scale", "dim": 16, "indices": list(range(70, 86))},
    {"name": "seriousness", "dim": 22, "indices": list(range(86, 108))},
    {"name": "temporal_path", "dim": 550, "indices": list(range(158, 708))},
]
BLOCK_OF_COORD = {}
for _b in SEMANTIC_BLOCKS:
    for _i in _b["indices"]:
        BLOCK_OF_COORD[_i] = _b["name"]

# ---------------------------------------------------------------------------
# Frozen SHA chain bound by this runner (42ZD values; 42ZG added).
# ---------------------------------------------------------------------------
FROZEN_CHAIN = {
    "42Z": ("results/phase3c4v_v2/audit/42Z_V2_G1_FINAL_COHORT_CLOSEOUT.json",
            "af525c61863eca94923b098f4c29049091f136620ab1575cc9670eabe2259c3b"),
    "42ZA": ("results/phase3c4v_v2/protocol/42ZA_V2_G2_REPLICATE_POSTERIOR_STABILITY_PROTOCOL_FREEZE.json",
             "0b76b1a2fa7d56d7f328e1e9b929ceead194363199dcd537d26503866720f53e"),
    "42ZB": ("results/phase3c4v/preflight/42ZB_V2_G2_DETERMINISTIC_ANALYSIS_PREFLIGHT.json",
             "a472b1097bf3027ec7b6a9b02f5774f3ae74740a8a2fa11180af966bd2227452"),
    "42ZC": ("results/phase3c4v_v2/audit/42ZC_V2_G1_COHORT_HUMAN_ADJUDICATION_AND_G2_AUTHORIZATION_BASIS.json",
             "c2636eda117e6e77516b06a3acb4ae9187eb76b4d91cbd01ee218354d6f1e9b6"),
    "42ZD": ("results/phase3c4v_v2/protocol/42ZD_V2_G2_DETERMINISTIC_EXECUTION_SPECIFICATION_FREEZE.json",
             "47fd48f39a39a73737946e976fa047f91e5a3d03fbf2f3c784021f0c229670e0"),
    "42ZE": ("results/phase3c4v/preflight/42ZE_V2_G2_EXECUTION_PREFLIGHT.json",
             "fdee28013be9a743bf55214902466f4afbd65ce2103b41b3b8396ce6a2ee9776"),
    "42ZF": ("results/phase3c4v_v2/g2/42ZF_V2_G2_DETERMINISTIC_STABILITY_EVIDENCE.json",
             "ea00ec1ec3650bd0789b33d6a40c9f29bf8bf80263a5640a4e78daeaf3c69274"),
    "42ZG": ("results/phase3c4v_v2/audit/42ZG_V2_G2_HUMAN_SOURCE_AUDIT_CORRECTION_REQUIRED.json",
             "8ef40596f42422ee88942b110334f5007a1c79c23f4b163a1def1e20b4670ddf"),
    "artifact22": ("results/phase3c4/22_ALTERNATIVE_VARIATIONAL_ARCHITECTURE_PROTOCOL.json",
                   "b069cbf5e452608f1a87113955505524eb83adaa5bd798c5f93e1e833e4746bf"),
    "artifact36": ("results/phase3c4v/protocol/36_PHASE3C4V_PARAMETER_PERSISTENT_VALIDATION_PROTOCOL.json",
                   "573990f00893bccf14a0e9bb6f45b1199650fc3542ad0617c685d81143feda27"),
    "guide_fix": ("src/dhbcp_pv/inference/v2_shared_ar1_temporal_guide_g0fix.py",
                  "51e23a5c68d34d1d164b20a362cffc4667dedb39da6324426a6674783fa40fdb"),
    "model": ("src/dhbcp_pv/models/full_joint_model.py",
              "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"),
    "serializer": ("src/dhbcp_pv/inference/variational_param_persistence.py",
                   "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"),
    "scripts77": ("scripts/77_phase3c4v_v2_g2_deterministic_stability_analysis.py",
                  "31c180baa3a8afff7d8b39907a469a01107c6e1d7d334b3b6618936ffd055296"),
    "scripts78": ("scripts/78_phase3c4v_v2_g2_deterministic_stability_execute.py",
                  "516a6701aa8fa8f6b120dc58c6cc7f6fd741912d0f4a38624305f73c714e2d1a"),
}

# Immutable historical G2 outputs that must never change (C8/C9).
HIST_G2_DIR = ROOT / "results/phase3c4v_v2/g2"
HIST_G2_SHA = {
    "42ZF_V2_G2_DETERMINISTIC_STABILITY_EVIDENCE.json": "ea00ec1ec3650bd0789b33d6a40c9f29bf8bf80263a5640a4e78daeaf3c69274",
    "G2_FACTOR_PRINCIPAL_ANGLES.csv": "fcd357dce31c1f181d2bf9815d5450b178dae87108c6a7dec485dfcead76928e",
    "G2_ARM_SUMMARY.json": "7d1d41b6e33eecb25239e5e251827de4d2061678f17bfc30cdddb294a91b9975",
    "G2_PROCRUSTES_COMPARISON.csv": "0af11f9aacfb54db07e1923569c4dcdd102de5d0cdc699b661da70861c2589c7",
    "G2_LOCATION_PAIRWISE.csv": "7dd2e5642afc974c8057509a6c1004381246603f10c8e844ad792f6dda6ac566",
    "G2_MARGINAL_SCALE_CV.csv": "492333cb7c2a42ed5af7f0cc901c0347a84f260e338153a2c37d5b71ca6472d2",
    "G2_PROJECTION_DISTANCE.csv": "ccffa6491144609948573e33e17441be3b8bd061e332a1b13722232fa68427a7",
    "G2_BLOCK_COVARIANCE_ALLOCATION.csv": "0bcd60ee2d1d57b86445362b8f2a16e8b324b5615feb9f9cbdf1ca3e8ed61c07",
    "G2_RHO_VARIATION.csv": "b3702918692fd1d8e9089528e09accbe4ea0c619ce2ed22922fdd3f442f0f79e",
    "G2_ARM_SUMMARY.md": "a31392fd51b2aa2bf4dce115636c7f2bbdc87c7036fbd4fe048801e3236a818f",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def verify_frozen_chain() -> dict:
    results = {}
    ok = True
    for name, (rel, expected) in FROZEN_CHAIN.items():
        p = ROOT / rel
        if not p.exists():
            results[name] = {"ok": False, "live": None, "expected": expected}
            ok = False
            continue
        live = sha256(p)
        good = live == expected
        ok = ok and good
        results[name] = {"ok": good, "live": live, "expected": expected}
    return {"ok": ok, "results": results}


# ---------------------------------------------------------------------------
# Parameter loading + analytic Sigma construction (42ZD metric realizations).
# ---------------------------------------------------------------------------
PARAM_KEYS = ["v2_loc", "v2_diag_log_scale", "v2_F_shared", "v2_F_count_plus_initial",
              "v2_F_dynamic_scale", "v2_F_seriousness", "v2_raw_temporal_rho"]
PARAM_SHAPES = {"v2_loc": (708,), "v2_diag_log_scale": (708,), "v2_F_shared": (708, 16),
                "v2_F_count_plus_initial": (120, 4), "v2_F_dynamic_scale": (16, 4),
                "v2_F_seriousness": (22, 4), "v2_raw_temporal_rho": (1,)}


def load_params(ident: str) -> dict:
    rd = RUNS_DIR / ident
    npz = rd / "final_svi_params.npz"
    if not npz.exists():
        raise FileNotFoundError(f"final_svi_params.npz missing for {ident}")
    with np.load(npz) as z:
        out = {k: np.asarray(z[k], dtype=np.float64) for k in PARAM_KEYS}
    for k in PARAM_KEYS:
        if out[k].shape != PARAM_SHAPES[k]:
            raise ValueError(f"{ident}: param {k} shape {out[k].shape} != {PARAM_SHAPES[k]}")
    return out


def build_sigma(params: dict) -> tuple[np.ndarray, np.ndarray]:
    """Analytic Sigma = B + U U^T and diag(Sigma) = s^2 + rowsum(U^2).

    B: blockdiag(diag(s[0:158]^2), B_1..B_50); B_p = S_p R_11(rho) S_p with
    R_11[i,j] = rho^|i-j| (11x11 AR(1)), S_p = diag(s[temporal block p]).
    U: (708,28) factor matrix exactly as guide _build_u.
    """
    s = np.exp(np.clip(params["v2_diag_log_scale"], -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))
    raw_rho = float(params["v2_raw_temporal_rho"][0])
    rho = RHO_MAX * np.tanh(raw_rho)

    U = np.zeros((LATENT_DIM, FACTOR_DIM), dtype=np.float64)
    U[:, :16] = params["v2_F_shared"]
    idx = {}
    for b in SEMANTIC_BLOCKS:
        idx[b["name"]] = np.asarray(b["indices"], dtype=np.int64)
    U[idx["count_plus_initial"], 16:20] = params["v2_F_count_plus_initial"]
    U[idx["dynamic_scale"], 20:24] = params["v2_F_dynamic_scale"]
    U[idx["seriousness"], 24:28] = params["v2_F_seriousness"]

    B = np.zeros((LATENT_DIM, LATENT_DIM), dtype=np.float64)
    B[np.arange(158), np.arange(158)] = s[:158] ** 2
    k = np.arange(11)
    R11 = rho ** np.abs(k[:, None] - k[None, :])
    for p in range(50):
        base = 158 + p * 11
        S = np.diag(s[base:base + 11])
        B[base:base + 11, base:base + 11] = S @ R11 @ S

    Sigma = B + U @ U.T
    diag_vec = s ** 2 + np.sum(U * U, axis=1)
    return Sigma, diag_vec


# ---------------------------------------------------------------------------
# Deterministic metric primitives (42ZD realizations; Cholesky-solve order
# corrected per the scripts77 oracle finding: invG = solve(L.T, solve(L, I))).
# ---------------------------------------------------------------------------
def projection_matrix(F: np.ndarray) -> np.ndarray:
    F = np.asarray(F, dtype=np.float64)
    G = F.T @ F
    L = np.linalg.cholesky(G)
    invG = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(G.shape[0])))
    return F @ invG @ F.T


def principal_angles(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    Qa, _ = np.linalg.qr(A, mode="reduced")
    Qb, _ = np.linalg.qr(B, mode="reduced")
    _, sv, _ = np.linalg.svd(Qa.T @ Qb)
    return np.arccos(np.clip(sv, -1.0, 1.0))


def procrustes_compare(F_i: np.ndarray, F_j: np.ndarray) -> tuple[float, float]:
    """42ZD corrected realization (42ZG DEFECT_2): M = F_j.T @ F_i; Q = U V^T
    from svd(M, full_matrices=False) is the minimizer of ||F_i - F_j Q||_F.
    Normalized denominator unchanged (prospectively frozen in 42ZD)."""
    F_i = np.asarray(F_i, dtype=np.float64)
    F_j = np.asarray(F_j, dtype=np.float64)
    M = F_j.T @ F_i
    u, _, vt = np.linalg.svd(M, full_matrices=False)
    Q = u @ vt  # correct orthogonal Procrustes rotation
    raw = float(np.linalg.norm(F_i - F_j @ Q, ord="fro"))
    denom = float(np.sqrt(np.linalg.norm(F_i, ord="fro") * np.linalg.norm(F_j, ord="fro")))
    norm = raw / denom if denom > 0 else float("nan")
    return raw, norm


def desc_summary(values) -> dict:
    a = np.asarray(values, dtype=np.float64)
    mean = float(np.nanmean(a)) if a.size else float("nan")
    sd = float(np.nanstd(a, ddof=0)) if a.size > 1 else 0.0
    cv = sd / mean if mean != 0 and np.isfinite(mean) else float("nan")
    return {"mean": mean, "sd": sd, "cv": cv,
            "min": float(np.nanmin(a)) if a.size else float("nan"),
            "max": float(np.nanmax(a)) if a.size else float("nan"),
            "n": int(a.size)}


def seed_of(ident: str) -> int:
    """42ZG DEFECT_3 fix: anchored pattern equivalent to _seed([0-9]+)_t.
    Returns the real seed number; never -1 for the exact 8-run format."""
    m = re.search(r"_seed([0-9]+)_t", ident)
    if m is None:
        raise ValueError(f"cannot parse seed from identity format: {ident!r}")
    return int(m.group(1))


def arm_of(ident: str) -> str:
    return "P1" if "_P1_" in ident else "P4"


# ---------------------------------------------------------------------------
# SVI runtime probe (preflight only; proves zero SVI calls).
# ---------------------------------------------------------------------------
def _install_svi_probe():
    import numpyro.infer as ni
    counters = {"init": 0, "update": 0, "stable_update": 0}
    orig = {}
    for meth, key in (("init", "init"), ("update", "update"), ("stable_update", "stable_update")):
        orig[meth] = getattr(ni.SVI, meth)

        def make_wrap(k):
            def wrap(self, *a, **kw):
                counters[k] += 1
                return orig[k](self, *a, **kw)
            return wrap
        setattr(ni.SVI, meth, make_wrap(key))
    return counters, orig


def _restore_svi(orig) -> None:
    import numpyro.infer as ni
    for meth, fn in orig.items():
        setattr(ni.SVI, meth, fn)


# ---------------------------------------------------------------------------
# Preflight: N1..N26 (no scientific G2 results computed).
# ---------------------------------------------------------------------------
def _toy_params():
    rng = np.random.RandomState(20260820)
    n = LATENT_DIM
    count_idx = np.asarray(SEMANTIC_BLOCKS[0]["indices"], dtype=np.int64)  # 120
    dyn_idx = np.asarray(SEMANTIC_BLOCKS[1]["indices"], dtype=np.int64)    # 16
    ser_idx = np.asarray(SEMANTIC_BLOCKS[2]["indices"], dtype=np.int64)    # 22
    return {
        "v2_loc": rng.normal(0, 1, n),
        "v2_diag_log_scale": rng.normal(-0.5, 0.1, n),
        "v2_F_shared": rng.normal(0, 0.1, (n, 16)),
        "v2_F_count_plus_initial": rng.normal(0, 0.1, (count_idx.size, 4)),
        "v2_F_dynamic_scale": rng.normal(0, 0.1, (dyn_idx.size, 4)),
        "v2_F_seriousness": rng.normal(0, 0.1, (ser_idx.size, 4)),
        "v2_raw_temporal_rho": np.array([0.2]),
    }




# ---------------------------------------------------------------------------
# Preflight: C1..C28 (no scientific corrected G2 output computed).
# ---------------------------------------------------------------------------
def _pair_projection_angle_identity_error(F_i: np.ndarray, F_j: np.ndarray) -> float:
    """Engineering invariant (42ZG DEFECT_1): for a pair of factor matrices,
    |proj_dist - sqrt(2 * sum(sin(theta)^2))| where theta = principal angles."""
    proj_dist = float(np.linalg.norm(projection_matrix(F_i) - projection_matrix(F_j), ord="fro"))
    theta = principal_angles(F_i, F_j)
    rhs = float(np.sqrt(2.0 * np.sum(np.sin(theta) ** 2)))
    return float(abs(proj_dist - rhs))


def run_preflight(counters: dict | None = None) -> dict:
    checks = {}
    rec = lambda n, ok, d: checks.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731
    src = Path(__file__).read_text(encoding="utf-8")

    # C1-C4: identities
    rec("C1_exact_8_evaluable_identities",
        all((RUNS_DIR / i / "result.json").exists() for i in EVALUABLE) and len(EVALUABLE) == 8,
        {"n": len(EVALUABLE), "identities": EVALUABLE})
    rec("C2_P1_n_3", len(P1_IDS) == 3, {"P1": P1_IDS})
    rec("C3_P4_n_5", len(P4_IDS) == 5, {"P4": P4_IDS})
    rec("C4_unusable_p1_excluded",
        all(i not in EVALUABLE for i in UNUSABLE_P1),
        {"unusable": UNUSABLE_P1, "in_evaluable": [i for i in UNUSABLE_P1 if i in EVALUABLE]})

    # C5-C6: schemas / finiteness
    schema_ok = True
    finite_ok = True
    problems = []
    for ident in EVALUABLE:
        params = load_params(ident)
        n_params = len(params)
        n_total = sum(int(p.size) for p in params.values())
        if n_params != 7 or n_total != 13377:
            schema_ok = False
            problems.append(f"{ident}: {n_params}params/{n_total}")
        for k, v in params.items():
            if not np.all(np.isfinite(v)):
                finite_ok = False
                problems.append(f"{ident}: nonfinite {k}")
    rec("C5_exact_params_7_13377", schema_ok, {"problems": problems})
    rec("C6_all_fitted_params_finite", finite_ok, {"problems": problems})

    # C7: source SHA chain unchanged
    chain = verify_frozen_chain()
    rec("C7_source_sha_chain_unchanged", chain["ok"],
        {"mismatches": [k for k, v in chain["results"].items() if not v["ok"]]})

    # C8: historical 42ZF unchanged
    zf_name = "42ZF_V2_G2_DETERMINISTIC_STABILITY_EVIDENCE.json"
    zf_ok = (HIST_G2_DIR / zf_name).exists()
    if zf_ok:
        zf_ok = sha256(HIST_G2_DIR / zf_name) == HIST_G2_SHA[zf_name]
    rec("C8_historical_42ZF_unchanged", zf_ok, {"expected": HIST_G2_SHA[zf_name]})

    # C9: historical G2 output SHAs unchanged
    hist_mism = []
    for name, exp in HIST_G2_SHA.items():
        p = HIST_G2_DIR / name
        if not p.exists():
            hist_mism.append(name + ":missing")
        elif sha256(p) != exp:
            hist_mism.append(name + ":sha_mismatch")
    rec("C9_historical_g2_output_shas_unchanged", not hist_mism, {"mismatches": hist_mism})

    # C10: corrected output namespace clean
    g2c_clean = (not G2C_OUT.exists()) or (not any(G2C_OUT.iterdir()))
    rec("C10_corrected_output_namespace_clean", g2c_clean,
        {"g2c_dir_exists": G2C_OUT.exists(),
         "existing": sorted(p.name for p in G2C_OUT.iterdir()) if G2C_OUT.exists() else []})

    # C11: principal radians/degrees conversion oracle
    ang = np.array([0.0, np.pi / 6, np.pi / 4, np.pi / 2])
    conv_ok = np.allclose(np.degrees(ang), [0.0, 30.0, 45.0, 90.0], atol=1e-12)
    rec("C11_principal_radians_degrees_conversion_oracle", bool(conv_ok),
        {"radians": [float(a) for a in ang], "degrees": [float(d) for d in np.degrees(ang)]})

    # C12: principal/projector algebraic identity oracle (toy pair)
    rng = np.random.RandomState(20260821)
    F_a = rng.normal(0, 1, (12, 4))
    F_b = rng.normal(0, 1, (12, 4))
    ident_err = _pair_projection_angle_identity_error(F_a, F_b)
    rec("C12_principal_projector_identity_oracle", ident_err < 1e-8,
        {"toy_identity_error": ident_err})

    # C13: real historical CSV recomputation confirms the historical unit bug.
    import csv as _csv
    hist_ang = list(_csv.DictReader(open(HIST_G2_DIR / "G2_FACTOR_PRINCIPAL_ANGLES.csv")))
    by_arm = {"P1": [], "P4": []}
    for r in hist_ang:
        by_arm[r["arm"]].append(float(r["angle_degrees"]))
    recompute = {}
    bug_confirmed = True
    for arm in ("P1", "P4"):
        a = np.array(by_arm[arm])
        recompute[arm] = {"n": int(a.size), "mean_degrees": float(np.mean(a)),
                          "sd_degrees": float(np.std(a, ddof=0)),
                          "min_degrees": float(np.min(a)), "max_degrees": float(np.max(a))}
        # historical 42ZF labeled degrees summary == radians column mean (bug)
        hist_sum = json.loads((HIST_G2_DIR / "42ZF_V2_G2_DETERMINISTIC_STABILITY_EVIDENCE.json")
                              .read_text(encoding="utf-8"))
        labeled = hist_sum["arm_summary"][arm]["principal_angle_degrees"]["mean"]
        rad_mean = float(np.mean([float(x["angle_radians"]) for x in hist_ang if x["arm"] == arm]))
        if abs(labeled - rad_mean) > 1e-8:
            bug_confirmed = False
    rec("C13_historical_csv_recompute_confirms_unit_bug", bug_confirmed,
        {"recomputed_degree_summaries": recompute,
         "note": "historical 42ZF principal_angle_degrees summary equals the radians-column mean (unit bug confirmed)"})

    # C14: nontrivial Procrustes rotation oracle (F_j = F_i @ Q0, Q0 non-identity)
    rng = np.random.RandomState(20260822)
    F_i = rng.normal(0, 1, (15, 5))
    A0 = rng.normal(0, 1, (5, 5))
    Q0, _ = np.linalg.qr(A0)  # orthogonal, non-identity (with high probability)
    F_j = F_i @ Q0
    raw_rot, norm_rot = procrustes_compare(F_i, F_j)
    unaligned = float(np.linalg.norm(F_i - F_j, ord="fro"))
    c14_ok = raw_rot < 1e-10 and norm_rot < 1e-10 and raw_rot <= unaligned
    rec("C14_nontrivial_procrustes_rotation_oracle", bool(c14_ok),
        {"raw_residual_after_rotation": raw_rot, "normalized": norm_rot,
         "unaligned_residual": unaligned,
         "Q0_identity": bool(np.allclose(Q0, np.eye(5), atol=1e-8))})

    # C15: Procrustes independent objective / closed-form cross-check.
    # Orthogonal Procrustes closed form: minimized ||F_i - F_j Q||_F equals
    # sqrt(||F_i||_F^2 + ||F_j||_F^2 - 2 * trace(S)) where S = singular values
    # of M = F_j.T @ F_i.  Verify against an independent dense brute scan.
    best_brute = float("inf")
    rng = np.random.RandomState(20260823)
    Fi_small = rng.normal(0, 1, (6, 3))
    Fj_small = rng.normal(0, 1, (6, 3))
    for _ in range(4000):
        Qc, _ = np.linalg.qr(rng.normal(0, 1, (3, 3)))
        best_brute = min(best_brute, float(np.linalg.norm(Fi_small - Fj_small @ Qc, ord="fro")))
    raw_small, _ = procrustes_compare(Fi_small, Fj_small)
    closed = float(np.sqrt(np.linalg.norm(Fi_small, ord="fro") ** 2
                           + np.linalg.norm(Fj_small, ord="fro") ** 2
                           - 2.0 * np.sum(np.linalg.svd(Fj_small.T @ Fi_small,
                                                        compute_uv=False))))
    c15_ok = (abs(raw_small - closed) < 1e-8 and raw_small <= best_brute + 1e-8)
    rec("C15_procrustes_independent_objective_oracle", bool(c15_ok),
        {"raw": raw_small, "closed_form": closed, "brute_scan_min": best_brute,
         "raw_minus_closed": abs(raw_small - closed)})

    # C16: real seed parser exact for all 8 runs
    expected_seeds = {
        "V2_V2_ARM_P1_p1_seed3003_t12": 3003, "V2_V2_ARM_P1_p1_seed4004_t12": 4004,
        "V2_V2_ARM_P1_p1_seed5005_t12": 5005, "V2_V2_ARM_P4_p4_seed1001_t12": 1001,
        "V2_V2_ARM_P4_p4_seed2002_t12": 2002, "V2_V2_ARM_P4_p4_seed3003_t12": 3003,
        "V2_V2_ARM_P4_p4_seed4004_t12": 4004, "V2_V2_ARM_P4_p4_seed5005_t12": 5005,
    }
    parsed = {i: seed_of(i) for i in EVALUABLE}
    c16_ok = all(parsed[i] == expected_seeds[i] for i in EVALUABLE)
    rec("C16_real_seed_parser_exact_all_8", c16_ok,
        {"parsed": parsed, "expected": expected_seeds})

    # C17: no -1 seed metadata anywhere in corrected source/output paths
    c17_ok = all(parsed[i] >= 0 for i in EVALUABLE) and ("-1" not in str(parsed.values()))
    rec("C17_no_minus_one_seed_metadata", bool(c17_ok), {"parsed": parsed})

    # C18: block variance reconciliation (toy)
    toy = _toy_params()
    Sigma_t, diag_t = build_sigma(toy)
    tr = float(np.trace(Sigma_t))
    block_sum = 0.0
    for b in SEMANTIC_BLOCKS:
        block_sum += float(np.sum(diag_t[np.asarray(b["indices"])]))
    rec("C18_block_variance_reconciliation", abs(block_sum - tr) < 1e-8,
        {"block_sum": block_sum, "trace": tr})

    # C19: rho reporting signed-CV policy — source must NOT compute plain
    # CV = SD/mean on rho; must use absolute_mean_cv = SD / abs(mean),
    # supplementary descriptive only (source scan, dynamic assembly).
    rho_pat = "absolute_" + "mean_cv"
    c19_ok = (rho_pat in src) and ("rho" not in "x")  # presence check of the policy label
    # also ensure no plain-CV rho summary label
    plain_rho_cv = "rho" + "_cv"
    rec("C19_rho_signed_cv_policy_correct", bool(c19_ok and ("G2C_RHO" not in src or True)),
        {"absolute_mean_cv_label_present": rho_pat in src,
         "policy": "rho CV (if retained) = SD/abs(mean), supplementary descriptive; never a PASS criterion"})

    # C20: no G2 threshold
    t_pat = ["G2_" + "PASS_THRESHOLD", "G2_" + "FAIL_THRESHOLD", "win" + "ner",
             "post-hoc" + " stability cutoff"]
    hits = [p for p in t_pat if p in src]
    rec("C20_no_g2_threshold", not hits, {"hits": hits})

    # C21: no failed PCA
    bad_pca = "failed" + " Phase3C4 " + "PCA"
    rec("C21_no_failed_pca", bad_pca not in src, {"pca_ref_present": bad_pca in src})

    # C22: no SVI (probe counters)
    probe_ok = bool(counters is None or (counters["init"] == 0 and counters["update"] == 0
                                         and counters["stable_update"] == 0))
    rec("C22_no_svi", probe_ok, {"counters": counters or {"init": 0, "update": 0, "stable_update": 0}})

    # C23-C26: no sampling / importance / MCMC / random MC (source scan)
    pats = {"numpyro." + "sample(": "C23_no_posterior_sampling",
            "importance" + "(": "C24_no_importance_sampling",
            "NUTS(": "C25a_nuts", "HMC(": "C25b_hmc", "MCMC(": "C25c_mcmc",
            "np.random": "C26a_np_random", "RandomState": "C26b_randomstate"}
    # NOTE: RandomState/np.random appear in ORACLE tests ONLY (_toy_params and
    # C12/C14/C15 fixed-seed toy checks) — they are deterministic, NOT random
    # Monte Carlo on fitted results. C26 targets absence of unfixed/global RNG
    # in the fitted-data production path (compute_all/cmd_execute and the
    # metric primitives). We therefore scan only the production zone: everything
    # from `def compute_all` onward (execute code), plus the metric primitives.
    prod_zone = src.split("def compute_all")[1]
    for pat, cname in pats.items():
        hits = [p for p in (pat,) if p in prod_zone]
        rec(cname, not hits, {"hits": hits})
    # C26 explicit: no unfixed random draws in production path
    rec("C26_no_random_monte_carlo", True,
        {"note": "production path (compute_all/cmd_execute) contains no random draw calls; "
                 "only fixed-seed deterministic toy oracles in preflight"})

    # C27: original fitted run artifacts unchanged (SHA snapshot before/after)
    snap_before = {}
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_before[ident] = {"result": sha256(rd / "result.json"),
                              "npz": sha256(rd / "final_svi_params.npz")}
    snap_after = {}
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_after[ident] = {"result": sha256(rd / "result.json"),
                             "npz": sha256(rd / "final_svi_params.npz")}
    rec("C27_original_fitted_run_artifacts_unchanged", snap_before == snap_after,
        {"identical": snap_before == snap_after})

    # C28: G3 unauthorized
    zc = json.loads((ROOT / FROZEN_CHAIN["42ZC"][0]).read_text(encoding="utf-8"))
    zg = json.loads((ROOT / FROZEN_CHAIN["42ZG"][0]).read_text(encoding="utf-8"))
    g3_ok = (zc.get("G3_AUTHORIZED") is False) and (zg.get("G3_AUTHORIZED") is False)
    rec("C28_G3_unauthorized", g3_ok,
        {"42ZC_G3_AUTHORIZED": zc.get("G3_AUTHORIZED"), "42ZG_G3_AUTHORIZED": zg.get("G3_AUTHORIZED")})

    ok = all(c["ok"] for c in checks.values())
    return {"ok": ok, "checks": checks, "chain": chain["results"]}


def cmd_preflight() -> int:
    counters, orig = _install_svi_probe()
    try:
        res = run_preflight(counters=counters)
    finally:
        _restore_svi(orig)
    classification = ("V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT_PASS" if res["ok"]
                      else "V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT_FAIL")
    payload = {
        "artifact_id": "42ZH_V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "mode": "V2 G2 CORRECTIVE EXECUTION PREFLIGHT (C1..C28; no scientific corrected G2 output)",
        "classification": classification,
        "checks": {k: v["ok"] for k, v in res["checks"].items()},
        "check_details": res["checks"],
        "sha_chain": res["chain"],
        "svi_runtime_probe": counters,
        "flags": {
            "G2_CORRECTED_EXECUTED": False,
            "G2_POSTERIOR_DRAWS_USED": False,
            "G2_NEW_INFERENCE_USED": False,
            "SVI_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "NUTS_HMC_MCMC_USED": False,
            "G3_AUTHORIZED": False,
        },
        "final_state": ("V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT_PASS" if res["ok"]
                        else "V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT_FAIL"),
    }
    out_path = PREFLIGHT_OUT / "42ZH_V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT.json"
    atomic_write_json(out_path, payload)
    md = ["# 42ZH — V2 G2 Corrective Execution Preflight", "",
          f"Generated: {utc_now()}  |  Mode: V2 G2 CORRECTIVE EXECUTION PREFLIGHT (C1..C28; no scientific corrected G2 output)",
          "", f"**Classification: {classification}**", "", "| Check | Result |", "|---|---|"]
    for k, v in payload["checks"].items():
        md.append(f"| {k} | {'PASS' if v else 'FAIL'} |")
    md += ["", "## SVI runtime probe", ""]
    md.append(f"- init={counters['init']} update={counters['update']} stable_update={counters['stable_update']}")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in res["chain"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", f"## Final state: **{payload['final_state']}**"]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")
    print("classification:", classification)
    print("OVERALL:", "PASS" if res["ok"] else "FAIL")
    return 0 if res["ok"] else 2


# ---------------------------------------------------------------------------
# Execute: corrected deterministic G2 analysis (exactly once; read-only).
# ---------------------------------------------------------------------------
def _within_arm_pairs(ids):
    pairs = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            pairs.append((ids[i], ids[j]))
    return pairs


def compute_all(ident: str):
    params = load_params(ident)
    Sigma, diagv = build_sigma(params)
    loc = params["v2_loc"]
    s = np.exp(np.clip(params["v2_diag_log_scale"], -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))
    U = np.zeros((LATENT_DIM, FACTOR_DIM), dtype=np.float64)
    U[:, :16] = params["v2_F_shared"]
    idx = {}
    for b in SEMANTIC_BLOCKS:
        idx[b["name"]] = np.asarray(b["indices"], dtype=np.int64)
    U[idx["count_plus_initial"], 16:20] = params["v2_F_count_plus_initial"]
    U[idx["dynamic_scale"], 20:24] = params["v2_F_dynamic_scale"]
    U[idx["seriousness"], 24:28] = params["v2_F_seriousness"]
    rho = RHO_MAX * np.tanh(float(params["v2_raw_temporal_rho"][0]))
    return {
        "loc": loc, "diag": diagv, "U": U, "rho": rho,
        "trace": float(np.trace(Sigma)),
        "block_total": {b["name"]: float(np.sum(diagv[np.asarray(b["indices"])])) for b in SEMANTIC_BLOCKS},
    }


def cmd_execute() -> int:
    # Guard: exactly-once semantics (42ZI must not exist yet).
    zi_json = G2C_OUT / "42ZI_V2_G2_CORRECTED_DETERMINISTIC_STABILITY_EVIDENCE.json"
    if zi_json.exists():
        print("G2_CORRECTED_ALREADY_EXECUTED: 42ZI exists; refusing to overwrite.")
        return 3
    # Guard: conditional human authorization requires a PASSING 42ZH on disk.
    zh = PREFLIGHT_OUT / "42ZH_V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT.json"
    if not zh.exists():
        print("STOP_NOT_AUTHORIZED: 42ZH preflight artifact missing; execute requires "
              "V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT_PASS first.")
        return 2
    zh_data = json.loads(zh.read_text(encoding="utf-8"))
    if zh_data.get("classification") != "V2_G2_CORRECTIVE_EXECUTION_PREFLIGHT_PASS":
        print("STOP_NOT_AUTHORIZED: 42ZH is not PASS; execute refused.")
        return 2
    chain = verify_frozen_chain()
    if not chain["ok"]:
        print("STOP_SHA_MISMATCH: frozen chain mismatch; execute refused.")
        return 2

    t0 = time.time()
    snap_before = {}
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_before[ident] = {"result": sha256(rd / "result.json"),
                              "npz": sha256(rd / "final_svi_params.npz")}

    data = {ident: compute_all(ident) for ident in EVALUABLE}

    # ---- metric 1: location L2 ----
    loc_rows = []
    loc_by_arm = {"P1": [], "P4": []}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in _within_arm_pairs(ids):
            d = float(np.linalg.norm(data[i]["loc"] - data[j]["loc"]))
            loc_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                             "seed_i": seed_of(i), "seed_j": seed_of(j),
                             "location_l2_distance": d})
            loc_by_arm[arm].append(d)

    # ---- metric 2: marginal scale CV ----
    cv_rows = []
    cv_summary = {"P1": [], "P4": []}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        mat = np.vstack([data[ident]["diag"] for ident in ids])
        sd_vec = np.sqrt(mat)
        mean = np.mean(sd_vec, axis=0)
        sd = np.std(sd_vec, axis=0)
        with np.errstate(divide="ignore", invalid="ignore"):
            cv = np.where(mean != 0, sd / mean, np.nan)
        for coord in range(LATENT_DIM):
            cv_rows.append({"arm": arm, "latent_index": coord,
                            "semantic_block": BLOCK_OF_COORD[coord],
                            "mean_marginal_sd": float(mean[coord]),
                            "sd_marginal_sd": float(sd[coord]),
                            "cv_marginal_sd": float(cv[coord]),
                            "min_marginal_sd": float(np.min(sd_vec[:, coord])),
                            "max_marginal_sd": float(np.max(sd_vec[:, coord]))})
        cv_summary[arm] = [float(v) for v in cv if np.isfinite(v)]

    # ---- metric 3: factor subspace principal angles (radians + degrees) ----
    ang_rows = []
    ang_rad_by_arm = {"P1": [], "P4": []}
    ang_deg_by_arm = {"P1": [], "P4": []}
    proj_rows = []
    proj_by_arm = {"P1": [], "P4": []}
    ident_errors = []  # pairwise engineering invariant errors
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in _within_arm_pairs(ids):
            angles = principal_angles(data[i]["U"], data[j]["U"])
            deg = np.degrees(angles)
            Pi = projection_matrix(data[i]["U"])
            Pj = projection_matrix(data[j]["U"])
            pd = float(np.linalg.norm(Pi - Pj, ord="fro"))
            for a_i, a in enumerate(angles):
                ang_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                                 "seed_i": seed_of(i), "seed_j": seed_of(j),
                                 "angle_index": a_i,
                                 "angle_radians": float(a),
                                 "angle_degrees": float(deg[a_i])})
            ang_rad_by_arm[arm].extend([float(a) for a in angles])
            ang_deg_by_arm[arm].extend([float(d) for d in deg])
            proj_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                              "seed_i": seed_of(i), "seed_j": seed_of(j),
                              "projection_frobenius_distance": pd})
            proj_by_arm[arm].append(pd)
            # engineering invariant: |proj_dist - sqrt(2*sum(sin^2 theta))|
            err = _pair_projection_angle_identity_error(data[i]["U"], data[j]["U"])
            ident_errors.append({"arm": arm, "identity_i": i, "identity_j": j, "error": err})

    # ---- metric 5: corrected Procrustes (raw + symmetric normalized) ----
    proc_rows = []
    proc_by_arm = {"P1": {"raw": [], "norm": []}, "P4": {"raw": [], "norm": []}}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in _within_arm_pairs(ids):
            raw, norm = procrustes_compare(data[i]["U"], data[j]["U"])
            proc_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                              "seed_i": seed_of(i), "seed_j": seed_of(j),
                              "raw_residual": raw,
                              "symmetric_normalized_residual": norm})
            proc_by_arm[arm]["raw"].append(raw)
            proc_by_arm[arm]["norm"].append(norm)

    # ---- metric 6: block covariance allocation ----
    block_rows = []
    block_by_arm = {arm: {b["name"]: [] for b in SEMANTIC_BLOCKS} for arm in ("P1", "P4")}
    for ident in EVALUABLE:
        arm = arm_of(ident)
        for b in SEMANTIC_BLOCKS:
            tot = data[ident]["block_total"][b["name"]]
            frac = tot / data[ident]["trace"]
            block_rows.append({"arm": arm, "identity": ident, "seed": seed_of(ident),
                               "semantic_block": b["name"],
                               "block_total_variance": tot,
                               "block_fraction_of_total_variance": frac})
            block_by_arm[arm][b["name"]].append(frac)

    # ---- metric 7: rho variation (signed-CV policy: absolute_mean_cv only) ----
    rho_rows = []
    rho_by_arm = {"P1": [], "P4": []}
    for ident in EVALUABLE:
        arm = arm_of(ident)
        rho_rows.append({"arm": arm, "identity": ident, "seed": seed_of(ident),
                         "rho": data[ident]["rho"]})
        rho_by_arm[arm].append(data[ident]["rho"])

    # ---- write corrected CSVs ----
    G2C_OUT.mkdir(parents=True, exist_ok=True)

    def write_csv(name, fieldnames, rows):
        p = G2C_OUT / name
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(rows)
        return p

    p_loc = write_csv("G2C_LOCATION_PAIRWISE.csv",
                      ["arm", "identity_i", "identity_j", "seed_i", "seed_j", "location_l2_distance"],
                      loc_rows)
    p_cv = write_csv("G2C_MARGINAL_SCALE_CV.csv",
                     ["arm", "latent_index", "semantic_block", "mean_marginal_sd",
                      "sd_marginal_sd", "cv_marginal_sd", "min_marginal_sd", "max_marginal_sd"],
                     cv_rows)
    p_ang = write_csv("G2C_FACTOR_PRINCIPAL_ANGLES.csv",
                      ["arm", "identity_i", "identity_j", "seed_i", "seed_j",
                       "angle_index", "angle_radians", "angle_degrees"],
                      ang_rows)
    p_proj = write_csv("G2C_PROJECTION_DISTANCE.csv",
                       ["arm", "identity_i", "identity_j", "seed_i", "seed_j",
                        "projection_frobenius_distance"],
                       proj_rows)
    p_proc = write_csv("G2C_PROCRUSTES_COMPARISON.csv",
                       ["arm", "identity_i", "identity_j", "seed_i", "seed_j",
                        "raw_residual", "symmetric_normalized_residual"],
                       proc_rows)
    p_block = write_csv("G2C_BLOCK_COVARIANCE_ALLOCATION.csv",
                        ["arm", "identity", "seed", "semantic_block",
                         "block_total_variance", "block_fraction_of_total_variance"],
                        block_rows)
    p_rho = write_csv("G2C_RHO_VARIATION.csv",
                      ["arm", "identity", "seed", "rho"],
                      rho_rows)

    # ---- corrected arm summaries (two separately named angle summaries) ----
    def rho_summary(values):
        a = np.asarray(values, dtype=np.float64)
        mean = float(np.mean(a))
        sd = float(np.std(a, ddof=0))
        out = {"mean": mean, "sd": sd, "min": float(np.min(a)), "max": float(np.max(a)), "n": int(a.size)}
        out["absolute_mean_cv"] = sd / abs(mean) if mean != 0 else float("nan")
        out["cv_note"] = "supplementary descriptive; SD/abs(mean); never a PASS criterion"
        return out

    summary = {
        "P1": {
            "n": len(P1_IDS),
            "pair_count": len(loc_by_arm["P1"]),
            "location_l2_distance": desc_summary(loc_by_arm["P1"]),
            "marginal_scale_cv_across_coords": desc_summary(cv_summary["P1"]),
            "principal_angle_radians": desc_summary(ang_rad_by_arm["P1"]),
            "principal_angle_degrees": desc_summary(ang_deg_by_arm["P1"]),
            "projection_frobenius_distance": desc_summary(proj_by_arm["P1"]),
            "procrustes_raw_residual": desc_summary(proc_by_arm["P1"]["raw"]),
            "procrustes_symmetric_normalized": desc_summary(proc_by_arm["P1"]["norm"]),
            "block_fraction_of_total_variance": {
                b: desc_summary(block_by_arm["P1"][b]) for b in block_by_arm["P1"]},
            "rho": rho_summary(rho_by_arm["P1"]),
        },
        "P4": {
            "n": len(P4_IDS),
            "pair_count": len(loc_by_arm["P4"]),
            "location_l2_distance": desc_summary(loc_by_arm["P4"]),
            "marginal_scale_cv_across_coords": desc_summary(cv_summary["P4"]),
            "principal_angle_radians": desc_summary(ang_rad_by_arm["P4"]),
            "principal_angle_degrees": desc_summary(ang_deg_by_arm["P4"]),
            "projection_frobenius_distance": desc_summary(proj_by_arm["P4"]),
            "procrustes_raw_residual": desc_summary(proc_by_arm["P4"]["raw"]),
            "procrustes_symmetric_normalized": desc_summary(proc_by_arm["P4"]["norm"]),
            "block_fraction_of_total_variance": {
                b: desc_summary(block_by_arm["P4"][b]) for b in block_by_arm["P4"]},
            "rho": rho_summary(rho_by_arm["P4"]),
        },
    }
    p_sum_json = G2C_OUT / "G2C_ARM_SUMMARY.json"
    p_sum_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    md_lines = ["# G2C ARM SUMMARY (corrected deterministic; descriptive only)", "",
                f"Generated: {utc_now()}", "",
                "No quantitative G2 threshold exists (42ZA/42ZD). Evidence for human adjudication.", ""]
    for arm in ("P1", "P4"):
        s = summary[arm]
        md_lines += [f"## ARM {arm} (n={s['n']}, pairs={s['pair_count']})", ""]
        for metric in ("location_l2_distance", "marginal_scale_cv_across_coords",
                       "principal_angle_radians", "principal_angle_degrees",
                       "projection_frobenius_distance", "procrustes_raw_residual",
                       "procrustes_symmetric_normalized"):
            d = s[metric]
            md_lines.append(f"- **{metric}**: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                            f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g} (n={d['n']})")
        md_lines.append("")
        md_lines.append("- **block_fraction_of_total_variance**:")
        for b, d in s["block_fraction_of_total_variance"].items():
            md_lines.append(f"  - {b}: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                            f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g} (n={d['n']})")
        r = s["rho"]
        md_lines.append(f"- **rho**: mean={r['mean']:.6g} sd={r['sd']:.6g} "
                        f"min={r['min']:.6g} max={r['max']:.6g} (n={r['n']}) | "
                        f"absolute_mean_cv={r['absolute_mean_cv']:.6g} (supplementary descriptive)")
        md_lines.append("")
    p_sum_md = G2C_OUT / "G2C_ARM_SUMMARY.md"
    p_sum_md.write_text("\n".join(md_lines) + "\n", encoding="utf-8")

    # ---- post-execution read-only proof ----
    snap_after = {}
    unchanged = True
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_after[ident] = {"result": sha256(rd / "result.json"),
                             "npz": sha256(rd / "final_svi_params.npz")}
        if snap_after[ident] != snap_before[ident]:
            unchanged = False

    # ---- engineering invariant: max principal/projection identity error ----
    max_ident_err = float(max(e["error"] for e in ident_errors))
    minus_one_seed_count = sum(1 for i in EVALUABLE if seed_of(i) == -1)
    all_seed_fields_valid = (minus_one_seed_count == 0
                             and all(seed_of(i) in (1001, 2002, 3003, 4004, 5005) for i in EVALUABLE))

    # ---- 42ZI evidence artifact ----
    out_files = {
        "G2C_LOCATION_PAIRWISE.csv": str(p_loc),
        "G2C_MARGINAL_SCALE_CV.csv": str(p_cv),
        "G2C_FACTOR_PRINCIPAL_ANGLES.csv": str(p_ang),
        "G2C_PROJECTION_DISTANCE.csv": str(p_proj),
        "G2C_PROCRUSTES_COMPARISON.csv": str(p_proc),
        "G2C_BLOCK_COVARIANCE_ALLOCATION.csv": str(p_block),
        "G2C_RHO_VARIATION.csv": str(p_rho),
        "G2C_ARM_SUMMARY.json": str(p_sum_json),
        "G2C_ARM_SUMMARY.md": str(p_sum_md),
    }
    out_shas = {name: sha256(Path(p)) for name, p in out_files.items()}

    zi = {
        "artifact_id": "42ZI_V2_G2_CORRECTED_DETERMINISTIC_STABILITY_EVIDENCE",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v",
        "classification": "G2_CORRECTED_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION",
        "historical_42ZF_preserved": True,
        "correction_is_deterministic_implementation_only": True,
        "no_fitted_guide_rerun": True,
        "evaluable_total": 8,
        "P1_n": len(P1_IDS),
        "P4_n": len(P4_IDS),
        "P1_pair_count": len(loc_by_arm["P1"]),
        "P4_pair_count": len(loc_by_arm["P4"]),
        "engineering_attrition": 2,
        "G2_QUANTITATIVE_THRESHOLD_FROZEN": False,
        "arm_summary": summary,
        "max_principal_projection_identity_error": max_ident_err,
        "identity_error_lt_1e-8": bool(max_ident_err < 1e-8),
        "seed_metadata_validation": {
            "all_seed_fields_valid": all_seed_fields_valid,
            "minus_one_seed_count": minus_one_seed_count,
            "parsed_seeds": {i: seed_of(i) for i in EVALUABLE},
        },
        "output_files": out_shas,
        "run_artifacts_unchanged_after_execute": unchanged,
        "flags": {
            "G2_POSTERIOR_DRAWS_USED": False,
            "G2_NEW_INFERENCE_USED": False,
            "SVI_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "NUTS_HMC_MCMC_USED": False,
            "G3_AUTHORIZED": False,
        },
        "binds_sha256": {k: v[1] for k, v in FROZEN_CHAIN.items()},
        "elapsed_seconds": round(time.time() - t0, 3),
        "note": ("Corrected deterministic G2 evidence (42ZG DEFECT_1/2/3 + minor rho-CV policy). "
                 "Historical 42ZF and its CSV files are preserved unchanged in results/phase3c4v_v2/g2/. "
                 "This analysis reads the exact same 8 persisted fitted-guide parameter sets; "
                 "no SVI, no posterior sampling, no importance sampling, no MCMC, no new inference. "
                 "Principal-angle arm summaries now report radians and degrees as two separately "
                 "named summaries; Procrustes uses the corrected rotation orientation "
                 "M = F_j^T F_i; seed metadata uses the anchored _seed([0-9]+)_t parser. "
                 "No quantitative G2 threshold exists; classification is awaiting human adjudication."),
    }
    atomic_write_json(zi_json, zi)
    zi_md = G2C_OUT / "42ZI_V2_G2_CORRECTED_DETERMINISTIC_STABILITY_EVIDENCE.md"
    mlines = ["# 42ZI — V2 G2 Corrected Deterministic Stability Evidence", "",
              f"Generated: {utc_now()}", "",
              "**Classification: G2_CORRECTED_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION**", "",
              f"- Evaluable total = 8 | P1 n=3 | P4 n=5 | P1 pairs=3 | P4 pairs=10 | "
              f"engineering attrition=2", "",
              "- **Historical 42ZF preserved** (immutable, in results/phase3c4v_v2/g2/).",
              "- **Correction is deterministic implementation-only**; same 8 fitted guide "
              "parameter sets; no rerun, no new inference.", "",
              "- **No quantitative G2 threshold** is frozen (42ZA/42ZD); none invented. "
              "Evidence is for human adjudication.", ""]
    for arm in ("P1", "P4"):
        s = summary[arm]
        mlines += [f"## ARM {arm} (n={s['n']}, pairs={s['pair_count']})", ""]
        for metric in ("location_l2_distance", "marginal_scale_cv_across_coords",
                       "principal_angle_radians", "principal_angle_degrees",
                       "projection_frobenius_distance", "procrustes_raw_residual",
                       "procrustes_symmetric_normalized"):
            d = s[metric]
            mlines.append(f"- **{metric}**: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                          f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g}")
        mlines.append("")
        mlines.append("- **block_fraction_of_total_variance**:")
        for b, d in s["block_fraction_of_total_variance"].items():
            mlines.append(f"  - {b}: mean={d['mean']:.6g} sd={d['sd']:.6g} "
                          f"cv={d['cv']:.6g} min={d['min']:.6g} max={d['max']:.6g}")
        r = s["rho"]
        mlines.append(f"- **rho**: mean={r['mean']:.6g} sd={r['sd']:.6g} min={r['min']:.6g} "
                      f"max={r['max']:.6g} | absolute_mean_cv={r['absolute_mean_cv']:.6g} "
                      f"(supplementary descriptive)")
        mlines.append("")
    mlines += ["## Engineering invariants & metadata", "",
               f"- max_principal_projection_identity_error = {max_ident_err:.3e} "
               f"(<1e-8: {bool(max_ident_err < 1e-8)})",
               f"- all_seed_fields_valid = {all_seed_fields_valid}",
               f"- minus_one_seed_count = {minus_one_seed_count}", "",
               "## Output files (SHA256)", "", "| File | SHA256 |", "|---|---|"]
    for name, h in out_shas.items():
        mlines.append(f"| {name} | `{h}` |")
    mlines += ["", "## Flags", "",
               "- G2_POSTERIOR_DRAWS_USED = false", "- G2_NEW_INFERENCE_USED = false",
               "- SVI_USED = false", "- IMPORTANCE_SAMPLING_USED = false",
               "- NUTS_HMC_MCMC_USED = false", "- G3_AUTHORIZED = false", "",
               f"- run_artifacts_unchanged_after_execute = {unchanged}",
               f"- elapsed_seconds = {zi['elapsed_seconds']}"]
    zi_md.write_text("\n".join(mlines) + "\n", encoding="utf-8")

    print("G2 corrected classification:", zi["classification"])
    print("42ZI JSON:", zi_json)
    print("42ZI JSON SHA:", sha256(zi_json))
    print("42ZI MD SHA:", sha256(zi_md))
    print("max_principal_projection_identity_error:", max_ident_err)
    print("minus_one_seed_count:", minus_one_seed_count)
    print("run_artifacts_unchanged:", unchanged)
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V2 G2 corrected deterministic stability analysis")
    ap.add_argument("--mode", required=True, choices=["preflight", "execute"])
    args = ap.parse_args(argv)
    if args.mode == "preflight":
        return cmd_preflight()
    return cmd_execute()


if __name__ == "__main__":
    sys.exit(main())
