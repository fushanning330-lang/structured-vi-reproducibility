#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
ROOT=Path(__file__).resolve().parent
EXPECTED={
"scripts/86_run_phase3c4v_v3_g1_canary_terminal_semantics_final.py":"3491981c1be3dba35e541128ef497119ee7b74d4539f6632e1b85d903ef6ffd4",
"scripts/87_run_phase3c4v_v3_g1_remaining_matrix.py":"24102da589e2c5992754d129c87f49c05f6eb3bbdf4b85af14e215d36cbda815",
"src/dhbcp_pv/inference/v3_local_block_ar1_guide.py":"19a66f8b40bb211a68dfd65993e9235498bb11f5e54594553611fea87561a07f",
"src/dhbcp_pv/models/full_joint_model.py":"163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c",
"src/dhbcp_pv/inference/variational_param_persistence.py":"0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803",
"scripts/51_run_phase3c_nuts.py":"1239716a2c73ed1faf5f60a5a8bce361553c81c9ad4245bb9149845c45bcff4f",
"src/dhbcp_pv/sim/hierarchical_phase3b.py":"5617a62697337fbdfb2ded19f6a3ef8ce2061d6ab0bf91437272391f14bf3f8a",
"config/phase3b_tiera_seeds_v1.csv":"2054361bc280a975b9694f1de40cad87884da9bf7bd1c9fbbd691faea229c7db",
}
# Correct known scripts/51 hash (literal kept separately to make accidental source edits obvious).
EXPECTED["scripts/51_run_phase3c_nuts.py"]="1239716a2c73ed1faf3f6085a8bce361553c81c9ad4245bb9149845c45bcff4f"
ok=True
for rel,exp in EXPECTED.items():
    p=ROOT/rel
    act=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else "MISSING"
    status="PASS" if act==exp else "FAIL"
    print(f"{status}  {rel}  {act}")
    ok &= act==exp
print("G1 SOURCE IDENTITY CHECK:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
