# Structured Variational Inference Reproducibility Archive

This repository accompanies the manuscript:

**From factor-space instability to reliable structured variational inference: replicate diagnostics, covariance reproducibility, and computational scaling with a pharmacovigilance application**

Author: **Shanning Fu**  
ORCID: **0009-0007-3280-7991**

## Purpose

The repository provides the author-generated code, frozen derived data, source-identity manifests, and reproduction scripts supporting the manuscript. It is intended for transparent inspection and reproduction of publication-facing outputs.

The complete submission-facing code/data archive is:

`archive/S2_File_Derived_Data_and_Code_V8_8_0.zip`

Raw FDA AEMS/FAERS source extracts are not redistributed. The supplied archive contains derived numerical data and the frozen source needed for the reported analyses.

## Reproduction scope

After extracting the S2 archive, the original publication-output route is:

```bash
python reproduce_plos_outputs.py --data-dir . --output-dir reproduced_outputs
```

Minimal dependencies for this route are listed in `requirements.txt` inside the S2 archive.

This reproduces the publication-facing derived outputs for:

- Tables 1–5
- Figures 3–5
- Supporting Figures S1–S6

Figures 1–2 are conceptual schematics and are not numerically regenerated.

## Computational extension (V8.8.0)

The additive `AI_COMPUTER_EXTENSION` directory in the S2 archive contains the frozen computational extension:

- **E1:** structured-vs-dense sample + logq kernel scaling benchmark
- **E2:** deterministic covariance-structure ablation on six known targets
- **E3:** deterministic rank-capacity truncation ablation
- **E4:** d=708 numerical-conditioning stress benchmark

Publication mapping:

- Fig 6A–B → E1 scalability benchmark
- Fig 6C → E2 structural ablation
- Fig 6D → E3 rank-capacity ablation
- Table 6 → E4 numerical-conditioning benchmark

## Frozen-result boundaries

No parent application G1 fit and no original 239 Module B simulation fit was rerun for the V8.8.0 computational extension. The original frozen application and simulation results remain unchanged.

The following interpretation boundaries apply:

- P1/P4 application comparisons are descriptive only.
- Representation reproducibility, covariance reproducibility, and known-target accuracy are distinct evidence layers.
- The synthetic benchmark is a well-specified known-target calibration, not a misspecification stress test.
- E1 is a computational-kernel benchmark, not an end-to-end FAERS runtime benchmark.
- E2/E3 are controlled in-family representational ablations.
- E4 is a numerical-conditioning stress test, not a model-misspecification test.

## Integrity verification

The S2 archive contains:

- `SHA256_MANIFEST.json` for the parent release
- `AI_EXTENSION_SHA256_MANIFEST.json` for the computational extension
- `G1_FROZEN_PROJECT_SOURCE/SOURCE_IDENTITY_MANIFEST.csv`
- `G1_FROZEN_PROJECT_SOURCE/verify_g1_source_hashes.py`

The SHA256 of the deposited S2 ZIP is recorded in `S2_SHA256.txt` in this repository.

## Software environment

The manuscript reports the software versions used for the original and extension workflows. The archive also contains frozen requirements and reproduction-specific dependencies.

## Data and code availability

All author-generated analysis code and derived data needed for the publication-facing reproduction route are provided in this public repository and in the manuscript's S2 Supporting Information file.

## License

No open-source license has been assigned in this repository package. Licensing is an author-controlled legal choice and can be added separately if desired.
