"""Phase3C.4V V3 — G3 COVARIANCE CONSEQUENCE DETERMINISTIC EXECUTION RUNNER (scripts/92).

Independent G3 deterministic executor implementing the FROZEN G3 protocol
(43U V3_G3_COVARIANCE_CONSEQUENCE_PROTOCOL_FREEZE, classification
V3_G3_COVARIANCE_CONSEQUENCE_PROTOCOL_FROZEN_PRE_IMPLEMENTATION) motivated by
43T (G2_EVIDENCE_COMPLETE_STABILITY_CONCERNS).

G3 scientific question (the ONLY question):
  Do the seed-dependent local-factor subspace differences observed in G2
  materially propagate to differences in the FINAL IMPLIED covariance Sigma_V3?

G3 analysis object: Sigma_V3 itself and its frozen decomposition
  Sigma_i = B_i + L_i,  B_i = B_AR1_i,  L_i = U_local_i @ U_local_i.T

G3 is NOT a factor-orientation re-analysis. No new model redesign, no new
inference, no new optimization, no posterior draws, no sampling, no IS, no PCA,
no NUTS/HMC/MCMC. G3 is deterministic analytic reconstruction from persisted
fitted V3 parameters ONLY (Sigma_V3 = B_AR1 + U_local U_local.T).

SOURCE EQUIVALENCE (reused frozen mathematics from scripts/91, which is
UNCHANGED, SHA e1d89cc98a43d4b381d80142148286f5e7790bfe011622d4572a4ad77c0bbc52):
  - canonical_raw_rho_scalar        (43O canonicalization)
  - load_params                     (persisted NPZ schema validation)
  - build_u_local                   (708x12 U_local embedding)
  - build_sigma_components          (s, U, rho, diag_vec)
  - build_ar1_dense / build_lowrank_dense / build_sigma_dense
                                    (B_AR1 and L = U U.T construction; Sigma = B + L)
  - SEMANTIC_BLOCKS                 (four frozen block index sets)
  - within_arm_pairs                (within-arm unordered ALL pairs)
  - sha256 / atomic_write_json / verify_frozen_chain
These reused implementations are copied verbatim from scripts91 (no scientific
semantic change); static source-equivalence is audited in the preflight.

MODES:
  --mode preflight (alias --preflight)
      ZERO-REAL-COMPUTE validation ONLY. Runs synthetic engineering tests
      G3T1..G3T11 (fabricated arrays ONLY) plus ZERO-SCIENTIFIC-COMPUTATION
      metadata checks (file existence, hashes, manifests, frozen chain incl.
      all G2 evidence hashes, no forbidden inference, no forbidden executor
      labels, no real fitted-value arithmetic in preflight). NO real G3 metric
      is computed from real fitted parameters. Writes
      results/phase3c4v_v3/preflight/V3_G3_COVARIANCE_CONSEQUENCE_PREFLIGHT_V1.{json,md}.
      SAFETY: if the DISTINCT G3 authorization
      (V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZATION.json) already
      exists, --preflight is REFUSED
      (STOP_PREFLIGHT_AFTER_G3_AUTHORIZATION, exit code 4) so the negative
      execute tests cannot enter the real scientific path.
  --mode execute (alias --execute)
      Real G3 covariance-consequence scientific execution. FORBIDDEN unless
      BOTH (a) a PASSING G3 preflight V1 artifact on disk AND (b) the DISTINCT
      G3 authorization artifact
      results/phase3c4v_v3/authorizations/V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZATION.json
      with {"V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZED": true}.
      The Attempt-1 scripts89 G2 authorization, the Attempt-2 scripts90 G2
      repaired authorization, and the Attempt-3 scripts91 G2 output-path
      repaired authorization are ALL HISTORICAL_CONSUMED and NOT sufficient for
      scripts92. Absent -> STOP_NOT_AUTHORIZED. Runs exactly once (refuses if
      43W evidence already exists).
      This PACKAGE DOES NOT create the G3 authorization and DOES NOT run real
      --execute.

Default invocation (no args): prints usage and runs NOTHING scientific.

G3 machine classification policy (43U section F):
  The executor may output ONLY
    G3_COVARIANCE_CONSEQUENCE_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION
  or
    G3_COVARIANCE_CONSEQUENCE_EXECUTION_INCOMPLETE
  The executor must NEVER output: stable, unstable, acceptable, unacceptable,
  PASS, FAIL, negligible, material (as scientific labels). Final scientific
  interpretation is by ChatGPT human adjudication ONLY. No automatic scientific
  threshold exists or is invented.
"""

import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# Frozen V3 G3 evaluable cohort (identical to G2; 43U section D).
# ---------------------------------------------------------------------------
EVALUABLE = [
    "V3_V3_ARM_P1_p1_seed1001_t12",
    "V3_V3_ARM_P1_p1_seed2002_t12",
    "V3_V3_ARM_P1_p1_seed3003_t12",
    "V3_V3_ARM_P1_p1_seed5005_t12",
    "V3_V3_ARM_P4_p4_seed1001_t12",
    "V3_V3_ARM_P4_p4_seed2002_t12",
    "V3_V3_ARM_P4_p4_seed3003_t12",
    "V3_V3_ARM_P4_p4_seed4004_t12",
    "V3_V3_ARM_P4_p4_seed5005_t12",
]
P1_IDS = [i for i in EVALUABLE if "_P1_" in i]     # exactly 4
P4_IDS = [i for i in EVALUABLE if "_P4_" in i]     # exactly 5
ENGINEERING_LOSS_P1 = ["V3_V3_ARM_P1_p1_seed4004_t12"]  # RUN_STARTED only; MUST_NOT_RERUN

RUNS_DIR = ROOT / "results/phase3c4v_v3/runs"
G2_OUT = ROOT / "results/phase3c4v_v3/g2"
G3_OUT = ROOT / "results/phase3c4v_v3/g3"
PREFLIGHT_OUT = ROOT / "results/phase3c4v_v3/preflight"
AUTH_DIR = ROOT / "results/phase3c4v_v3/authorizations"

# ---------------------------------------------------------------------------
# Authorization gate (43U section H).
# scripts92 requires a DISTINCT, new G3 authorization. The Attempt-1/2/3 G2
# authorizations are HISTORICAL_CONSUMED and invalid for scripts92 even if they
# still contain true.
# ---------------------------------------------------------------------------
OLD_AUTH_FILE = AUTH_DIR / "V3_G2_REAL_EXECUTION_AUTHORIZATION.json"
REPAIRED_AUTH_FILE = AUTH_DIR / "V3_G2_POST_FAILURE_REPAIRED_EXECUTION_AUTHORIZATION.json"
OUTPUT_PATH_REPAIRED_AUTH_FILE = AUTH_DIR / "V3_G2_OUTPUT_PATH_REPAIRED_EXECUTION_AUTHORIZATION.json"
G3_AUTH_FILE = AUTH_DIR / "V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZATION.json"
G3_AUTH_KEY = "V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZED"

# Frozen architecture constants (V3_LOCAL_BLOCK_AR1_NO_SHARED).
LATENT_DIM = 708
FACTOR_DIM = 12            # V3: NO F_shared; three rank-4 local families
FAMILY_RANK = 4
TOTAL_ELEMENTS = 2049      # 708 + 708 + 480 + 64 + 88 + 1
LOG_SCALE_ABS_MAX = 300.0
RHO_MAX = 0.99

# Semantic blocks (frozen in 43N/43O; identical to V3 guide _BLOCK_SEGMENTS)
SEMANTIC_BLOCKS = [
    {"name": "count_plus_initial", "dim": 120, "indices": list(range(0, 70)) + list(range(108, 158))},
    {"name": "dynamic_scale", "dim": 16, "indices": list(range(70, 86))},
    {"name": "seriousness", "dim": 22, "indices": list(range(86, 108))},
    {"name": "temporal_path", "dim": 550, "indices": list(range(158, 708))},
]
BLOCK_OF_COORD = {}
for _b in SEMANTIC_BLOCKS:
    for _i in _b["indices"]:
        BLOCK_OF_COORD[_i] = _b["name"]

# Frozen V3 persisted parameter schema (43N/43O; scripts87 V3_PARAM_SHAPES)
PARAM_KEYS = ["v3_loc", "v3_diag_log_scale", "v3_F_count_plus_initial",
              "v3_F_dynamic_scale", "v3_F_seriousness", "v3_raw_temporal_rho"]
PARAM_SHAPES = {"v3_loc": (708,), "v3_diag_log_scale": (708,),
                "v3_F_count_plus_initial": (120, 4), "v3_F_dynamic_scale": (16, 4),
                "v3_F_seriousness": (22, 4), "v3_raw_temporal_rho": (1,)}

# ---------------------------------------------------------------------------
# G3 frozen SHA chain (43U section L): binds scientific model, V3 guide,
# serializer, scripts87, 43N-43Q, scripts91, 43S, 43T, 43U, the Attempt-3 G2
# authorization SHA, the Attempt-3 terminal record SHA, and ALL 43S output-file
# (G2 CSV) hashes. Any live mismatch -> package incomplete -> STOP.
# ---------------------------------------------------------------------------
G3_FROZEN_CHAIN = {
    "model": ("src/dhbcp_pv/models/full_joint_model.py",
              "163c86e5708d1ed895e8cfb72ff4ff0332ea9cd0c1d2140a9dd66985f72c6a7c"),
    "guide_v3": ("src/dhbcp_pv/inference/v3_local_block_ar1_guide.py",
                 "19a66f8b40bb211a68dfd65993e9235498bb11f5e54594553611fea87561a07f"),
    "serializer": ("src/dhbcp_pv/inference/variational_param_persistence.py",
                   "0a89624c875da48b5b918cfe6974ff95319d8ff57bf6a31c699035b6d2ac8803"),
    "scripts87": ("scripts/87_run_phase3c4v_v3_g1_remaining_matrix.py",
                  "24102da589e2c5992754d129c87f49c05f6eb3bbdf4b85af14e215d36cbda815"),
    "43N": ("results/phase3c4v_v3/audit/43N_V3_G2_ADAPTIVE_STABILITY_PROTOCOL_REFREEZE.json",
            "a1dfe7a9d1b41c30443f9f71f16e805c41eae934ca3983cc99953ca6246cb1ba"),
    "43O": ("results/phase3c4v_v3/audit/43O_V3_G2_DETERMINISTIC_SPECIFICATION_CLARIFICATION_FREEZE.json",
            "4547b218ea765b950aa0ef3e4735bf0b41bc8bc92f4a790341a5821ea7733082"),
    "43P": ("results/phase3c4v_v3/audit/43P_V3_G2_PRE_IMPLEMENTATION_PROTOCOL_AMENDMENT_FREEZE.json",
            "c96adfdd773c686adba6360e4e1e85834c331cfc813e10215be1f0fe959e8e8a"),
    "43Q": ("results/phase3c4v_v3/audit/43Q_V3_G2_FINAL_ALGEBRAIC_CLARIFICATION_FREEZE.json",
            "f06c142b9aef404f45966f4fa6238ad246cc0aef6a4a86b292d2eded68dfd637"),
    "scripts91": ("scripts/91_phase3c4v_v3_g2_deterministic_stability_execute.py",
                  "e1d89cc98a43d4b381d80142148286f5e7790bfe011622d4572a4ad77c0bbc52"),
    "43S": ("results/phase3c4v_v3/g2/43S_V3_G2_DETERMINISTIC_STABILITY_EVIDENCE.json",
            "6d9c351aaff3a182feb2c229b1f9fadfd9a2bc61af68246423c2654d92c64a71"),
    "43T": ("results/phase3c4v_v3/audit/43T_V3_G2_HUMAN_STABILITY_ADJUDICATION.json",
            "d67fe1b89a418fcb51d5f0e51b1322373c01a9700848a4f77ee738502014c6ac"),
    "43T_MD": ("results/phase3c4v_v3/audit/43T_V3_G2_HUMAN_STABILITY_ADJUDICATION.md",
               "5625f54afba60532077ad7c26a3d7d3764777ffc4aef1ca7c58816d7c52cea38"),
    "43U": ("results/phase3c4v_v3/audit/43U_V3_G3_COVARIANCE_CONSEQUENCE_PROTOCOL_FREEZE.json",
            "d137460a7a51ce33cef2a1cb9d6abe916dddfd09ae65497aa84d4db59811fd29"),
    "43U_MD": ("results/phase3c4v_v3/audit/43U_V3_G3_COVARIANCE_CONSEQUENCE_PROTOCOL_FREEZE.md",
               "6ba4db437fc5822a22f47e593aa9834680d465ca0e9717b8bee0a444975e5287"),
    "attempt3_authorization": ("results/phase3c4v_v3/authorizations/V3_G2_OUTPUT_PATH_REPAIRED_EXECUTION_AUTHORIZATION.json",
                               "a228e4848786b3ed51a485f0a5a14202696a26d6be2359fbd9ab2bcca938f526"),
    "attempt3_terminal_record": ("results/phase3c4v_v3/g2_output_path_repaired_execute_terminal_record.txt",
                                 "d8baa177ce94bbbbcc05db6b1dd95d7cdfabc12fd4449363f54e66a3f4a3153f"),
    "G2_LOCATION_PAIRWISE.csv": ("results/phase3c4v_v3/g2/G2_LOCATION_PAIRWISE.csv",
                                 "7d0677dcecf24747a44e3a92e568bfc93d6ab40f5413c9ab89c1d87715990107"),
    "G2_MARGINAL_SCALE_CV.csv": ("results/phase3c4v_v3/g2/G2_MARGINAL_SCALE_CV.csv",
                                 "73f596a841b792612991bcf3d9c6af8aed411dbc40ed69d841a89d6182b07175"),
    "G2_FACTOR_PRINCIPAL_ANGLES.csv": ("results/phase3c4v_v3/g2/G2_FACTOR_PRINCIPAL_ANGLES.csv",
                                       "e470931fb7980522858ef676269dbe1bc0250c65e9136bda034d606d32c048a6"),
    "G2_PROJECTION_DISTANCE.csv": ("results/phase3c4v_v3/g2/G2_PROJECTION_DISTANCE.csv",
                                   "6c1cf4e6f572cc05bad907e093ec3952b640477602b65e062998b01fbdef9c5e"),
    "G2_PROCRUSTES_COMPARISON.csv": ("results/phase3c4v_v3/g2/G2_PROCRUSTES_COMPARISON.csv",
                                     "d954aea7217f104889b86b49bba605f6e195be5e136b29d0b8847d80dd4df3df"),
    "G2_BLOCK_COVARIANCE_ALLOCATION.csv": ("results/phase3c4v_v3/g2/G2_BLOCK_COVARIANCE_ALLOCATION.csv",
                                           "8d42f173f2a549e587d2d674c0545a9e56e725e986e26e24049d7614c80c9ccf"),
    "G2_BLOCK_DELTA_ALLOCATION.csv": ("results/phase3c4v_v3/g2/G2_BLOCK_DELTA_ALLOCATION.csv",
                                      "fcb87cc87a16a9462c4c0ff7592a108305638afb2efdcc7b3fbc59be17d2d1f0"),
    "G2_RHO_VARIATION.csv": ("results/phase3c4v_v3/g2/G2_RHO_VARIATION.csv",
                             "d3aecad5f8ef405393ba7c966b6098bd79156d6fa8ee14045522a6cd8fe39b23"),
    "G2_DELTA_RHO_PAIRWISE.csv": ("results/phase3c4v_v3/g2/G2_DELTA_RHO_PAIRWISE.csv",
                                  "b3b808a9ff9cd754f998dd77b0e3ccde0a17dc6b74b2bd3ad4f6f8c6e878a890"),
}

# Prospective numerical tolerances (x64 machine-precision appropriate).
# These are IMPLEMENTATION tolerances only - NOT scientific stability thresholds.
ABS_TOL = 1e-10
REL_TOL = 1e-8

# Real-execution gate. This package MUST keep this True and the G3
# authorization artifact MUST remain absent, so --execute is refused.
EXECUTION_AUTHORIZATION_REQUIRED = True

# Zero-compute proof counters. Incremented ONLY in the real scientific path
# (load_params / G3 metric computation); printed at Gate-1 refusal so the
# --execute negative-gate test can deterministically prove 0 real computation.
_FITTED_PARAM_LOADS = 0
_SCIENTIFIC_METRIC_CALLS = 0


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


# ---------------------------------------------------------------------------
# REUSED FROZEN MATHEMATICS FROM SCRIPTS91 (source-equivalent; no semantic
# change): canonical_raw_rho_scalar, load_params, build_u_local,
# build_sigma_components, build_ar1_dense, build_lowrank_dense,
# build_sigma_dense, SEMANTIC_BLOCKS indexing, within_arm_pairs, sha256 chain.
# ---------------------------------------------------------------------------
def canonical_raw_rho_scalar(x) -> np.ndarray:
    """Frozen 43O canonicalization: () or (1,) -> 0-d scalar via reshape.

    Raises ValueError for any other shape. NO [0] indexing after reshape.
    """
    a = np.asarray(x, dtype=np.float64)
    if a.shape not in ((), (1,)):
        raise ValueError(f"v3_raw_temporal_rho must be scalar () or one-element (1,); got shape {a.shape}")
    return np.reshape(a, ())


def load_params(ident: str) -> dict:
    """Load a persisted V3 parameter mapping (NPZ), validating the frozen schema.

    READ-ONLY w.r.t. the run directory. Never samples. Shape-checked.
    """
    global _FITTED_PARAM_LOADS
    _FITTED_PARAM_LOADS += 1
    rd = RUNS_DIR / ident
    npz = rd / "final_svi_params.npz"
    if not npz.exists():
        raise FileNotFoundError(f"final_svi_params.npz missing for {ident}")
    with np.load(npz, allow_pickle=False) as z:
        missing = [k for k in PARAM_KEYS if k not in z.files]
        if missing:
            raise ValueError(f"{ident}: missing keys {missing}")
        out = {k: np.asarray(z[k], dtype=np.float64) for k in PARAM_KEYS}
    for k in PARAM_KEYS:
        if out[k].shape != PARAM_SHAPES[k]:
            raise ValueError(f"{ident}: param {k} shape {out[k].shape} != {PARAM_SHAPES[k]}")
    if not all(np.all(np.isfinite(v)) for v in out.values()):
        raise ValueError(f"{ident}: non-finite parameter value present")
    return out


def build_u_local(params: dict) -> np.ndarray:
    """Embedded V3 factor matrix U_local (708, 12).

    cols [0:4] = F_count_plus_initial (120 rows)
    cols [4:8] = F_dynamic_scale       (16 rows)
    cols [8:12]= F_seriousness         (22 rows)
    NO F_shared. NO temporal low-rank factor.
    """
    U = np.zeros((LATENT_DIM, FACTOR_DIM), dtype=np.float64)
    idx = {}
    for b in SEMANTIC_BLOCKS:
        idx[b["name"]] = np.asarray(b["indices"], dtype=np.int64)
    U[idx["count_plus_initial"], 0:4] = params["v3_F_count_plus_initial"]
    U[idx["dynamic_scale"], 4:8] = params["v3_F_dynamic_scale"]
    U[idx["seriousness"], 8:12] = params["v3_F_seriousness"]
    return U


def build_sigma_components(params: dict) -> tuple[np.ndarray, np.ndarray, float, np.ndarray]:
    """Return (s, U_local, rho, diag_vec) for the frozen V3 covariance.

    s = exp(clip(v3_diag_log_scale, -300, 300))
    U_local = build_u_local(params)
    rho = 0.99 * tanh(canonical_raw_rho_scalar(v3_raw_temporal_rho))
    diag_vec[i] = s[i]**2 + ||U_local[i,:]||^2  == diag(B_AR1 + U U^T)
    """
    s = np.exp(np.clip(params["v3_diag_log_scale"], -LOG_SCALE_ABS_MAX, LOG_SCALE_ABS_MAX))
    U = build_u_local(params)
    raw = canonical_raw_rho_scalar(params["v3_raw_temporal_rho"])
    rho = RHO_MAX * float(np.tanh(raw))
    diag_vec = s ** 2 + np.sum(U * U, axis=1)
    return s, U, rho, diag_vec


def build_ar1_dense(params: dict) -> np.ndarray:
    """B_AR1_i: 708x708 frozen AR1 covariance block (rho = 0.99*tanh(raw))."""
    s, _, rho, _ = build_sigma_components(params)
    B = np.zeros((LATENT_DIM, LATENT_DIM), dtype=np.float64)
    B[np.arange(158), np.arange(158)] = s[:158] ** 2
    k = np.arange(11)
    R11 = rho ** np.abs(k[:, None] - k[None, :])
    for p in range(50):
        base = 158 + p * 11
        S = np.diag(s[base:base + 11])
        B[base:base + 11, base:base + 11] = S @ R11 @ S
    return B


def build_lowrank_dense(params: dict) -> np.ndarray:
    """L_i = U_local_i @ U_local_i.T (rank <= 12 local low-rank component)."""
    U = build_u_local(params)
    return U @ U.T


def build_sigma_dense(params: dict) -> np.ndarray:
    """Dense 708x708 Sigma_V3 = B_AR1 + U_local U_local.T."""
    return build_ar1_dense(params) + build_lowrank_dense(params)


def within_arm_pairs(ids):
    pairs = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            pairs.append((ids[i], ids[j]))
    return pairs


def desc_summary(values) -> dict:
    """Frozen 42ZA-style summary over finite values (mean, SD ddof=0, CV, min, max, n)."""
    a = np.asarray(values, dtype=np.float64)
    a = a[np.isfinite(a)]
    n = int(a.size)
    if n == 0:
        return {"mean": float("nan"), "sd": float("nan"), "cv": float("nan"),
                "min": float("nan"), "max": float("nan"), "n": 0}
    mean = float(np.mean(a))
    sd = float(np.std(a, ddof=0))
    cv = sd / mean if mean != 0 and np.isfinite(mean) else float("nan")
    return {"mean": mean, "sd": sd, "cv": cv,
            "min": float(np.min(a)), "max": float(np.max(a)), "n": n}


def seed_of(ident: str) -> int:
    """Strict deterministic seed parser (Repair B). Raises ValueError if malformed."""
    for tok in ident.split("_"):
        if tok.startswith("seed") and tok[4:].isdigit():
            return int(tok[4:])
    raise ValueError(f"malformed identity: no seedXXXX token in {ident!r}")


def arm_of(ident: str) -> str:
    return "P1" if "_P1_" in ident else "P4"


def verify_frozen_chain() -> dict:
    results = {}
    ok = True
    for name, (rel, expected) in G3_FROZEN_CHAIN.items():
        p = ROOT / rel
        if not p.exists():
            results[name] = {"ok": False, "live": None, "expected": expected}
            ok = False
            continue
        live = sha256(p)
        good = (live == expected) if len(expected) == 64 else (live.startswith(expected))
        ok = ok and good
        results[name] = {"ok": good, "live": live, "expected": expected}
    return {"ok": ok, "results": results}


# ---------------------------------------------------------------------------
# G3 Metrics (FROZEN in 43U section E - must not be altered).
# All metrics are human-adjudication evidence ONLY; no automatic threshold.
# ---------------------------------------------------------------------------
def g3_metric1_sigma_relative_frobenius(Si: np.ndarray, Sj: np.ndarray) -> dict:
    """Metric 1: D_Sigma_F(i,j) = ||Si-Sj||_F / (0.5*(||Si||_F+||Sj||_F)).

    No epsilon. If denominator <= 0 -> deterministic_abort.
    Also records absolute_Frobenius_distance = ||Si-Sj||_F.
    """
    num = float(np.linalg.norm(Si - Sj, ord="fro"))
    denom = 0.5 * (float(np.linalg.norm(Si, ord="fro")) + float(np.linalg.norm(Sj, ord="fro")))
    if denom <= 0.0:
        return {"deterministic_abort": True}
    return {"deterministic_abort": False,
            "relative_frobenius": float(num / denom),
            "absolute_frobenius": num}


def g3_metric2_correlation_consequence(Si: np.ndarray, Sj: np.ndarray) -> dict:
    """Metric 2: R = D^(-1/2) S D^(-1/2); strict upper triangle RMSE + max_abs.

    All diagonal entries must be > 0 (NO epsilon fallback). Diagonal EXCLUDED.
    """
    di = np.diag(Si)
    dj = np.diag(Sj)
    if not (np.all(di > 0.0) and np.all(dj > 0.0)):
        return {"deterministic_abort": True}
    Ri = Si / np.sqrt(di)[:, None] / np.sqrt(di)[None, :]
    Rj = Sj / np.sqrt(dj)[:, None] / np.sqrt(dj)[None, :]
    iu = np.triu_indices(Si.shape[0], k=1)
    diff = Ri[iu] - Rj[iu]
    rmse = float(np.sqrt(np.mean(diff ** 2)))
    max_abs = float(np.max(np.abs(diff)))
    return {"deterministic_abort": False,
            "correlation_rmse": rmse,
            "max_abs_correlation_difference": max_abs}


def g3_metric3_spectrum(Si: np.ndarray) -> dict:
    """Metric 3 per-run: eigvalsh(Si), descending, trace-normalized spectrum.

    Checks symmetry / finite / PSD numerical tolerance (diagnostic only).
    NO silent eigenvalue clipping as scientific correction.
    """
    sym_ok = bool(np.allclose(Si, Si.T, atol=REL_TOL * max(1.0, float(np.max(np.abs(Si))))))
    fin_ok = bool(np.all(np.isfinite(Si)))
    lam = np.linalg.eigvalsh(Si)          # ascending
    lam_desc = lam[::-1]                   # descending
    tr = float(np.sum(lam_desc))
    if tr <= 0.0:
        return {"deterministic_abort": True}
    p = lam_desc / tr
    return {"deterministic_abort": False,
            "symmetry_ok": sym_ok,
            "finite_ok": fin_ok,
            "psd_min_eigval": float(lam_desc[-1]),
            "lambda_max": float(lam_desc[0]),
            "lambda_min": float(lam_desc[-1]),
            "trace": tr,
            "spectral_concentration": float(np.sum(p ** 2)),
            "p": p}


def g3_metric3_spectrum_distance(spec_i: dict, spec_j: dict) -> dict:
    """Metric 3 pairwise: spectrum_L2_distance = ||p_i - p_j||_2."""
    pi = spec_i["p"]
    pj = spec_j["p"]
    return {"deterministic_abort": False,
            "spectrum_l2_distance": float(np.linalg.norm(pi - pj, ord=2))}


def g3_metric4_block_relative_frobenius(Si: np.ndarray, Sj: np.ndarray,
                                        idx_b: np.ndarray) -> dict:
    """Metric 4: blockwise relative Frobenius on Sigma[np.ix_(idx_B, idx_B)].

    No epsilon. If denominator <= 0 -> deterministic_abort.
    """
    A = Si[np.ix_(idx_b, idx_b)]
    Bm = Sj[np.ix_(idx_b, idx_b)]
    num = float(np.linalg.norm(A - Bm, ord="fro"))
    denom = 0.5 * (float(np.linalg.norm(A, ord="fro")) + float(np.linalg.norm(Bm, ord="fro")))
    if denom <= 0.0:
        return {"deterministic_abort": True}
    return {"deterministic_abort": False,
            "block_relative_frobenius": float(num / denom)}


def g3_metric5_per_run(params: dict) -> dict:
    """Metric 5 per-run: B_i + L_i decomposition, trace shares, L Frobenius ratio.

    Verifies Sigma_i == B_i + L_i to x64 implementation tolerance.
    low_rank_trace_share + AR1_trace_share ~= 1 (no normalization trick).
    NOTE: this helper is shared by synthetic tests and the real path; the real
    computation counter is incremented ONLY in cmd_execute, never here.
    """
    S = build_sigma_dense(params)
    B = build_ar1_dense(params)
    L = build_lowrank_dense(params)
    maxdiff = float(np.max(np.abs(S - (B + L))))
    scale = max(1.0, float(np.max(np.abs(S))))
    eq_ok = bool(maxdiff <= REL_TOL * scale)
    trS = float(np.trace(S))
    trB = float(np.trace(B))
    trL = float(np.trace(L))
    if trS <= 0.0:
        return {"deterministic_abort": True}
    lr_share = trL / trS
    ar1_share = trB / trS
    froS = float(np.linalg.norm(S, ord="fro"))
    froL = float(np.linalg.norm(L, ord="fro"))
    return {"deterministic_abort": False,
            "sigma_equals_B_plus_L": eq_ok,
            "max_abs_decomposition_diff": maxdiff,
            "trace": trS,
            "low_rank_trace_share": lr_share,
            "ar1_trace_share": ar1_share,
            "trace_share_sum": lr_share + ar1_share,
            "low_rank_frobenius_ratio": float(froL / froS) if froS > 0.0 else float("nan")}


def g3_metric5_pairwise(Bi: np.ndarray, Bj: np.ndarray, Li: np.ndarray, Lj: np.ndarray) -> dict:
    """Metric 5 pairwise: relative_Frobenius_B and relative_Frobenius_L.

    Same symmetric denominator ||X_i-X_j||_F / (0.5*(||X_i||_F+||X_j||_F)).
    No epsilon; denominator <= 0 -> deterministic_abort.
    """
    numB = float(np.linalg.norm(Bi - Bj, ord="fro"))
    denB = 0.5 * (float(np.linalg.norm(Bi, ord="fro")) + float(np.linalg.norm(Bj, ord="fro")))
    numL = float(np.linalg.norm(Li - Lj, ord="fro"))
    denL = 0.5 * (float(np.linalg.norm(Li, ord="fro")) + float(np.linalg.norm(Lj, ord="fro")))
    if denB <= 0.0 or denL <= 0.0:
        return {"deterministic_abort": True}
    return {"deterministic_abort": False,
            "relative_frobenius_B": float(numB / denB),
            "relative_frobenius_L": float(numL / denL)}


# ---------------------------------------------------------------------------
# Real scientific execution (cmd_execute) - FORBIDDEN during this package.
# ---------------------------------------------------------------------------
def cmd_execute() -> int:
    global _FITTED_PARAM_LOADS, _SCIENTIFIC_METRIC_CALLS
    print("G3_EXECUTE_DISPATCH_REACHED_CMD_EXECUTE")
    # ---- Gate 1: DISTINCT G3 authorization (REQUIRED) ----
    if EXECUTION_AUTHORIZATION_REQUIRED:
        auth_ok = False
        if G3_AUTH_FILE.exists():
            try:
                auth = json.loads(G3_AUTH_FILE.read_text(encoding="utf-8"))
                auth_ok = auth.get(G3_AUTH_KEY) is True
            except Exception:  # noqa: BLE001
                auth_ok = False
        if not auth_ok:
            print("STOP_NOT_AUTHORIZED: real G3 covariance-consequence execution requires the "
                  "DISTINCT G3 authorization artifact "
                  "(V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZATION.json with "
                  "V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZED=true). The Attempt-1 "
                  "scripts89 G2 authorization, the Attempt-2 scripts90 G2 repaired "
                  "authorization, and the Attempt-3 scripts91 G2 output-path repaired "
                  "authorization are HISTORICAL_CONSUMED and NOT sufficient for scripts92.")
            print(f"ZERO_COMPUTE_PROOF fitted_param_loads={_FITTED_PARAM_LOADS} "
                  f"scientific_metric_calls={_SCIENTIFIC_METRIC_CALLS}")
            return 2
    # ---- Gate 2: passing G3 preflight V1 on disk ----
    pf = PREFLIGHT_OUT / "V3_G3_COVARIANCE_CONSEQUENCE_PREFLIGHT_V1.json"
    if not pf.exists():
        print("STOP_NOT_AUTHORIZED: G3 preflight V1 artifact missing; --execute requires "
              "the accepted G3 preflight first.")
        return 2
    pf_data = json.loads(pf.read_text(encoding="utf-8"))
    if pf_data.get("classification") != "V3_G3_COVARIANCE_CONSEQUENCE_PREFLIGHT_PASS":
        print("STOP_NOT_AUTHORIZED: G3 preflight V1 artifact is present but its "
              "classification is not the accepted preflight classification; "
              "--execute refused.")
        return 2
    # ---- Gate 3: frozen chain exact ----
    chain = verify_frozen_chain()
    if not chain["ok"]:
        print("STOP_SHA_MISMATCH: frozen chain mismatch; --execute refused.")
        return 2
    # ---- Gate 4: exactly-once semantics ----
    zs = G3_OUT / "43W_V3_G3_COVARIANCE_CONSEQUENCE_EVIDENCE.json"
    if zs.exists():
        print("G3_ALREADY_EXECUTED: 43W evidence exists; refusing to overwrite. "
              "G3 execute is exactly-once.")
        return 3

    t0 = time.time()
    snap_before = {}
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_before[ident] = {"result": sha256(rd / "result.json"),
                              "npz": sha256(rd / "final_svi_params.npz")}

    # ---- load params + build Sigma_i = B_i + L_i for every evaluable identity ----
    sigmas = {}
    bs = {}
    ls = {}
    per_run_m5 = {}
    per_run_m3 = {}
    abort = False
    for ident in EVALUABLE:
        params = load_params(ident)
        S = build_sigma_dense(params)
        B = build_ar1_dense(params)
        L = build_lowrank_dense(params)
        sigmas[ident] = S
        bs[ident] = B
        ls[ident] = L
        m5 = g3_metric5_per_run(params)
        m3 = g3_metric3_spectrum(S)
        _SCIENTIFIC_METRIC_CALLS += 1   # real G3 metric computation for this identity
        if m5.get("deterministic_abort") or m3.get("deterministic_abort"):
            abort = True
            break
        per_run_m5[ident] = m5
        per_run_m3[ident] = m3
    if abort:
        payload = {"artifact_id": "43W_V3_G3_COVARIANCE_CONSEQUENCE_EVIDENCE",
                   "schema_version": "1.0",
                   "created_utc": utc_now(),
                   "project": "DHBCP-PV_V2_codebase_V0_1",
                   "phase": "phase3c4v_v3",
                   "classification": "G3_COVARIANCE_CONSEQUENCE_EXECUTION_INCOMPLETE",
                   "reason": "deterministic_abort in per-run metric construction "
                             "(denominator <= 0 or trace <= 0); evidence written; STOP."}
        atomic_write_json(zs, payload)
        print("G3_COVARIANCE_CONSEQUENCE_EXECUTION_INCOMPLETE: deterministic_abort; STOP.")
        return 0

    # ---- G3 Metric 1 + Metric 2 + Metric 3 pairwise + Metric 4 + Metric 5 pairwise ----
    sigma_rows = []
    corr_rows = []
    spec_rows = []
    block_rows = []
    comp_rows = []
    comp_pair_rows = []
    m1_by_arm = {"P1": [], "P4": []}
    m2_by_arm = {"P1": [], "P4": []}
    m3_by_arm = {"P1": [], "P4": []}
    m4_by_arm = {"P1": {b["name"]: [] for b in SEMANTIC_BLOCKS},
                 "P4": {b["name"]: [] for b in SEMANTIC_BLOCKS}}
    m5B_by_arm = {"P1": [], "P4": []}
    m5L_by_arm = {"P1": [], "P4": []}
    for arm, ids in (("P1", P1_IDS), ("P4", P4_IDS)):
        for (i, j) in within_arm_pairs(ids):
            m1 = g3_metric1_sigma_relative_frobenius(sigmas[i], sigmas[j])
            m2 = g3_metric2_correlation_consequence(sigmas[i], sigmas[j])
            m3 = g3_metric3_spectrum_distance(per_run_m3[i], per_run_m3[j])
            if m1.get("deterministic_abort") or m2.get("deterministic_abort") \
                    or m3.get("deterministic_abort"):
                abort = True
                break
            sigma_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                               "relative_frobenius": m1["relative_frobenius"],
                               "absolute_frobenius": m1["absolute_frobenius"]})
            m1_by_arm[arm].append(m1["relative_frobenius"])
            corr_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                              "correlation_rmse": m2["correlation_rmse"],
                              "max_abs_correlation_difference": m2["max_abs_correlation_difference"]})
            m2_by_arm[arm].append(m2["correlation_rmse"])
            spec_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                              "spectrum_l2_distance": m3["spectrum_l2_distance"]})
            m3_by_arm[arm].append(m3["spectrum_l2_distance"])
            for b in SEMANTIC_BLOCKS:
                idx_b = np.asarray(b["indices"], dtype=np.int64)
                m4 = g3_metric4_block_relative_frobenius(sigmas[i], sigmas[j], idx_b)
                if m4.get("deterministic_abort"):
                    abort = True
                    break
                block_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                                   "block": b["name"],
                                   "block_relative_frobenius": m4["block_relative_frobenius"]})
                m4_by_arm[arm][b["name"]].append(m4["block_relative_frobenius"])
            if abort:
                break
            m5p = g3_metric5_pairwise(bs[i], bs[j], ls[i], ls[j])
            if m5p.get("deterministic_abort"):
                abort = True
                break
            comp_pair_rows.append({"arm": arm, "identity_i": i, "identity_j": j,
                                   "relative_frobenius_B": m5p["relative_frobenius_B"],
                                   "relative_frobenius_L": m5p["relative_frobenius_L"]})
            m5B_by_arm[arm].append(m5p["relative_frobenius_B"])
            m5L_by_arm[arm].append(m5p["relative_frobenius_L"])
        if abort:
            break
    if abort:
        payload = {"artifact_id": "43W_V3_G3_COVARIANCE_CONSEQUENCE_EVIDENCE",
                   "schema_version": "1.0",
                   "created_utc": utc_now(),
                   "project": "DHBCP-PV_V2_codebase_V0_1",
                   "phase": "phase3c4v_v3",
                   "classification": "G3_COVARIANCE_CONSEQUENCE_EXECUTION_INCOMPLETE",
                   "reason": "deterministic_abort in pairwise metric construction; "
                             "evidence written; STOP."}
        atomic_write_json(zs, payload)
        print("G3_COVARIANCE_CONSEQUENCE_EXECUTION_INCOMPLETE: deterministic_abort; STOP.")
        return 0

    # ---- per-run component decomposition rows (Metric 5) ----
    for ident in EVALUABLE:
        m5 = per_run_m5[ident]
        comp_rows.append({"arm": arm_of(ident), "identity": ident,
                          "seed": seed_of(ident),
                          "trace": m5["trace"],
                          "low_rank_trace_share": m5["low_rank_trace_share"],
                          "ar1_trace_share": m5["ar1_trace_share"],
                          "trace_share_sum": m5["trace_share_sum"],
                          "low_rank_frobenius_ratio": m5["low_rank_frobenius_ratio"],
                          "sigma_equals_B_plus_L": m5["sigma_equals_B_plus_L"]})

    snap_after = {}
    unchanged = True
    for ident in EVALUABLE:
        rd = RUNS_DIR / ident
        snap_after[ident] = {"result": sha256(rd / "result.json"),
                             "npz": sha256(rd / "final_svi_params.npz")}
        if snap_after[ident] != snap_before[ident]:
            unchanged = False

    # ---- G3 output namespace (independent g3/; does not overwrite G2) ----
    def write_csv(name, fieldnames, rows):
        p = G3_OUT / name
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(rows)
        return p

    G3_OUT.mkdir(parents=True, exist_ok=True)
    files = {
        "G3_SIGMA_PAIRWISE.csv": write_csv("G3_SIGMA_PAIRWISE.csv",
            ["arm", "identity_i", "identity_j", "relative_frobenius", "absolute_frobenius"],
            sigma_rows),
        "G3_CORRELATION_CONSEQUENCE.csv": write_csv("G3_CORRELATION_CONSEQUENCE.csv",
            ["arm", "identity_i", "identity_j", "correlation_rmse",
             "max_abs_correlation_difference"], corr_rows),
        "G3_SPECTRUM_CONSEQUENCE.csv": write_csv("G3_SPECTRUM_CONSEQUENCE.csv",
            ["arm", "identity_i", "identity_j", "spectrum_l2_distance"], spec_rows),
        "G3_BLOCK_COVARIANCE_CONSEQUENCE.csv": write_csv("G3_BLOCK_COVARIANCE_CONSEQUENCE.csv",
            ["arm", "identity_i", "identity_j", "block", "block_relative_frobenius"], block_rows),
        "G3_COMPONENT_DECOMPOSITION.csv": write_csv("G3_COMPONENT_DECOMPOSITION.csv",
            ["arm", "identity", "seed", "trace", "low_rank_trace_share", "ar1_trace_share",
             "trace_share_sum", "low_rank_frobenius_ratio", "sigma_equals_B_plus_L"], comp_rows),
        "G3_COMPONENT_PAIRWISE.csv": write_csv("G3_COMPONENT_PAIRWISE.csv",
            ["arm", "identity_i", "identity_j", "relative_frobenius_B", "relative_frobenius_L"],
            comp_pair_rows),
    }
    out_shas = {name: sha256(p) for name, p in files.items()}

    arm_summary = {}
    for arm in ("P1", "P4"):
        arm_summary[arm] = {
            "n": len(P1_IDS) if arm == "P1" else len(P4_IDS),
            "pair_count": len(m1_by_arm[arm]),
            "sigma_relative_frobenius": desc_summary(m1_by_arm[arm]),
            "correlation_rmse": desc_summary(m2_by_arm[arm]),
            "spectrum_l2_distance": desc_summary(m3_by_arm[arm]),
            "block_relative_frobenius": {b["name"]: desc_summary(m4_by_arm[arm][b["name"]])
                                         for b in SEMANTIC_BLOCKS},
            "component_relative_frobenius_B": desc_summary(m5B_by_arm[arm]),
            "component_relative_frobenius_L": desc_summary(m5L_by_arm[arm]),
        }

    per_run_records = {"P1": [], "P4": []}
    for ident in EVALUABLE:
        m5 = per_run_m5[ident]
        m3 = per_run_m3[ident]
        per_run_records[arm_of(ident)].append({
            "identity": ident, "seed": seed_of(ident),
            "trace": m5["trace"], "low_rank_trace_share": m5["low_rank_trace_share"],
            "ar1_trace_share": m5["ar1_trace_share"],
            "trace_share_sum": m5["trace_share_sum"],
            "low_rank_frobenius_ratio": m5["low_rank_frobenius_ratio"],
            "sigma_equals_B_plus_L": m5["sigma_equals_B_plus_L"],
            "lambda_max": m3["lambda_max"], "lambda_min": m3["lambda_min"],
            "spectral_concentration": m3["spectral_concentration"],
            "spectrum_symmetry_ok": m3["symmetry_ok"],
            "spectrum_finite_ok": m3["finite_ok"],
            "spectrum_psd_min_eigval": m3["psd_min_eigval"]})

    zs_data = {
        "artifact_id": "43W_V3_G3_COVARIANCE_CONSEQUENCE_EVIDENCE",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v_v3",
        "classification": "G3_COVARIANCE_CONSEQUENCE_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION",
        "evaluable_total": 9,
        "P1_n": len(P1_IDS),
        "P4_n": len(P4_IDS),
        "P1_pair_count": len(m1_by_arm["P1"]),
        "P4_pair_count": len(m1_by_arm["P4"]),
        "no_automatic_threshold": True,
        "threshold_policy": "No automatic scientific threshold exists or is invented; "
                            "metrics are human-adjudication evidence ONLY (43U).",
        "machine_classification_policy": {
            "allowed_classifications": [
                "G3_COVARIANCE_CONSEQUENCE_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION",
                "G3_COVARIANCE_CONSEQUENCE_EXECUTION_INCOMPLETE"
            ],
            "final_scientific_interpretation_by": "ChatGPT human adjudication"
        },
        "arm_summary": arm_summary,
        "per_run_records": per_run_records,
        "output_files": out_shas,
        "run_artifacts_unchanged_after_execute": unchanged,
        "flags": {"G3_POSTERIOR_DRAWS_USED": False, "G3_NEW_INFERENCE_USED": False,
                  "G2_RERUN": False, "SVI_USED": False, "IMPORTANCE_SAMPLING_USED": False,
                  "NUTS_HMC_MCMC_USED": False, "G3_AUTHORIZED": True},
        "binds_sha256": {k: v[1] for k, v in G3_FROZEN_CHAIN.items()},
        "elapsed_seconds": round(time.time() - t0, 3),
        "note": "Deterministic G3 covariance-consequence evidence computed analytically "
                "from persisted fitted V3 guide params (Sigma_V3 = B_AR1 + U_local U_local.T). "
                "No posterior draws, no new inference, no SVI, no sampling, no MCMC. "
                "Read-only w.r.t. all 9 evaluable run directories.",
    }
    atomic_write_json(zs, zs_data)
    print("G3 classification:", zs_data["classification"])
    print("43W JSON:", zs)
    print("43W JSON SHA:", sha256(zs))
    print("run_artifacts_unchanged:", unchanged)
    return 0


# ---------------------------------------------------------------------------
# G3 synthetic engineering tests G3T1..G3T11 (fabricated arrays ONLY).
# ---------------------------------------------------------------------------
def _toy_params(seed=20260822, rho=0.2) -> dict:
    rng = np.random.RandomState(seed)
    return {
        "v3_loc": rng.normal(0, 1, 708),
        "v3_diag_log_scale": rng.normal(-0.5, 0.1, 708),
        "v3_F_count_plus_initial": rng.normal(0, 0.1, (120, 4)),
        "v3_F_dynamic_scale": rng.normal(0, 0.1, (16, 4)),
        "v3_F_seriousness": rng.normal(0, 0.1, (22, 4)),
        "v3_raw_temporal_rho": np.array([rho]),
    }


def _synthetic_spd(n: int, seed: int) -> np.ndarray:
    """Synthetic SPD covariance for reference tests (test fixture only)."""
    rng = np.random.RandomState(seed)
    M = rng.normal(0, 1, (n, n))
    return M @ M.T + n * np.eye(n)


def run_g3_synthetic_tests() -> dict:
    """Fabricated arrays ONLY. Never loads real fitted V3 values."""
    results = {}
    rec = lambda n, ok, d: results.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731

    # ---- G3T1: Sigma == B + L decomposition identity (machine precision) ----
    toy = _toy_params(seed=101)
    S = build_sigma_dense(toy)
    B = build_ar1_dense(toy)
    L = build_lowrank_dense(toy)
    maxdiff1 = float(np.max(np.abs(S - (B + L))))
    rec("G3T1_sigma_decomposition_identity",
        S.shape == (708, 708) and maxdiff1 < ABS_TOL,
        {"shape": list(S.shape), "max_abs_diff": maxdiff1,
         "tolerance": ABS_TOL,
         "note": "Sigma_V3 == B_AR1 + U_local U_local.T to machine precision"})

    # ---- G3T2: sigma relative Frobenius reference ----
    A = _synthetic_spd(40, seed=7)
    Cmat = _synthetic_spd(40, seed=11)
    ref_num = float(np.linalg.norm(A - Cmat, ord="fro"))
    ref_den = 0.5 * (float(np.linalg.norm(A, ord="fro")) + float(np.linalg.norm(Cmat, ord="fro")))
    ref_rel = float(ref_num / ref_den)
    m2 = g3_metric1_sigma_relative_frobenius(A, Cmat)
    rec("G3T2_sigma_relative_frobenius_reference",
        (not m2.get("deterministic_abort", False))
        and abs(m2["relative_frobenius"] - ref_rel) < ABS_TOL
        and abs(m2["absolute_frobenius"] - ref_num) < ABS_TOL,
        {"impl_relative": m2.get("relative_frobenius"), "ref_relative": ref_rel,
         "impl_absolute": m2.get("absolute_frobenius"), "ref_absolute": ref_num})

    # ---- G3T3: correlation consequence reference (diag(R)=1, RMSE) ----
    n3 = 30
    A3 = _synthetic_spd(n3, seed=13)
    C3 = _synthetic_spd(n3, seed=17)
    dA = np.diag(A3)
    dC = np.diag(C3)
    RA = A3 / np.sqrt(dA)[:, None] / np.sqrt(dA)[None, :]
    RC = C3 / np.sqrt(dC)[:, None] / np.sqrt(dC)[None, :]
    iu3 = np.triu_indices(n3, k=1)
    ref_rmse = float(np.sqrt(np.mean((RA[iu3] - RC[iu3]) ** 2)))
    ref_max = float(np.max(np.abs(RA[iu3] - RC[iu3])))
    m3t = g3_metric2_correlation_consequence(A3, C3)
    diag_ok = (np.max(np.abs(np.diag(RA) - 1.0)) < ABS_TOL
               and np.max(np.abs(np.diag(RC) - 1.0)) < ABS_TOL)
    rec("G3T3_correlation_consequence_reference",
        (not m3t.get("deterministic_abort", False))
        and diag_ok
        and abs(m3t["correlation_rmse"] - ref_rmse) < ABS_TOL
        and abs(m3t["max_abs_correlation_difference"] - ref_max) < ABS_TOL,
        {"diag_R_minus_1_max": float(max(np.max(np.abs(np.diag(RA) - 1.0)),
                                         np.max(np.abs(np.diag(RC) - 1.0)))),
         "impl_rmse": m3t.get("correlation_rmse"), "ref_rmse": ref_rmse,
         "impl_max_abs": m3t.get("max_abs_correlation_difference"), "ref_max_abs": ref_max,
         "no_epsilon": True})

    # ---- G3T4: spectrum metric reference ----
    n4 = 30
    A4 = _synthetic_spd(n4, seed=19)
    C4 = _synthetic_spd(n4, seed=23)
    specA = g3_metric3_spectrum(A4)
    specC = g3_metric3_spectrum(C4)
    lamA = np.linalg.eigvalsh(A4)[::-1]
    pA_ref = lamA / np.sum(lamA)
    lamC = np.linalg.eigvalsh(C4)[::-1]
    pC_ref = lamC / np.sum(lamC)
    ref_l2 = float(np.linalg.norm(pA_ref - pC_ref, ord=2))
    ref_conc = float(np.sum(pA_ref ** 2))
    d4 = g3_metric3_spectrum_distance(specA, specC)
    ok4 = ((not specA.get("deterministic_abort", False))
           and (not specC.get("deterministic_abort", False))
           and abs(np.sum(specA["p"]) - 1.0) < ABS_TOL
           and abs(np.sum(specC["p"]) - 1.0) < ABS_TOL
           and abs(specA["spectral_concentration"] - ref_conc) < ABS_TOL
           and abs(d4["spectrum_l2_distance"] - ref_l2) < ABS_TOL)
    rec("G3T4_spectrum_metric_reference", ok4,
        {"sum_p_A": float(np.sum(specA["p"])), "sum_p_C": float(np.sum(specC["p"])),
         "impl_l2": d4.get("spectrum_l2_distance"), "ref_l2": ref_l2,
         "impl_concentration": specA.get("spectral_concentration"), "ref_concentration": ref_conc,
         "symmetry_ok": specA.get("symmetry_ok"), "finite_ok": specA.get("finite_ok"),
         "psd_min_eigval": specA.get("psd_min_eigval")})

    # ---- G3T5: block relative Frobenius reference (four frozen blocks) ----
    n5 = 60
    A5 = _synthetic_spd(n5, seed=29)
    C5 = _synthetic_spd(n5, seed=31)
    idx_blocks = {
        "count_plus_initial": np.arange(0, 20, dtype=np.int64),
        "dynamic_scale": np.arange(20, 26, dtype=np.int64),
        "seriousness": np.arange(26, 34, dtype=np.int64),
        "temporal_path": np.arange(34, 60, dtype=np.int64),
    }
    ok5 = True
    detail5 = {}
    for bname, idx_b in idx_blocks.items():
        m4v = g3_metric4_block_relative_frobenius(A5, C5, idx_b)
        subA = A5[np.ix_(idx_b, idx_b)]
        subC = C5[np.ix_(idx_b, idx_b)]
        ref = float(np.linalg.norm(subA - subC, ord="fro")
                    / (0.5 * (np.linalg.norm(subA, ord="fro")
                              + np.linalg.norm(subC, ord="fro"))))
        good = (not m4v.get("deterministic_abort", False)) \
            and abs(m4v["block_relative_frobenius"] - ref) < ABS_TOL
        ok5 = ok5 and good
        detail5[bname] = {"impl": m4v.get("block_relative_frobenius"), "ref": ref, "ok": good}
    rec("G3T5_block_relative_frobenius_reference", ok5, detail5)

    # ---- G3T6: component trace share (trace(B)+trace(L)=trace(Sigma)) ----
    toy6 = _toy_params(seed=37)
    S6 = build_sigma_dense(toy6)
    B6 = build_ar1_dense(toy6)
    L6 = build_lowrank_dense(toy6)
    trS6 = float(np.trace(S6))
    trB6 = float(np.trace(B6))
    trL6 = float(np.trace(L6))
    m5r = g3_metric5_per_run(toy6)
    ok6 = (abs((trB6 + trL6) - trS6) < ABS_TOL
           and (not m5r.get("deterministic_abort", False))
           and abs((m5r["ar1_trace_share"] + m5r["low_rank_trace_share"]) - 1.0) < ABS_TOL
           and m5r["sigma_equals_B_plus_L"])
    rec("G3T6_component_trace_share", ok6,
        {"trace_B_plus_L_minus_trace_S": float((trB6 + trL6) - trS6),
         "ar1_trace_share": m5r.get("ar1_trace_share"),
         "low_rank_trace_share": m5r.get("low_rank_trace_share"),
         "share_sum": m5r.get("trace_share_sum"),
         "sigma_equals_B_plus_L": m5r.get("sigma_equals_B_plus_L")})

    # ---- G3T7: pair generation (P1=6, P4=10, cross=0) ----
    p1_pairs = within_arm_pairs(P1_IDS)
    p4_pairs = within_arm_pairs(P4_IDS)
    cross = [p for p in p1_pairs + p4_pairs if arm_of(p[0]) != arm_of(p[1])]
    rec("G3T7_pair_generation",
        len(p1_pairs) == 6 and len(p4_pairs) == 10 and not cross,
        {"P1": len(p1_pairs), "P4": len(p4_pairs), "cross_arm": len(cross)})

    # ---- G3T8: real --execute requires the NEW DISTINCT G3 authorization ----
    g3_entries_before = sorted(p.name for p in G3_OUT.iterdir()) if G3_OUT.exists() else []
    g3_auth_before = G3_AUTH_FILE.exists()
    proc8 = subprocess.run([sys.executable, str(Path(__file__).resolve()),
                            "--mode", "execute"],
                           capture_output=True, text=True, cwd=str(ROOT), timeout=180)
    out8 = (proc8.stdout or "") + (proc8.stderr or "")
    dispatch8 = "G3_EXECUTE_DISPATCH_REACHED_CMD_EXECUTE" in out8
    gate1_8 = "STOP_NOT_AUTHORIZED" in out8 and "G3 authorization" in out8
    zero8 = "ZERO_COMPUTE_PROOF fitted_param_loads=0 scientific_metric_calls=0" in out8
    g3_entries_after = sorted(p.name for p in G3_OUT.iterdir()) if G3_OUT.exists() else []
    g3_auth_after = G3_AUTH_FILE.exists()
    zs8_absent = not (G3_OUT / "43W_V3_G3_COVARIANCE_CONSEQUENCE_EVIDENCE.json").exists()
    rec("G3T8_real_execute_requires_new_G3_authorization",
        (proc8.returncode == 2 and dispatch8 and gate1_8 and zero8
         and g3_entries_before == g3_entries_after == []
         and not g3_auth_before and not g3_auth_after and zs8_absent),
        {"returncode": proc8.returncode, "dispatch_marker": dispatch8,
         "gate1_refusal": gate1_8, "zero_compute_proof": zero8,
         "g3_entries_before": g3_entries_before, "g3_entries_after": g3_entries_after,
         "g3_auth_before": g3_auth_before, "g3_auth_after": g3_auth_after,
         "43W_absent": zs8_absent,
         "real_fitted_param_loads": 0, "real_g3_metric_calculations": 0})

    # ---- G3T9: Attempt-1/2/3 G2 authorizations are NOT sufficient for scripts92 ----
    proc9 = subprocess.run([sys.executable, str(Path(__file__).resolve()),
                            "--mode", "execute"],
                           capture_output=True, text=True, cwd=str(ROOT), timeout=180)
    out9 = (proc9.stdout or "") + (proc9.stderr or "")
    refused9 = proc9.returncode == 2
    old_not_honored9 = ("HISTORICAL_CONSUMED" in out9
                        and "NOT sufficient for scripts92" in out9)
    attempt1_present9 = OLD_AUTH_FILE.exists()
    attempt2_present9 = REPAIRED_AUTH_FILE.exists()
    attempt3_present9 = OUTPUT_PATH_REPAIRED_AUTH_FILE.exists()
    g3_auth_absent9 = not G3_AUTH_FILE.exists()
    g3_entries9 = sorted(p.name for p in G3_OUT.iterdir()) if G3_OUT.exists() else []
    rec("G3T9_old_G2_authorizations_not_sufficient",
        refused9 and old_not_honored9 and attempt1_present9 and attempt2_present9
        and attempt3_present9 and g3_auth_absent9 and g3_entries9 == [],
        {"returncode": proc9.returncode,
         "old_g2_auths_not_honored": old_not_honored9,
         "attempt1_g2_auth_present": attempt1_present9,
         "attempt2_g2_auth_present": attempt2_present9,
         "attempt3_g2_auth_present": attempt3_present9,
         "g3_auth_absent": g3_auth_absent9,
         "g3_entries_after": g3_entries9,
         "note": "scripts92 Gate 1 ignores ALL of the Attempt-1 scripts89, Attempt-2 "
                 "scripts90, and Attempt-3 scripts91 G2 authorizations (HISTORICAL_CONSUMED); "
                 "it requires the DISTINCT "
                 "V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZATION.json."})

    # ---- G3T10: default invocation is safe ----
    proc10 = subprocess.run([sys.executable, str(Path(__file__).resolve())],
                            capture_output=True, text=True, cwd=str(ROOT), timeout=180)
    out10 = (proc10.stdout or "") + (proc10.stderr or "")
    def_safe10 = "NOTHING scientific" in out10
    g3_entries10 = sorted(p.name for p in G3_OUT.iterdir()) if G3_OUT.exists() else []
    rec("G3T10_default_invocation_safe",
        proc10.returncode == 0 and def_safe10 and g3_entries10 == []
        and not (G3_OUT / "43W_V3_G3_COVARIANCE_CONSEQUENCE_EVIDENCE.json").exists(),
        {"returncode": proc10.returncode, "safe_message": def_safe10,
         "g3_entries_after": g3_entries10, "43W_absent": True})

    # ---- G3T11: preflight after G3 authorization is forbidden (isolated) ----
    _td11 = tempfile.mkdtemp(prefix="s92_t11_")
    _tmp_auth11 = Path(_td11) / "V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZATION.json"
    _tmp_auth11.write_text(json.dumps({"V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZED": True}),
                           encoding="utf-8")
    _src92 = Path(__file__).read_text(encoding="utf-8")
    _DEF_LINE = 'G3_AUTH_FILE = AUTH_DIR / "V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZATION.json"'
    _patched_lines = []
    for _line in _src92.split("\n"):
        if _line.strip() == _DEF_LINE:
            _patched_lines.append(f'G3_AUTH_FILE = Path({str(_tmp_auth11)!r})')
        else:
            _patched_lines.append(_line)
    _patched = "\n".join(_patched_lines)
    _tmp_mod11 = Path(_td11) / "tmp_s92.py"
    _tmp_mod11.write_text(_patched, encoding="utf-8")
    proc11 = subprocess.run([sys.executable, str(_tmp_mod11), "--mode", "preflight"],
                            capture_output=True, text=True, cwd=str(ROOT), timeout=180)
    out11 = (proc11.stdout or "") + (proc11.stderr or "")
    refused11 = proc11.returncode == 4
    msg11 = "STOP_PREFLIGHT_AFTER_G3_AUTHORIZATION" in out11
    no_fitted11 = ("fitted_param_loads" not in out11) or ("fitted_param_loads=0" in out11)
    try:
        _tmp_mod11.unlink()
        _tmp_auth11.unlink()
        os.rmdir(_td11)
    except OSError:
        pass
    rec("G3T11_preflight_after_G3_authorization_forbidden",
        refused11 and msg11 and no_fitted11,
        {"returncode": proc11.returncode, "refusal_message": msg11,
         "isolated_temp": True, "no_real_auth_created": True})

    return results


# ---------------------------------------------------------------------------
# G3 ZERO-REAL-COMPUTE metadata preflight (43U section K / L).
# Reads metadata, hashes, manifests, file existence, synthetic arrays ONLY.
# ---------------------------------------------------------------------------
def run_g3_zero_compute_preflight() -> dict:
    checks = {}
    rec = lambda n, ok, d: checks.__setitem__(n, {"ok": bool(ok), "detail": d})  # noqa: E731

    # ZG1: g3 output namespace clean (no scientific evidence yet)
    rec("ZG1_g3_namespace_clean",
        (not G3_OUT.exists()) or (not any(G3_OUT.iterdir())),
        {"g3_dir_exists": G3_OUT.exists(),
         "existing": sorted(p.name for p in G3_OUT.iterdir()) if G3_OUT.exists() else []})

    # ZG2: DISTINCT G3 authorization ABSENT (this package must not create it)
    rec("ZG2_g3_authorization_absent", not G3_AUTH_FILE.exists(),
        {"g3_auth_exists": G3_AUTH_FILE.exists(),
         "note": "V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZATION.json must remain "
                 "absent; real G3 remains forbidden until a future human authorization."})

    # ZG3: no real G3 evidence (43W absent, G3 CSVs absent)
    zs_absent = not (G3_OUT / "43W_V3_G3_COVARIANCE_CONSEQUENCE_EVIDENCE.json").exists()
    csv_names = ["G3_SIGMA_PAIRWISE.csv", "G3_CORRELATION_CONSEQUENCE.csv",
                 "G3_SPECTRUM_CONSEQUENCE.csv", "G3_BLOCK_COVARIANCE_CONSEQUENCE.csv",
                 "G3_COMPONENT_DECOMPOSITION.csv", "G3_COMPONENT_PAIRWISE.csv"]
    csv_absent = all(not (G3_OUT / n).exists() for n in csv_names)
    rec("ZG3_no_real_g3_evidence", zs_absent and csv_absent,
        {"43W_absent": zs_absent, "g3_csvs_absent": csv_absent})

    # ZG4: 43S evidence present with the expected classification (metadata read)
    zs_path = G2_OUT / "43S_V3_G2_DETERMINISTIC_STABILITY_EVIDENCE.json"
    zs_ok = False
    if zs_path.exists():
        try:
            zs_d = json.loads(zs_path.read_text(encoding="utf-8"))
            zs_ok = (zs_d.get("classification")
                     == "G2_EVIDENCE_COMPLETE_AWAITING_HUMAN_ADJUDICATION"
                     and zs_d.get("run_artifacts_unchanged_after_execute") is True)
        except Exception:  # noqa: BLE001
            zs_ok = False
    rec("ZG4_43S_evidence_classification_ok", zs_ok,
        {"43S_exists": zs_path.exists(), "classification_ok": zs_ok})

    # ZG5: G2 evidence CSV files exist (all 9)
    g2_csvs = ["G2_LOCATION_PAIRWISE.csv", "G2_MARGINAL_SCALE_CV.csv",
               "G2_FACTOR_PRINCIPAL_ANGLES.csv", "G2_PROJECTION_DISTANCE.csv",
               "G2_PROCRUSTES_COMPARISON.csv", "G2_BLOCK_COVARIANCE_ALLOCATION.csv",
               "G2_BLOCK_DELTA_ALLOCATION.csv", "G2_RHO_VARIATION.csv",
               "G2_DELTA_RHO_PAIRWISE.csv"]
    all_exist = all((G2_OUT / n).exists() for n in g2_csvs)
    rec("ZG5_g2_evidence_files_exist", all_exist, {"n": len(g2_csvs)})

    # ZG6: G2 evidence CSV hashes live-match 43S-bound hashes (L. requirement)
    hash_ok = True
    hash_problems = []
    for n in g2_csvs:
        live = sha256(G2_OUT / n)
        expected = G3_FROZEN_CHAIN.get(n, (None, None))[1]
        if live != expected:
            hash_ok = False
            hash_problems.append(f"{n}: live {live} != expected {expected}")
    rec("ZG6_g2_evidence_hashes_live_match", hash_ok and all_exist,
        {"problems": hash_problems or "all 9 G2 CSV hashes match"})

    # ZG7: evaluable run dirs have RUN_STARTED + npz + manifest (metadata only)
    dirs_ok = all((RUNS_DIR / i).is_dir() for i in EVALUABLE)
    artifacts_ok = all((RUNS_DIR / i / "RUN_STARTED").exists()
                       and (RUNS_DIR / i / "final_svi_params.npz").exists()
                       and (RUNS_DIR / i / "final_svi_params_manifest.json").exists()
                       for i in EVALUABLE)
    rec("ZG7_evaluable_run_metadata_present", dirs_ok and artifacts_ok,
        {"n": len(EVALUABLE), "dirs_ok": dirs_ok, "artifacts_ok": artifacts_ok})

    # ZG8: pair counts exact (static constants)
    rec("ZG8_pair_counts_exact",
        len(within_arm_pairs(P1_IDS)) == 6 and len(within_arm_pairs(P4_IDS)) == 10,
        {"P1": len(within_arm_pairs(P1_IDS)), "P4": len(within_arm_pairs(P4_IDS))})

    # ZG9: frozen chain exact (all bound SHAs incl. 43T/43U/Attempt-3/43S/G2 CSVs)
    chain = verify_frozen_chain()
    rec("ZG9_frozen_chain_exact", chain["ok"],
        {"mismatches": [k for k, v in chain["results"].items() if not v["ok"]]})

    # ZG10: no forbidden executor scientific labels in cmd_execute source
    # (the preflight artifact classification literal
    # V3_G3_COVARIANCE_CONSEQUENCE_PREFLIGHT_PASS is an allowed engineering
    # artifact name, NOT a G3 scientific metric label; it is stripped before
    # scanning so it cannot create a false positive. The scan is bounded to the
    # cmd_execute function body only.)
    src = Path(__file__).read_text(encoding="utf-8")
    exec_src = src.split("def cmd_execute", 1)[1].split("def run_g3_synthetic_tests", 1)[0]
    exec_src_scan = exec_src.replace("V3_G3_COVARIANCE_CONSEQUENCE_PREFLIGHT_PASS", "")
    lbl_hits = [p for p in ("st" + "able", "unst" + "able", "accept" + "able",
                            "unaccept" + "able", "PAS" + "S", "FA" + "IL",
                            "neglig" + "ible", "mat" + "erial") if p in exec_src_scan]
    rec("ZG10_no_forbidden_executor_labels_in_execute",
        not lbl_hits, {"hits": lbl_hits,
                       "note": "cmd_execute must never emit stable/unstable/acceptable/"
                               "unacceptable/PASS/FAIL/negligible/material as scientific "
                               "labels; the preflight artifact classification string is "
                               "an allowed engineering name and is excluded from the scan"})

    # ZG11: no forbidden inference patterns in this source
    pat_svi = "SVI" + "("
    pat_trace_elbo = "Trace" + "_ELBO"
    pat_optim = "optimizer" + "("
    pat_sample = "numpyro." + "sample("
    pat_importance = "importance" + "("
    pat_nuts = "NUT" + "S("
    pat_hmc = "HM" + "C("
    pat_mcmc = "MCM" + "C("
    pat_pca = "PCA" + "("
    hits11 = [p for p in (pat_svi, pat_trace_elbo, pat_optim, pat_sample, pat_importance,
                          pat_nuts, pat_hmc, pat_mcmc, pat_pca) if p in src]
    rec("ZG11_no_forbidden_inference", not hits11, {"hits": hits11})

    # ZG12: no real fitted-value arithmetic in the zero-compute preflight path
    # (slice-based scan of run_g3_zero_compute_preflight only; synthetic tests
    # are allowed to call metric helpers on fabricated arrays)
    pf_src = src.split("def run_g3_zero_compute_preflight", 1)[1].split("def cmd_preflight", 1)[0]
    forbidden_calls = ["load_params(", "build_sigma_dense(", "build_ar1_dense(",
                       "build_lowrank_dense(", "g3_metric1_sigma_relative_frobenius(",
                       "g3_metric2_correlation_consequence(", "g3_metric3_spectrum(",
                       "g3_metric4_block_relative_frobenius(", "g3_metric5_per_run(",
                       "g3_metric5_pairwise("]
    z12_hits = [c for c in forbidden_calls if c in pf_src]
    rec("ZG12_no_fitted_arithmetic_in_preflight", not z12_hits,
        {"hits": z12_hits, "note": "preflight reads metadata/hashes only; no G3 arithmetic "
                                   "on real fitted values"})

    return checks


def cmd_preflight() -> int:
    # Preflight-after-G3-authorization safety: once the DISTINCT G3
    # authorization exists, --preflight must REFUSE so the preflight's negative
    # execute tests cannot accidentally enter the real scientific execution
    # path. Preflight must run BEFORE the G3 authorization is created.
    if G3_AUTH_FILE.exists():
        print("STOP_PREFLIGHT_AFTER_G3_AUTHORIZATION: a G3 covariance-consequence "
              "authorization already exists; --preflight is forbidden after "
              "authorization to protect the real scientific path. Preflight must "
              "run BEFORE the new authorization is created.")
        return 4
    t0 = time.time()
    syn = run_g3_synthetic_tests()
    zc = run_g3_zero_compute_preflight()
    chain = verify_frozen_chain()

    # 43U section L: any G2 evidence hash mismatch -> package incomplete -> STOP.
    g2_hash_ok = zc.get("ZG6_g2_evidence_hashes_live_match", {}).get("ok", False)

    syn_ok = all(v["ok"] for v in syn.values())
    zc_ok = all(v["ok"] for v in zc.values())
    chain_ok = chain["ok"]
    ok = syn_ok and zc_ok and chain_ok and g2_hash_ok
    if not g2_hash_ok:
        classification = "V3_G3_ENGINEERING_PACKAGE_INCOMPLETE"
    else:
        classification = ("V3_G3_COVARIANCE_CONSEQUENCE_PREFLIGHT_PASS" if ok
                          else "V3_G3_COVARIANCE_CONSEQUENCE_PREFLIGHT_FAIL")

    payload = {
        "artifact_id": "V3_G3_COVARIANCE_CONSEQUENCE_PREFLIGHT_V1",
        "schema_version": "1.0",
        "created_utc": utc_now(),
        "project": "DHBCP-PV_V2_codebase_V0_1",
        "phase": "phase3c4v_v3",
        "executor": str(Path(__file__).resolve().name),
        "executor_sha256": sha256(Path(__file__).resolve()),
        "mode": ("G3 COVARIANCE CONSEQUENCE ZERO-REAL-COMPUTE PREFLIGHT V1 "
                 "(scripts92) - synthetic engineering tests G3T1..G3T11 + "
                 "ZERO-SCIENTIFIC-COMPUTATION metadata checks; NO G3 metric "
                 "computed from real fitted parameters"),
        "classification": classification,
        "synthetic_tests": {k: v["ok"] for k, v in syn.items()},
        "synthetic_test_details": syn,
        "zero_compute_checks": {k: v["ok"] for k, v in zc.items()},
        "zero_compute_details": zc,
        "sha_chain": chain["results"],
        "real_fitted_parameter_loads": _FITTED_PARAM_LOADS,
        "real_g3_scientific_metric_computations": _SCIENTIFIC_METRIC_CALLS,
        "g3_authorization_exists": G3_AUTH_FILE.exists(),
        "real_g3_executed": False,
        "43w_created": (G3_OUT / "43W_V3_G3_COVARIANCE_CONSEQUENCE_EVIDENCE.json").exists(),
        "g3_csv_created": any(G3_OUT.iterdir()) if G3_OUT.exists() else False,
        "flags": {
            "REAL_G3_EXECUTION": False,
            "REAL_G3_FORBIDDEN_DURING_PACKAGE": True,
            "G3_AUTHORIZED": False,
            "G3_POSTERIOR_DRAWS_USED": False,
            "G3_NEW_INFERENCE_USED": False,
            "G2_RERUN": False,
            "SVI_USED": False,
            "IMPORTANCE_SAMPLING_USED": False,
            "NUTS_HMC_MCMC_USED": False,
        },
        "final_state": classification,
        "elapsed_seconds": round(time.time() - t0, 3),
    }
    out_path = PREFLIGHT_OUT / "V3_G3_COVARIANCE_CONSEQUENCE_PREFLIGHT_V1.json"
    atomic_write_json(out_path, payload)
    md = ["# V3 G3 Covariance Consequence Preflight V1 (scripts92)", "",
          f"Generated: {utc_now()}", "",
          f"**Classification: {classification}**", "",
          "## Synthetic engineering tests (fabricated arrays only)", "",
          "| Test | Result |", "|---|---|"]
    for k, v in syn.items():
        md.append(f"| {k} | {'PASS' if v['ok'] else 'FAIL'} |")
    md += ["", "## Zero-real-compute metadata checks", "", "| Check | Result |", "|---|---|"]
    for k, v in zc.items():
        md.append(f"| {k} | {'PASS' if v['ok'] else 'FAIL'} |")
    md += ["", "## Frozen SHA chain", ""]
    for k, v in chain["results"].items():
        md.append(f"- {k}: {'OK' if v['ok'] else 'MISMATCH'} `{v['live']}`")
    md += ["", f"## Final state: **{classification}**", "",
           f"REAL_FITTED_PARAMETER_LOADS={_FITTED_PARAM_LOADS}  "
           f"REAL_G3_SCIENTIFIC_METRIC_COMPUTATIONS={_SCIENTIFIC_METRIC_CALLS}",
           "",
           f"G3_AUTHORIZATION_EXISTS={G3_AUTH_FILE.exists()}  "
           f"REAL_G3_EXECUTED=False  43W_CREATED=False  G3_CSV_CREATED=False", "",
           "Real G3 covariance-consequence EXECUTION REMAINS FORBIDDEN until a DISTINCT "
           "G3 authorization (V3_G3_COVARIANCE_CONSEQUENCE_EXECUTION_AUTHORIZATION.json) "
           "is created after this preflight, following ChatGPT human review of this "
           "package (43V). Preflight is forbidden once that authorization exists."]
    (out_path.with_suffix(".md")).write_text("\n".join(md) + "\n", encoding="utf-8")

    print("classification:", classification)
    n_syn = sum(1 for v in syn.values() if v["ok"])
    print(f"G3 synthetic tests passed {n_syn}/{len(syn)}")
    failed = [k for k, v in syn.items() if not v["ok"]]
    if failed:
        print("failed G3 synthetic tests:", failed)
    print("OVERALL:", "PASS" if ok else "FAIL")
    return 0 if ok else 2


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="V3 G3 covariance consequence executor (frozen 43U protocol)")
    ap.add_argument("--mode", choices=["preflight", "execute"],
                    help="preflight: synthetic+metadata validation ONLY; execute: real G3 (FORBIDDEN during this package)")
    ap.add_argument("--preflight", action="store_true", help="alias for --mode preflight")
    ap.add_argument("--execute", action="store_true", help="alias for --mode execute (refused during this package)")
    args = ap.parse_args(argv)

    mode = args.mode
    if mode is None:
        if args.preflight:
            mode = "preflight"
        elif args.execute:
            mode = "execute"
        else:
            print("V3 G3 covariance consequence deterministic executor (frozen 43U protocol).")
            print("Default invocation runs NOTHING scientific.")
            print("Use --mode preflight (or --preflight) for synthetic + metadata validation.")
            print("Use --mode execute (or --execute) ONLY after explicit human authorization;")
            print("REAL G3 EXECUTION IS FORBIDDEN DURING THIS PACKAGE.")
            return 0

    if mode == "preflight":
        return cmd_preflight()

    if mode == "execute":
        return cmd_execute()

    return 2  # unreachable


if __name__ == "__main__":
    sys.exit(main())
